# PlayTube

Pemutar musik/video (audio-first) berbasis **NewPipeExtractor**, UI baru dengan Jetpack Compose (Material 3).
Dibuat sebagai base: bisa dibuild tanpa PC, lewat GitHub Actions.

## Fitur
- **Tampilan seragam gaya Google** (Material 3) untuk musik dan video: biru Google, putih bersih (terang) atau abu gelap (gelap, ikut sistem), header, chip, tombol pil, dan loading yang sama di semua layar
- **Loading bergelombang** gaya Material Expressive (bentuk yang berputar dan berubah bentuk)
- **Beranda Musik**: chip suasana, Pilihan cepat (Putar semua), Pintasan cepat, Album untuk kamu, Rilis terbaru, Artis untuk kamu
- **Beranda Video**: chip Beranda / Langganan / Musik / Live, feed thumbnail besar
- **Halaman tonton** video: pemutar di atas dengan kontrol (minimize, setelan, layar penuh, geser waktu, ketuk 2x = maju/mundur 10 dtk), judul, channel, Langganan, suka, bagikan, komentar, video terkait
- **Kualitas HD sampai 4K dan 60 fps** (video adaptif digabung dengan audio terbaik; pilih kualitas dan kecepatan di dalam pemutar; batas default 1080p di Setelan)
- **Lagu**: tampilan Sedang Diputar dengan sampul HD, antrean, dan **lirik** (sinkron bila tersedia, via LRCLIB)
- **Halaman artis** (cari artis di Cari > Artis): foto besar, Langganan, Radio, Putar, Lagu teratas, Album, Single & EP, Video, Playlist, Penggemar mungkin juga suka, Tentang; panah di tiap bagian membuka daftar lengkap (semua album, dst.)
- **Halaman channel video**: banner, avatar, jumlah pelanggan, tab Video/Playlist, Langganan
- Video yang ditolak YouTube untuk stream langsung (mis. "dibuat untuk anak-anak") otomatis diputar lewat pemutar tersemat YouTube
- Halaman album/playlist dengan sampul HD
- Putar di latar belakang (notifikasi, layar kunci, Bluetooth) lewat Media3; video bisa dijadikan audio saja lewat tombol "Audio"
- Pustaka: Favorit, Riwayat, Video ditonton, Langganan
- Setelan: tema, kualitas audio, batas kualitas video, utamakan 60 fps

## Build lewat GitHub Actions (tanpa PC)
1. Buat repo baru di GitHub (disarankan **Private**).
2. Upload `project.zip` ke root repo (Add file > Upload files).
3. Add file > Create new file, nama `.github/workflows/build.yml`, tempel isi `build.yml`, commit.
4. Tab **Actions** > Build APK > Run workflow (atau otomatis jalan saat commit).
5. Selesai (± 5–10 menit) → buka **Releases** di halaman repo → unduh APK-nya (`app-release.apk`, atau `PlayTube-N.apk` bila memakai build.yml terbaru).

Jika build gagal, buka run-nya: bagian **Summary** menampilkan ringkasan error. Salin dan kirim ke Claude.

## Struktur
- `app/src/main/java/app/mixbase/data` — Engine (NewPipeExtractor), Downloader (OkHttp), penyimpanan
- `app/src/main/java/app/mixbase/player` — PlaybackService (ExoPlayer/Media3) dan PlayerConnection
- `app/src/main/java/app/mixbase/ui` — layar Compose (Cari, Pustaka, Setelan, Pemutar)

## Catatan
- Kunci penanda tangan (`keystore/mixbase.jks`) adalah kunci pribadi untuk build sendiri, bukan untuk Play Store.
  Karena kuncinya tetap, APK baru bisa menimpa versi lama tanpa uninstall.
- Lisensi: NewPipeExtractor berlisensi GPLv3, jadi aplikasi ini juga harus GPLv3 bila dibagikan
  (sertakan teks lisensi dan source). Jangan memakai nama/logo NewPipe.
- Pengambilan stream bergantung pada perubahan di sisi situs sumber. Jika pemutaran gagal (mis. 403),
  perbarui versi `NewPipeExtractor` di `app/build.gradle.kts`.

## Catatan teknis
- Memakai NewPipeExtractor **v0.26.5** (sama seperti URMIX). v0.27.x membuang klien ANDROID sehingga video "dibuat untuk anak-anak" ditolak YouTube.
- User-Agent stream disesuaikan per alamat (klien ANDROID / iOS / visionOS) agar tidak dibatasi.

## Catatan halaman artis
- YouTube tidak memisahkan "Single" dan "EP" dari "Album" di halaman channel, jadi rilis dibagi dengan perkiraan jumlah lagu: sampai 6 lagu = Single & EP, lebih dari itu = Album.
- "Lagu teratas" dan "Penggemar mungkin juga suka" berasal dari pencarian YouTube Music berdasarkan nama artis (YouTube tidak memberi daftar lagu populer/artis serupa lewat NewPipeExtractor), jadi bisa kurang tepat untuk nama artis yang umum.
