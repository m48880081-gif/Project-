# MixBase

Pemutar musik/video (audio-first) berbasis **NewPipeExtractor**, UI baru dengan Jetpack Compose (Material 3).
Dibuat sebagai base: bisa dibuild tanpa PC, lewat GitHub Actions.

## Fitur
- Cari lagu/video (filter Musik / Video) dengan saran pencarian dan muat halaman berikutnya otomatis
- Putar di latar belakang (notifikasi, layar kunci, Bluetooth) lewat Media3
- Antrean: putar berikutnya, tambah ke antrean, acak, ulangi, hapus dari antrean
- Pustaka: favorit dan riwayat
- Setelan: tema (sistem/terang/gelap), warna dinamis, kualitas audio

## Build lewat GitHub Actions (tanpa PC)
1. Buat repo baru di GitHub (disarankan **Private**).
2. Upload `project.zip` ke root repo (Add file > Upload files).
3. Add file > Create new file, nama `.github/workflows/build.yml`, tempel isi `build.yml`, commit.
4. Tab **Actions** > Build APK > Run workflow (atau otomatis jalan saat commit).
5. Selesai (± 5–10 menit) → buka **Releases** di halaman repo → unduh `app-release.apk`.

Jika build gagal, buka run-nya: bagian **Summary** menampilkan ringkasan error. Salin dan kirim ke Claude.

## Struktur
- `app/src/main/java/app/mixbase/data` — Engine (NewPipeExtractor), Downloader (OkHttp), penyimpanan
- `app/src/main/java/app/mixbase/player` — PlaybackService (ExoPlayer/Media3) dan PlayerConnection
- `app/src/main/java/app/mixbase/ui` — layar Compose (Cari, Pustaka, Setelan, Pemutar)

## Catatan
- Kunci penanda tangan (`keystore/mixbase.jks`) adalah kunci pribadi untuk build sendiri, bukan untuk Play Store.
  Karena kuncinya tetap, APK baru bisa menimpa versi lama tanpa uninstall.
- Lisensi: NewPipeExtractor berlisensi GPLv3, jadi aplikasi ini juga harus GPLv3 bila dibagikan
  (sertakan teks lisensi dan source). Jangan memakai nama/logo NewPipe.
- Pengambilan stream bergantung pada perubahan di sisi situs sumber. Jika pemutaran gagal (mis. 403),
  perbarui versi `NewPipeExtractor` di `app/build.gradle.kts`.
