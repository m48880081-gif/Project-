# MixBase

Pemutar musik/video (audio-first) berbasis **NewPipeExtractor**, UI baru dengan Jetpack Compose (Material 3).
Dibuat sebagai base: bisa dibuild tanpa PC, lewat GitHub Actions.

## Fitur
- **Beranda Musik** gaya YouTube Music: chip suasana, Pilihan cepat (Putar semua), Pintasan cepat, Album untuk kamu, Rilis terbaru, Artis untuk kamu (tema putih)
- **Beranda Video** gaya YouTube: tab Beranda / Langganan / Musik / Live, feed thumbnail besar
- **Halaman tonton** video: pemutar di atas dengan kontrol (minimize, setelan, layar penuh, geser waktu, ketuk 2x = maju/mundur 10 dtk), judul, channel, Langganan, suka, bagikan, komentar, video terkait
- **Kualitas HD sampai 4K dan 60 fps** (video adaptif digabung dengan audio terbaik; pilih kualitas dan kecepatan di dalam pemutar; batas default 1080p di Setelan)
- **Lagu**: tampilan Sedang Diputar dengan sampul HD, antrean, dan **lirik** (sinkron bila tersedia, via LRCLIB)
- **Halaman akun/channel/artis**: banner, avatar, jumlah pelanggan, tab Video/Album/Playlist, tombol Putar semua, Langganan
- Video yang ditolak YouTube untuk stream langsung (mis. "dibuat untuk anak-anak") otomatis diputar lewat pemutar tersemat YouTube
- Halaman album/playlist dengan sampul HD
- Putar di latar belakang (notifikasi, layar kunci, Bluetooth) lewat Media3; video bisa dijadikan audio saja lewat tombol "Audio"
- Pustaka: Favorit, Riwayat, Video ditonton, Langganan
- Setelan: tema, kualitas audio, batas kualitas video, utamakan 60 fps

## Build lewat GitHub Actions (tanpa PC)
1. Buat repo baru di GitHub (disarankan **Private**).
2. Upload `project.zip` ke root repo (Add file > Upload files).
3. Add file > Create new file, nama `.github/workflows/build.yml`, tempel isi `build.yml`, commit.
4. Tab **Actions** > Build APK > Run workflow (atau otomatis jalan saat commit).
5. Selesai (± 5–10 menit) → buka **Releases** di halaman repo → unduh `app-release.apk`.

Jika build gagal, buka run-nya: bagian **Summary** menampilkan ringkasan error. Salin dan kirim ke Claude.

## Struktur
- `app/src/main/java/app/mixbase/data` — Engine (NewPipeExtractor), Downloader (OkHttp), penyimpanan
- `app/src/main/java/app/mixbase/player` — PlaybackService (ExoPlayer/Media3) dan PlayerConnection
- `app/src/main/java/app/mixbase/ui` — layar Compose (Cari, Pustaka, Setelan, Pemutar)

## Catatan
- Kunci penanda tangan (`keystore/mixbase.jks`) adalah kunci pribadi untuk build sendiri, bukan untuk Play Store.
  Karena kuncinya tetap, APK baru bisa menimpa versi lama tanpa uninstall.
- Lisensi: NewPipeExtractor berlisensi GPLv3, jadi aplikasi ini juga harus GPLv3 bila dibagikan
  (sertakan teks lisensi dan source). Jangan memakai nama/logo NewPipe.
- Pengambilan stream bergantung pada perubahan di sisi situs sumber. Jika pemutaran gagal (mis. 403),
  perbarui versi `NewPipeExtractor` di `app/build.gradle.kts`.
