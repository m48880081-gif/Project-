# PlayTube

Pemutar musik/video (audio-first) berbasis **NewPipeExtractor**, UI baru dengan Jetpack Compose (Material 3).
Dibuat sebagai base: bisa dibuild tanpa PC, lewat GitHub Actions.

## Fitur
- **Dua mode terpisah**, pilih lewat menu garis tiga (☰) di kiri atas:
  - **Video** (gaya YouTube): bilah bawah Beranda · Cari · Langganan · Unduhan · Shorts
  - **Musik** (gaya YouTube Music): bilah bawah Beranda · Cari · Unduhan · Playlist (Favorit & Riwayat putar)
- Mini player musik punya tombol X untuk menutupnya
- **Menu samping** (gaya NewPipe) hanya berisi: pilihan Mode (Video / Musik), Setelan, dan keterangan aplikasi (nama, pengembang, versi). Nama pengembang diubah di `app/src/main/res/values/strings.xml` (`developer_name`)
- **Unduhan**: lewat menu ⋮ pada lagu/video atau tombol "Unduh" di halaman tonton. Audio (M4A) dan video (MP4, mengikuti batas kualitas di Setelan, maksimal 1080p) disimpan di `Android/data/app.mixbase/files/Download/PlayTube` dan bisa diputar tanpa internet. Progres unduhan tampil di bilah notifikasi (dengan tombol Batalkan) dan unduhan tetap berjalan saat aplikasi di latar belakang
- **Tampilan seragam gaya Google** (Material 3) untuk musik dan video: biru Google, putih bersih (terang) atau abu gelap (gelap, ikut sistem), header, chip, tombol pil, dan loading yang sama di semua layar
- **Loading bergelombang** gaya Material Expressive (bentuk yang berputar dan berubah bentuk)
- **Beranda Musik**: chip suasana, Pilihan cepat (Putar semua), Pintasan cepat, Album untuk kamu, Rilis terbaru, Artis untuk kamu
- **Beranda Video**: video dikelompokkan per baris dan **tiap baris bisa digeser ke samping** (kiri/kanan), sedangkan daftar tetap bisa digulir ke bawah (Langganan punya tab sendiri)
- **Bilah atas dan bawah berupa kotak padat** (tanpa efek fade): header (menu, logo, muat ulang, cari) selalu tampil di atas, dan bilah navigasi bawah pas dengan navigasi 3 tombol maupun gestur. Mini player tetap tampil saat menggulir
- **Halaman Cari** (Video dan Musik): kotak besar berisi riwayat pencarian (bisa dihapus satu per satu atau semua) dan saran pencarian; di bawahnya kotak kecil berisi video/lagu yang bisa digeser ke samping: pratinjau hasil untuk kata yang sedang diketik (mis. "Upin"), atau riwayat tontonan/putar bila kolom kosong
- **Buka link YouTube**: ketuk link youtube.com / youtu.be / music.youtube.com dari aplikasi lain, pakai menu Bagikan, atau tempel link di kolom Cari. Link di komentar dan deskripsi video bisa diketuk. Bila link masih terbuka di browser, aktifkan lewat Setelan > Link YouTube > "Atur buka link di aplikasi ini" (pilih "Buka link yang didukung")
- **Shorts** (tab terakhir di mode Video): video pendek satu per layar, digeser atas-bawah seperti TikTok. Otomatis diputar dan diulang, ketuk layar untuk jeda/lanjut, video berikutnya disiapkan lebih dulu. Tombol Tonton (buka di halaman tonton), Audio (putar sebagai lagu), Bagikan, dan ketuk nama channel untuk membuka halamannya. Tiga pemutar dipakai bergilir: video berikutnya sudah dimuat (dijeda, bingkai pertama siap) sebelum digeser sehingga langsung jalan, dengan resolusi dibatasi 720p. Daftar diambil dari pencarian YouTube yang disaring video berdurasi sampai 90 detik
- **Subtitle dan bahasa** (0.6.0): ikon CC di pemutar membuka menu Subtitle dan Suara. Subtitle bahasa asli atau otomatis dari YouTube, bisa diterjemahkan otomatis ke 15 bahasa (memakai fitur terjemahan YouTube). Bila pembuat video menyediakan suara multi-bahasa (mis. dubbing AI), suara bisa diganti tanpa mengulang video. Setelan > Bahasa: bahasa konten (judul, deskripsi, dll diminta dalam bahasa itu), utamakan suara dubbing, dan subtitle otomatis bila bahasa video berbeda. Semua bergantung pada data yang disediakan YouTube per video; subtitle bisa gagal dimuat bila YouTube menolak permintaan
- **Bahasa aplikasi dan konten** (0.7.0): Setelan > Bahasa mengganti bahasa seluruh tampilan (menu, tombol, setelan, notifikasi). Tampilan penuh tersedia untuk Indonesia dan Inggris; bahasa lain memakai tampilan Inggris. Judul video berbahasa lain diterjemahkan otomatis di HP (ML Kit, model ± 30 MB diunduh sekali) supaya daftar dan halaman tonton sama; bisa dimatikan. Tanggal unggah diubah menjadi "1 tahun lalu" dan angka mengikuti bahasa (rb/jt atau K/M)
- **Terjemahan lirik** (0.7.0): di layar lirik penuh ketuk "Terjemahkan lirik", pilih bahasa; lirik asli tetap tampil dan terjemahannya muncul di bawah tiap baris. Pilihan bahasa diingat untuk lagu berikutnya. Penerjemah memakai ML Kit di HP (tanpa internet setelah model terunduh)
- **Tampilan Material 3 Expressive** (0.8.0): palet biru + magenta, sudut besar, huruf tebal, gerak berbasis spring di seluruh aplikasi (efek tekan memantul pada semua tombol dan baris, pil indikator navigasi yang meregang, transisi antar-tab dan antar-layar, mini player melayang dengan progres bergelombang, slider bergelombang di layar Sedang Diputar, sampul yang "bernapas", tombol putar yang berubah bentuk, penanda ekualiser pada lagu yang diputar). Semua gerak dibuat manual dengan API Compose biasa tanpa menaikkan versi pustaka.
- **Cadangkan / Pulihkan** (0.8.1): halaman masuk/login sudah dihapus. Langganan, favorit, riwayat, setelan, dan daftar unduhan tetap tersimpan di perangkat. Untuk pindah HP atau setelah pasang ulang, pakai Setelan > Data > Cadangkan lalu Pulihkan (berkas JSON); unduhan yang berkasnya belum ada di HP baru muncul sebagai spanduk "Unduh ulang" di tab Unduhan
- **Layar Sedang Diputar baru** (0.8.1): sampul penuh yang memudar ke warna sampul, judul + favorit, progres bergelombang, kontrol, dan baris tombol (lirik, antrean, bagikan, timer tidur). Geser ke atas (atau ketuk titik tiga) untuk halaman penuh berisi aksi: bagikan, unduh, lirik, favorit, timer tidur, buka artis. Antrean berupa tombol yang membuka lembar daftar lagu
- **Putar instan** (0.8.1): alamat stream lagu yang tampil di daftar dan lagu berikutnya di antrean disiapkan lebih dulu di latar belakang, dan pemutar mulai setelah ±0,5 detik data, jadi lagu yang diketuk langsung berbunyi
- **Latar warna sampul** (0.8.1): gradasi lembut dari warna sampul lagu/video yang aktif di semua layar
- **Layar lirik gaya Apple Music** (0.8.2): latar gradasi warna sampul, baris aktif terisi mengikuti lagu, baris lain mengabur makin jauh, terjemahan kecil di bawah tiap baris. Ada dua mode: tidak penuh (lirik + kontrol) dan penuh (ketuk ikon sudut di samping judul; hanya judul + progres). Volume dihapus dari pemutar
- **Bilah transparan** (0.8.2): nav bar berupa pil panjang melayang tembus pandang (tab aktif melebar berisi ikon + nama), pemutar mini lagu/video berupa pil kaca dengan progres sebagai isian warna, status bar transparan (foto artis naik sampai tepi atas)
- **Video terkait** (0.8.2): di halaman tonton hanya satu baris yang digeser ke samping
- **Perbaikan** (0.8.2): tombol kembali menutup pemutar penuh lebih dulu (tidak lagi menutup album di bawahnya), tombol kembali di halaman album melayang sehingga tetap terjangkau; lirik dicari dengan judul/artis yang dinormalkan sehingga lagu yang sama mendapat lirik yang sama dari album, artis, maupun Cari (menu titik tiga di layar lirik menampilkan sumber lirik)
- **Pengenalan awal** (0.8.0): (1) pilih bahasa dan langsung mengunduh model terjemahan lirik (bahasa pilihan + Inggris sebagai perantara + bahasa tambahan opsional) dengan status unduhan, lalu (2) pilih format audio unduhan: **M4A (AAC)** atau **WEBM (Opus)** dengan tingkat kualitas Tertinggi / Seimbang / Hemat. Bisa diubah kapan saja di Setelan > Audio, dan model bahasa dikelola di Setelan > Bahasa > "Kelola model terjemahan lirik". **MP3 tidak tersedia** karena YouTube hanya menyediakan M4A dan WEBM; mengubahnya ke MP3 butuh pustaka konversi tambahan
- **Halaman tonton** video: pemutar di atas dengan kontrol (minimize, setelan, layar penuh, geser waktu, ketuk 2x = maju/mundur 10 dtk), judul, channel, Langganan, suka, bagikan, komentar, video terkait
- **Kualitas HD sampai 4K dan 60 fps** (video adaptif digabung dengan audio terbaik; pilih kualitas dan kecepatan di dalam pemutar; batas default 1080p di Setelan)
- **Resolusi otomatis (ikut internet)**: video diunduh per potongan lewat DASH; saat internet lambat resolusi turun sendiri (sampai paling rendah), saat lancar naik lagi (sampai 1080p, batas di Setelan). HP yang tidak kuat mendekode ikut diturunkan. Pilihan kualitas manual tetap ada
- **Permintaan ke YouTube meniru NewPipe** (nomor `rn`, POST ringan, header `TE`, User-Agent sesuai klien) dan musik yang ditolak 403 otomatis dicoba ulang dengan stream/cara lain
- **Lagu**: tampilan Sedang Diputar dengan sampul HD, antrean, dan **lirik** (sinkron bila tersedia, via LRCLIB)
- **Data musik dari YouTube Music** (cara yang sama dipakai InnerTune): pencarian lagu/album/artis, gambar sampul HD, halaman artis (lagu teratas, semua album, single & EP, video, artis serupa), dan halaman album mengambil metadata langsung dari YouTube Music. **Pemutaran audio tetap lewat sistem lama (NewPipe)**; bila sumber metadata baru gagal, otomatis kembali ke sistem lama
- **Halaman artis** (cari artis di Cari > Artis): foto besar, Langganan, Radio, Putar, Lagu teratas, Album, Single & EP, Video, Playlist, Penggemar mungkin juga suka, Tentang; panah di tiap bagian membuka daftar lengkap (semua album, dst.)
- **Halaman channel video**: banner, avatar, jumlah pelanggan, tab Video/Playlist, Langganan
- Video yang ditolak YouTube untuk stream langsung (mis. "dibuat untuk anak-anak") otomatis diputar lewat pemutar tersemat YouTube
- Halaman album/playlist dengan sampul HD
- Putar di latar belakang (notifikasi, layar kunci, Bluetooth) lewat Media3; video bisa dijadikan audio saja lewat tombol "Audio"
- Favorit & riwayat putar (tab Playlist di mode Musik), riwayat tontonan (baris "Terakhir ditonton" di halaman Cari mode Video), langganan channel (tab Langganan)
- Setelan: tema, kualitas audio, batas kualitas video, utamakan 60 fps

## Build lewat GitHub Actions (tanpa PC)
1. Buat repo baru di GitHub (disarankan **Private**).
2. Upload `project.zip` ke root repo (Add file > Upload files).
3. Add file > Create new file, nama `.github/workflows/build.yml`, tempel isi `build.yml`, commit.
4. Tab **Actions** > Build APK > Run workflow (atau otomatis jalan saat commit).
5. Selesai (± 5–10 menit) → buka **Releases** di halaman repo → unduh APK-nya (`app-release.apk`, atau `PlayTube-N.apk` bila memakai build.yml terbaru).

Jika build gagal, buka run-nya: bagian **Summary** menampilkan ringkasan error. Salin dan kirim ke Claude.

## Struktur
- `app/src/main/java/app/mixbase/data` — Engine (NewPipeExtractor), MusicApi (metadata YouTube Music), Downloader (OkHttp), penyimpanan, Downloads (unduhan)
- `app/src/main/java/app/mixbase/player` — PlaybackService (ExoPlayer/Media3) dan PlayerConnection
- `app/src/main/java/app/mixbase/ui` — layar Compose (tab tiap mode, menu samping, Unduhan, Setelan, Pemutar). `Expressive.kt` berisi komponen/gerak Expressive bersama, `AuthScreen.kt` halaman masuk, `Onboarding.kt` alur bahasa + format audio
- `app/src/main/java/app/mixbase/data/Accounts.kt`, `Backup.kt`, `LangModels.kt` — akun lokal, cadangan/pulihkan, dan unduhan model bahasa

## Catatan
- Kunci penanda tangan (`keystore/mixbase.jks`) adalah kunci pribadi untuk build sendiri, bukan untuk Play Store.
  Karena kuncinya tetap, APK baru bisa menimpa versi lama tanpa uninstall.
- Lisensi: NewPipeExtractor berlisensi GPLv3, jadi aplikasi ini juga harus GPLv3 bila dibagikan
  (sertakan teks lisensi dan source). Jangan memakai nama/logo NewPipe.
- Pengambilan stream bergantung pada perubahan di sisi situs sumber. Jika pemutaran gagal (mis. 403),
  perbarui versi `NewPipeExtractor` di `app/build.gradle.kts`.

## Catatan teknis
- Memakai NewPipeExtractor **v0.26.5** (sama seperti URMIX). v0.27.x membuang klien ANDROID sehingga video "dibuat untuk anak-anak" ditolak YouTube.
- User-Agent stream disesuaikan per alamat (klien ANDROID / iOS / visionOS) agar tidak dibatasi.

## Catatan data musik (MusicApi)
- `data/MusicApi.kt` memanggil API internal YouTube Music (klien WEB_REMIX, `music.youtube.com/youtubei/v1`) lewat OkHttp + `org.json`, tanpa pustaka tambahan. Ia hanya mengambil metadata; tiap lagu tetap berupa `https://www.youtube.com/watch?v=ID` sehingga audio diputar oleh jalur lama.
- Pencarian musik (`Engine.search`), halaman artis, "Lihat semua", dan halaman album memakai MusicApi lebih dulu, lalu jatuh ke NewPipe bila gagal atau kosong.
- "Lagu teratas" mengikuti urutan populer dari YouTube Music; "Album" dan "Single & EP" dipisah menurut jenis rilis dari YouTube Music.
- Bila YouTube mengubah bentuk balasan, parser mencari berdasarkan nama renderer (bukan posisi) supaya lebih tahan perubahan. Versi klien bawaan diganti otomatis dengan versi terbaru dari halaman music.youtube.com bila ditolak.
- Tanpa NewPipe (jalur cadangan): YouTube tidak memisahkan "Single" dan "EP" dari "Album" di halaman channel, jadi rilis dibagi dengan perkiraan jumlah lagu (sampai 6 lagu = Single & EP).
