# MixBase

Pemutar musik/video (audio-first) berbasis **NewPipeExtractor**, UI baru dengan Jetpack Compose (Material 3).
Dibuat sebagai base: bisa dibuild tanpa PC, lewat GitHub Actions.

## Fitur
- Cari lagu/video (filter Musik / Video) dengan saran pencarian dan muat halaman berikutnya otomatis
- Putar di latar belakang (notifikasi, layar kunci, Bluetooth) lewat Media3
- Antrean: putar berikutnya, tambah ke antrean, acak, ulangi, hapus dari antrean
- Pustaka: favorit dan riwayat
- Setelan: tema (sistem/terang/gelap), warna dinamis, kualitas audio
- **Tonton video HD** (v0.2.0): pilih filter "Video" di pencarian, atau tombol Audio/Video di layar pemutar.
  Kualitas bisa dipilih (360p sampai 1080p, atau lebih bila HP mendukung), ada layar penuh (landscape).
  Di latar belakang hanya audio yang diputar (hemat kuota).
- **Diagnostik**: Setelan > Diagnostik > "Tes koneksi YouTube" menguji tiap jalur dan menampilkan log yang bisa disalin.

## Build lewat GitHub Actions (tanpa PC)
1. Buat repo baru di GitHub (disarankan **Private**).
2. Upload `project.zip` ke root repo (Add file > Upload files).
3. Add file > Create new file, nama `.github/workflows/build.yml`, tempel isi `build.yml`, commit.
4. Tab **Actions** > Build APK > Run workflow (atau otomatis jalan saat commit).
5. Selesai (± 5–10 menit) → buka **Releases** di halaman repo → unduh `app-release.apk`.

Jika build gagal, buka run-nya: bagian **Summary** menampilkan ringkasan error. Salin dan kirim ke Claude.

## Struktur
- `app/src/main/java/app/mixbase/data` — Engine (NewPipeExtractor), Downloader (OkHttp), penyimpanan
- `app/src/main/java/app/mixbase/player` — PlaybackService (ExoPlayer/Media3) dan PlayerConnection
- `app/src/main/java/app/mixbase/ui` — layar Compose (Cari, Pustaka, Setelan, Pemutar)

## Catatan
- Kunci penanda tangan (`keystore/mixbase.jks`) adalah kunci pribadi untuk build sendiri, bukan untuk Play Store.
  Karena kuncinya tetap, APK baru bisa menimpa versi lama tanpa uninstall.
- Lisensi: NewPipeExtractor berlisensi GPLv3, jadi aplikasi ini juga harus GPLv3 bila dibagikan
  (sertakan teks lisensi dan source). Jangan memakai nama/logo NewPipe.
- Pengambilan stream bergantung pada perubahan di sisi situs sumber. Sejak v0.2.0 `Engine` mencoba beberapa
  jalur berurutan (NewPipeExtractor, lalu klien InnerTube ANDROID_VR langsung), memeriksa URL sebelum dipakai,
  dan otomatis mengulang dengan URL baru bila gagal. Error seperti `UNPLAYABLE` / 403 yang menimpa satu jalur
  tidak lagi menghentikan pemutaran selama jalur lain masih bekerja.
- Video HD di YouTube terpisah dari audionya (adaptive), jadi pemutar menggabungkan dua stream (MergingMediaSource).
  Codec dipilih sesuai kemampuan HP (H.264 dulu, lalu VP9/HEVC/AV1); bila decoder error, otomatis turun ke H.264.
- Jika masih gagal: jalankan Diagnostik dan kirim hasilnya, atau perbarui versi `NewPipeExtractor`
  di `app/build.gradle.kts`.
