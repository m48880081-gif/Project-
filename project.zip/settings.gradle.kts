pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // NewPipeExtractor dan nanojson di-host di JitPack
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "MixBase"
include(":app")
