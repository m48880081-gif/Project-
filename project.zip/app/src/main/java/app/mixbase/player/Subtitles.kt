package app.mixbase.player

import app.mixbase.data.Engine
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Satu baris subtitle: tampil dari [startMs] sampai [endMs]. */
class Cue(val startMs: Long, val endMs: Long, val text: String)

/**
 * Mengambil subtitle YouTube (format json3) dan mencari baris yang cocok dengan posisi video.
 * Terjemahan otomatis memakai parameter `tlang` milik YouTube.
 */
object Subtitles {

    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0"

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    /** Alamat subtitle dalam format json3, opsional diterjemahkan ke [translateTo] (kode bahasa). */
    fun urlFor(opt: Engine.SubtitleOption, translateTo: String?): String {
        var u = opt.url
            .replace(Regex("[&?]fmt=[^&]*"), "")
            .replace(Regex("[&?]tlang=[^&]*"), "")
        u += if (u.contains('?')) "&fmt=json3" else "?fmt=json3"
        if (!translateTo.isNullOrBlank()) u += "&tlang=$translateTo"
        return u
    }

    /** Unduh dan urai subtitle. Dilempar [Exception] bila gagal atau kosong. Panggil dari thread IO. */
    fun fetch(opt: Engine.SubtitleOption, translateTo: String?): List<Cue> {
        val req = Request.Builder()
            .url(urlFor(opt, translateTo))
            .header("User-Agent", UA)
            .header("Accept-Language", "en-US,en;q=0.9")
            .build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IllegalStateException("HTTP ${resp.code}")
            val body = resp.body?.string().orEmpty()
            if (body.isBlank()) throw IllegalStateException("YouTube tidak mengirim isi subtitle")
            val cues = parse(body)
            if (cues.isEmpty()) throw IllegalStateException("Subtitle kosong")
            return cues
        }
    }

    /** Urai respons json3 YouTube menjadi daftar baris yang terurut. */
    fun parse(json: String): List<Cue> {
        val events = JSONObject(json).optJSONArray("events") ?: return emptyList()
        val out = ArrayList<Cue>()
        for (i in 0 until events.length()) {
            val ev = events.optJSONObject(i) ?: continue
            val segs = ev.optJSONArray("segs") ?: continue
            val sb = StringBuilder()
            for (j in 0 until segs.length()) {
                sb.append(segs.optJSONObject(j)?.optString("utf8").orEmpty())
            }
            val text = sb.toString()
                .replace("\r", "")
                .lines()
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .joinToString("\n")
            if (text.isEmpty()) continue
            val start = ev.optLong("tStartMs", 0L)
            var dur = ev.optLong("dDurationMs", 0L)
            if (dur <= 0L) dur = 3000L
            out.add(Cue(start, start + dur, text))
        }
        out.sortBy { it.startMs }
        // Subtitle otomatis sering bertumpuk: potong akhir baris agar tidak menimpa baris berikutnya.
        val fixed = ArrayList<Cue>(out.size)
        for (k in out.indices) {
            val c = out[k]
            val next = out.getOrNull(k + 1)
            val end = if (next != null && next.startMs in (c.startMs + 1) until c.endMs) next.startMs else c.endMs
            fixed.add(Cue(c.startMs, end, c.text))
        }
        return fixed
    }

    /** Teks yang harus tampil pada [positionMs], atau string kosong. */
    fun textAt(cues: List<Cue>, positionMs: Long): String {
        if (cues.isEmpty()) return ""
        var lo = 0
        var hi = cues.size - 1
        var found = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (cues[mid].startMs <= positionMs) {
                found = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        if (found < 0) return ""
        var k = found
        var steps = 0
        while (k >= 0 && steps < 4) {
            val c = cues[k]
            if (positionMs < c.endMs) return c.text
            k--
            steps++
        }
        return ""
    }
}
