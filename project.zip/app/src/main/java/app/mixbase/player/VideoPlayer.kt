package app.mixbase.player

import android.content.Context
import android.view.TextureView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import app.mixbase.data.AppDownloader
import app.mixbase.data.Engine
import app.mixbase.data.Store
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Pemutar video (terpisah dari pemutar musik).
 *
 * YouTube hanya menyediakan HD (720p ke atas, termasuk 60 fps) sebagai stream terpisah:
 * video-saja + audio-saja. Keduanya digabung di sini dengan MergingMediaSource.
 * Bila gagal (mis. 403 atau codec tidak didukung) otomatis turun ke cadangan:
 *   kualitas yang dipilih → 720p-atau-lebih-rendah (H.264) → stream gabungan → HLS.
 */
@OptIn(UnstableApi::class)
class VideoPlayer(private val context: Context) {

    private sealed class Step(val label: String) {
        class Adaptive(label: String, val videoUrl: String, val audioUrl: String) : Step(label)
        class Muxed(label: String, val url: String) : Step(label)
        class Hls(label: String, val url: String) : Step(label)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val store = Store(context)

    private var exo: ExoPlayer? = null
    private var view: TextureView? = null
    private var job: Job? = null
    private var commentJob: Job? = null
    private var commentSession: Engine.CommentSession? = null
    private var plan: List<Step> = emptyList()
    private var planIndex = 0

    /** Dipanggil setiap video baru dibuka (untuk riwayat tontonan). */
    var onOpened: ((Track) -> Unit)? = null

    // ---------------- State untuk UI ----------------

    var track by mutableStateOf<Track?>(null)
        private set
    var details by mutableStateOf<Engine.VideoDetails?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var ended by mutableStateOf(false)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var bufferedMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    var aspect by mutableFloatStateOf(16f / 9f)
        private set
    var activeLabel by mutableStateOf("")
        private set
    var chosen by mutableStateOf<Engine.Quality?>(null)
        private set
    var speed by mutableFloatStateOf(1f)
        private set

    var comments by mutableStateOf<List<Engine.CommentItem>>(emptyList())
        private set
    var commentsTotal by mutableIntStateOf(-1)
        private set
    var commentsDisabled by mutableStateOf(false)
        private set
    var commentsLoading by mutableStateOf(false)
        private set
    var commentsLoaded by mutableStateOf(false)
        private set
    var commentsMore by mutableStateOf(false)
        private set

    /** true selama ada video yang sedang dibuka (termasuk saat diminimalkan). */
    val active: Boolean
        get() = track != null

    // ---------------- Listener ----------------

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync()
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                aspect = videoSize.width.toFloat() * videoSize.pixelWidthHeightRatio /
                    videoSize.height.toFloat()
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            handleError(error)
        }
    }

    private fun sync() {
        val p = exo ?: return
        isPlaying = p.isPlaying
        buffering = p.playbackState == Player.STATE_BUFFERING
        ended = p.playbackState == Player.STATE_ENDED
        val d = p.duration
        durationMs = if (d == C.TIME_UNSET || d < 0L) 0L else d
        positionMs = if (p.currentPosition < 0L) 0L else p.currentPosition
        bufferedMs = if (p.bufferedPosition < 0L) 0L else p.bufferedPosition
    }

    /** Dipanggil berkala oleh UI saat memutar, untuk memperbarui posisi. */
    fun tick() {
        sync()
    }

    // ---------------- Pembuatan pemutar ----------------

    private fun httpFactory(): DefaultHttpDataSource.Factory =
        DefaultHttpDataSource.Factory()
            .setUserAgent(AppDownloader.USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

    private fun ensurePlayer(): ExoPlayer {
        val existing = exo
        if (existing != null) return existing

        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val renderers = DefaultRenderersFactory(context).setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(context, renderers)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(listener)
        val v = view
        if (v != null) p.setVideoTextureView(v)
        p.playbackParameters = PlaybackParameters(speed)
        exo = p
        return p
    }

    fun attach(v: TextureView) {
        view = v
        exo?.setVideoTextureView(v)
    }

    fun detach(v: TextureView) {
        if (view === v) {
            exo?.clearVideoTextureView(v)
            view = null
        }
    }

    // ---------------- Membuka video ----------------

    fun open(t: Track) {
        if (track?.url == t.url) return
        resetState()
        track = t
        loading = true
        onOpened?.invoke(t)

        job = scope.launch {
            try {
                val d = withContext(Dispatchers.IO) { Engine.videoDetails(t.url) }
                if (track?.url != t.url) return@launch
                details = d
                plan = buildPlan(d, null)
                if (plan.isEmpty()) {
                    error = "Tidak ada stream video yang bisa diputar untuk video ini"
                } else {
                    playStep(0, 0L)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (track?.url == t.url) {
                    error = "Gagal memuat video: ${e.message ?: e.javaClass.simpleName}"
                }
            } finally {
                if (track?.url == t.url) loading = false
            }
        }
    }

    fun retry() {
        val t = track ?: return
        stop()
        open(t)
    }

    private fun resetState() {
        job?.cancel()
        commentJob?.cancel()
        exo?.release()
        exo = null
        commentSession = null
        track = null
        details = null
        loading = false
        error = null
        isPlaying = false
        buffering = false
        ended = false
        positionMs = 0L
        bufferedMs = 0L
        durationMs = 0L
        aspect = 16f / 9f
        activeLabel = ""
        chosen = null
        plan = emptyList()
        planIndex = 0
        comments = emptyList()
        commentsTotal = -1
        commentsDisabled = false
        commentsLoading = false
        commentsLoaded = false
        commentsMore = false
    }

    /** Hentikan dan lepaskan video (menutup mini bar). */
    fun stop() {
        resetState()
    }

    // ---------------- Rencana pemutaran ----------------

    private fun isAvc(q: Engine.Quality): Boolean = q.codec.lowercase().startsWith("avc")

    /** Kualitas awal: setinggi mungkin sampai batas di Setelan; utamakan 60 fps bila diminta. */
    private fun defaultQuality(list: List<Engine.Quality>): Engine.Quality? {
        if (list.isEmpty()) return null
        val cap = store.maxHeight
        val capped = list.filter { it.height <= cap }.ifEmpty { list.takeLast(1) }
        val top = capped.maxOf { it.height }
        val atTop = capped.filter { it.height == top }
        return if (store.prefer60) {
            atTop.maxByOrNull { it.fps }
        } else {
            atTop.minByOrNull { it.fps }
        }
    }

    private fun buildPlan(d: Engine.VideoDetails, pick: Engine.Quality?): List<Step> {
        val steps = ArrayList<Step>()

        if (d.live) {
            val hls = d.hlsUrl
            if (hls != null) steps.add(Step.Hls("Live", hls))
            return steps
        }

        val audio = d.audioUrl
        if (audio != null && d.qualities.isNotEmpty()) {
            val q = pick ?: defaultQuality(d.qualities)
            if (q != null) {
                steps.add(Step.Adaptive(q.label, q.url, audio))
                // Cadangan: H.264 ≤ 720p (paling kompatibel dan paling ringan).
                val alt = d.qualities.firstOrNull {
                    it !== q && isAvc(it) && it.height <= 720 && it.height <= q.height
                }
                if (alt != null) steps.add(Step.Adaptive(alt.label, alt.url, audio))
            }
        }

        val muxed = d.muxedUrl
        if (muxed != null) steps.add(Step.Muxed("${d.muxedHeight}p", muxed))

        val hls = d.hlsUrl
        if (hls != null) steps.add(Step.Hls("Otomatis", hls))
        return steps
    }

    private fun progressive(url: String): MediaSource =
        ProgressiveMediaSource.Factory(httpFactory()).createMediaSource(MediaItem.fromUri(url))

    private fun playStep(index: Int, startMs: Long) {
        val step = plan[index]
        planIndex = index
        val p = ensurePlayer()

        val source: MediaSource = when (step) {
            is Step.Adaptive -> MergingMediaSource(progressive(step.videoUrl), progressive(step.audioUrl))
            is Step.Muxed -> progressive(step.url)
            is Step.Hls -> HlsMediaSource.Factory(httpFactory()).createMediaSource(MediaItem.fromUri(step.url))
        }
        activeLabel = step.label
        error = null
        p.setMediaSource(source, startMs)
        p.prepare()
        p.playWhenReady = true
    }

    private fun handleError(e: PlaybackException) {
        val p = exo ?: return
        val resume = if (p.currentPosition < 0L) 0L else p.currentPosition
        if (planIndex + 1 < plan.size) {
            playStep(planIndex + 1, resume)
            return
        }
        val why = e.cause?.message ?: e.message ?: e.errorCodeName
        error = "Video gagal diputar: $why"
    }

    // ---------------- Kontrol ----------------

    fun play() {
        val p = exo ?: return
        if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
        if (p.playbackState == Player.STATE_IDLE) p.prepare()
        p.play()
    }

    fun pause() {
        exo?.pause()
    }

    fun togglePlay() {
        val p = exo ?: return
        if (p.isPlaying) pause() else play()
    }

    fun seekTo(ms: Long) {
        val p = exo ?: return
        p.seekTo(if (ms < 0L) 0L else ms)
        sync()
    }

    fun seekBy(deltaMs: Long) {
        val p = exo ?: return
        var target = p.currentPosition + deltaMs
        if (target < 0L) target = 0L
        val d = p.duration
        if (d != C.TIME_UNSET && d > 0L && target > d) target = d
        p.seekTo(target)
        sync()
    }

    /** [q] null = otomatis (kualitas terbaik sesuai Setelan). */
    fun chooseQuality(q: Engine.Quality?) {
        val d = details ?: return
        chosen = q
        val steps = buildPlan(d, q)
        if (steps.isEmpty()) return
        val resume = positionMs
        plan = steps
        playStep(0, resume)
    }

    fun changeSpeed(s: Float) {
        speed = s
        exo?.playbackParameters = PlaybackParameters(s)
    }

    // ---------------- Komentar ----------------

    fun loadComments() {
        val t = track ?: return
        if (commentsLoaded || commentsLoading) return
        commentsLoading = true
        val url = t.url
        commentJob = scope.launch {
            try {
                val session = withContext(Dispatchers.IO) { Engine.commentSession(url) }
                val first = withContext(Dispatchers.IO) { session.first() }
                if (track?.url == url) {
                    commentSession = session
                    comments = first
                    commentsTotal = session.total
                    commentsDisabled = session.disabled
                    commentsMore = session.hasMore
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Komentar bersifat tambahan: kegagalan tidak mengganggu pemutaran.
            } finally {
                if (track?.url == url) {
                    commentsLoading = false
                    commentsLoaded = true
                }
            }
        }
    }

    fun loadMoreComments() {
        val s = commentSession ?: return
        val url = track?.url ?: return
        if (commentsLoading || !commentsMore) return
        commentsLoading = true
        commentJob = scope.launch {
            try {
                val more = withContext(Dispatchers.IO) { s.more() }
                if (track?.url == url) {
                    comments = comments + more
                    commentsMore = s.hasMore
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (track?.url == url) commentsMore = false
            } finally {
                if (track?.url == url) commentsLoading = false
            }
        }
    }
}
