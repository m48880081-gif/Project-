package app.mixbase.player

import android.content.Context
import android.net.Uri
import android.view.TextureView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.dash.DashMediaSource
import androidx.media3.exoplayer.dash.manifest.DashManifestParser
import androidx.media3.exoplayer.hls.HlsMediaSource
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.trackselection.AdaptiveTrackSelection
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter
import app.mixbase.data.AppDownloader
import app.mixbase.data.Downloads
import app.mixbase.data.Engine
import app.mixbase.data.Store
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.File

/**
 * Pemutar video (terpisah dari pemutar musik).
 *
 * YouTube hanya menyediakan HD (720p ke atas, termasuk 60 fps) sebagai stream terpisah:
 * video-saja + audio-saja. Dua cara menggabungkannya:
 *  - DASH (utama): manifest dibuat dari indeks stream; video diunduh per potongan kecil dan
 *    pada mode "Otomatis" resolusi naik-turun sendiri mengikuti kecepatan internet.
 *  - MergingMediaSource (cadangan): dua unduhan utuh yang digabung.
 * Bila gagal (mis. 403 atau codec tidak didukung) otomatis turun ke cadangan berikutnya:
 *   DASH → gabungan biasa (cara NewPipe, lalu GET biasa) → stream gabungan → HLS.
 */
@OptIn(UnstableApi::class)
class VideoPlayer(private val context: Context) {

    private sealed class Step(val label: String, val legacy: Boolean) {
        class Dash(label: String, val mpd: String, val auto: Boolean, val heights: List<Int>) :
            Step(label, false)
        class Adaptive(label: String, val videoUrl: String, val audioUrl: String, legacy: Boolean) :
            Step(label, legacy)
        class Muxed(label: String, val url: String, legacy: Boolean) : Step(label, legacy)
        class Hls(label: String, val url: String, legacy: Boolean) : Step(label, legacy)

        /** Berkas video hasil unduhan di perangkat (bisa diputar tanpa internet). */
        class Local(label: String, val path: String) : Step(label, false)
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val store = Store(context)

    private var exo: ExoPlayer? = null
    private var view: TextureView? = null
    private var job: Job? = null
    private var commentJob: Job? = null
    private var commentSession: Engine.CommentSession? = null
    private var plan: List<Step> = emptyList()
    private var planIndex = 0
    private var autoMode = false
    private var selector: DefaultTrackSelector? = null
    private var ladder: List<Int> = emptyList()
    private var playingHeight = 0

    // Satu pengukur kecepatan dipakai terus antar-video, supaya perkiraan internet tidak dimulai dari nol.
    private val bandwidth: DefaultBandwidthMeter by lazy {
        DefaultBandwidthMeter.Builder(context)
            .setInitialBitrateEstimate(C.NETWORK_TYPE_WIFI, 8_000_000L)
            .build()
    }

    /** Dipanggil setiap video baru dibuka (untuk riwayat tontonan). */
    var onOpened: ((Track) -> Unit)? = null

    // ---------------- State untuk UI ----------------

    var track by mutableStateOf<Track?>(null)
        private set
    var details by mutableStateOf<Engine.VideoDetails?>(null)
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    /** true: video diputar lewat pemutar tersemat YouTube (cadangan saat stream ditolak). */
    var useEmbed by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var ended by mutableStateOf(false)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var bufferedMs by mutableLongStateOf(0L)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    var aspect by mutableFloatStateOf(16f / 9f)
        private set
    var activeLabel by mutableStateOf("")
        private set
    var chosen by mutableStateOf<Engine.Quality?>(null)
        private set
    var speed by mutableFloatStateOf(1f)
        private set

    var comments by mutableStateOf<List<Engine.CommentItem>>(emptyList())
        private set
    var commentsTotal by mutableIntStateOf(-1)
        private set
    var commentsDisabled by mutableStateOf(false)
        private set
    var commentsLoading by mutableStateOf(false)
        private set
    var commentsLoaded by mutableStateOf(false)
        private set
    var commentsMore by mutableStateOf(false)
        private set

    /** true selama ada video yang sedang dibuka (termasuk saat diminimalkan). */
    val active: Boolean
        get() = track != null

    // ---------------- Listener ----------------

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync()
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                aspect = videoSize.width.toFloat() * videoSize.pixelWidthHeightRatio /
                    videoSize.height.toFloat()
                playingHeight = videoSize.height
                if (autoMode) {
                    activeLabel = "Otomatis · ${minOf(videoSize.width, videoSize.height)}p"
                }
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            handleError(error)
        }
    }

    /**
     * Perlindungan "lag" yang bukan karena internet: bila HP tidak kuat mendekode resolusi yang
     * sedang diputar (banyak frame terbuang), mode Otomatis turun satu tingkat dan tidak naik
     * lagi ke resolusi itu selama video ini.
     */
    private val frameWatch = object : AnalyticsListener {
        override fun onDroppedVideoFrames(
            eventTime: AnalyticsListener.EventTime,
            droppedFrames: Int,
            elapsedMs: Long,
        ) {
            if (!autoMode || elapsedMs <= 0L) return
            val perSecond = droppedFrames * 1000f / elapsedMs.toFloat()
            if (perSecond < 8f) return
            val ts = selector ?: return
            val lower = ladder.lastOrNull { it < playingHeight } ?: return
            ts.setParameters(ts.buildUponParameters().setMaxVideoSize(Int.MAX_VALUE, lower).build())
        }
    }

    private fun sync() {
        val p = exo ?: return
        isPlaying = p.isPlaying
        buffering = p.playbackState == Player.STATE_BUFFERING
        ended = p.playbackState == Player.STATE_ENDED
        val d = p.duration
        durationMs = if (d == C.TIME_UNSET || d < 0L) 0L else d
        positionMs = if (p.currentPosition < 0L) 0L else p.currentPosition
        bufferedMs = if (p.bufferedPosition < 0L) 0L else p.bufferedPosition
    }

    /** Dipanggil berkala oleh UI saat memutar, untuk memperbarui posisi. */
    fun tick() {
        sync()
    }

    // ---------------- Pembuatan pemutar ----------------

    private fun ensurePlayer(): ExoPlayer {
        val existing = exo
        if (existing != null) return existing

        val attrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()
        val renderers = DefaultRenderersFactory(context).setEnableDecoderFallback(true)
        // Buffer lebih besar dan jeda isi ulang lebih lama: mengurangi putus-putus di jaringan lambat.
        val load = DefaultLoadControl.Builder()
            .setBufferDurationsMs(30_000, 60_000, 1_500, 4_000)
            .build()
        // Pemilih resolusi otomatis: naik setelah ~5 dtk buffer cukup, turun bila buffer < 15 dtk
        // dan internet tidak sanggup lagi. Dipakai pada mode "Otomatis" (manifest DASH).
        val tracks = DefaultTrackSelector(
            context,
            AdaptiveTrackSelection.Factory(5_000, 15_000, 25_000, 0.7f),
        )
        val p = ExoPlayer.Builder(context, renderers)
            .setLoadControl(load)
            .setTrackSelector(tracks)
            .setBandwidthMeter(bandwidth)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(listener)
        p.addAnalyticsListener(frameWatch)
        selector = tracks
        val v = view
        if (v != null) p.setVideoTextureView(v)
        p.playbackParameters = PlaybackParameters(speed)
        exo = p
        return p
    }

    fun attach(v: TextureView) {
        view = v
        exo?.setVideoTextureView(v)
    }

    fun detach(v: TextureView) {
        if (view === v) {
            exo?.clearVideoTextureView(v)
            view = null
        }
    }

    // ---------------- Membuka video ----------------

    fun open(t: Track) {
        if (track?.url == t.url) return
        resetState()
        track = t
        loading = true
        onOpened?.invoke(t)

        val local = Downloads.localVideo(t.url)
        job = scope.launch {
            try {
                if (local != null) {
                    // Sudah diunduh: putar dari penyimpanan, tanpa menunggu internet.
                    plan = listOf(Step.Local("Unduhan", local))
                    playStep(0, 0L)
                    loading = false
                    // Detail (deskripsi, video terkait) diambil bila internet ada; bila tidak, tetap diputar.
                    try {
                        val info = withContext(Dispatchers.IO) { Engine.videoDetails(t.url) }
                        if (track?.url == t.url) details = info
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // tanpa internet: abaikan
                    }
                    return@launch
                }
                val d = withContext(Dispatchers.IO) { Engine.videoDetails(t.url) }
                if (track?.url != t.url) return@launch
                details = d
                plan = buildPlan(d, null)
                if (plan.isEmpty()) {
                    error = "Tidak ada stream video yang bisa diputar untuk video ini"
                } else {
                    playStep(0, 0L)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (track?.url == t.url) {
                    val msg = e.message ?: ""
                    val rejected = msg.contains("UNPLAYABLE", true) ||
                        msg.contains("not available", true) ||
                        msg.contains("sign in", true) ||
                        msg.contains("LOGIN_REQUIRED", true) ||
                        msg.contains("403")
                    if (rejected && embedVideoId() != null) {
                        // Mis. video "dibuat untuk anak-anak": YouTube menolak stream langsung.
                        useEmbed = true
                    } else {
                        error = "Gagal memuat video: ${msg.ifBlank { e.javaClass.simpleName }}"
                    }
                }
            } finally {
                if (track?.url == t.url) loading = false
            }
        }
    }

    /** ID video YouTube (11 karakter) dari URL video yang sedang dibuka, atau null. */
    fun embedVideoId(): String? {
        val u = track?.url ?: return null
        val m = Regex("(?:[?&]v=|youtu\\.be/|/shorts/|/embed/|/live/)([A-Za-z0-9_-]{11})").find(u)
        return m?.groupValues?.get(1)
    }

    /** Pindah ke pemutar tersemat YouTube (cadangan). */
    fun startEmbed() {
        if (embedVideoId() == null) return
        job?.cancel()
        exo?.release()
        exo = null
        isPlaying = false
        buffering = false
        loading = false
        error = null
        useEmbed = true
    }

    fun retry() {
        val t = track ?: return
        stop()
        open(t)
    }

    private fun resetState() {
        job?.cancel()
        commentJob?.cancel()
        exo?.release()
        exo = null
        commentSession = null
        track = null
        details = null
        loading = false
        error = null
        useEmbed = false
        isPlaying = false
        buffering = false
        ended = false
        positionMs = 0L
        bufferedMs = 0L
        durationMs = 0L
        aspect = 16f / 9f
        activeLabel = ""
        autoMode = false
        ladder = emptyList()
        playingHeight = 0
        selector = null
        chosen = null
        plan = emptyList()
        planIndex = 0
        comments = emptyList()
        commentsTotal = -1
        commentsDisabled = false
        commentsLoading = false
        commentsLoaded = false
        commentsMore = false
    }

    /** Hentikan dan lepaskan video (menutup mini bar). */
    fun stop() {
        resetState()
    }

    // ---------------- Rencana pemutaran ----------------

    private fun isAvc(q: Engine.Quality): Boolean = q.codec.lowercase().startsWith("avc")

    /** "720p60 · H.264" — jenis codec ikut ditampilkan supaya mudah melacak video yang berat. */
    private fun labelWithCodec(q: Engine.Quality): String {
        val c = q.codec.lowercase()
        val name = when {
            c.startsWith("avc") -> "H.264"
            c.startsWith("vp9") || c.startsWith("vp09") -> "VP9"
            c.startsWith("av01") -> "AV1"
            else -> ""
        }
        return if (name.isEmpty()) q.label else "${q.label} · $name"
    }

    /** Kualitas awal: setinggi mungkin sampai batas di Setelan; utamakan 60 fps bila diminta. */
    private fun defaultQuality(list: List<Engine.Quality>): Engine.Quality? {
        if (list.isEmpty()) return null
        val cap = store.maxHeight
        val capped = list.filter { it.height <= cap }.ifEmpty { list.takeLast(1) }
        val top = capped.maxOf { it.height }
        val atTop = capped.filter { it.height == top }
        return if (store.prefer60) {
            atTop.maxByOrNull { it.fps }
        } else {
            atTop.minByOrNull { it.fps }
        }
    }

    private fun familyOf(codec: String): String {
        val c = codec.lowercase()
        return when {
            c.startsWith("avc") -> "avc"
            c.startsWith("vp09") || c.startsWith("vp9") -> "vp9"
            c.startsWith("av01") -> "av1"
            else -> "other"
        }
    }

    /**
     * Tangga resolusi untuk mode Otomatis: satu stream per tinggi, dari rendah ke tinggi, sampai
     * batas di Setelan. Hanya satu keluarga codec (ExoPlayer hanya bisa berpindah mulus antar
     * stream sejenis): H.264 bila cukup lengkap (sampai 1080p), kalau tidak yang paling lengkap.
     * Null bila datanya belum cukup untuk manifest.
     */
    private fun autoLadder(d: Engine.VideoDetails): List<Engine.Rep>? {
        val cap = store.maxHeight
        val usable = d.qualities.filter { it.rep?.ranged == true }
        if (usable.isEmpty()) return null

        val families = usable.groupBy { familyOf(it.codec) }
        fun heights(list: List<Engine.Quality>): Int =
            list.filter { it.height <= cap }.map { it.height }.toSet().size

        val avc = families["avc"]
        val family: List<Engine.Quality> = if (avc != null && heights(avc) >= 3) {
            avc
        } else {
            families.values.maxByOrNull { heights(it) } ?: return null
        }

        var capped = family.filter { it.height <= cap }
        if (capped.isEmpty()) capped = listOf(family.minByOrNull { it.height } ?: return null)

        val prefer60 = store.prefer60
        val perHeight = capped.groupBy { it.height }.map { entry ->
            val g = entry.value
            val best = if (prefer60) g.maxByOrNull { it.fps } else g.minByOrNull { it.fps }
            best ?: g.first()
        }
        return perHeight.sortedBy { it.height }.mapNotNull { it.rep }
    }

    private fun dashStep(
        d: Engine.VideoDetails,
        label: String,
        videos: List<Engine.Rep>,
        auto: Boolean,
    ): Step? {
        val a = d.audioRep ?: return null
        val ms = DashMpd.durationMs(videos + a, d.durationSec)
        val mpd = DashMpd.build(videos, a, ms) ?: return null
        return Step.Dash(label, mpd, auto, videos.map { it.height }.sorted())
    }

    private fun buildPlan(d: Engine.VideoDetails, pick: Engine.Quality?): List<Step> {
        val steps = ArrayList<Step>()

        if (d.live) {
            val hls = d.hlsUrl
            if (hls != null) {
                steps.add(Step.Hls("Live", hls, false))
                steps.add(Step.Hls("Live", hls, true))
            }
            return steps
        }

        val audio = d.audioUrl
        if (audio != null && d.qualities.isNotEmpty()) {
            // 1) DASH: per potongan; pada mode Otomatis resolusi mengikuti internet.
            if (pick == null) {
                val reps = autoLadder(d)
                if (reps != null) {
                    val st = dashStep(d, "Otomatis", reps, true)
                    if (st != null) steps.add(st)
                }
            } else {
                val r = pick.rep
                if (r != null && r.ranged) {
                    val st = dashStep(d, labelWithCodec(pick), listOf(r), false)
                    if (st != null) steps.add(st)
                }
            }

            // 2) Dua unduhan utuh yang digabung (cara NewPipe, lalu GET biasa).
            val q = pick ?: defaultQuality(d.qualities)
            if (q != null) {
                steps.add(Step.Adaptive(labelWithCodec(q), q.url, audio, false))
                steps.add(Step.Adaptive(labelWithCodec(q), q.url, audio, true))
                // Cadangan: H.264 ≤ 720p (paling kompatibel dan paling ringan).
                val alt = d.qualities.firstOrNull {
                    it !== q && isAvc(it) && it.height <= 720 && it.height <= q.height
                }
                if (alt != null) steps.add(Step.Adaptive(labelWithCodec(alt), alt.url, audio, false))
            }
        }

        val muxed = d.muxedUrl
        if (muxed != null) {
            steps.add(Step.Muxed("${d.muxedHeight}p", muxed, false))
            steps.add(Step.Muxed("${d.muxedHeight}p", muxed, true))
        }

        val hls = d.hlsUrl
        if (hls != null) {
            steps.add(Step.Hls("Otomatis", hls, true))
            steps.add(Step.Hls("Otomatis", hls, false))
        }
        return steps
    }

    private fun playStep(index: Int, startMs: Long) {
        val step = plan[index]
        planIndex = index
        val p = ensurePlayer()
        val factory = YoutubeStreams.factory(step.legacy, context)
        val policy = QuickFailPolicy()

        val source: MediaSource = try {
            when (step) {
                is Step.Dash -> {
                    val manifest = DashManifestParser().parse(
                        Uri.EMPTY,
                        ByteArrayInputStream(step.mpd.toByteArray(Charsets.UTF_8)),
                    )
                    DashMediaSource.Factory(factory)
                        .setLoadErrorHandlingPolicy(policy)
                        .createMediaSource(manifest)
                }
                is Step.Adaptive -> MergingMediaSource(
                    progressive(factory, policy, step.videoUrl),
                    progressive(factory, policy, step.audioUrl),
                )
                is Step.Muxed -> progressive(factory, policy, step.url)
                is Step.Local -> progressive(factory, policy, Uri.fromFile(File(step.path)).toString())
                is Step.Hls -> HlsMediaSource.Factory(factory)
                    .setLoadErrorHandlingPolicy(policy)
                    .createMediaSource(MediaItem.fromUri(step.url))
            }
        } catch (e: Exception) {
            // Manifest/sumber tidak bisa dibuat: coba cadangan berikutnya.
            if (index + 1 < plan.size) {
                playStep(index + 1, startMs)
            } else {
                error = "Video gagal diputar: ${e.message ?: e.javaClass.simpleName}"
            }
            return
        }

        autoMode = step is Step.Dash && step.auto
        ladder = if (step is Step.Dash) step.heights else emptyList()
        selector?.let { ts ->
            ts.setParameters(ts.buildUponParameters().clearVideoSizeConstraints().build())
        }
        activeLabel = step.label
        error = null
        p.setMediaSource(source, startMs)
        p.prepare()
        p.playWhenReady = true
    }

    private fun progressive(
        factory: DataSource.Factory,
        policy: QuickFailPolicy,
        url: String,
    ): MediaSource =
        ProgressiveMediaSource.Factory(factory)
            .setLoadErrorHandlingPolicy(policy)
            .createMediaSource(MediaItem.fromUri(url))

    private fun handleError(e: PlaybackException) {
        val p = exo ?: return
        val resume = if (p.currentPosition < 0L) 0L else p.currentPosition
        if (planIndex + 1 < plan.size) {
            playStep(planIndex + 1, resume)
            return
        }
        val why = e.cause?.message ?: e.message ?: e.errorCodeName
        error = "Video gagal diputar: $why"
    }

    // ---------------- Kontrol ----------------

    fun play() {
        val p = exo ?: return
        if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
        if (p.playbackState == Player.STATE_IDLE) p.prepare()
        p.play()
    }

    fun pause() {
        exo?.pause()
    }

    fun togglePlay() {
        val p = exo ?: return
        if (p.isPlaying) pause() else play()
    }

    fun seekTo(ms: Long) {
        val p = exo ?: return
        p.seekTo(if (ms < 0L) 0L else ms)
        sync()
    }

    fun seekBy(deltaMs: Long) {
        val p = exo ?: return
        var target = p.currentPosition + deltaMs
        if (target < 0L) target = 0L
        val d = p.duration
        if (d != C.TIME_UNSET && d > 0L && target > d) target = d
        p.seekTo(target)
        sync()
    }

    /** [q] null = otomatis (kualitas terbaik sesuai Setelan). */
    fun chooseQuality(q: Engine.Quality?) {
        val d = details ?: return
        chosen = q
        val steps = buildPlan(d, q)
        if (steps.isEmpty()) return
        val resume = positionMs
        plan = steps
        playStep(0, resume)
    }

    fun changeSpeed(s: Float) {
        speed = s
        exo?.playbackParameters = PlaybackParameters(s)
    }

    // ---------------- Komentar ----------------

    fun loadComments() {
        val t = track ?: return
        if (commentsLoaded || commentsLoading) return
        commentsLoading = true
        val url = t.url
        commentJob = scope.launch {
            try {
                val session = withContext(Dispatchers.IO) { Engine.commentSession(url) }
                val first = withContext(Dispatchers.IO) { session.first() }
                if (track?.url == url) {
                    commentSession = session
                    comments = first
                    commentsTotal = session.total
                    commentsDisabled = session.disabled
                    commentsMore = session.hasMore
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Komentar bersifat tambahan: kegagalan tidak mengganggu pemutaran.
            } finally {
                if (track?.url == url) {
                    commentsLoading = false
                    commentsLoaded = true
                }
            }
        }
    }

    fun loadMoreComments() {
        val s = commentSession ?: return
        val url = track?.url ?: return
        if (commentsLoading || !commentsMore) return
        commentsLoading = true
        commentJob = scope.launch {
            try {
                val more = withContext(Dispatchers.IO) { s.more() }
                if (track?.url == url) {
                    comments = comments + more
                    commentsMore = s.hasMore
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (track?.url == url) commentsMore = false
            } finally {
                if (track?.url == url) commentsLoading = false
            }
        }
    }
}
