package app.mixbase.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import app.mixbase.data.Engine
import app.mixbase.data.Store
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.IOException

/**
 * Service pemutar: ExoPlayer + MediaSession (notifikasi, kontrol layar kunci, Bluetooth).
 *
 * Item antrean menyimpan URL HALAMAN (mis. https://www.youtube.com/watch?v=...).
 * URL stream yang sebenarnya diambil lewat NewPipeExtractor tepat sebelum dibuka
 * (ResolvingDataSource), jadi tidak ada URL kedaluwarsa di antrean.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null

    override fun onCreate() {
        super.onCreate()
        Engine.init()

        // User-Agent TIDAK diset di sini: dipasang per alamat stream di resolve(), karena YouTube
        // membatasi/menolak bila identitasnya tidak cocok dengan klien pembuat alamat itu.
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val resolver = ResolvingDataSource.Resolver { spec -> resolve(spec) }
        val dataSourceFactory = ResolvingDataSource.Factory(http, resolver)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        session = MediaSession.Builder(this, player)
            .setCallback(SessionCallback())
            .build()
    }

    /** Dipanggil di thread loader ExoPlayer setiap kali sumber dibuka (termasuk saat seek). */
    private fun resolve(spec: DataSpec): DataSpec {
        val host = spec.uri.host ?: ""
        val isPage = host.endsWith("youtube.com") || host == "youtu.be"
        if (!isPage) return spec

        val hq = getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).getBoolean(Store.KEY_HQ, true)
        val streamUrl = try {
            Engine.resolveAudio(spec.uri.toString(), hq)
        } catch (e: Exception) {
            throw IOException(e.message ?: "Gagal mengambil stream audio", e)
        }
        return spec
            .withUri(Uri.parse(streamUrl))
            .withAdditionalHeaders(mapOf("User-Agent" to Engine.streamUserAgent(streamUrl)))
    }

    /** Pastikan setiap MediaItem dari controller punya URI (diambil dari mediaId = URL halaman). */
    private class SessionCallback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val updated = mediaItems.map { it.buildUpon().setUri(it.mediaId).build() }.toMutableList()
            return Futures.immediateFuture(updated)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
