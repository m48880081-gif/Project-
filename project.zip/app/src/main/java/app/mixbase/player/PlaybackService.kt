package app.mixbase.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.drm.DrmSessionManagerProvider
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import app.mixbase.data.Engine
import app.mixbase.data.Store
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.IOException

/**
 * Service pemutar: ExoPlayer + MediaSession (notifikasi, kontrol layar kunci, Bluetooth).
 *
 * Item antrean menyimpan URL HALAMAN (mediaId = https://www.youtube.com/watch?v=...).
 * URL stream sebenarnya diambil tepat sebelum dibuka (ResolvingDataSource), jadi tidak
 * ada URL kedaluwarsa di antrean:
 *  - mode audio : satu sumber  mixbase://audio/<id>
 *  - mode video : audio + video digabung (MergingMediaSource) supaya bisa 1080p ke atas,
 *                 sumber  mixbase://video/<id>?h=<batas tinggi>  +  mixbase://audio/<id>
 *
 * Kalau pemutaran error: URL dibuang dan dicoba lagi (maks 2x). Kalau tetap gagal,
 * pemutar menampilkan pesan dan melompat ke lagu berikutnya (maks 3 berturut-turut).
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private val retries = HashMap<String, Int>()
    private var skipStreak = 0

    override fun onCreate() {
        super.onCreate()
        Engine.init()

        // User-Agent TIDAK diset di sini: resolver mengisinya per stream
        // (tiap client YouTube butuh User-Agent yang cocok, kalau tidak server membalas 403).
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(25_000)

        val resolver = ResolvingDataSource.Resolver { spec -> resolve(spec) }
        val dataSourceFactory = ResolvingDataSource.Factory(http, resolver)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(MixSourceFactory(dataSourceFactory))
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        player.addListener(
            object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        retries.clear()
                        skipStreak = 0
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    handleError(player, error)
                }
            },
        )

        session = MediaSession.Builder(this, player)
            .setCallback(SessionCallback())
            .build()
    }

    /** Dipanggil di thread loader ExoPlayer setiap kali sumber dibuka (termasuk saat seek). */
    private fun resolve(spec: DataSpec): DataSpec {
        val uri = spec.uri
        if (uri.scheme != SCHEME) return spec

        val id = uri.lastPathSegment ?: throw IOException("URL internal tidak valid: $uri")
        val cand = try {
            if (uri.host == "video") {
                Engine.pickVideo(id, uri.getQueryParameter("h")?.toIntOrNull() ?: 0)
            } else {
                val hq = getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE).getBoolean(Store.KEY_HQ, true)
                Engine.pickAudio(id, hq)
            }
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException(e.message ?: "Gagal mengambil stream", e)
        }
        return spec
            .withUri(Uri.parse(Engine.playUrl(cand)))
            .withAdditionalHeaders(mapOf("User-Agent" to cand.ua))
    }

    private fun handleError(p: ExoPlayer, error: PlaybackException) {
        val id = p.currentMediaItem?.mediaId?.let { Engine.videoIdOf(it) }
        val http = (error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
        val msg: String = error.cause?.message ?: error.message ?: error.errorCodeName
        val resolveFailed = msg.startsWith(Engine.ALL_FAILED_PREFIX)
        val decoderError = when (error.errorCode) {
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            -> true
            else -> false
        }
        Engine.log("ERROR ${error.errorCodeName} http=$http : ${msg.take(200)}")

        // Coba lagi dengan URL baru (URL kedaluwarsa / ditolak 403 / jaringan putus sebentar).
        if (id != null && !resolveFailed) {
            val n = retries[id] ?: 0
            if (n < 2) {
                retries[id] = n + 1
                if (decoderError) Engine.safeVideoOnly = true
                Engine.invalidate(id, http != null)
                Engine.log("coba lagi ke-${n + 1} untuk $id")
                p.prepare()
                return
            }
        }

        Toast.makeText(
            applicationContext,
            "Gagal memutar: ${msg.take(160)}\nDetail: Setelan > Diagnostik",
            Toast.LENGTH_LONG,
        ).show()

        if (p.hasNextMediaItem() && skipStreak < 3) {
            skipStreak += 1
            p.seekToNextMediaItem()
            p.prepare()
            p.play()
        }
    }

    /**
     * Membuat sumber media dari MediaItem. Mode (audio/video) dan batas tinggi dibaca dari
     * extras metadata yang diisi PlayerConnection.
     */
    private class MixSourceFactory(dataSourceFactory: DataSource.Factory) : MediaSource.Factory {

        private val progressive = ProgressiveMediaSource.Factory(dataSourceFactory)

        override fun setDrmSessionManagerProvider(
            drmSessionManagerProvider: DrmSessionManagerProvider,
        ): MediaSource.Factory {
            progressive.setDrmSessionManagerProvider(drmSessionManagerProvider)
            return this
        }

        override fun setLoadErrorHandlingPolicy(
            loadErrorHandlingPolicy: LoadErrorHandlingPolicy,
        ): MediaSource.Factory {
            progressive.setLoadErrorHandlingPolicy(loadErrorHandlingPolicy)
            return this
        }

        override fun getSupportedTypes(): IntArray = progressive.getSupportedTypes()

        override fun createMediaSource(mediaItem: MediaItem): MediaSource {
            val id = Engine.videoIdOf(mediaItem.mediaId)
                ?: return progressive.createMediaSource(mediaItem)

            val extras = mediaItem.mediaMetadata.extras
            val video = extras?.getBoolean(EXTRA_VIDEO, false) ?: false
            val maxH = extras?.getInt(EXTRA_MAXH, 0) ?: 0

            val audioItem = mediaItem.buildUpon().setUri("$SCHEME://audio/$id").build()
            val audioSource = progressive.createMediaSource(audioItem)
            if (!video) return audioSource

            val videoItem = mediaItem.buildUpon().setUri("$SCHEME://video/$id?h=$maxH").build()
            return MergingMediaSource(progressive.createMediaSource(videoItem), audioSource)
        }
    }

    /** Pastikan setiap MediaItem dari controller punya URI (diambil dari mediaId = URL halaman). */
    private class SessionCallback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val updated = mediaItems.map { it.buildUpon().setUri(it.mediaId).build() }.toMutableList()
            return Futures.immediateFuture(updated)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }

    companion object {
        private const val SCHEME = "mixbase"
    }
}
