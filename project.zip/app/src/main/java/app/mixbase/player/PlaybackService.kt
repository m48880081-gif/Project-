package app.mixbase.player

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import app.mixbase.data.Accounts
import app.mixbase.data.Downloads
import app.mixbase.data.Engine
import app.mixbase.data.Store
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/**
 * Service pemutar: ExoPlayer + MediaSession (notifikasi, kontrol layar kunci, Bluetooth).
 *
 * Item antrean menyimpan URL HALAMAN (mis. https://www.youtube.com/watch?v=...).
 * URL stream yang sebenarnya diambil lewat NewPipeExtractor tepat sebelum dibuka
 * (ResolvingDataSource), jadi tidak ada URL kedaluwarsa di antrean.
 */
@OptIn(UnstableApi::class)
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null

    /**
     * Percobaan memutar satu lagu. Bila server menolak (403) pemutar mengulang otomatis dengan
     * cara/stream lain, berurutan: [0] cara NewPipe + stream terbaik, [1] cara NewPipe + stream
     * kedua (alamat baru), [2] GET biasa + stream terbaik, [3] GET biasa + stream kedua.
     * [base] = 2 bila sebelumnya hanya GET biasa yang berhasil (langsung mulai dari sana).
     */
    private class Attempt(val base: Int) {
        @Volatile
        var tries = 0

        val mode: Int
            get() = (base + tries) % 4
    }

    private val attempts = ConcurrentHashMap<String, Attempt>()

    @Volatile
    private var legacyWorks = false

    private val retryListener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            if (!isForbidden(error)) return
            val p = session?.player ?: return
            val id = p.currentMediaItem?.mediaId ?: return
            val a = attempts[id] ?: return
            a.tries += 1
            Engine.forgetAudio(id)
            if (a.tries < 4) {
                p.prepare()
            } else {
                attempts.remove(id)
            }
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState != Player.STATE_READY) return
            val p = session?.player ?: return
            val id = p.currentMediaItem?.mediaId ?: return
            val a = attempts[id] ?: return
            legacyWorks = a.mode >= 2
            if (attempts.size > 40) attempts.clear()
        }
    }

    override fun onCreate() {
        super.onCreate()
        Engine.init()

        // Semua permintaan ke googlevideo.com dibuat mengikuti cara NewPipe (lihat YoutubeStreams):
        // User-Agent tidak diset di pabrik, tetapi per alamat di dalam resolve().
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)

        val resolver = ResolvingDataSource.Resolver { spec -> resolve(spec) }
        // DefaultDataSource: selain alamat http(s), berkas lokal (file://) hasil unduhan ikut bisa dibuka.
        val dataSourceFactory = ResolvingDataSource.Factory(DefaultDataSource.Factory(this, http), resolver)

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val sources = DefaultMediaSourceFactory(dataSourceFactory)
            .setLoadErrorHandlingPolicy(QuickFailPolicy())

        val player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(sources)
            .setAudioAttributes(audioAttributes, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()
        // Pemutar ini hanya untuk suara: bila berkas unduhan berupa video (MP4), gambarnya tidak didekode.
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .build()
        player.addListener(retryListener)

        session = MediaSession.Builder(this, player)
            .setCallback(SessionCallback())
            .build()
    }

    /** Dipanggil di thread loader ExoPlayer setiap kali sumber dibuka (termasuk saat seek). */
    private fun resolve(spec: DataSpec): DataSpec {
        val host = spec.uri.host ?: ""
        val isPage = host.endsWith("youtube.com") || host == "youtu.be"
        if (!isPage) return spec

        val key = spec.uri.toString()

        // Sudah diunduh: putar dari berkas di perangkat (tanpa internet).
        val local = Downloads.localAudio(key)
        if (local != null) return spec.withUri(Uri.fromFile(File(local)))

        val attempt = attempts.getOrPut(key) { Attempt(if (legacyWorks) 2 else 0) }
        val mode = attempt.mode

        val hq = getSharedPreferences(Accounts.prefsName(), Context.MODE_PRIVATE).getBoolean(Store.KEY_HQ, true)
        val streamUrl = try {
            Engine.resolveAudio(key, hq, mode % 2)
        } catch (e: Exception) {
            throw IOException(e.message ?: "Gagal mengambil stream audio", e)
        }
        return YoutubeStreams.prepare(spec.withUri(Uri.parse(streamUrl)), mode >= 2)
    }

    /** Pastikan setiap MediaItem dari controller punya URI (diambil dari mediaId = URL halaman). */
    private class SessionCallback : MediaSession.Callback {
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: MutableList<MediaItem>,
        ): ListenableFuture<MutableList<MediaItem>> {
            val updated = mediaItems.map { it.buildUpon().setUri(it.mediaId).build() }.toMutableList()
            return Futures.immediateFuture(updated)
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
