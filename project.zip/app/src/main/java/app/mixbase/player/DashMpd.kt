package app.mixbase.player

import app.mixbase.data.Engine
import java.util.Locale

/**
 * Menyusun manifest DASH (MPD) dari stream video-saja + audio-saja milik YouTube.
 *
 * Dengan manifest ini ExoPlayer mengunduh video per potongan kecil (berdasarkan indeks sidx/cues
 * yang sudah diberikan YouTube) dan bisa berpindah resolusi di tengah jalan mengikuti kecepatan
 * internet — turun saat tersendat, naik lagi saat lancar. Ini juga cara NewPipe memutar YouTube.
 */
object DashMpd {

    private fun esc(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    /** Durasi terpendek yang diketahui (ms), supaya tidak melewati ujung stream. 0 bila tak diketahui. */
    fun durationMs(reps: List<Engine.Rep>, fallbackSec: Long): Long {
        var best = Long.MAX_VALUE
        for (r in reps) {
            if (r.durationMs > 0L && r.durationMs < best) best = r.durationMs
        }
        if (best != Long.MAX_VALUE) return best
        return if (fallbackSec > 0L) fallbackSec * 1000L else 0L
    }

    private fun appendRep(sb: StringBuilder, r: Engine.Rep, audio: Boolean) {
        sb.append("<Representation id=\"").append(esc(r.id)).append("\"")
        if (r.codec.isNotBlank()) sb.append(" codecs=\"").append(esc(r.codec)).append("\"")
        sb.append(" bandwidth=\"").append(if (r.bandwidth > 0) r.bandwidth else 1000).append("\"")
        if (!audio) {
            if (r.width > 0) sb.append(" width=\"").append(r.width).append("\"")
            if (r.height > 0) sb.append(" height=\"").append(r.height).append("\"")
            if (r.fps > 0) sb.append(" frameRate=\"").append(r.fps).append("\"")
        }
        sb.append(">")
        if (audio) {
            sb.append("<AudioChannelConfiguration")
            sb.append(" schemeIdUri=\"urn:mpeg:dash:23003:3:audio_channel_configuration:2011\"")
            sb.append(" value=\"2\"/>")
        }
        sb.append("<BaseURL>").append(esc(r.url)).append("</BaseURL>")
        sb.append("<SegmentBase indexRange=\"").append(r.indexStart).append("-").append(r.indexEnd).append("\">")
        sb.append("<Initialization range=\"").append(r.initStart).append("-").append(r.initEnd).append("\"/>")
        sb.append("</SegmentBase>")
        sb.append("</Representation>")
    }

    /**
     * [videos] harus berupa satu keluarga codec (mime sama) supaya ExoPlayer bisa berpindah mulus.
     * Hasilnya string XML MPD, atau null bila datanya tidak lengkap.
     */
    fun build(videos: List<Engine.Rep>, audio: Engine.Rep, durationMs: Long): String? {
        if (videos.isEmpty() || durationMs <= 0L) return null
        if (!audio.ranged || videos.any { !it.ranged }) return null

        val seconds = String.format(Locale.US, "%.3f", durationMs / 1000.0)
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
        sb.append("<MPD xmlns=\"urn:mpeg:DASH:schema:MPD:2011\"")
        sb.append(" profiles=\"urn:mpeg:dash:profile:full:2011\"")
        sb.append(" minBufferTime=\"PT1.500S\" type=\"static\"")
        sb.append(" mediaPresentationDuration=\"PT").append(seconds).append("S\">")
        sb.append("<Period id=\"0\" start=\"PT0S\">")

        var setId = 0
        val byMime = videos.groupBy { it.mime }
        for ((mime, group) in byMime) {
            sb.append("<AdaptationSet id=\"").append(setId).append("\"")
            sb.append(" mimeType=\"").append(esc(mime)).append("\"")
            sb.append(" subsegmentAlignment=\"true\" subsegmentStartsWithSAP=\"1\">")
            sb.append("<Role schemeIdUri=\"urn:mpeg:DASH:role:2011\" value=\"main\"/>")
            for (r in group.sortedBy { it.height }) appendRep(sb, r, false)
            sb.append("</AdaptationSet>")
            setId += 1
        }

        sb.append("<AdaptationSet id=\"").append(setId).append("\"")
        sb.append(" mimeType=\"").append(esc(audio.mime)).append("\"")
        sb.append(" subsegmentAlignment=\"true\" subsegmentStartsWithSAP=\"1\">")
        sb.append("<Role schemeIdUri=\"urn:mpeg:DASH:role:2011\" value=\"main\"/>")
        appendRep(sb, audio, true)
        sb.append("</AdaptationSet>")

        sb.append("</Period></MPD>")
        return sb.toString()
    }
}
