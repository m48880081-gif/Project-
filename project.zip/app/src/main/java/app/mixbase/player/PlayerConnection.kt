package app.mixbase.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.TextureView
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.mixbase.data.Engine
import app.mixbase.data.Store
import app.mixbase.data.Track

const val EXTRA_DURATION = "dur"
const val EXTRA_VIDEO = "video"
const val EXTRA_MAXH = "maxh"

/**
 * [video] dan [maxHeight] disimpan di metadata item supaya PlaybackService tahu
 * apakah item ini diputar sebagai audio saja atau audio + video.
 */
fun Track.toMediaItem(video: Boolean = false, maxHeight: Int = 0): MediaItem {
    val extras = Bundle()
    extras.putLong(EXTRA_DURATION, durationSec)
    extras.putBoolean(EXTRA_VIDEO, video)
    extras.putInt(EXTRA_MAXH, maxHeight)
    val meta = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist)
        .setArtworkUri(if (thumb != null) Uri.parse(thumb) else null)
        .setExtras(extras)
        .build()
    return MediaItem.Builder()
        .setMediaId(url)
        .setUri(url)
        .setMediaMetadata(meta)
        .build()
}

fun MediaItem.toTrack(): Track {
    val m = mediaMetadata
    val art = m.artworkUri
    return Track(
        url = mediaId,
        title = m.title?.toString() ?: "",
        artist = m.artist?.toString() ?: "",
        durationSec = m.extras?.getLong(EXTRA_DURATION) ?: 0L,
        thumb = art?.toString(),
    )
}

/**
 * Jembatan antara UI (Compose) dan PlaybackService lewat MediaController.
 * Semua state yang dibaca UI adalah Compose state, jadi UI otomatis ter-update.
 */
class PlayerConnection(private val context: Context) {

    private val prefs = context.applicationContext.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE)

    private var controller: MediaController? = null
    private var connecting = false
    private val pending = ArrayList<(MediaController) -> Unit>()

    /** Dipanggil setiap ada lagu baru mulai diputar (untuk riwayat). */
    var onTrackStarted: ((Track) -> Unit)? = null

    var isPlaying by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var current by mutableStateOf<Track?>(null)
        private set
    var queue by mutableStateOf<List<Track>>(emptyList())
        private set
    var index by mutableIntStateOf(-1)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
        private set

    /** true = antrean diputar sebagai video (audio + video digabung). */
    var videoMode by mutableStateOf(prefs.getBoolean(Store.KEY_VIDEO_MODE, false))
        private set

    /** Batas tinggi video; 0 = otomatis (maks 1080p). */
    var videoHeight by mutableIntStateOf(prefs.getInt(Store.KEY_VIDEO_H, 0))
        private set
    var videoAspect by mutableFloatStateOf(16f / 9f)
        private set
    var videoReady by mutableStateOf(false)
        private set

    /** Tinggi video yang sedang tampil (piksel), 0 kalau belum ada. */
    var videoPx by mutableIntStateOf(0)
        private set

    /** Pesan error pemutar yang sedang aktif (null kalau tidak ada). */
    var playerError by mutableStateOf<String?>(null)
        private set

    private var surfaceOwner: TextureView? = null
    private var appVisible = true

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            if (mediaItem != null) onTrackStarted?.invoke(mediaItem.toTrack())
        }
    }

    fun connect() {
        if (controller != null || connecting) return
        connecting = true
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                connecting = false
                try {
                    val c = future.get()
                    c.addListener(listener)
                    controller = c
                    applyVideoTrack(c)
                    refresh()
                    val todo = ArrayList(pending)
                    pending.clear()
                    for (job in todo) job(c)
                } catch (e: Exception) {
                    Toast.makeText(context, "Pemutar gagal terhubung: ${e.message}", Toast.LENGTH_LONG).show()
                }
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) {
            block(c)
        } else {
            pending.add(block)
            connect()
        }
    }

    private fun item(t: Track): MediaItem = t.toMediaItem(videoMode, videoHeight)

    private fun refresh() {
        val c = controller ?: return
        isPlaying = c.isPlaying
        buffering = c.playbackState == Player.STATE_BUFFERING
        shuffle = c.shuffleModeEnabled
        repeatMode = c.repeatMode
        index = c.currentMediaItemIndex
        current = c.currentMediaItem?.toTrack()
        val d = c.duration
        durationMs = if (d == C.TIME_UNSET || d < 0L) 0L else d
        positionMs = if (c.currentPosition < 0L) 0L else c.currentPosition

        val vs = c.videoSize
        videoReady = vs.width > 0 && vs.height > 0
        videoPx = if (videoReady) vs.height else 0
        if (videoReady) {
            videoAspect = ((vs.width * vs.pixelWidthHeightRatio) / vs.height.toFloat()).coerceIn(0.5f, 2.4f)
        }

        val e = c.playerError
        playerError = if (e == null) {
            null
        } else {
            val why: String = e.cause?.message ?: e.message ?: e.errorCodeName
            "Gagal memutar: " + why.take(220)
        }

        val n = c.mediaItemCount
        val list = ArrayList<Track>(n)
        for (i in 0 until n) list.add(c.getMediaItemAt(i).toTrack())
        queue = list
    }

    /** Dipanggil berkala oleh UI saat sedang memutar, untuk memperbarui posisi. */
    fun tick() {
        val c = controller ?: return
        positionMs = if (c.currentPosition < 0L) 0L else c.currentPosition
        val d = c.duration
        if (d != C.TIME_UNSET && d > 0L) durationMs = d
    }

    // ------------------------------------------------------------ antrean

    /**
     * Putar [tracks] mulai dari [startIndex]. [video] = true/false memaksa mode video/audio
     * (dan mengingatnya); null = pakai mode yang sedang aktif.
     */
    fun playQueue(tracks: List<Track>, startIndex: Int, video: Boolean? = null) {
        if (tracks.isEmpty()) return
        if (video != null && video != videoMode) {
            videoMode = video
            prefs.edit().putBoolean(Store.KEY_VIDEO_MODE, video).apply()
        }
        val items = tracks.map { item(it) }
        withController { c ->
            c.setMediaItems(items, startIndex, 0L)
            c.prepare()
            c.play()
        }
    }

    fun playNext(track: Track) {
        withController { c ->
            if (c.mediaItemCount == 0) {
                c.setMediaItems(listOf(item(track)), 0, 0L)
                c.prepare()
                c.play()
            } else {
                c.addMediaItem(c.currentMediaItemIndex + 1, item(track))
            }
        }
    }

    fun addToQueue(track: Track) {
        withController { c ->
            val wasEmpty = c.mediaItemCount == 0
            c.addMediaItem(item(track))
            if (wasEmpty) {
                c.prepare()
                c.play()
            }
        }
    }

    // --------------------------------------------------------- video / kualitas

    @JvmName("changeVideoMode")
    fun setVideoMode(on: Boolean) {
        if (on == videoMode) return
        videoMode = on
        prefs.edit().putBoolean(Store.KEY_VIDEO_MODE, on).apply()
        reload()
    }

    /** [h] = batas tinggi video (0 = otomatis). */
    @JvmName("changeVideoHeight")
    fun setVideoHeight(h: Int) {
        if (h == videoHeight) return
        videoHeight = h
        prefs.edit().putInt(Store.KEY_VIDEO_H, h).apply()
        if (videoMode) reload()
    }

    /** Bangun ulang seluruh antrean dengan mode/kualitas baru, posisi dipertahankan. */
    private fun reload() {
        withController { c ->
            val n = c.mediaItemCount
            if (n == 0) return@withController
            val items = ArrayList<MediaItem>(n)
            for (i in 0 until n) items.add(item(c.getMediaItemAt(i).toTrack()))
            val idx = c.currentMediaItemIndex.coerceAtLeast(0)
            val pos = c.currentPosition.coerceAtLeast(0L)
            val play = c.playWhenReady
            c.setMediaItems(items, idx, pos)
            c.prepare()
            c.playWhenReady = play
        }
    }

    /** Pasang layar video. Dipanggil oleh VideoSurface saat dibuat. */
    fun attachVideo(tv: TextureView) {
        surfaceOwner = tv
        withController { c ->
            c.setVideoTextureView(tv)
            applyVideoTrack(c)
        }
    }

    fun detachVideo(tv: TextureView) {
        if (surfaceOwner === tv) surfaceOwner = null
        val c = controller ?: return
        c.clearVideoTextureView(tv)
        applyVideoTrack(c)
    }

    /** Aplikasi di layar / di latar belakang. Di latar belakang video dimatikan (hemat kuota). */
    fun setAppVisible(visible: Boolean) {
        appVisible = visible
        val c = controller ?: return
        applyVideoTrack(c)
    }

    private fun applyVideoTrack(c: MediaController) {
        val wantVideo = surfaceOwner != null && appVisible
        val params = c.trackSelectionParameters
        val disabled = params.disabledTrackTypes.contains(C.TRACK_TYPE_VIDEO)
        if (disabled == wantVideo) {
            c.trackSelectionParameters = params.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, !wantVideo)
                .build()
        }
    }

    // --------------------------------------------------------------- kontrol

    /** Coba lagi setelah error: buang URL lama lalu siapkan ulang. */
    fun retry() {
        val id = current?.url?.let { Engine.videoIdOf(it) }
        if (id != null) Engine.invalidate(id, false)
        withController { c ->
            c.prepare()
            c.play()
        }
    }

    fun togglePlay() {
        withController { c ->
            if (c.isPlaying) {
                c.pause()
            } else {
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                c.play()
            }
        }
    }

    fun next() = withController { it.seekToNext() }

    fun previous() = withController { it.seekToPrevious() }

    fun seekTo(ms: Long) = withController { it.seekTo(ms) }

    fun jumpTo(i: Int) {
        withController { c ->
            c.seekToDefaultPosition(i)
            c.play()
        }
    }

    fun removeAt(i: Int) = withController { it.removeMediaItem(i) }

    fun toggleShuffle() {
        withController { c -> c.shuffleModeEnabled = !c.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        withController { c ->
            c.repeatMode = when (c.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
}
