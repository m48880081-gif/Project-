package app.mixbase.player

import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.mixbase.data.Track

private const val EXTRA_DURATION = "dur"
private const val EXTRA_CHANNEL = "ch"

fun Track.toMediaItem(): MediaItem {
    val extras = Bundle()
    extras.putLong(EXTRA_DURATION, durationSec)
    if (uploaderUrl != null) extras.putString(EXTRA_CHANNEL, uploaderUrl)
    val meta = MediaMetadata.Builder()
        .setTitle(title)
        .setArtist(artist)
        .setArtworkUri(if (thumb != null) Uri.parse(thumb) else null)
        .setExtras(extras)
        .build()
    return MediaItem.Builder()
        .setMediaId(url)
        .setUri(url)
        .setMediaMetadata(meta)
        .build()
}

fun MediaItem.toTrack(): Track {
    val m = mediaMetadata
    val art = m.artworkUri
    return Track(
        url = mediaId,
        title = m.title?.toString() ?: "",
        artist = m.artist?.toString() ?: "",
        durationSec = m.extras?.getLong(EXTRA_DURATION) ?: 0L,
        thumb = art?.toString(),
        uploaderUrl = m.extras?.getString(EXTRA_CHANNEL),
    )
}

/**
 * Jembatan antara UI (Compose) dan PlaybackService lewat MediaController.
 * Semua state yang dibaca UI adalah Compose state, jadi UI otomatis ter-update.
 */
class PlayerConnection(private val context: Context) {

    private var controller: MediaController? = null
    private var connecting = false
    private val pending = ArrayList<(MediaController) -> Unit>()

    /** Dipanggil setiap ada lagu baru mulai diputar (untuk riwayat). */
    var onTrackStarted: ((Track) -> Unit)? = null

    /** Dipanggil tepat sebelum musik mulai diputar (mis. untuk menghentikan pemutar video). */
    var onBeforePlay: (() -> Unit)? = null

    var isPlaying by mutableStateOf(false)
        private set
    var buffering by mutableStateOf(false)
        private set
    var current by mutableStateOf<Track?>(null)
        private set
    var queue by mutableStateOf<List<Track>>(emptyList())
        private set
    var index by mutableIntStateOf(-1)
        private set
    var durationMs by mutableLongStateOf(0L)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set
    var shuffle by mutableStateOf(false)
        private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF)
        private set

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            refresh()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            if (mediaItem != null) onTrackStarted?.invoke(mediaItem.toTrack())
        }

        override fun onPlayerError(error: PlaybackException) {
            val why = error.cause?.message ?: error.message ?: error.errorCodeName
            Toast.makeText(context, "Gagal memutar: $why", Toast.LENGTH_LONG).show()
        }
    }

    fun connect() {
        if (controller != null || connecting) return
        connecting = true
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                connecting = false
                try {
                    val c = future.get()
                    c.addListener(listener)
                    controller = c
                    refresh()
                    val todo = ArrayList(pending)
                    pending.clear()
                    for (job in todo) job(c)
                } catch (e: Exception) {
                    Toast.makeText(context, "Pemutar gagal terhubung: ${e.message}", Toast.LENGTH_LONG).show()
                }
            },
            ContextCompat.getMainExecutor(context),
        )
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) {
            block(c)
        } else {
            pending.add(block)
            connect()
        }
    }

    private fun refresh() {
        val c = controller ?: return
        isPlaying = c.isPlaying
        buffering = c.playbackState == Player.STATE_BUFFERING
        shuffle = c.shuffleModeEnabled
        repeatMode = c.repeatMode
        index = c.currentMediaItemIndex
        current = c.currentMediaItem?.toTrack()
        val d = c.duration
        durationMs = if (d == C.TIME_UNSET || d < 0L) 0L else d
        positionMs = if (c.currentPosition < 0L) 0L else c.currentPosition

        val n = c.mediaItemCount
        val list = ArrayList<Track>(n)
        for (i in 0 until n) list.add(c.getMediaItemAt(i).toTrack())
        queue = list
    }

    /** Dipanggil berkala oleh UI saat sedang memutar, untuk memperbarui posisi. */
    fun tick() {
        val c = controller ?: return
        positionMs = if (c.currentPosition < 0L) 0L else c.currentPosition
        val d = c.duration
        if (d != C.TIME_UNSET && d > 0L) durationMs = d
    }

    fun playQueue(tracks: List<Track>, startIndex: Int, startMs: Long = 0L) {
        if (tracks.isEmpty()) return
        onBeforePlay?.invoke()
        val items = tracks.map { it.toMediaItem() }
        withController { c ->
            c.setMediaItems(items, startIndex, startMs)
            c.prepare()
            c.play()
        }
    }

    fun playNext(track: Track) {
        withController { c ->
            if (c.mediaItemCount == 0) {
                c.setMediaItems(listOf(track.toMediaItem()), 0, 0L)
                c.prepare()
                c.play()
            } else {
                c.addMediaItem(c.currentMediaItemIndex + 1, track.toMediaItem())
            }
        }
    }

    fun addToQueue(track: Track) {
        withController { c ->
            val wasEmpty = c.mediaItemCount == 0
            c.addMediaItem(track.toMediaItem())
            if (wasEmpty) {
                c.prepare()
                c.play()
            }
        }
    }

    /** Jeda bila sedang memutar (dipakai saat video mulai). */
    fun pause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause()
    }

    fun togglePlay() {
        withController { c ->
            if (c.isPlaying) {
                c.pause()
            } else {
                if (c.playbackState == Player.STATE_IDLE) c.prepare()
                c.play()
            }
        }
    }

    fun next() = withController { it.seekToNext() }

    fun previous() = withController { it.seekToPrevious() }

    fun seekTo(ms: Long) = withController { it.seekTo(ms) }

    fun jumpTo(i: Int) {
        withController { c ->
            c.seekToDefaultPosition(i)
            c.play()
        }
    }

    fun removeAt(i: Int) = withController { it.removeMediaItem(i) }

    fun toggleShuffle() {
        withController { c -> c.shuffleModeEnabled = !c.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        withController { c ->
            c.repeatMode = when (c.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }
}
