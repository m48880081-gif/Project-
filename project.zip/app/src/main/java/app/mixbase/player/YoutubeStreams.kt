package app.mixbase.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.C
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy
import app.mixbase.data.Engine
import java.util.concurrent.atomic.AtomicLong

/**
 * Cara meminta data ke server video YouTube (googlevideo.com).
 *
 * Aplikasi YouTube/NewPipe tidak sekadar "GET": setiap permintaan ke /videoplayback membawa
 * nomor urut `&rn=`, memakai metode POST dengan isi kecil {0x78, 0x00}, header `TE: trailers`,
 * dan User-Agent yang cocok dengan klien pembuat alamat itu. Permintaan GET polos mudah ditolak
 * (HTTP 403) atau diperlambat — itu penyebab lagu gagal diputar dan video tersendat walau
 * internet kencang. Di sini semua permintaan stream dibuat mengikuti cara NewPipe.
 *
 * Mode [legacy] = GET biasa (cara lama), dipakai hanya sebagai cadangan terakhir bila cara
 * NewPipe ternyata tetap ditolak.
 */
@OptIn(UnstableApi::class)
object YoutubeStreams {

    private val counter = AtomicLong(0L)
    private val POST_BODY = byteArrayOf(0x78, 0x00)

    fun isStreamHost(host: String?): Boolean =
        host != null && (host == "googlevideo.com" || host.endsWith(".googlevideo.com"))

    /** Ubah [spec] menjadi permintaan gaya YouTube. Alamat selain googlevideo dibiarkan. */
    fun prepare(spec: DataSpec, legacy: Boolean): DataSpec {
        val uri = spec.uri
        if (!isStreamHost(uri.host)) return spec

        var url = uri.toString()
        val headers = HashMap<String, String>(spec.httpRequestHeaders)
        headers["User-Agent"] = Engine.streamUserAgent(url)

        if (legacy) {
            return spec.buildUpon().setHttpRequestHeaders(headers).build()
        }

        val path = uri.path ?: ""
        if (path.startsWith("/videoplayback") && uri.query != null && !url.contains("&rn=")) {
            url += "&rn=" + counter.getAndIncrement()
        }

        if (Engine.isWebStream(url)) {
            headers["Origin"] = "https://www.youtube.com"
            headers["Referer"] = "https://www.youtube.com"
            headers["Sec-Fetch-Dest"] = "empty"
            headers["Sec-Fetch-Mode"] = "cors"
            headers["Sec-Fetch-Site"] = "cross-site"
        }
        headers["TE"] = "trailers"

        return spec.buildUpon()
            .setUri(Uri.parse(url))
            .setHttpMethod(DataSpec.HTTP_METHOD_POST)
            .setHttpBody(POST_BODY)
            .setHttpRequestHeaders(headers)
            .build()
    }

    /**
     * Pabrik sumber data untuk stream YouTube. User-Agent TIDAK diset di pabrik: DefaultHttpDataSource
     * akan menimpa header User-Agent per-permintaan dengan nilai pabrik.
     */
    fun factory(legacy: Boolean, context: Context? = null): DataSource.Factory {
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(20_000)
        // Dengan [context], berkas lokal (file://) ikut bisa dibuka — dipakai untuk memutar unduhan.
        val base: DataSource.Factory = if (context != null) DefaultDataSource.Factory(context, http) else http
        val resolver = ResolvingDataSource.Resolver { spec -> prepare(spec, legacy) }
        return ResolvingDataSource.Factory(base, resolver)
    }
}

/** true bila [t] atau penyebabnya adalah penolakan server (HTTP 403 / 410). */
@OptIn(UnstableApi::class)
fun isForbidden(t: Throwable?): Boolean {
    var c: Throwable? = t
    var depth = 0
    while (c != null && depth < 8) {
        if (c is HttpDataSource.InvalidResponseCodeException) {
            val code = c.responseCode
            if (code == 403 || code == 410) return true
        }
        c = c.cause
        depth += 1
    }
    return false
}

/**
 * Kebijakan muat ulang yang langsung menyerah pada 403/410 (mengulang permintaan yang sama
 * tidak akan berhasil); kegagalan lain tetap diulang seperti biasa. Dengan begitu pemutar bisa
 * segera mencoba cara/stream cadangan, bukan menunggu beberapa detik.
 */
@OptIn(UnstableApi::class)
class QuickFailPolicy : DefaultLoadErrorHandlingPolicy() {
    override fun getRetryDelayMsFor(loadErrorInfo: LoadErrorHandlingPolicy.LoadErrorInfo): Long {
        if (isForbidden(loadErrorInfo.exception)) return C.TIME_UNSET
        return super.getRetryDelayMsFor(loadErrorInfo)
    }
}
