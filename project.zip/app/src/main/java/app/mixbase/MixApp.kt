package app.mixbase

import android.app.Application
import app.mixbase.data.Engine
import app.mixbase.player.PlayerConnection
import app.mixbase.player.VideoPlayer

class MixApp : Application() {

    lateinit var player: PlayerConnection
        private set

    lateinit var video: VideoPlayer
        private set

    override fun onCreate() {
        super.onCreate()
        Engine.init()
        player = PlayerConnection(this)
        video = VideoPlayer(this)

        // Hanya satu yang boleh memutar: musik dimulai → video berhenti.
        player.onBeforePlay = { video.stop() }
    }
}
