package app.mixbase

import android.app.Application
import app.mixbase.data.Engine
import app.mixbase.player.PlayerConnection

class MixApp : Application() {

    lateinit var player: PlayerConnection
        private set

    override fun onCreate() {
        super.onCreate()
        Engine.init()
        player = PlayerConnection(this)
    }
}
