package app.mixbase

import android.app.Application
import app.mixbase.data.Accounts
import app.mixbase.data.Downloads
import app.mixbase.data.Engine
import app.mixbase.data.I18n
import app.mixbase.data.Store
import app.mixbase.player.PlayerConnection
import app.mixbase.player.VideoPlayer

class MixApp : Application() {

    lateinit var player: PlayerConnection
        private set

    lateinit var video: VideoPlayer
        private set

    /**
     * Tiga pemutar khusus Shorts, dipakai bergilir: video yang sedang tampil, yang berikutnya (sudah dimuat
     * lebih dulu supaya langsung jalan saat digeser), dan yang sebelumnya. Terpisah dari pemutar halaman tonton.
     */
    lateinit var shorts: List<VideoPlayer>
        private set

    override fun onCreate() {
        super.onCreate()
        Engine.init()
        // Akun dulu: penyimpanan (Store) dan unduhan milik akun yang sedang masuk.
        Accounts.init(this)
        val store = Store(this)
        Engine.setContentLanguage(store.contentLang)
        I18n.lang = store.contentLang
        I18n.translateTitles = store.translateTitles
        Downloads.init(this)
        player = PlayerConnection(this)
        video = VideoPlayer(this)
        shorts = List(3) {
            VideoPlayer(this).also { p ->
                p.heightCap = 720
                p.autoLanguage = false
            }
        }

        // Hanya satu yang boleh memutar: musik dimulai → video dan Shorts berhenti.
        player.onBeforePlay = {
            video.stop()
            for (p in shorts) p.stop()
        }
    }
}
