package app.mixbase

import android.app.Application
import app.mixbase.data.Downloads
import app.mixbase.data.Engine
import app.mixbase.player.PlayerConnection
import app.mixbase.player.VideoPlayer

class MixApp : Application() {

    lateinit var player: PlayerConnection
        private set

    lateinit var video: VideoPlayer
        private set

    /** Pemutar khusus Shorts (terpisah dari pemutar halaman tonton). */
    lateinit var shorts: VideoPlayer
        private set

    override fun onCreate() {
        super.onCreate()
        Engine.init()
        Downloads.init(this)
        player = PlayerConnection(this)
        video = VideoPlayer(this)
        shorts = VideoPlayer(this)

        // Hanya satu yang boleh memutar: musik dimulai → video dan Shorts berhenti.
        player.onBeforePlay = {
            video.stop()
            shorts.stop()
        }
    }
}
