package app.mixbase.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Cadangan data akun ke satu berkas JSON: langganan, favorit, riwayat, riwayat pencarian, setelan, dan
 * daftar unduhan. Berkas audio/video hasil unduhan TIDAK ikut (ukurannya besar); saat dipulihkan di HP lain,
 * unduhan yang berkasnya belum ada dicatat supaya bisa diunduh ulang sekali ketuk (lihat [Downloads.redoAll]).
 *
 * Akun (nama pengguna & sandi) tidak termasuk dalam cadangan.
 */
object Backup {

    private const val APP = "PlayTube"

    /** Isi cadangan akun yang sedang masuk, sebagai teks JSON. */
    fun export(context: Context): String {
        val root = JSONObject()
        root.put("app", APP)
        root.put("version", 1)
        root.put("account", "")
        root.put("time", System.currentTimeMillis())

        val data = JSONObject()
        val sp = context.applicationContext.getSharedPreferences(Accounts.prefsName(), Context.MODE_PRIVATE)
        for ((key, value) in sp.all) {
            if (value == null) continue
            val o = JSONObject()
            when (value) {
                is String -> {
                    o.put("t", "s")
                    o.put("v", value)
                }

                is Int -> {
                    o.put("t", "i")
                    o.put("v", value)
                }

                is Long -> {
                    o.put("t", "l")
                    o.put("v", value)
                }

                is Float -> {
                    o.put("t", "f")
                    o.put("v", value.toDouble())
                }

                is Boolean -> {
                    o.put("t", "b")
                    o.put("v", value)
                }

                else -> continue
            }
            data.put(key, o)
        }
        root.put("data", data)
        return root.toString()
    }

    /**
     * Pulihkan [json] ke akun yang sedang masuk (menimpa data yang sama).
     * @return jumlah item yang dipulihkan, atau -1 bila berkas bukan cadangan PlayTube.
     */
    fun import(context: Context, json: String): Int {
        val root = try {
            JSONObject(json)
        } catch (e: Exception) {
            return -1
        }
        if (root.optString("app") != APP) return -1
        val data = root.optJSONObject("data") ?: return -1

        val ed = context.applicationContext
            .getSharedPreferences(Accounts.prefsName(), Context.MODE_PRIVATE)
            .edit()
        var count = 0
        val keys = data.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val o = data.optJSONObject(key) ?: continue
            when (o.optString("t")) {
                "s" -> {
                    if (key == "dl") {
                        // Unduhan yang berkasnya ada tetap dipakai; sisanya dicatat untuk diunduh ulang.
                        val parts = splitDownloads(o.optString("v"))
                        ed.putString("dl", parts.first)
                        ed.putString("dl_redo", parts.second)
                    } else {
                        ed.putString(key, o.optString("v"))
                    }
                }

                "i" -> ed.putInt(key, o.optInt("v"))
                "l" -> ed.putLong(key, o.optLong("v"))
                "f" -> ed.putFloat(key, o.optDouble("v").toFloat())
                "b" -> ed.putBoolean(key, o.optBoolean("v"))
                else -> continue
            }
            count += 1
        }
        ed.commit()
        return count
    }

    /** Pisahkan daftar unduhan: (yang berkasnya masih ada, yang perlu diunduh ulang). */
    private fun splitDownloads(raw: String): Pair<String, String> {
        val keep = JSONArray()
        val redo = JSONArray()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val path = o.optString("p", "")
                if (path.isNotEmpty() && File(path).exists()) keep.put(o) else redo.put(o)
            }
        } catch (e: Exception) {
            // daftar rusak: abaikan
        }
        return Pair(keep.toString(), redo.toString())
    }
}
