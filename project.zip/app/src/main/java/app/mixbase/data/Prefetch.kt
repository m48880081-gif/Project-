package app.mixbase.data

import android.content.Context

/** Pemanasan alamat stream audio (lihat [Engine.prefetchAudio]) memakai pilihan kualitas yang sedang aktif. */
object Prefetch {
    fun audio(context: Context, urls: List<String>) {
        if (urls.isEmpty()) return
        val hq = context.applicationContext
            .getSharedPreferences(Accounts.prefsName(), Context.MODE_PRIVATE)
            .getBoolean(Store.KEY_HQ, true)
        Engine.prefetchAudio(urls, hq)
    }
}
