package app.mixbase.data

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Satu baris lirik yang bertanda waktu. */
class LyricLine(val timeMs: Long, val text: String)

/** Hasil lirik: [synced] terisi bila lirik berjalan tersedia; [plain] teks biasa. */
class LyricsData(
    val synced: List<LyricLine>,
    val plain: String,
    val instrumental: Boolean,
)

/**
 * Lirik dari LRCLIB (https://lrclib.net) — layanan lirik terbuka tanpa kunci API.
 * NewPipeExtractor tidak menyediakan lirik, jadi diambil terpisah berdasarkan judul + artis.
 */
object Lyrics {

    private const val BASE = "https://lrclib.net/api"
    private const val UA = "PlayTube/0.3 (https://github.com; pemutar pribadi)"

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /** BLOKING (jaringan). Mengembalikan null bila lirik tidak ditemukan. */
    fun fetch(artist: String, title: String, durationSec: Long): LyricsData? {
        val a = cleanArtist(artist)
        val t = cleanTitle(title)
        if (t.isBlank()) return null

        // Judul YouTube sering berbentuk "Artis - Lagu".
        var artistName = a
        var trackName = t
        val dash = t.indexOf(" - ")
        if (dash > 0) {
            artistName = t.substring(0, dash).trim()
            trackName = t.substring(dash + 3).trim()
        }

        // 1) Pencocokan tepat (judul + artis + durasi)
        var found = exact(artistName, trackName, durationSec)
        if (found == null && (artistName != a || trackName != t)) {
            found = exact(a, t, durationSec)
        }
        if (found != null) return found

        // 2) Pencarian longgar
        found = search("$artistName $trackName", durationSec)
        if (found == null && artistName != a) found = search("$a $t", durationSec)
        return found
    }

    private fun exact(artist: String, track: String, durationSec: Long): LyricsData? {
        val b = "$BASE/get".toHttpUrl().newBuilder()
            .addQueryParameter("track_name", track)
            .addQueryParameter("artist_name", artist)
        if (durationSec > 0L) b.addQueryParameter("duration", durationSec.toString())
        val body = get(b.build().toString()) ?: return null
        return try {
            parse(JSONObject(body))
        } catch (e: Exception) {
            null
        }
    }

    private fun search(query: String, durationSec: Long): LyricsData? {
        val url = "$BASE/search".toHttpUrl().newBuilder()
            .addQueryParameter("q", query)
            .build()
            .toString()
        val body = get(url) ?: return null
        return try {
            val arr = JSONArray(body)
            var best: JSONObject? = null
            var bestScore = Long.MAX_VALUE
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val hasText = !o.optString("syncedLyrics", "").isBlank() ||
                    !o.optString("plainLyrics", "").isBlank() ||
                    o.optBoolean("instrumental", false)
                if (!hasText) continue
                val d = o.optDouble("duration", 0.0)
                // Utamakan durasi yang paling dekat; lirik berjalan sedikit diunggulkan.
                var score = if (durationSec > 0L && d > 0.0) {
                    Math.abs(d - durationSec.toDouble()).toLong() * 10L
                } else {
                    50L
                }
                if (o.optString("syncedLyrics", "").isBlank()) score += 5L
                if (score < bestScore) {
                    bestScore = score
                    best = o
                }
            }
            // Durasi terlalu jauh berarti kemungkinan lagu lain.
            if (best == null || (durationSec > 0L && bestScore > 200L)) null else parse(best)
        } catch (e: Exception) {
            null
        }
    }

    private fun get(url: String): String? {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        return try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) null else resp.body?.string()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parse(o: JSONObject): LyricsData? {
        val instrumental = o.optBoolean("instrumental", false)
        val syncedRaw = o.optString("syncedLyrics", "")
        val plain = o.optString("plainLyrics", "")
        val synced = parseSynced(syncedRaw)
        if (!instrumental && synced.isEmpty() && plain.isBlank()) return null
        return LyricsData(synced, plain.trim(), instrumental)
    }

    /** Format LRC: "[mm:ss.xx] teks". Baris dengan beberapa tanda waktu didukung. */
    internal fun parseSynced(raw: String): List<LyricLine> {
        if (raw.isBlank()) return emptyList()
        val tag = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")
        val out = ArrayList<LyricLine>()
        for (line in raw.lines()) {
            val matches = tag.findAll(line).toList()
            if (matches.isEmpty()) continue
            val text = line.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val fracText = m.groupValues[3]
                val frac = if (fracText.isEmpty()) {
                    0L
                } else {
                    // ".5" = 500 ms, ".50" = 500 ms, ".500" = 500 ms
                    (fracText + "00").substring(0, 3).toLong()
                }
                out.add(LyricLine(min * 60_000L + sec * 1000L + frac, text))
            }
        }
        out.sortBy { it.timeMs }
        return out
    }

    private fun cleanArtist(s: String): String {
        var r = s.trim()
        r = r.replace(Regex("(?i)\\s*-\\s*topic$"), "")
        r = r.replace(Regex("(?i)vevo$"), "")
        r = r.replace(Regex("(?i)\\s*official$"), "")
        return r.trim()
    }

    private fun cleanTitle(s: String): String {
        var r = s
        // Buang keterangan dalam kurung: (Official Video), [Lyrics], dst.
        r = r.replace(Regex("\\s*[\\(\\[【][^\\)\\]】]*[\\)\\]】]"), "")
        r = r.replace(Regex("(?i)\\b(official\\s+(music\\s+)?video|official\\s+audio|lyric\\s+video|lyrics?|video\\s+clip|full\\s+movie|mv)\\b"), "")
        r = r.replace(Regex("\\s{2,}"), " ")
        return r.trim().trim('-', '|', ' ')
    }
}
