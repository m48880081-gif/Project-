package app.mixbase.data

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Satu baris lirik yang bertanda waktu. */
class LyricLine(val timeMs: Long, val text: String)

/** Hasil lirik: [synced] terisi bila lirik berjalan tersedia; [plain] teks biasa. */
class LyricsData(
    val synced: List<LyricLine>,
    val plain: String,
    val instrumental: Boolean,
)

/**
 * Lirik dari LRCLIB (https://lrclib.net) — layanan lirik terbuka tanpa kunci API.
 * NewPipeExtractor tidak menyediakan lirik, jadi diambil terpisah berdasarkan judul + artis.
 */
object Lyrics {

    private const val BASE = "https://lrclib.net/api"
    private const val UA = "PlayTube/0.3 (https://github.com; pemutar pribadi)"

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /** Satu kemungkinan pasangan (artis, judul) untuk dicocokkan ke LRCLIB. */
    private class Cand(val artist: String, val track: String)

    /**
     * BLOKING (jaringan). Mengembalikan null bila lirik tidak ditemukan.
     *
     * Metadata lagu dari hasil pencarian, album, dan link bisa berbeda-beda (artis gabungan,
     * judul memakai "feat.", akhiran "- Remastered", durasi kosong). Karena itu ada beberapa
     * varian artis/judul, dan hasil pencarian dinilai dari kemiripan judul, artis, dan durasi,
     * supaya lagu yang sama mendapat lirik yang sama dari mana pun diputar.
     */
    fun fetch(artist: String, title: String, durationSec: Long): LyricsData? {
        val cands = candidates(artist, title)
        if (cands.isEmpty()) return null

        // 1) Pencocokan tepat dengan durasi (paling akurat bila durasi diketahui)
        if (durationSec > 0L) {
            for (c in cands) {
                val r = exact(c.artist, c.track, durationSec)
                if (r != null) return r
            }
        }

        // 2) Pencarian longgar + penilaian
        val pool = collectPool(cands)
        val found = pick(pool, cands, durationSec)
        if (found != null) return found

        // 3) Pencocokan tepat tanpa durasi (versi apa pun)
        for (c in cands) {
            val r = exact(c.artist, c.track, 0L)
            if (r != null) return r
        }

        // 4) Durasi yang diberikan mungkin meleset (mis. dari pemutar): nilai ulang tanpa durasi
        return if (durationSec > 0L) pick(pool, cands, 0L) else null
    }

    private fun candidates(artistIn: String, titleIn: String): List<Cand> {
        val a = cleanArtist(artistIn)
        val t = cleanTitle(titleIn)
        if (t.isBlank()) return emptyList()

        val out = LinkedHashMap<String, Cand>()
        fun add(ar: String, tr: String) {
            val tt = tr.trim()
            if (tt.isBlank()) return
            val key = norm(ar) + "|" + norm(tt)
            if (!out.containsKey(key)) out[key] = Cand(ar.trim(), tt)
        }

        // Judul YouTube sering berbentuk "Artis - Lagu"; tapi "Lagu - Remastered" bukan itu.
        val dash = t.indexOf(" - ")
        var splitArtist = ""
        var splitTrack = ""
        var splitFirst = false
        if (dash > 0) {
            splitArtist = t.substring(0, dash).trim()
            splitTrack = t.substring(dash + 3).trim()
            splitFirst = splitTrack.isNotBlank() && !looksLikeVersion(splitTrack)
        }

        if (splitFirst) {
            add(splitArtist, splitTrack)
            add(firstArtist(splitArtist), splitTrack)
        }
        add(a, t)
        add(firstArtist(a), t)
        if (dash > 0 && !splitFirst) {
            add(a, stripExtras(t))
            add(firstArtist(a), stripExtras(t))
        }
        val base = if (splitFirst) splitTrack else t
        val stripped = stripExtras(base)
        if (stripped != base) {
            val ar = if (splitFirst) splitArtist else a
            add(ar, stripped)
            add(firstArtist(ar), stripped)
        }
        if (a.isNotBlank()) add("", stripped.ifBlank { base })
        return out.values.toList()
    }

    private fun exact(artist: String, track: String, durationSec: Long): LyricsData? {
        // LRCLIB mewajibkan nama artis untuk /get.
        if (artist.isBlank()) return null
        val b = "$BASE/get".toHttpUrl().newBuilder()
            .addQueryParameter("track_name", track)
            .addQueryParameter("artist_name", artist)
        if (durationSec > 0L) b.addQueryParameter("duration", durationSec.toString())
        val body = get(b.build().toString()) ?: return null
        return try {
            parse(JSONObject(body))
        } catch (e: Exception) {
            null
        }
    }

    /** Kumpulkan hasil dari beberapa kueri LRCLIB (tanpa menilai). */
    private fun collectPool(cands: List<Cand>): List<JSONObject> {
        val pool = LinkedHashMap<String, JSONObject>()
        fun collect(url: String) {
            val body = get(url) ?: return
            try {
                val arr = JSONArray(body)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optLong("id", -1L)
                    pool[if (id >= 0L) id.toString() else "n$i-${pool.size}"] = o
                }
            } catch (e: Exception) {
                // abaikan: kueri berikutnya masih bisa berhasil
            }
        }

        val main = cands.first()
        collect(
            "$BASE/search".toHttpUrl().newBuilder()
                .addQueryParameter("track_name", main.track)
                .apply { if (main.artist.isNotBlank()) addQueryParameter("artist_name", main.artist) }
                .build().toString(),
        )
        val queries = LinkedHashSet<String>()
        for (c in cands.take(3)) queries.add((c.artist + " " + c.track).trim())
        for (q in queries.take(2)) {
            collect("$BASE/search".toHttpUrl().newBuilder().addQueryParameter("q", q).build().toString())
        }
        return pool.values.toList()
    }

    /** Pilih hasil yang paling cocok dari [pool] berdasarkan judul, artis, dan durasi. */
    private fun pick(pool: List<JSONObject>, cands: List<Cand>, durationSec: Long): LyricsData? {
        var best: JSONObject? = null
        var bestScore = Double.MAX_VALUE
        for (o in pool) {
            val hasSynced = o.optString("syncedLyrics", "").isNotBlank()
            val hasText = hasSynced ||
                o.optString("plainLyrics", "").isNotBlank() ||
                o.optBoolean("instrumental", false)
            if (!hasText) continue

            val rTitle = o.optString("trackName", "")
            val rArtist = o.optString("artistName", "")
            var tSim = 0.0
            var aOk = false
            for (c in cands) {
                tSim = maxOf(tSim, titleSim(c.track, rTitle))
                if (artistMatches(c.artist, rArtist)) aOk = true
            }
            if (tSim < 0.6) continue

            val d = o.optDouble("duration", 0.0)
            val known = durationSec > 0L && d > 0.0
            val delta = if (known) Math.abs(d - durationSec.toDouble()) else 0.0
            if (known && delta > 25.0) continue
            // Tanpa artis yang cocok, hanya terima bila judul sama persis dan durasi nyaris sama.
            if (!aOk && !(known && delta <= 3.0 && tSim >= 0.99)) continue

            var score = if (known) delta * 10.0 else 50.0
            score += (1.0 - tSim) * 300.0
            if (!aOk) score += 60.0
            if (!hasSynced) score += 15.0
            if (score < bestScore) {
                bestScore = score
                best = o
            }
        }
        return if (best == null) null else parse(best)
    }

    private val VERSION_WORDS = Regex(
        "(?i)^(\\d{4}\\s+)?(remaster|re-master|.*\\bversion\\b|.*\\bedit\\b|live\\b|.*\\bmix\\b|remix|acoustic|instrumental|" +
            "mono|stereo|deluxe|radio|single|original|bonus|demo|extended|reprise|from\\b|ost\\b|.*\\bver\\.?).*",
    )

    private fun looksLikeVersion(s: String): Boolean = VERSION_WORDS.matches(s.trim())

    /** Buang akhiran versi (" - Remastered 2011") dan "feat. ..." dari judul. */
    private fun stripExtras(s: String): String {
        var r = s.replace(Regex("\\s+[-\u2013\u2014]\\s+.*$"), "")
        r = r.replace(Regex("(?i)\\s+(feat\\.?|ft\\.?|featuring)\\s+.*$"), "")
        return r.trim()
    }

    /** Artis pertama dari "A, B & C" / "A feat. B" dan sejenisnya. */
    private fun firstArtist(s: String): String {
        val parts = s.split(
            Regex("(?i)\\s*(,|;|&|/|\\bfeat\\.?(?=\\s)|\\bft\\.?(?=\\s)|\\bfeaturing\\b|\\bwith\\b|\\bx\\b|\\band\\b|\u3001|\u30fb)\\s*"),
        )
        return parts.firstOrNull { it.isNotBlank() }?.trim() ?: s.trim()
    }

    private fun norm(s: String): String {
        val d = java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD)
        return d.replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^\\p{L}\\p{N}]+"), " ")
            .trim()
    }

    private fun titleSim(a: String, b: String): Double {
        val na = norm(a)
        val nb = norm(b)
        if (na.isEmpty() || nb.isEmpty()) return 0.0
        if (na == nb) return 1.0
        val ta = na.split(' ').toSet()
        val tb = nb.split(' ').toSet()
        val uni = ta.union(tb).size.toDouble()
        var j = if (uni == 0.0) 0.0 else ta.intersect(tb).size.toDouble() / uni
        val shorter = if (na.length < nb.length) na else nb
        val longer = if (na.length < nb.length) nb else na
        if (shorter.length >= 3 && longer.contains(shorter)) j = maxOf(j, 0.7)
        return j
    }

    /** Artis kosong dianggap cocok (tidak diketahui); selain itu perlu irisan nama yang cukup. */
    private fun artistMatches(want: String, got: String): Boolean {
        val tw = norm(want).split(' ').filter { it.isNotEmpty() }.toSet()
        if (tw.isEmpty()) return true
        val tg = norm(got).split(' ').filter { it.isNotEmpty() }.toSet()
        if (tg.isEmpty()) return false
        val inter = tw.intersect(tg).size.toDouble()
        return inter > 0.0 && inter / minOf(tw.size, tg.size).toDouble() >= 0.5
    }

    private fun get(url: String): String? {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        return try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) null else resp.body?.string()
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parse(o: JSONObject): LyricsData? {
        val instrumental = o.optBoolean("instrumental", false)
        val syncedRaw = o.optString("syncedLyrics", "")
        val plain = o.optString("plainLyrics", "")
        val synced = parseSynced(syncedRaw)
        if (!instrumental && synced.isEmpty() && plain.isBlank()) return null
        return LyricsData(synced, plain.trim(), instrumental)
    }

    /** Format LRC: "[mm:ss.xx] teks". Baris dengan beberapa tanda waktu didukung. */
    internal fun parseSynced(raw: String): List<LyricLine> {
        if (raw.isBlank()) return emptyList()
        val tag = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")
        val out = ArrayList<LyricLine>()
        for (line in raw.lines()) {
            val matches = tag.findAll(line).toList()
            if (matches.isEmpty()) continue
            val text = line.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val fracText = m.groupValues[3]
                val frac = if (fracText.isEmpty()) {
                    0L
                } else {
                    // ".5" = 500 ms, ".50" = 500 ms, ".500" = 500 ms
                    (fracText + "00").substring(0, 3).toLong()
                }
                out.add(LyricLine(min * 60_000L + sec * 1000L + frac, text))
            }
        }
        out.sortBy { it.timeMs }
        return out
    }

    private fun cleanArtist(s: String): String {
        var r = s.trim()
        r = r.replace(Regex("(?i)\\s*-\\s*topic$"), "")
        r = r.replace(Regex("(?i)vevo$"), "")
        r = r.replace(Regex("(?i)\\s*official$"), "")
        return r.trim()
    }

    private fun cleanTitle(s: String): String {
        var r = s
        // Buang keterangan dalam kurung: (Official Video), [Lyrics], dst.
        r = r.replace(Regex("\\s*[\\(\\[【][^\\)\\]】]*[\\)\\]】]"), "")
        r = r.replace(Regex("(?i)\\b(official\\s+(music\\s+)?video|official\\s+audio|lyric\\s+video|lyrics?|video\\s+clip|full\\s+movie|mv)\\b"), "")
        r = r.replace(Regex("\\s{2,}"), " ")
        return r.trim().trim('-', '|', ' ')
    }
}
