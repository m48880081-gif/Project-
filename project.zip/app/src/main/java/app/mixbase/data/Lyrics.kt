package app.mixbase.data

import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** Satu baris lirik yang bertanda waktu. */
class LyricLine(val timeMs: Long, val text: String)

/** Hasil lirik: [synced] terisi bila lirik berjalan tersedia; [plain] teks biasa. */
class LyricsData(
    val synced: List<LyricLine>,
    val plain: String,
    val instrumental: Boolean,
)

/**
 * Lirik dari LRCLIB (https://lrclib.net) — layanan lirik terbuka tanpa kunci API.
 * NewPipeExtractor tidak menyediakan lirik, jadi diambil terpisah berdasarkan judul + artis.
 *
 * Lagu yang sama bisa datang dari sumber yang berbeda (hasil pencarian, halaman album, antrean) dengan
 * penulisan judul/artis yang sedikit berbeda ("Judul - Remastered", "Artis A, Artis B", "Artis - Topic").
 * Karena itu judul dan artis dinormalkan lebih dulu ([queryOf]) dan kandidat dari LRCLIB dinilai
 * berdasarkan kecocokan judul + artis (durasi hanya pelengkap), sehingga lagu yang sama selalu
 * mendapat lirik yang sama dari sumber mana pun.
 */
object Lyrics {

    private const val BASE = "https://lrclib.net/api"
    private const val UA = "PlayTube/0.3 (https://github.com; pemutar pribadi)"

    /** Nilai minimum agar kandidat pencarian dipakai. */
    private const val MIN_SCORE = 20

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    /** Nama yang dicoba untuk mencari: artis dan judul, masing-masing berurutan dari yang paling mungkin. */
    private class Query(val artists: List<String>, val titles: List<String>)

    /** Kunci identitas lagu: sama untuk lagu yang sama dari sumber mana pun (dipakai untuk cache). */
    fun keyOf(artist: String, title: String): String {
        val q = queryOf(artist, title)
        val a = firstArtist(q.artists.firstOrNull() ?: "")
        val t = q.titles.firstOrNull() ?: ""
        return norm(a) + "|" + norm(t)
    }

    /** BLOKING (jaringan). Mengembalikan null bila lirik tidak ditemukan atau jaringan bermasalah. */
    fun fetch(artist: String, title: String, durationSec: Long): LyricsData? {
        val q = queryOf(artist, title)
        if (q.titles.isEmpty()) return null
        val dur = if (durationSec > 0L) durationSec else 0L
        return try {
            lookup(q, dur)
        } catch (e: IOException) {
            // Jaringan bermasalah: jangan coba puluhan kali, hasilnya tidak disimpan sehingga bisa diulang.
            null
        }
    }

    private fun lookup(q: Query, dur: Long): LyricsData? {
        val artists = q.artists.take(3)
        val titles = q.titles.take(2)

        // 1) Pencocokan tepat (judul + artis + durasi)
        for (t in titles) {
            for (a in artists) {
                exact(a, t, dur)?.let { return it }
            }
        }

        // 2) Pencarian berparameter: judul harus cocok, artis dan durasi jadi nilai tambah
        for (t in titles) {
            val params = ArrayList<Pair<String, String>>()
            params.add("track_name" to t)
            val a = artists.firstOrNull()
            if (a != null) params.add("artist_name" to a)
            search(params, q, dur)?.let { return it }
        }

        // 3) Pencocokan tepat tanpa durasi (rekaman lain dari lagu yang sama)
        if (dur > 0L) {
            for (t in titles) {
                for (a in artists) {
                    exact(a, t, 0L)?.let { return it }
                }
            }
        }

        // 4) Pencarian bebas
        val a0 = artists.firstOrNull() ?: ""
        for (t in titles) {
            val text = if (a0.isEmpty()) t else "$a0 $t"
            search(listOf("q" to text), q, dur)?.let { return it }
        }
        if (a0.isNotEmpty()) {
            search(listOf("q" to titles.first()), q, dur)?.let { return it }
        }
        return null
    }

    private fun exact(artist: String, track: String, durationSec: Long): LyricsData? {
        if (artist.isBlank() || track.isBlank()) return null
        val b = "$BASE/get".toHttpUrl().newBuilder()
            .addQueryParameter("track_name", track)
            .addQueryParameter("artist_name", artist)
        if (durationSec > 0L) b.addQueryParameter("duration", durationSec.toString())
        val body = get(b.build().toString()) ?: return null
        return try {
            parse(JSONObject(body))
        } catch (e: Exception) {
            null
        }
    }

    private fun search(params: List<Pair<String, String>>, q: Query, dur: Long): LyricsData? {
        val b = "$BASE/search".toHttpUrl().newBuilder()
        for (p in params) b.addQueryParameter(p.first, p.second)
        val body = get(b.build().toString()) ?: return null
        return try {
            val arr = JSONArray(body)
            var best: JSONObject? = null
            var bestScore = Int.MIN_VALUE
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val s = score(o, q, dur) ?: continue
                if (s > bestScore) {
                    bestScore = s
                    best = o
                }
            }
            val pick = best
            if (pick == null || bestScore < MIN_SCORE) null else parse(pick)
        } catch (e: Exception) {
            null
        }
    }

    /** Nilai kandidat; null bila bukan lagu yang dicari atau tidak punya lirik. */
    private fun score(o: JSONObject, q: Query, dur: Long): Int? {
        val synced = o.optString("syncedLyrics", "")
        val plain = o.optString("plainLyrics", "")
        val instrumental = o.optBoolean("instrumental", false)
        if (synced.isBlank() && plain.isBlank() && !instrumental) return null

        val trackName = o.optString("trackName", "")
        val artistName = o.optString("artistName", "")
        if (q.titles.none { sameTitle(it, trackName) }) return null

        var s = 0
        s += if (q.artists.any { sameName(it, artistName) }) 100 else -40
        if (synced.isNotBlank()) s += 40
        val d = o.optDouble("duration", 0.0)
        if (dur > 0L && d > 0.0) {
            val diff = Math.abs(d - dur.toDouble())
            s += if (diff <= 2.0) 30 else -(Math.min(diff, 40.0) * 2.0).toInt()
        }
        return s
    }

    /** Null untuk jawaban tidak berhasil (mis. 404); IOException bila jaringan gagal. */
    private fun get(url: String): String? {
        val req = Request.Builder().url(url).header("User-Agent", UA).build()
        return client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) null else resp.body?.string()
        }
    }

    private fun parse(o: JSONObject): LyricsData? {
        val instrumental = o.optBoolean("instrumental", false)
        val syncedRaw = o.optString("syncedLyrics", "")
        val plain = o.optString("plainLyrics", "")
        val synced = parseSynced(syncedRaw)
        if (!instrumental && synced.isEmpty() && plain.isBlank()) return null
        return LyricsData(synced, plain.trim(), instrumental)
    }

    /** Format LRC: "[mm:ss.xx] teks". Baris dengan beberapa tanda waktu didukung. */
    internal fun parseSynced(raw: String): List<LyricLine> {
        if (raw.isBlank()) return emptyList()
        val tag = Regex("\\[(\\d{1,3}):(\\d{2})(?:[.:](\\d{1,3}))?]")
        val out = ArrayList<LyricLine>()
        for (line in raw.lines()) {
            val matches = tag.findAll(line).toList()
            if (matches.isEmpty()) continue
            val text = line.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val fracText = m.groupValues[3]
                val frac = if (fracText.isEmpty()) {
                    0L
                } else {
                    // ".5" = 500 ms, ".50" = 500 ms, ".500" = 500 ms
                    (fracText + "00").substring(0, 3).toLong()
                }
                out.add(LyricLine(min * 60_000L + sec * 1000L + frac, text))
            }
        }
        out.sortBy { it.timeMs }
        return out
    }

    // ---------------- Normalisasi nama ----------------

    private val TITLE_SUFFIX = Regex(
        "(?i)\\s+-\\s+(remaster(ed)?\\b.*|\\d{4}\\s+remaster(ed)?\\b.*|" +
            "live(\\s+(at|in|from|version|session|on|\\d)\\b.*)?|.*\\b(version|edit|mix|remix)|mono|stereo|acoustic\\b.*)$",
    )
    private val FEAT = Regex("(?i)\\s+(feat\\.?|ft\\.?|featuring)\\s+.*$")
    private val NOISE = Regex(
        "(?i)\\b(official\\s+(music\\s+)?video|official\\s+audio|lyric\\s+video|lyrics?|video\\s+clip|full\\s+movie|mv)\\b",
    )
    private val ARTIST_SPLIT = Regex(
        "\\s*(?:,|;|/|&|\\+|\\bfeat\\.?|\\bft\\.?|\\bfeaturing\\b|\\bx\\b|\\bdan\\b|\\band\\b)\\s*",
        RegexOption.IGNORE_CASE,
    )

    /** Nama artis, judul, dan variannya yang akan dicoba. */
    private fun queryOf(artist: String, title: String): Query {
        val full = cleanArtist(artist)
        val artists = ArrayList<String>()
        if (full.isNotBlank()) artists.add(full)
        val first = firstArtist(full)
        if (first.isNotBlank() && !artists.contains(first)) artists.add(first)

        val t = cleanTitle(title)
        val titles = ArrayList<String>()
        val dash = t.indexOf(" - ")
        if (dash > 0) {
            val left = t.substring(0, dash).trim()
            val right = t.substring(dash + 3).trim()
            when {
                left.isEmpty() || right.isEmpty() -> titles.add(t.replace(" - ", " ").trim())
                artists.any { sameName(it, left) } -> titles.add(right)
                artists.any { sameName(it, right) } -> titles.add(left)
                artists.isEmpty() -> {
                    artists.add(left)
                    titles.add(right)
                }
                else -> {
                    // Bisa "Artis - Lagu" (artis berbeda dari pengunggah) atau judul yang memang memuat tanda "-".
                    artists.add(0, left)
                    titles.add(right)
                    titles.add(t)
                }
            }
        } else {
            titles.add(t)
        }
        titles.removeAll { it.isBlank() }
        return Query(artists, titles.distinct())
    }

    private fun firstArtist(s: String): String =
        s.split(ARTIST_SPLIT).firstOrNull { it.isNotBlank() }?.trim() ?: ""

    private fun cleanArtist(s: String): String {
        var r = s.trim()
        r = r.replace(Regex("(?i)\\s*-\\s*topic$"), "")
        r = r.replace(Regex("(?i)vevo$"), "")
        r = r.replace(Regex("(?i)\\s*official$"), "")
        return r.trim()
    }

    private fun cleanTitle(s: String): String {
        var r = s.replace('–', '-').replace('—', '-')
        // Buang keterangan dalam kurung: (Official Video), [Lyrics], (Remastered), dst.
        r = r.replace(Regex("\\s*[\\(\\[【][^\\)\\]】]*[\\)\\]】]"), "")
        // Buang akhiran versi: " - Remastered 2011", " - Live at ...", " - Radio Edit"
        r = r.replace(TITLE_SUFFIX, "")
        r = r.replace(FEAT, "")
        r = r.replace(NOISE, "")
        r = r.replace(Regex("\\s{2,}"), " ")
        return r.trim().trim('-', '|', ' ')
    }

    private fun norm(s: String): String =
        s.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()

    /** Nama artis dianggap sama bila salah satunya memuat yang lain ("Dewa 19" ~ "Dewa 19 Ahmad Dhani"). */
    private fun sameName(a: String, b: String): Boolean {
        val x = norm(a)
        val y = norm(b)
        if (x.isEmpty() || y.isEmpty()) return false
        return x == y || x.contains(y) || y.contains(x)
    }

    /** Judul dianggap sama bila persis atau salah satunya memuat yang lain dengan panjang yang sepadan. */
    private fun sameTitle(a: String, b: String): Boolean {
        val x = norm(cleanTitle(a))
        val y = norm(cleanTitle(b))
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        val shorter = if (x.length <= y.length) x else y
        val longer = if (x.length <= y.length) y else x
        return shorter.length >= 4 && longer.contains(shorter) &&
            shorter.length.toDouble() / longer.length.toDouble() >= 0.6
    }
}
