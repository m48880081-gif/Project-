package app.mixbase.data

import android.media.MediaCodecList
import android.net.Uri
import android.util.Log
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.search.SearchExtractor
import org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper
import org.schabi.newpipe.extractor.stream.AudioTrackType
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.stream.VideoStream
import org.schabi.newpipe.extractor.Page as ExtractorPage
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * Pembungkus NewPipeExtractor: inisialisasi, pencarian, saran pencarian, dan
 * pengambilan stream audio/video.
 *
 * Pengambilan stream memakai BEBERAPA JALUR berurutan (extractor NewPipe lalu client
 * ANDROID_VR langsung). Jalur yang berhasil terakhir dicoba lebih dulu. Setiap hasil
 * dites dulu (request kecil ke server video) supaya URL yang ditolak (403) tidak
 * sampai ke pemutar. Semua langkah dicatat di log (Setelan > Diagnostik).
 */
object Engine {

    const val FILTER_MUSIC = "music_songs"
    const val FILTER_VIDEO = "videos"

    /** Awalan pesan saat semua jalur gagal (dipakai PlaybackService untuk mengenalinya). */
    const val ALL_FAILED_PREFIX = "Semua jalur gagal"

    private const val SERVICE_NAME = "YouTube"
    private const val CACHE_MS = 15L * 60L * 1000L
    private const val DEFAULT_MAX_HEIGHT = 1080

    private const val VR_VERSION = "1.65.10"
    private const val VR_UA =
        "com.google.android.apps.youtube.vr.oculus/1.65.10 " +
            "(Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip"

    private val STRATEGIES = listOf("extractor", "android_vr")
    private val CODEC_RE = Regex("codecs=\"([^\"]+)\"")

    /** Satu stream yang bisa dibuka pemutar. */
    class Cand(
        val url: String,
        val mime: String,
        val bitrate: Int,
        val height: Int,
        val fps: Int,
        val codec: String,
        val ua: String,
    )

    private class Resolved(
        val via: String,
        val at: Long,
        val audio: List<Cand>,
        val video: List<Cand>,
        val muxed: List<Cand>,
    )

    private val cache = HashMap<String, Resolved>()
    private val blocked = HashMap<String, MutableSet<String>>()
    private val locks = ConcurrentHashMap<String, Any>()
    private val decoderCache = HashMap<String, Boolean>()
    private val rn = AtomicInteger(0)

    @Volatile
    private var lastGood: String? = null

    /** Jadi true kalau decoder video error; setelah itu hanya H.264 yang dipilih. */
    @Volatile
    var safeVideoOnly = false

    @Volatile
    private var ready = false

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    fun init() {
        if (ready) return
        synchronized(this) {
            if (ready) return
            NewPipe.init(AppDownloader(), Localization("id", "ID"), ContentCountry("ID"))
            ready = true
        }
    }

    private fun service() = NewPipe.getService(SERVICE_NAME)

    // ------------------------------------------------------------------ log

    private val logLines = ArrayDeque<String>()

    fun log(msg: String) {
        Log.d("MixEngine", msg)
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        synchronized(logLines) {
            logLines.addLast("$stamp $msg")
            while (logLines.size > 120) logLines.removeFirst()
        }
    }

    fun logText(): String = synchronized(logLines) { logLines.joinToString("\n") }

    fun clearLog() {
        synchronized(logLines) { logLines.clear() }
    }

    private fun brief(e: Throwable): String =
        (e.message ?: e.javaClass.simpleName).replace('\n', ' ').take(180)

    // ------------------------------------------------------------- pencarian

    /** Saran pencarian untuk teks yang sedang diketik. */
    fun suggestions(query: String): List<String> {
        init()
        val list: List<String> = service().getSuggestionExtractor().suggestionList(query)
        return list.take(8)
    }

    /** Mulai sesi pencarian baru. Panggil [SearchSession.first], lalu [SearchSession.more]. */
    fun newSearch(query: String, filter: String): SearchSession {
        init()
        val extractor = service().getSearchExtractor(query, listOf(filter), "")
        return SearchSession(extractor)
    }

    class SearchSession internal constructor(private val extractor: SearchExtractor) {

        private var next: ExtractorPage? = null

        var hasMore: Boolean = false
            private set

        fun first(): List<Track> {
            extractor.fetchPage()
            return consume(extractor.getInitialPage())
        }

        fun more(): List<Track> {
            val page = next ?: return emptyList()
            return consume(extractor.getPage(page))
        }

        private fun consume(page: ListExtractor.InfoItemsPage<InfoItem>): List<Track> {
            next = page.getNextPage()
            hasMore = next != null
            val out = ArrayList<Track>()
            for (item in page.getItems()) {
                val t = toTrack(item)
                if (t != null) out.add(t)
            }
            return out
        }
    }

    private fun toTrack(item: InfoItem): Track? {
        if (item !is StreamInfoItem) return null
        val type = item.getStreamType()
        if (type == StreamType.LIVE_STREAM || type == StreamType.AUDIO_LIVE_STREAM) return null

        var thumb: String? = null
        var bestHeight = -1
        for (img in item.getThumbnails()) {
            if (img.getHeight() >= bestHeight) {
                bestHeight = img.getHeight()
                thumb = img.getUrl()
            }
        }
        return Track(
            url = item.getUrl(),
            title = item.getName() ?: "",
            artist = item.getUploaderName() ?: "",
            durationSec = item.getDuration(),
            thumb = thumb,
        )
    }

    // ------------------------------------------------------------ video ID

    private val ID_RE = Regex("^[A-Za-z0-9_-]{6,20}$")

    /** Ambil ID video dari URL YouTube (watch?v=, youtu.be, shorts, embed). */
    fun videoIdOf(url: String): String? {
        val uri = try {
            Uri.parse(url)
        } catch (e: Exception) {
            return null
        }
        val host = uri.host ?: return null
        val id: String? = when {
            host == "youtu.be" -> uri.lastPathSegment
            host.endsWith("youtube.com") -> {
                val v = uri.getQueryParameter("v")
                if (v != null) {
                    v
                } else {
                    val seg = uri.pathSegments
                    if (seg.size >= 2 && (seg[0] == "shorts" || seg[0] == "embed" || seg[0] == "live")) seg[1] else null
                }
            }
            else -> null
        }
        return if (id != null && ID_RE.matches(id)) id else null
    }

    // ------------------------------------------------------ resolusi stream

    private fun order(id: String): List<String> {
        val bad: Set<String> = synchronized(cache) { blocked[id]?.toSet() ?: emptySet() }
        val last = lastGood
        val base = if (last != null) listOf(last) + STRATEGIES.filter { it != last } else STRATEGIES
        return base.filter { it !in bad } + base.filter { it in bad }
    }

    private fun fresh(r: Resolved?): Boolean =
        r != null && System.currentTimeMillis() - r.at < CACHE_MS

    /** BLOKING (jaringan). Dipanggil dari thread loader ExoPlayer. */
    private fun resolve(id: String): Resolved {
        init()
        synchronized(cache) {
            val c = cache[id]
            if (c != null && fresh(c)) return c
        }
        val lock = locks.getOrPut(id) { Any() }
        synchronized(lock) {
            synchronized(cache) {
                val c = cache[id]
                if (c != null && fresh(c)) return c
            }
            val errors = ArrayList<String>()
            for (name in order(id)) {
                val t0 = System.currentTimeMillis()
                try {
                    val r = fetchWith(name, id)
                    if (r.audio.isEmpty() && r.muxed.isEmpty()) {
                        throw IOException("tidak ada stream audio")
                    }
                    val target = r.audio.maxByOrNull { it.bitrate } ?: r.muxed.first()
                    if (!probe(target)) {
                        throw IOException("server video menolak URL (HTTP 4xx)")
                    }
                    synchronized(cache) { cache[id] = r }
                    lastGood = name
                    log(
                        "OK $id via $name: audio=${r.audio.size} video=${r.video.size} " +
                            "muxed=${r.muxed.size} (${System.currentTimeMillis() - t0} ms)",
                    )
                    return r
                } catch (e: Exception) {
                    val msg = brief(e)
                    errors.add("$name: $msg")
                    log("GAGAL $id via $name: $msg")
                }
            }
            throw IOException(ALL_FAILED_PREFIX + " — " + errors.joinToString("; "))
        }
    }

    /** Buang cache video ini. Kalau [blame], jalur yang dipakai ditandai buruk untuk video ini. */
    fun invalidate(id: String, blame: Boolean) {
        synchronized(cache) {
            val r = cache.remove(id)
            if (blame && r != null) {
                blocked.getOrPut(id) { HashSet() }.add(r.via)
                log("Jalur ${r.via} ditandai buruk untuk $id")
            }
        }
    }

    private fun fetchWith(name: String, id: String): Resolved =
        if (name == "android_vr") fetchAndroidVr(id) else fetchExtractor(id)

    // ---- Jalur 1: NewPipeExtractor

    private fun uaFor(url: String): String = when {
        YoutubeParsingHelper.isVisionOsStreamingUrl(url) -> YoutubeParsingHelper.getVisionOsUserAgent(null)
        url.contains("c=ANDROID_VR") -> VR_UA
        else -> AppDownloader.USER_AGENT
    }

    private fun toCand(v: VideoStream): Cand? {
        if (!v.isUrl() || v.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) return null
        val url: String = v.getContent()
        val mime: String = v.getFormat()?.getMimeType() ?: "video/mp4"
        val codec: String = v.getCodec() ?: ""
        return Cand(url, mime, v.getBitrate(), v.getHeight(), v.getFps(), codec, uaFor(url))
    }

    private fun fetchExtractor(id: String): Resolved {
        val ex = service().getStreamExtractor("https://www.youtube.com/watch?v=$id")
        ex.fetchPage()

        val mainAudio = ArrayList<Cand>()
        val altAudio = ArrayList<Cand>()
        for (s in ex.getAudioStreams()) {
            if (!s.isUrl() || s.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue
            val url: String = s.getContent()
            val br = if (s.getAverageBitrate() > 0) s.getAverageBitrate() else s.getBitrate()
            val mime: String = s.getFormat()?.getMimeType() ?: "audio/mp4"
            val codec: String = s.getCodec() ?: ""
            val c = Cand(url, mime, br, 0, 0, codec, uaFor(url))
            val type = s.getAudioTrackType()
            if (type == AudioTrackType.DUBBED || type == AudioTrackType.DESCRIPTIVE) {
                altAudio.add(c)
            } else {
                mainAudio.add(c)
            }
        }

        val video = ArrayList<Cand>()
        for (v in ex.getVideoOnlyStreams()) {
            val c = toCand(v)
            if (c != null) video.add(c)
        }
        val muxed = ArrayList<Cand>()
        for (v in ex.getVideoStreams()) {
            if (v.isVideoOnly()) continue
            val c = toCand(v)
            if (c != null) muxed.add(c)
        }

        val audio: List<Cand> = if (mainAudio.isNotEmpty()) mainAudio else altAudio
        return Resolved("extractor", System.currentTimeMillis(), audio, video, muxed)
    }

    // ---- Jalur 2: client ANDROID_VR langsung ke InnerTube

    private fun objs(arr: JSONArray?): List<JSONObject> {
        val out = ArrayList<JSONObject>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            if (o != null) out.add(o)
        }
        return out
    }

    private fun vrCand(o: JSONObject): Cand? {
        val url = o.optString("url", "")
        if (url.isEmpty()) return null
        val full = o.optString("mimeType", "")
        val mime = full.substringBefore(';').trim()
        val codec = CODEC_RE.find(full)?.groupValues?.get(1) ?: ""
        val avg = o.optInt("averageBitrate", 0)
        val br = if (avg > 0) avg else o.optInt("bitrate", 0)
        return Cand(url, mime, br, o.optInt("height", 0), o.optInt("fps", 0), codec, VR_UA)
    }

    private fun isAltAudio(o: JSONObject, url: String): Boolean {
        val decoded = Uri.decode(url)
        if (decoded.contains("acont=dubbed") || decoded.contains("acont=descriptive")) return true
        val track = o.optJSONObject("audioTrack") ?: return false
        return !track.optBoolean("audioIsDefault", true)
    }

    private fun fetchAndroidVr(id: String): Resolved {
        val client = JSONObject()
            .put("clientName", "ANDROID_VR")
            .put("clientVersion", VR_VERSION)
            .put("deviceMake", "Oculus")
            .put("deviceModel", "Quest 3")
            .put("osName", "Android")
            .put("osVersion", "12L")
            .put("androidSdkVersion", 32)
            .put("hl", "id")
            .put("gl", "ID")
            .put("userAgent", VR_UA)
        val context = JSONObject()
            .put("client", client)
            .put("user", JSONObject().put("lockedSafetyMode", false))
            .put("request", JSONObject().put("useSsl", true))
        val body = JSONObject()
            .put("context", context)
            .put("videoId", id)
            .put("contentCheckOk", true)
            .put("racyCheckOk", true)
            .put(
                "playbackContext",
                JSONObject().put(
                    "contentPlaybackContext",
                    JSONObject().put("html5Preference", "HTML5_PREF_WANTS"),
                ),
            )

        val req = Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .header("User-Agent", VR_UA)
            .header("X-YouTube-Client-Name", "28")
            .header("X-YouTube-Client-Version", VR_VERSION)
            .header("Origin", "https://www.youtube.com")
            .header("Accept-Language", "id-ID,id;q=0.9,en;q=0.8")
            .build()

        val text: String = http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            r.body?.string() ?: throw IOException("respons kosong")
        }

        val root = JSONObject(text)
        val ps = root.optJSONObject("playabilityStatus")
        val status = ps?.optString("status", "") ?: ""
        if (status != "OK") {
            throw IOException("Got error $status: \"${ps?.optString("reason", "") ?: ""}\"")
        }
        val gotId = root.optJSONObject("videoDetails")?.optString("videoId", "") ?: ""
        if (gotId != id) throw IOException("respons YouTube tidak cocok dengan video yang diminta")
        val sd = root.optJSONObject("streamingData") ?: throw IOException("tidak ada streamingData")

        val mainAudio = ArrayList<Cand>()
        val altAudio = ArrayList<Cand>()
        val video = ArrayList<Cand>()
        for (o in objs(sd.optJSONArray("adaptiveFormats"))) {
            val c = vrCand(o) ?: continue
            if (c.mime.startsWith("audio/")) {
                if (isAltAudio(o, c.url)) altAudio.add(c) else mainAudio.add(c)
            } else if (c.mime.startsWith("video/") && c.height > 0) {
                video.add(c)
            }
        }
        val muxed = ArrayList<Cand>()
        for (o in objs(sd.optJSONArray("formats"))) {
            val c = vrCand(o) ?: continue
            if (c.mime.startsWith("video/") && c.height > 0) muxed.add(c)
        }

        val audio: List<Cand> = if (mainAudio.isNotEmpty()) mainAudio else altAudio
        return Resolved("android_vr", System.currentTimeMillis(), audio, video, muxed)
    }

    // -------------------------------------------------------------- tes URL

    /** URL yang benar-benar dibuka pemutar (ditambah parameter rn seperti NewPipe). */
    fun playUrl(c: Cand): String {
        val u = c.url
        return if (u.contains("videoplayback") && !u.contains("&rn=") && !u.contains("?rn=")) {
            u + "&rn=" + rn.incrementAndGet()
        } else {
            u
        }
    }

    /** false hanya kalau server jelas menolak (HTTP 4xx). Error jaringan dianggap lolos. */
    private fun probe(c: Cand): Boolean {
        return try {
            val req = Request.Builder()
                .url(playUrl(c))
                .header("User-Agent", c.ua)
                .header("Range", "bytes=0-1")
                .build()
            http.newCall(req).execute().use { r ->
                if (r.code in 400..499) {
                    log("tes URL stream: HTTP ${r.code}")
                    false
                } else {
                    true
                }
            }
        } catch (e: Exception) {
            log("tes URL stream error (diabaikan): ${brief(e)}")
            true
        }
    }

    // ---------------------------------------------------------------- pilihan

    private fun decoderExists(codec: String): Boolean {
        val mime = when {
            codec.startsWith("avc1") || codec.startsWith("avc3") -> "video/avc"
            codec.startsWith("vp09") || codec.startsWith("vp9") -> "video/x-vnd.on2.vp9"
            codec.startsWith("av01") -> "video/av01"
            codec.startsWith("hev1") || codec.startsWith("hvc1") -> "video/hevc"
            else -> return true
        }
        synchronized(decoderCache) {
            val known = decoderCache[mime]
            if (known != null) return known
            val ok = try {
                MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.any { info ->
                    !info.isEncoder && info.supportedTypes.any { t -> t.equals(mime, ignoreCase = true) }
                }
            } catch (e: Exception) {
                true
            }
            decoderCache[mime] = ok
            return ok
        }
    }

    private fun codecRank(codec: String): Int = when {
        codec.startsWith("avc") -> 0
        codec.startsWith("vp09") || codec.startsWith("vp9") -> 1
        codec.startsWith("hev1") || codec.startsWith("hvc1") -> 2
        codec.startsWith("av01") -> 3
        else -> 4
    }

    /** Stream audio terbaik (atau terhemat) untuk video [id]. BLOKING. */
    fun pickAudio(id: String, high: Boolean): Cand {
        val r = resolve(id)
        val list = if (r.audio.isNotEmpty()) r.audio else r.muxed
        if (list.isEmpty()) throw IOException("Tidak ada stream audio")
        val sorted = list.sortedBy { it.bitrate }
        return if (high) sorted.last() else sorted.first()
    }

    /** Stream video terbaik dengan tinggi <= [maxHeight] (0 = otomatis, maks 1080p). BLOKING. */
    fun pickVideo(id: String, maxHeight: Int): Cand {
        val r = resolve(id)
        val pool = if (r.video.isNotEmpty()) r.video else r.muxed
        if (pool.isEmpty()) throw IOException("Tidak ada stream video")
        val cap = if (maxHeight <= 0) DEFAULT_MAX_HEIGHT else maxHeight

        var usable = pool.filter {
            decoderExists(it.codec) && (!safeVideoOnly || it.codec.isEmpty() || it.codec.startsWith("avc"))
        }
        if (usable.isEmpty()) usable = pool

        val within = usable.filter { it.height in 1..cap }
        val list: List<Cand> = if (within.isNotEmpty()) {
            within
        } else {
            listOf(usable.minByOrNull { it.height } ?: usable.first())
        }
        return list.sortedWith(
            compareByDescending<Cand> { it.height }
                .thenBy { codecRank(it.codec) }
                .thenByDescending { it.fps }
                .thenByDescending { it.bitrate },
        ).first()
    }

    /** Daftar tinggi video yang tersedia (terbesar dulu); kosong kalau belum pernah di-resolve. */
    fun heightsFor(id: String): List<Int> {
        val r = synchronized(cache) { cache[id] } ?: return emptyList()
        val pool = if (r.video.isNotEmpty()) r.video else r.muxed
        return pool
            .filter { decoderExists(it.codec) }
            .map { it.height }
            .filter { it > 0 }
            .distinct()
            .sortedDescending()
    }

    // --------------------------------------------------------------- diagnostik

    /** Tes tiap jalur untuk video [id] dan kembalikan ringkasan teks. BLOKING. */
    fun selfTest(id: String): String {
        init()
        val sb = StringBuilder()
        for (name in STRATEGIES) {
            val t0 = System.currentTimeMillis()
            try {
                val r = fetchWith(name, id)
                val a = r.audio.maxByOrNull { it.bitrate }
                val dl = if (a != null && probe(a)) "unduh OK" else "unduh DITOLAK"
                val hs = r.video.map { it.height }.filter { it > 0 }.distinct().sortedDescending()
                sb.append(
                    "[OK] $name: audio ${r.audio.size}, video ${r.video.size} $hs, " +
                        "muxed ${r.muxed.size}, $dl (${System.currentTimeMillis() - t0} ms)\n",
                )
            } catch (e: Exception) {
                sb.append("[GAGAL] $name: ${brief(e)} (${System.currentTimeMillis() - t0} ms)\n")
            }
        }
        val out = sb.toString().trimEnd()
        log("TES $id\n$out")
        return out
    }
}
