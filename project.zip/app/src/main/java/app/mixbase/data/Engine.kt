package app.mixbase.data

import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.search.SearchExtractor
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.Page as ExtractorPage

/**
 * Pembungkus tipis di atas NewPipeExtractor: inisialisasi, pencarian, saran pencarian,
 * dan pengambilan URL stream audio.
 */
object Engine {

    const val FILTER_MUSIC = "music_songs"
    const val FILTER_VIDEO = "videos"

    private const val SERVICE_NAME = "YouTube"
    private const val CACHE_MS = 20L * 60L * 1000L

    private class Cached(val streamUrl: String, val at: Long)

    private val cache = HashMap<String, Cached>()

    @Volatile
    private var ready = false

    fun init() {
        if (ready) return
        synchronized(this) {
            if (ready) return
            NewPipe.init(AppDownloader(), Localization("id", "ID"), ContentCountry("ID"))
            ready = true
        }
    }

    private fun service() = NewPipe.getService(SERVICE_NAME)

    /** Saran pencarian untuk teks yang sedang diketik. */
    fun suggestions(query: String): List<String> {
        init()
        val list: List<String> = service().getSuggestionExtractor().suggestionList(query)
        return list.take(8)
    }

    /** Mulai sesi pencarian baru. Panggil [SearchSession.first], lalu [SearchSession.more]. */
    fun newSearch(query: String, filter: String): SearchSession {
        init()
        val extractor = service().getSearchExtractor(query, listOf(filter), "")
        return SearchSession(extractor)
    }

    class SearchSession internal constructor(private val extractor: SearchExtractor) {

        private var next: ExtractorPage? = null

        var hasMore: Boolean = false
            private set

        fun first(): List<Track> {
            extractor.fetchPage()
            return consume(extractor.getInitialPage())
        }

        fun more(): List<Track> {
            val page = next ?: return emptyList()
            return consume(extractor.getPage(page))
        }

        private fun consume(page: ListExtractor.InfoItemsPage<InfoItem>): List<Track> {
            next = page.getNextPage()
            hasMore = next != null
            val out = ArrayList<Track>()
            for (item in page.getItems()) {
                val t = toTrack(item)
                if (t != null) out.add(t)
            }
            return out
        }
    }

    private fun toTrack(item: InfoItem): Track? {
        if (item !is StreamInfoItem) return null
        val type = item.getStreamType()
        if (type == StreamType.LIVE_STREAM || type == StreamType.AUDIO_LIVE_STREAM) return null

        var thumb: String? = null
        var bestHeight = -1
        for (img in item.getThumbnails()) {
            if (img.getHeight() >= bestHeight) {
                bestHeight = img.getHeight()
                thumb = img.getUrl()
            }
        }
        return Track(
            url = item.getUrl(),
            title = item.getName() ?: "",
            artist = item.getUploaderName() ?: "",
            durationSec = item.getDuration(),
            thumb = thumb,
        )
    }

    /**
     * Ambil URL stream audio langsung untuk halaman [pageUrl]. BLOKING (jaringan) —
     * dipanggil dari thread loader ExoPlayer, bukan dari main thread.
     */
    fun resolveAudio(pageUrl: String, highQuality: Boolean): String {
        init()
        val key = "$pageUrl|$highQuality"
        val now = System.currentTimeMillis()
        synchronized(cache) {
            val c = cache[key]
            if (c != null && now - c.at < CACHE_MS) return c.streamUrl
        }

        val info = StreamInfo.getInfo(service(), pageUrl)
        val candidates = info.getAudioStreams().filter {
            it.isUrl() && it.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP
        }
        if (candidates.isEmpty()) {
            throw IllegalStateException("Tidak ada stream audio yang bisa diputar")
        }

        val withBitrate = candidates.filter { it.getAverageBitrate() > 0 }
        val pick = if (highQuality) {
            withBitrate.maxByOrNull { it.getAverageBitrate() } ?: candidates.first()
        } else {
            withBitrate.minByOrNull { it.getAverageBitrate() } ?: candidates.first()
        }

        val streamUrl: String = pick.getContent()
        synchronized(cache) {
            cache[key] = Cached(streamUrl, now)
        }
        return streamUrl
    }
}
