package app.mixbase.data

import androidx.core.text.HtmlCompat
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.comments.CommentsExtractor
import org.schabi.newpipe.extractor.comments.CommentsInfoItem
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.search.SearchExtractor
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.stream.VideoStream
import org.schabi.newpipe.extractor.Page as ExtractorPage

/**
 * Pembungkus tipis di atas NewPipeExtractor: inisialisasi, pencarian, saran pencarian,
 * detail video (stream HD), channel, album, komentar, dan URL stream audio.
 */
object Engine {

    const val FILTER_MUSIC = "music_songs"
    const val FILTER_ALBUM = "music_albums"
    const val FILTER_ARTIST = "music_artists"
    const val FILTER_VIDEO = "videos"

    private const val SERVICE_NAME = "YouTube"
    private const val CACHE_MS = 20L * 60L * 1000L
    private const val INFO_CACHE_MS = 10L * 60L * 1000L

    private class Cached(val streamUrl: String, val at: Long)
    private class CachedInfo(val value: Any, val at: Long)

    private val cache = HashMap<String, Cached>()
    private val infoCache = HashMap<String, CachedInfo>()

    @Volatile
    private var ready = false

    fun init() {
        if (ready) return
        synchronized(this) {
            if (ready) return
            NewPipe.init(AppDownloader(), Localization("id", "ID"), ContentCountry("ID"))
            ready = true
        }
    }

    private fun service() = NewPipe.getService(SERVICE_NAME)

    @Suppress("UNCHECKED_CAST")
    private fun <T : Any> cached(key: String, load: () -> T): T {
        val now = System.currentTimeMillis()
        synchronized(infoCache) {
            val c = infoCache[key]
            if (c != null && now - c.at < INFO_CACHE_MS) return c.value as T
        }
        val v = load()
        synchronized(infoCache) {
            infoCache[key] = CachedInfo(v, now)
            if (infoCache.size > 60) {
                val oldest = infoCache.entries.minByOrNull { it.value.at }
                if (oldest != null) infoCache.remove(oldest.key)
            }
        }
        return v
    }

    /** Saran pencarian untuk teks yang sedang diketik. */
    fun suggestions(query: String): List<String> {
        init()
        val list: List<String> = service().getSuggestionExtractor().suggestionList(query)
        return list.take(8)
    }

    /**
     * Mulai sesi pencarian baru. Panggil [SearchSession.first], lalu [SearchSession.more].
     * [includeLive] true: siaran langsung ikut dikembalikan (ditandai Track.live).
     */
    fun newSearch(query: String, filter: String, includeLive: Boolean = false): SearchSession {
        init()
        val extractor = service().getSearchExtractor(query, listOf(filter), "")
        return SearchSession(extractor, includeLive)
    }

    class SearchSession internal constructor(
        private val extractor: SearchExtractor,
        private val includeLive: Boolean,
    ) {

        private var next: ExtractorPage? = null

        var hasMore: Boolean = false
            private set

        fun first(): Batch {
            extractor.fetchPage()
            return consume(extractor.getInitialPage())
        }

        fun more(): Batch {
            val page = next ?: return Batch(emptyList(), emptyList())
            return consume(extractor.getPage(page))
        }

        private fun consume(page: ListExtractor.InfoItemsPage<InfoItem>): Batch {
            next = page.getNextPage()
            hasMore = next != null
            return toBatch(page.getItems(), includeLive)
        }
    }

    // ---------------- Konversi item ----------------

    private fun bestImage(list: List<Image>?): String? {
        if (list == null) return null
        var best: String? = null
        var bestHeight = -1
        for (img in list) {
            if (img.getHeight() >= bestHeight) {
                bestHeight = img.getHeight()
                best = img.getUrl()
            }
        }
        return best
    }

    private fun toBatch(items: List<InfoItem>, includeLive: Boolean): Batch {
        val tracks = ArrayList<Track>()
        val entries = ArrayList<Entry>()
        for (item in items) {
            val t = toTrack(item, includeLive)
            if (t != null) {
                tracks.add(t)
                continue
            }
            val e = toEntry(item)
            if (e != null) entries.add(e)
        }
        return Batch(tracks, entries)
    }

    private fun toTrack(item: InfoItem, includeLive: Boolean): Track? {
        if (item !is StreamInfoItem) return null
        val type = item.getStreamType()
        val live = type == StreamType.LIVE_STREAM || type == StreamType.AUDIO_LIVE_STREAM
        if (live && !includeLive) return null

        return Track(
            url = item.getUrl(),
            title = item.getName() ?: "",
            artist = item.getUploaderName() ?: "",
            durationSec = item.getDuration(),
            thumb = bestImage(item.getThumbnails()),
            uploaderUrl = item.getUploaderUrl(),
            views = item.getViewCount(),
            uploaded = item.getTextualUploadDate(),
            live = live,
            avatar = bestImage(item.getUploaderAvatars()),
        )
    }

    private fun toEntry(item: InfoItem): Entry? {
        if (item is PlaylistInfoItem) {
            val n = item.getStreamCount()
            val owner = item.getUploaderName() ?: ""
            val sub = listOf(owner, if (n > 0L) "$n lagu" else "")
                .filter { it.isNotBlank() }
                .joinToString(" • ")
            return Entry(
                kind = Entry.ALBUM,
                url = item.getUrl(),
                title = item.getName() ?: "",
                sub = sub,
                thumb = bestImage(item.getThumbnails()),
            )
        }
        if (item is ChannelInfoItem) {
            val subs = item.getSubscriberCount()
            return Entry(
                kind = Entry.ARTIST,
                url = item.getUrl(),
                title = item.getName() ?: "",
                sub = if (subs >= 0L) "${compactCount(subs)} subscriber" else "",
                thumb = bestImage(item.getThumbnails()),
            )
        }
        return null
    }

    // ---------------- Audio (pemutar musik) ----------------

    /**
     * Ambil URL stream audio langsung untuk halaman [pageUrl]. BLOKING (jaringan) —
     * dipanggil dari thread loader ExoPlayer, bukan dari main thread.
     */
    fun resolveAudio(pageUrl: String, highQuality: Boolean): String {
        init()
        val key = "$pageUrl|$highQuality"
        val now = System.currentTimeMillis()
        synchronized(cache) {
            val c = cache[key]
            if (c != null && now - c.at < CACHE_MS) return c.streamUrl
        }

        val info = StreamInfo.getInfo(service(), pageUrl)
        val candidates = info.getAudioStreams().filter {
            it.isUrl() && it.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP
        }
        if (candidates.isEmpty()) {
            throw IllegalStateException("Tidak ada stream audio yang bisa diputar")
        }

        val withBitrate = candidates.filter { it.getAverageBitrate() > 0 }
        val pick = if (highQuality) {
            withBitrate.maxByOrNull { it.getAverageBitrate() } ?: candidates.first()
        } else {
            withBitrate.minByOrNull { it.getAverageBitrate() } ?: candidates.first()
        }

        val streamUrl: String = pick.getContent()
        synchronized(cache) {
            cache[key] = Cached(streamUrl, now)
        }
        return streamUrl
    }

    // ---------------- Video ----------------

    /** Satu pilihan kualitas video-saja (harus digabung dengan audio). */
    class Quality(
        val height: Int,
        val fps: Int,
        val codec: String,
        val url: String,
    ) {
        /** "1080p60", "720p", ... */
        val label: String
            get() = if (fps >= 50) "${height}p60" else "${height}p"

        val hd: Boolean
            get() = height >= 720
    }

    class VideoDetails(
        val url: String,
        val title: String,
        val uploader: String,
        val uploaderUrl: String?,
        val avatar: String?,
        val subscribers: Long,
        val views: Long,
        val likes: Long,
        val uploaded: String,
        val description: String,
        val durationSec: Long,
        val thumb: String?,
        val live: Boolean,
        /** Pilihan kualitas video-saja, tertinggi dulu. */
        val qualities: List<Quality>,
        val audioUrl: String?,
        /** Stream gabungan (video+audio) kualitas rendah, cadangan. */
        val muxedUrl: String?,
        val muxedHeight: Int,
        val hlsUrl: String?,
        val related: List<Track>,
    )

    private fun codecRank(codec: String): Int {
        val c = codec.lowercase()
        return when {
            c.startsWith("avc") -> 0
            c.startsWith("vp09") || c.startsWith("vp9") -> 1
            c.startsWith("av01") -> 2
            else -> 3
        }
    }

    private fun heightOf(s: VideoStream): Int {
        val h = s.getHeight()
        if (h > 0) return h
        val m = Regex("(\\d{3,4})p").find(s.getResolution() ?: "")
        return m?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    private fun fpsOf(s: VideoStream): Int {
        val f = s.getFps()
        if (f >= 50) return 60
        return 30
    }

    // Description dibaca lewat refleksi supaya tidak bergantung pada bentuk kelasnya
    // (getter Java atau properti Kotlin) di versi extractor yang dipakai.
    private fun callGetter(target: Any, name: String): Any? = try {
        target.javaClass.getMethod(name).invoke(target)
    } catch (e: Exception) {
        null
    }

    private fun plainText(d: Any?): String {
        if (d == null) return ""
        if (d is String) return d.trim()
        val raw: String = (callGetter(d, "getContent") as? String) ?: ""
        val type: Int = (callGetter(d, "getType") as? Number)?.toInt() ?: 0
        val looksHtml = Regex("<[a-zA-Z/][^>]*>").containsMatchIn(raw)
        if (type == 1 || looksHtml) {
            return HtmlCompat.fromHtml(raw, HtmlCompat.FROM_HTML_MODE_LEGACY).toString().trim()
        }
        return raw.trim()
    }

    /** Detail lengkap sebuah video + daftar stream HD. BLOKING (jaringan). */
    fun videoDetails(pageUrl: String): VideoDetails {
        init()
        val info = StreamInfo.getInfo(service(), pageUrl)

        // Video-saja (adaptif): satu entri terbaik per kombinasi tinggi + fps.
        val groups = HashMap<Int, Quality>()
        for (s in info.getVideoOnlyStreams()) {
            if (!s.isUrl() || s.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue
            val h = heightOf(s)
            if (h <= 0) continue
            val q = Quality(h, fpsOf(s), s.getCodec() ?: "", s.getContent())
            val key = h * 100 + q.fps
            val old = groups[key]
            if (old == null || codecRank(q.codec) < codecRank(old.codec)) groups[key] = q
        }
        val qualities = groups.values
            .sortedWith(compareByDescending<Quality> { it.height }.thenByDescending { it.fps })

        // Audio: pakai trek asli (bukan hasil dubbing otomatis), bitrate tertinggi.
        val audios = info.getAudioStreams().filter {
            it.isUrl() && it.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP
        }
        val originals = audios.filter {
            val t = it.getAudioTrackType()?.toString()
            t == null || t == "ORIGINAL"
        }
        val pool = if (originals.isNotEmpty()) originals else audios
        val audioUrl: String? = pool.maxByOrNull { it.getAverageBitrate() }?.getContent()

        // Gabungan (video+audio) — biasanya hanya sampai 360p.
        var muxedUrl: String? = null
        var muxedHeight = 0
        for (s in info.getVideoStreams()) {
            if (!s.isUrl() || s.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue
            val h = heightOf(s)
            if (h >= muxedHeight) {
                muxedHeight = h
                muxedUrl = s.getContent()
            }
        }

        val hls: String? = info.getHlsUrl()?.takeIf { it.isNotBlank() }

        val related = ArrayList<Track>()
        for (item in info.getRelatedItems()) {
            val t = toTrack(item, false)
            if (t != null) related.add(t)
        }

        val type = info.getStreamType()
        return VideoDetails(
            url = pageUrl,
            title = info.getName() ?: "",
            uploader = info.getUploaderName() ?: "",
            uploaderUrl = info.getUploaderUrl()?.takeIf { it.isNotBlank() },
            avatar = bestImage(info.getUploaderAvatars()),
            subscribers = info.getUploaderSubscriberCount(),
            views = info.getViewCount(),
            likes = info.getLikeCount(),
            uploaded = info.getTextualUploadDate() ?: "",
            description = plainText(info.getDescription()),
            durationSec = info.getDuration(),
            thumb = bestImage(info.getThumbnails()),
            live = type == StreamType.LIVE_STREAM || type == StreamType.AUDIO_LIVE_STREAM,
            qualities = qualities,
            audioUrl = audioUrl,
            muxedUrl = muxedUrl,
            muxedHeight = muxedHeight,
            hlsUrl = hls,
            related = related,
        )
    }

    // ---------------- Komentar ----------------

    class CommentItem(
        val author: String,
        val avatar: String?,
        val text: String,
        val likes: Long,
        val date: String,
        val pinned: Boolean,
    )

    fun commentSession(pageUrl: String): CommentSession {
        init()
        return CommentSession(service().getCommentsExtractor(pageUrl))
    }

    class CommentSession internal constructor(private val ex: CommentsExtractor) {

        private var next: ExtractorPage? = null

        var disabled: Boolean = false
            private set
        var total: Int = -1
            private set
        var hasMore: Boolean = false
            private set

        fun first(): List<CommentItem> {
            ex.fetchPage()
            disabled = try {
                ex.isCommentsDisabled()
            } catch (e: Exception) {
                false
            }
            if (disabled) return emptyList()
            total = readCount(ex)
            return consume(ex.getInitialPage())
        }

        fun more(): List<CommentItem> {
            val p = next ?: return emptyList()
            return consume(ex.getPage(p))
        }

        private fun consume(page: ListExtractor.InfoItemsPage<CommentsInfoItem>): List<CommentItem> {
            next = page.getNextPage()
            hasMore = next != null
            val out = ArrayList<CommentItem>()
            for (c in page.getItems()) {
                out.add(
                    CommentItem(
                        author = (c.getUploaderName() ?: "").removePrefix("@"),
                        avatar = bestImage(c.getUploaderAvatars()),
                        text = textOf(c.getCommentText()),
                        likes = c.getLikeCount().toLong(),
                        date = c.getTextualUploadDate() ?: "",
                        pinned = c.isPinned(),
                    ),
                )
            }
            return out
        }

        // getCommentsCount() ada di versi extractor yang lebih baru; dipanggil lewat refleksi
        // supaya tetap aman bila tidak tersedia.
        private fun readCount(target: Any): Int = try {
            (target.javaClass.getMethod("getCommentsCount").invoke(target) as? Number)?.toInt() ?: -1
        } catch (e: Exception) {
            -1
        }
    }

    // Teks komentar bisa bertipe String atau Description tergantung versi extractor.
    private fun textOf(x: Any?): String = when (x) {
        null -> ""
        is String -> x
        else -> if (x.javaClass.simpleName == "Description") plainText(x) else x.toString()
    }

    // ---------------- Channel / artis ----------------

    class ChannelTab internal constructor(
        val id: String,
        val label: String,
        internal val handler: ListLinkHandler,
    )

    class ChannelDetails internal constructor(
        val url: String,
        val name: String,
        val avatar: String?,
        val banner: String?,
        val subscribers: Long,
        val description: String,
        val tabs: List<ChannelTab>,
    )

    private fun tabLabel(id: String): String? = when (id) {
        "videos" -> "Video"
        "shorts" -> "Shorts"
        "livestreams" -> "Live"
        "playlists" -> "Playlist"
        "albums" -> "Album"
        "tracks" -> "Lagu"
        "releases" -> "Rilis"
        else -> null
    }

    fun channel(url: String): ChannelDetails = cached("ch|$url") {
        init()
        val info = ChannelInfo.getInfo(service(), url)
        val tabs = ArrayList<ChannelTab>()
        for (h in info.getTabs()) {
            val id = h.getContentFilters().firstOrNull() ?: continue
            val label = tabLabel(id) ?: continue
            tabs.add(ChannelTab(id, label, h))
        }
        // Video dulu, lalu urutan aslinya.
        tabs.sortBy { if (it.id == "videos") 0 else 1 }
        ChannelDetails(
            url = url,
            name = info.getName() ?: "",
            avatar = bestImage(info.getAvatars()),
            banner = bestImage(info.getBanners()),
            subscribers = info.getSubscriberCount(),
            description = info.getDescription() ?: "",
            tabs = tabs,
        )
    }

    fun openTab(tab: ChannelTab): TabSession {
        init()
        val ex: ListExtractor<InfoItem> = service().getChannelTabExtractor(tab.handler)
        return TabSession(ex)
    }

    class TabSession internal constructor(private val ex: ListExtractor<InfoItem>) {

        private var next: ExtractorPage? = null

        var hasMore: Boolean = false
            private set

        fun first(): Batch {
            ex.fetchPage()
            return consume(ex.getInitialPage())
        }

        fun more(): Batch {
            val p = next ?: return Batch(emptyList(), emptyList())
            return consume(ex.getPage(p))
        }

        private fun consume(page: ListExtractor.InfoItemsPage<InfoItem>): Batch {
            next = page.getNextPage()
            hasMore = next != null
            return toBatch(page.getItems(), true)
        }
    }

    /** Video terbaru sebuah channel (untuk tab Langganan). BLOKING. */
    fun latestVideos(channelUrl: String, limit: Int): List<Track> {
        val details = channel(channelUrl)
        val tab = details.tabs.firstOrNull { it.id == "videos" } ?: return emptyList()
        val batch = openTab(tab).first()
        return batch.tracks.filter { !it.live }.take(limit)
    }

    // ---------------- Album / playlist ----------------

    class AlbumDetails(
        val title: String,
        val artist: String,
        val artistUrl: String?,
        val thumb: String?,
        val tracks: List<Track>,
    )

    fun album(url: String): AlbumDetails = cached("al|$url") {
        init()
        val info = PlaylistInfo.getInfo(service(), url)
        val cover = bestImage(info.getThumbnails())
        val owner = info.getUploaderName() ?: ""
        val tracks = ArrayList<Track>()
        for (item in info.getRelatedItems()) {
            val t = toTrack(item, false) ?: continue
            tracks.add(
                t.copy(
                    thumb = cover ?: t.thumb,
                    artist = if (t.artist.isBlank()) owner else t.artist,
                ),
            )
        }
        AlbumDetails(
            title = info.getName() ?: "",
            artist = owner,
            artistUrl = info.getUploaderUrl()?.takeIf { it.isNotBlank() },
            thumb = cover,
            tracks = tracks,
        )
    }
}
