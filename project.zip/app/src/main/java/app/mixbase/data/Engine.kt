package app.mixbase.data

import androidx.core.text.HtmlCompat
import org.schabi.newpipe.extractor.Image
import org.schabi.newpipe.extractor.InfoItem
import org.schabi.newpipe.extractor.MediaFormat
import org.schabi.newpipe.extractor.ListExtractor
import org.schabi.newpipe.extractor.NewPipe
import org.schabi.newpipe.extractor.channel.ChannelInfo
import org.schabi.newpipe.extractor.channel.ChannelInfoItem
import org.schabi.newpipe.extractor.comments.CommentsExtractor
import org.schabi.newpipe.extractor.comments.CommentsInfoItem
import org.schabi.newpipe.extractor.linkhandler.ListLinkHandler
import org.schabi.newpipe.extractor.localization.ContentCountry
import org.schabi.newpipe.extractor.localization.Localization
import org.schabi.newpipe.extractor.playlist.PlaylistInfo
import org.schabi.newpipe.extractor.playlist.PlaylistInfoItem
import org.schabi.newpipe.extractor.search.SearchExtractor
import org.schabi.newpipe.extractor.stream.AudioStream
import org.schabi.newpipe.extractor.stream.DeliveryMethod
import org.schabi.newpipe.extractor.stream.Stream
import org.schabi.newpipe.extractor.stream.StreamInfo
import org.schabi.newpipe.extractor.stream.StreamInfoItem
import org.schabi.newpipe.extractor.stream.StreamType
import org.schabi.newpipe.extractor.stream.VideoStream
import org.schabi.newpipe.extractor.Page as ExtractorPage

/**
 * Pembungkus tipis di atas NewPipeExtractor: inisialisasi, pencarian, saran pencarian,
 * detail video (stream HD), channel, album, komentar, dan URL stream audio.
 */
object Engine {

    const val FILTER_MUSIC = "music_songs"
    const val FILTER_ALBUM = "music_albums"
    const val FILTER_MUSIC_VIDEO = "music_videos"
    const val FILTER_ARTIST = "music_artists"
    const val FILTER_VIDEO = "videos"

    private const val SERVICE_NAME = "YouTube"
    private const val CACHE_MS = 20L * 60L * 1000L
    private const val INFO_CACHE_MS = 10L * 60L * 1000L

    private class Cached(val streamUrl: String, val at: Long)
    private class CachedInfo(val value: Any, val at: Long)

    private val cache = HashMap<String, Cached>()
    private val infoCache = HashMap<String, CachedInfo>()

    @Volatile
    private var ready = false

    fun init() {
        if (ready) return
        synchronized(this) {
            if (ready) return
            NewPipe.init(AppDownloader(), Localization("id", "ID"), ContentCountry("ID"))
            ready = true
        }
    }

    private fun service() = NewPipe.getService(SERVICE_NAME)

    @Volatile
    private var contentLang = "id"

    /** Bahasa konten yang sedang dipakai (kode ISO). */
    fun contentLanguage(): String = contentLang

    /**
     * Ganti bahasa konten: judul, deskripsi, dan teks lain dari YouTube diminta dalam bahasa ini
     * (bila video/channel menyediakan terjemahannya). Cache daftar dikosongkan.
     */
    fun setContentLanguage(code: String) {
        init()
        val lang = Languages.byCode(code) ?: Languages.ALL.first()
        contentLang = lang.code
        NewPipe.setupLocalization(Localization(lang.code, lang.country), ContentCountry("ID"))
        MusicApi.hl = lang.code
        synchronized(infoCache) { infoCache.clear() }
        synchronized(prefetched) { prefetched.clear() }
    }

    /**
     * User-Agent yang cocok dengan klien YouTube pembuat alamat stream. YouTube membatasi
     * kecepatan (video putus-putus) bila identitasnya tidak cocok. Dibaca lewat refleksi agar
     * tetap bisa dikompilasi di versi extractor mana pun; bila tidak ada, pakai bawaan.
     */
    fun streamUserAgent(url: String): String {
        try {
            val helper = Class.forName("org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper")
            val locale = Class.forName("org.schabi.newpipe.extractor.localization.Localization")
            val pairs = listOf(
                "isVisionOsStreamingUrl" to "getVisionOsUserAgent",
                "isIosStreamingUrl" to "getIosUserAgent",
                "isAndroidStreamingUrl" to "getAndroidUserAgent",
            )
            for ((check, agent) in pairs) {
                val match = try {
                    helper.getMethod(check, String::class.java).invoke(null, url) as? Boolean == true
                } catch (e: Exception) {
                    false
                }
                if (!match) continue
                val ua = try {
                    helper.getMethod(agent, locale).invoke(null, *arrayOf<Any?>(null)) as? String
                } catch (e: Exception) {
                    null
                }
                if (!ua.isNullOrBlank()) return ua
            }
        } catch (e: Exception) {
            // abaikan: pakai User-Agent bawaan
        }
        return AppDownloader.USER_AGENT
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T : Any> cached(key: String, load: () -> T): T {
        val now = System.currentTimeMillis()
        synchronized(infoCache) {
            val c = infoCache[key]
            if (c != null && now - c.at < INFO_CACHE_MS) return c.value as T
        }
        val v = load()
        synchronized(infoCache) {
            infoCache[key] = CachedInfo(v, now)
            if (infoCache.size > 60) {
                val oldest = infoCache.entries.minByOrNull { it.value.at }
                if (oldest != null) infoCache.remove(oldest.key)
            }
        }
        return v
    }

    /** Saran pencarian untuk teks yang sedang diketik. */
    fun suggestions(query: String): List<String> {
        init()
        val list: List<String> = service().getSuggestionExtractor().suggestionList(query)
        return list.take(8)
    }

    /**
     * Mulai sesi pencarian baru. Panggil [SearchSession.first], lalu [SearchSession.more].
     * [includeLive] true: siaran langsung ikut dikembalikan (ditandai Track.live).
     */
    fun newSearch(query: String, filter: String, includeLive: Boolean = false): SearchSession {
        init()
        val extractor = service().getSearchExtractor(query, listOf(filter), "")
        return SearchSession(extractor, includeLive)
    }

    /**
     * Pencarian musik memakai YouTube Music ([MusicApi]: gambar, album, dan artis lengkap) dan
     * otomatis kembali ke pencarian NewPipe bila gagal atau kosong. Filter lain (video) langsung
     * memakai NewPipe. Pemutaran audio tidak terpengaruh: url tiap lagu tetap halaman watch.
     */
    fun search(query: String, filter: String, includeLive: Boolean = false): Pager {
        if (!MusicApi.supports(filter)) return newSearch(query, filter, includeLive)
        return Artist.FallbackPager(
            listOf<() -> Pager>(
                { MusicApi.searchPager(query, filter) },
                { newSearch(query, filter, includeLive) },
            ),
        )
    }

    /** Sumber daftar berhalaman (hasil pencarian atau isi tab channel). Semua panggilan BLOKING. */
    interface Pager {
        val hasMore: Boolean
        fun first(): Batch
        fun more(): Batch
    }

    /** Pager yang menyaring isi pager lain (mis. hanya album milik satu artis). */
    class FilteredPager(
        private val inner: Pager,
        private val keepEntry: (Entry) -> Boolean,
        private val keepTrack: (Track) -> Boolean,
    ) : Pager {
        override val hasMore: Boolean
            get() = inner.hasMore

        override fun first(): Batch = filtered(inner.first())

        override fun more(): Batch = filtered(inner.more())

        private fun filtered(b: Batch): Batch =
            Batch(b.tracks.filter(keepTrack), b.entries.filter(keepEntry))
    }

    class SearchSession internal constructor(
        private val extractor: SearchExtractor,
        private val includeLive: Boolean,
    ) : Pager {

        private var next: ExtractorPage? = null

        override var hasMore: Boolean = false
            private set

        override fun first(): Batch {
            extractor.fetchPage()
            return consume(extractor.getInitialPage())
        }

        override fun more(): Batch {
            val page = next ?: return Batch(emptyList(), emptyList())
            return consume(extractor.getPage(page))
        }

        private fun consume(page: ListExtractor.InfoItemsPage<InfoItem>): Batch {
            next = page.getNextPage()
            hasMore = next != null
            return toBatch(page.getItems(), includeLive)
        }
    }

    // ---------------- Konversi item ----------------

    private fun bestImage(list: List<Image>?): String? {
        if (list == null) return null
        var best: String? = null
        var bestHeight = -1
        for (img in list) {
            if (img.getHeight() >= bestHeight) {
                bestHeight = img.getHeight()
                best = img.getUrl()
            }
        }
        return best
    }

    private fun toBatch(items: List<InfoItem>, includeLive: Boolean): Batch {
        val tracks = ArrayList<Track>()
        val entries = ArrayList<Entry>()
        for (item in items) {
            val t = toTrack(item, includeLive)
            if (t != null) {
                tracks.add(t)
                continue
            }
            val e = toEntry(item)
            if (e != null) entries.add(e)
        }
        return Batch(tracks, entries)
    }

    private fun toTrack(item: InfoItem, includeLive: Boolean): Track? {
        if (item !is StreamInfoItem) return null
        val type = item.getStreamType()
        val live = type == StreamType.LIVE_STREAM || type == StreamType.AUDIO_LIVE_STREAM
        if (live && !includeLive) return null

        return Track(
            url = item.getUrl(),
            title = item.getName() ?: "",
            artist = item.getUploaderName() ?: "",
            durationSec = item.getDuration(),
            thumb = bestImage(item.getThumbnails()),
            uploaderUrl = item.getUploaderUrl(),
            views = item.getViewCount(),
            uploaded = item.getTextualUploadDate(),
            live = live,
            avatar = bestImage(item.getUploaderAvatars()),
        )
    }

    private fun toEntry(item: InfoItem): Entry? {
        if (item is PlaylistInfoItem) {
            val n = item.getStreamCount()
            val owner = item.getUploaderName() ?: ""
            val sub = listOf(owner, if (n > 0L) "$n lagu" else "")
                .filter { it.isNotBlank() }
                .joinToString(" • ")
            return Entry(
                kind = Entry.ALBUM,
                url = item.getUrl(),
                title = item.getName() ?: "",
                sub = sub,
                thumb = bestImage(item.getThumbnails()),
            )
        }
        if (item is ChannelInfoItem) {
            val subs = item.getSubscriberCount()
            return Entry(
                kind = Entry.ARTIST,
                url = item.getUrl(),
                title = item.getName() ?: "",
                sub = if (subs >= 0L) "${compactCount(subs)} subscriber" else "",
                thumb = bestImage(item.getThumbnails()),
            )
        }
        return null
    }

    // ---------------- Audio (pemutar musik) ----------------

    /**
     * Ambil URL stream audio langsung untuk halaman [pageUrl]. BLOKING (jaringan) —
     * dipanggil dari thread loader ExoPlayer, bukan dari main thread.
     */
    fun resolveAudio(pageUrl: String, highQuality: Boolean, skip: Int = 0): String {
        init()
        val which = if (skip < 0) 0 else skip
        val key = "$pageUrl|$highQuality|$which"
        val now = System.currentTimeMillis()
        synchronized(cache) {
            val c = cache[key]
            if (c != null && now - c.at < CACHE_MS) return c.streamUrl
        }

        val info = StreamInfo.getInfo(service(), pageUrl)
        val all = info.getAudioStreams().filter {
            it.isUrl() && it.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP
        }
        // Utamakan trek asli (bukan hasil dubbing otomatis).
        val originals = all.filter {
            val t = it.getAudioTrackType()?.toString()
            t == null || t == "ORIGINAL"
        }
        val candidates = if (originals.isNotEmpty()) originals else all
        if (candidates.isEmpty()) {
            throw IllegalStateException("Tidak ada stream audio yang bisa diputar")
        }

        // Urutan pilihan: kualitas tertinggi (atau terendah bila hemat data) dulu. Pilihan ke-2 dst.
        // dipakai sebagai cadangan bila stream pertama ditolak server (403).
        val withBitrate = candidates.filter { it.getAverageBitrate() > 0 }
        val ordered = if (withBitrate.isEmpty()) {
            candidates
        } else if (highQuality) {
            withBitrate.sortedByDescending { it.getAverageBitrate() }
        } else {
            withBitrate.sortedBy { it.getAverageBitrate() }
        }
        val pick = ordered[which % ordered.size]

        val streamUrl: String = pick.getContent()
        synchronized(cache) {
            cache[key] = Cached(streamUrl, now)
        }
        return streamUrl
    }

    /** Pilih audio terbaik untuk diunduh: m4a (AAC) bila ada karena paling kompatibel, kalau tidak yang terbaik. */
    fun audioForDownload(pageUrl: String): DlAudio {
        init()
        val info = StreamInfo.getInfo(service(), pageUrl)
        val all = info.getAudioStreams().filter {
            it.isUrl() && it.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP
        }
        val originals = all.filter {
            val t = it.getAudioTrackType()?.toString()
            t == null || t == "ORIGINAL"
        }
        val pool = if (originals.isNotEmpty()) originals else all
        if (pool.isEmpty()) throw IllegalStateException("Tidak ada stream audio untuk diunduh")
        val aac = pool
            .filter { mimeOrNull(it.getFormat()) == "audio/mp4" }
            .maxByOrNull { it.getAverageBitrate() }
        if (aac != null) return DlAudio(aac.getContent(), "m4a")
        val best = pool.maxByOrNull { it.getAverageBitrate() } ?: pool.first()
        return DlAudio(best.getContent(), "webm")
    }

    /** Buang alamat stream yang tersimpan untuk [pageUrl] (mis. setelah ditolak 403 / kedaluwarsa). */
    fun forgetAudio(pageUrl: String) {
        synchronized(cache) {
            val iter = cache.keys.iterator()
            while (iter.hasNext()) {
                if (iter.next().startsWith("$pageUrl|")) iter.remove()
            }
        }
    }

    // ---------------- Video ----------------

    /**
     * Satu stream adaptif (video-saja atau audio-saja) beserta rentang byte (init + indeks) yang
     * dibutuhkan untuk menyusun manifest DASH. [ranged] false bila rentangnya tidak diketahui.
     */
    class Rep(
        val id: String,
        val url: String,
        val mime: String,
        val codec: String,
        val bandwidth: Int,
        val width: Int,
        val height: Int,
        val fps: Int,
        val initStart: Int,
        val initEnd: Int,
        val indexStart: Int,
        val indexEnd: Int,
        val durationMs: Long,
    ) {
        val ranged: Boolean
            get() = initEnd > 0 && indexEnd > 0 && indexStart > 0
    }

    /** Satu pilihan kualitas video-saja (harus digabung dengan audio). */
    class Quality(
        val height: Int,
        val fps: Int,
        val codec: String,
        val url: String,
        val rep: Rep? = null,
    ) {
        /** "1080p60", "720p", ... */
        val label: String
            get() = if (fps >= 50) "${height}p60" else "${height}p"

        val hd: Boolean
            get() = height >= 720
    }

    class VideoDetails(
        val url: String,
        val title: String,
        val uploader: String,
        val uploaderUrl: String?,
        val avatar: String?,
        val subscribers: Long,
        val views: Long,
        val likes: Long,
        val uploaded: String,
        val description: String,
        val durationSec: Long,
        val thumb: String?,
        val live: Boolean,
        /** Pilihan kualitas video-saja, tertinggi dulu. */
        val qualities: List<Quality>,
        val audioUrl: String?,
        /** Stream gabungan (video+audio) kualitas rendah, cadangan. */
        val muxedUrl: String?,
        val muxedHeight: Int,
        val hlsUrl: String?,
        val related: List<Track>,
        /** Data audio untuk manifest DASH (mode Otomatis); null bila tidak lengkap. */
        val audioRep: Rep? = null,
        /** Audio AAC (m4a) terbaik — dipakai untuk unduhan video HD (digabung ke MP4). */
        val aacUrl: String? = null,
        /** Trek suara per bahasa; kosong bila video hanya punya satu suara. */
        val audioTracks: List<AudioTrackOption> = emptyList(),
        /** Subtitle yang tersedia (asli dan otomatis). */
        val subtitles: List<SubtitleOption> = emptyList(),
    )

    /** Satu pilihan trek suara (bahasa) pada video yang punya beberapa suara, mis. dubbing AI. */
    class AudioTrackOption(
        val id: String,
        /** Mis. "Inggris · Asli" atau "Indonesia · Dubbing". */
        val label: String,
        /** Kode bahasa dasar ("id", "en", ...), kosong bila tidak diketahui. */
        val language: String,
        val dubbed: Boolean,
        val original: Boolean,
        val url: String,
        val rep: Rep?,
    )

    /** Satu pilihan subtitle. [url] adalah alamat berkas subtitle dari YouTube (format ditentukan saat diunduh). */
    class SubtitleOption(
        val code: String,
        val label: String,
        val auto: Boolean,
        val url: String,
    )

    /** Hasil pemilihan audio untuk diunduh: alamat stream dan ekstensi berkas (m4a / webm). */
    class DlAudio(val url: String, val ext: String)

    private fun mimeOrNull(f: MediaFormat?): String? =
        try {
            f?.getMimeType()
        } catch (e: Exception) {
            null
        }

    private fun durationOf(s: Stream): Long = try {
        s.getItagItem()?.getApproxDurationMs() ?: -1L
    } catch (e: Exception) {
        -1L
    }

    private fun repOf(s: VideoStream, height: Int): Rep = Rep(
        id = "v${s.getItag()}",
        url = s.getContent(),
        mime = mimeOrNull(s.getFormat()) ?: "video/mp4",
        codec = s.getCodec() ?: "",
        bandwidth = if (s.getBitrate() > 0) s.getBitrate() else height * 3000,
        width = s.getWidth(),
        height = height,
        fps = s.getFps(),
        initStart = s.getInitStart(),
        initEnd = s.getInitEnd(),
        indexStart = s.getIndexStart(),
        indexEnd = s.getIndexEnd(),
        durationMs = durationOf(s),
    )

    private fun repOf(s: AudioStream): Rep = Rep(
        id = "a${s.getItag()}",
        url = s.getContent(),
        mime = mimeOrNull(s.getFormat()) ?: "audio/mp4",
        codec = s.getCodec() ?: "",
        bandwidth = if (s.getBitrate() > 0) s.getBitrate() else 128_000,
        width = 0,
        height = 0,
        fps = 0,
        initStart = s.getInitStart(),
        initEnd = s.getInitEnd(),
        indexStart = s.getIndexStart(),
        indexEnd = s.getIndexEnd(),
        durationMs = durationOf(s),
    )

    /** true bila alamat stream ini berasal dari klien web YouTube (perlu Origin/Referer). */
    fun isWebStream(url: String): Boolean {
        try {
            val helper = Class.forName("org.schabi.newpipe.extractor.services.youtube.YoutubeParsingHelper")
            for (name in listOf("isWebStreamingUrl", "isWebEmbeddedPlayerStreamingUrl")) {
                val hit = try {
                    helper.getMethod(name, String::class.java).invoke(null, url) as? Boolean == true
                } catch (e: Exception) {
                    false
                }
                if (hit) return true
            }
        } catch (e: Exception) {
            // abaikan
        }
        return false
    }

    private fun codecRank(codec: String): Int {
        val c = codec.lowercase()
        return when {
            c.startsWith("avc") -> 0
            c.startsWith("vp09") || c.startsWith("vp9") -> 1
            c.startsWith("av01") -> 2
            else -> 3
        }
    }

    private fun heightOf(s: VideoStream): Int {
        val h = s.getHeight()
        if (h > 0) return h
        val m = Regex("(\\d{3,4})p").find(s.getResolution() ?: "")
        return m?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    private fun fpsOf(s: VideoStream): Int {
        val f = s.getFps()
        if (f >= 50) return 60
        return 30
    }

    // Description dibaca lewat refleksi supaya tidak bergantung pada bentuk kelasnya
    // (getter Java atau properti Kotlin) di versi extractor yang dipakai.
    private fun callGetter(target: Any, name: String): Any? = try {
        target.javaClass.getMethod(name).invoke(target)
    } catch (e: Exception) {
        null
    }

    private fun plainText(d: Any?): String {
        if (d == null) return ""
        if (d is String) return d.trim()
        val raw: String = (callGetter(d, "getContent") as? String) ?: ""
        val type: Int = (callGetter(d, "getType") as? Number)?.toInt() ?: 0
        val looksHtml = Regex("<[a-zA-Z/][^>]*>").containsMatchIn(raw)
        if (type == 1 || looksHtml) {
            return HtmlCompat.fromHtml(raw, HtmlCompat.FROM_HTML_MODE_LEGACY).toString().trim()
        }
        return raw.trim()
    }

    /** Detail lengkap sebuah video + daftar stream HD. BLOKING (jaringan). */
    fun videoDetails(pageUrl: String): VideoDetails {
        val ready = synchronized(prefetched) { prefetched.remove(pageUrl) }
        if (ready != null && System.currentTimeMillis() - ready.at < PREFETCH_TTL_MS) return ready.details
        return loadDetails(pageUrl)
    }

    /** Muat detail video lebih dulu (mis. Shorts berikutnya) supaya saat dibuka langsung siap. BLOKING. */
    fun prefetchDetails(pageUrl: String) {
        try {
            val d = loadDetails(pageUrl)
            synchronized(prefetched) {
                if (prefetched.size >= 6) prefetched.clear()
                prefetched[pageUrl] = Prefetched(d, System.currentTimeMillis())
            }
        } catch (e: Exception) {
            // Gagal menyiapkan lebih dulu tidak apa-apa: dimuat saat video dibuka.
        }
    }

    private class Prefetched(val details: VideoDetails, val at: Long)

    private val prefetched = HashMap<String, Prefetched>()

    private const val PREFETCH_TTL_MS = 5 * 60 * 1000L

    private fun loadDetails(pageUrl: String): VideoDetails {
        init()
        val info = StreamInfo.getInfo(service(), pageUrl)

        // Video-saja (adaptif): satu entri terbaik per kombinasi tinggi + fps.
        val groups = HashMap<Int, Quality>()
        for (s in info.getVideoOnlyStreams()) {
            if (!s.isUrl() || s.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue
            val h = heightOf(s)
            if (h <= 0) continue
            val q = Quality(h, fpsOf(s), s.getCodec() ?: "", s.getContent(), repOf(s, h))
            val key = h * 100 + q.fps
            val old = groups[key]
            if (old == null || codecRank(q.codec) < codecRank(old.codec)) groups[key] = q
        }
        val qualities = groups.values
            .sortedWith(compareByDescending<Quality> { it.height }.thenByDescending { it.fps })

        // Audio: pakai trek asli (bukan hasil dubbing otomatis), bitrate tertinggi.
        val audios = info.getAudioStreams().filter {
            it.isUrl() && it.getDeliveryMethod() == DeliveryMethod.PROGRESSIVE_HTTP
        }
        val originals = audios.filter {
            val t = it.getAudioTrackType()?.toString()
            t == null || t == "ORIGINAL"
        }
        val pool = if (originals.isNotEmpty()) originals else audios
        val bestAudio: AudioStream? = pool.maxByOrNull { it.getAverageBitrate() }
        val audioUrl: String? = bestAudio?.getContent()
        val audioRep: Rep? = bestAudio?.let { repOf(it) }
        val aacUrl: String? = pool
            .filter { mimeOrNull(it.getFormat()) == "audio/mp4" }
            .maxByOrNull { it.getAverageBitrate() }
            ?.getContent()

        // Trek suara per bahasa (video dengan dubbing / multi-bahasa).
        val trackGroups = LinkedHashMap<String, MutableList<AudioStream>>()
        for (a in audios) {
            val id = a.getAudioTrackId() ?: "default"
            trackGroups.getOrPut(id) { ArrayList() }.add(a)
        }
        val audioTracks = ArrayList<AudioTrackOption>()
        if (trackGroups.size >= 2) {
            for ((id, list) in trackGroups) {
                val best = list.maxByOrNull { it.getAverageBitrate() } ?: continue
                val lang = try {
                    best.getAudioLocale()?.getLanguage() ?: ""
                } catch (e: Exception) {
                    ""
                }
                val type = best.getAudioTrackType()?.toString()
                val kind = when (type) {
                    "ORIGINAL" -> "Asli"
                    "DUBBED" -> "Dubbing"
                    "DESCRIPTIVE" -> "Deskripsi audio"
                    else -> ""
                }
                val name = if (lang.isNotEmpty()) Languages.nameOf(lang) else (best.getAudioTrackName() ?: id)
                audioTracks.add(
                    AudioTrackOption(
                        id = id,
                        label = if (kind.isEmpty()) name else "$name · $kind",
                        language = lang,
                        dubbed = type == "DUBBED",
                        original = type == "ORIGINAL",
                        url = best.getContent(),
                        rep = repOf(best),
                    ),
                )
            }
            audioTracks.sortWith(compareByDescending<AudioTrackOption> { it.original }.thenBy { it.label })
        }

        // Subtitle yang tersedia.
        val subtitles = ArrayList<SubtitleOption>()
        try {
            for (st in info.getSubtitles()) {
                val tag = st.getLanguageTag()
                val auto = st.isAutoGenerated()
                val nm = Languages.nameOf(tag)
                subtitles.add(
                    SubtitleOption(
                        code = tag,
                        label = if (auto) "$nm (otomatis)" else nm,
                        auto = auto,
                        url = st.getContent(),
                    ),
                )
            }
            subtitles.sortWith(compareBy<SubtitleOption> { it.auto }.thenBy { it.label })
        } catch (e: Exception) {
            // Tanpa subtitle: abaikan.
        }

        // Gabungan (video+audio) — biasanya hanya sampai 360p.
        var muxedUrl: String? = null
        var muxedHeight = 0
        for (s in info.getVideoStreams()) {
            if (!s.isUrl() || s.getDeliveryMethod() != DeliveryMethod.PROGRESSIVE_HTTP) continue
            val h = heightOf(s)
            if (h >= muxedHeight) {
                muxedHeight = h
                muxedUrl = s.getContent()
            }
        }

        val hls: String? = info.getHlsUrl()?.takeIf { it.isNotBlank() }

        val related = ArrayList<Track>()
        for (item in info.getRelatedItems()) {
            val t = toTrack(item, false)
            if (t != null) related.add(t)
        }

        val type = info.getStreamType()
        return VideoDetails(
            url = pageUrl,
            title = info.getName() ?: "",
            uploader = info.getUploaderName() ?: "",
            uploaderUrl = info.getUploaderUrl()?.takeIf { it.isNotBlank() },
            avatar = bestImage(info.getUploaderAvatars()),
            subscribers = info.getUploaderSubscriberCount(),
            views = info.getViewCount(),
            likes = info.getLikeCount(),
            uploaded = info.getTextualUploadDate() ?: "",
            description = plainText(info.getDescription()),
            durationSec = info.getDuration(),
            thumb = bestImage(info.getThumbnails()),
            live = type == StreamType.LIVE_STREAM || type == StreamType.AUDIO_LIVE_STREAM,
            qualities = qualities,
            audioUrl = audioUrl,
            muxedUrl = muxedUrl,
            muxedHeight = muxedHeight,
            hlsUrl = hls,
            related = related,
            audioRep = audioRep,
            aacUrl = aacUrl,
            audioTracks = audioTracks,
            subtitles = subtitles,
        )
    }

    // ---------------- Komentar ----------------

    class CommentItem(
        val author: String,
        val avatar: String?,
        val text: String,
        val likes: Long,
        val date: String,
        val pinned: Boolean,
    )

    fun commentSession(pageUrl: String): CommentSession {
        init()
        return CommentSession(service().getCommentsExtractor(pageUrl))
    }

    class CommentSession internal constructor(private val ex: CommentsExtractor) {

        private var next: ExtractorPage? = null

        var disabled: Boolean = false
            private set
        var total: Int = -1
            private set
        var hasMore: Boolean = false
            private set

        fun first(): List<CommentItem> {
            ex.fetchPage()
            disabled = try {
                ex.isCommentsDisabled()
            } catch (e: Exception) {
                false
            }
            if (disabled) return emptyList()
            total = readCount(ex)
            return consume(ex.getInitialPage())
        }

        fun more(): List<CommentItem> {
            val p = next ?: return emptyList()
            return consume(ex.getPage(p))
        }

        private fun consume(page: ListExtractor.InfoItemsPage<CommentsInfoItem>): List<CommentItem> {
            next = page.getNextPage()
            hasMore = next != null
            val out = ArrayList<CommentItem>()
            for (c in page.getItems()) {
                out.add(
                    CommentItem(
                        author = (c.getUploaderName() ?: "").removePrefix("@"),
                        avatar = bestImage(c.getUploaderAvatars()),
                        text = textOf(c.getCommentText()),
                        likes = c.getLikeCount().toLong(),
                        date = c.getTextualUploadDate() ?: "",
                        pinned = c.isPinned(),
                    ),
                )
            }
            return out
        }

        // getCommentsCount() ada di versi extractor yang lebih baru; dipanggil lewat refleksi
        // supaya tetap aman bila tidak tersedia.
        private fun readCount(target: Any): Int = try {
            (target.javaClass.getMethod("getCommentsCount").invoke(target) as? Number)?.toInt() ?: -1
        } catch (e: Exception) {
            -1
        }
    }

    // Teks komentar bisa bertipe String atau Description tergantung versi extractor.
    private fun textOf(x: Any?): String = when (x) {
        null -> ""
        is String -> x
        else -> if (x.javaClass.simpleName == "Description") plainText(x) else x.toString()
    }

    // ---------------- Channel / artis ----------------

    class ChannelTab internal constructor(
        val id: String,
        val label: String,
        internal val handler: ListLinkHandler,
    )

    class ChannelDetails internal constructor(
        val url: String,
        val name: String,
        val avatar: String?,
        val banner: String?,
        val subscribers: Long,
        val description: String,
        val tabs: List<ChannelTab>,
    )

    private fun tabLabel(id: String): String? = when (id) {
        "videos" -> "Video"
        "shorts" -> "Shorts"
        "livestreams" -> "Live"
        "playlists" -> "Playlist"
        "albums" -> "Album"
        "tracks" -> "Lagu"
        "releases" -> "Rilis"
        else -> null
    }

    fun channel(url: String): ChannelDetails = cached("ch|$url") {
        init()
        val info = ChannelInfo.getInfo(service(), url)
        val tabs = ArrayList<ChannelTab>()
        for (h in info.getTabs()) {
            val id = h.getContentFilters().firstOrNull() ?: continue
            val label = tabLabel(id) ?: continue
            tabs.add(ChannelTab(id, label, h))
        }
        // Video dulu, lalu urutan aslinya.
        tabs.sortBy { if (it.id == "videos") 0 else 1 }
        ChannelDetails(
            url = url,
            name = info.getName() ?: "",
            avatar = bestImage(info.getAvatars()),
            banner = bestImage(info.getBanners()),
            subscribers = info.getSubscriberCount(),
            description = info.getDescription() ?: "",
            tabs = tabs,
        )
    }

    fun openTab(tab: ChannelTab): TabSession {
        init()
        val ex: ListExtractor<InfoItem> = service().getChannelTabExtractor(tab.handler)
        return TabSession(ex)
    }

    class TabSession internal constructor(private val ex: ListExtractor<InfoItem>) : Pager {

        private var next: ExtractorPage? = null

        override var hasMore: Boolean = false
            private set

        override fun first(): Batch {
            ex.fetchPage()
            return consume(ex.getInitialPage())
        }

        override fun more(): Batch {
            val p = next ?: return Batch(emptyList(), emptyList())
            return consume(ex.getPage(p))
        }

        private fun consume(page: ListExtractor.InfoItemsPage<InfoItem>): Batch {
            next = page.getNextPage()
            hasMore = next != null
            return toBatch(page.getItems(), true)
        }
    }

    /** Video terbaru sebuah channel (untuk tab Langganan). BLOKING. */
    fun latestVideos(channelUrl: String, limit: Int): List<Track> {
        val details = channel(channelUrl)
        val tab = details.tabs.firstOrNull { it.id == "videos" } ?: return emptyList()
        val batch = openTab(tab).first()
        return batch.tracks.filter { !it.live }.take(limit)
    }

    // ---------------- Album / playlist ----------------

    class AlbumDetails(
        val title: String,
        val artist: String,
        val artistUrl: String?,
        val thumb: String?,
        val tracks: List<Track>,
    )

    fun album(url: String): AlbumDetails = cached("al|$url") {
        init()
        // Sumber utama: YouTube Music (daftar lagu, artis, dan sampul HD lengkap). Bila gagal: sistem lama.
        val viaMusic = try {
            MusicApi.album(url)
        } catch (e: Exception) {
            null
        }
        if (viaMusic != null && viaMusic.tracks.isNotEmpty()) return@cached viaMusic
        val listId = Regex("[?&]list=([A-Za-z0-9_-]+)").find(url)?.groupValues?.get(1)
        val oldUrl = if (listId != null && url.contains("/browse/")) {
            "https://www.youtube.com/playlist?list=$listId"
        } else {
            url
        }
        val info = PlaylistInfo.getInfo(service(), oldUrl)
        val cover = bestImage(info.getThumbnails())
        val owner = info.getUploaderName() ?: ""
        val tracks = ArrayList<Track>()
        for (item in info.getRelatedItems()) {
            val t = toTrack(item, false) ?: continue
            tracks.add(
                t.copy(
                    thumb = cover ?: t.thumb,
                    artist = if (t.artist.isBlank()) owner else t.artist,
                ),
            )
        }
        AlbumDetails(
            title = info.getName() ?: "",
            artist = owner,
            artistUrl = info.getUploaderUrl()?.takeIf { it.isNotBlank() },
            thumb = cover,
            tracks = tracks,
        )
    }
}
