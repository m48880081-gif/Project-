package app.mixbase.data

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** Teks sudah dalam bahasa tujuan, tidak perlu diterjemahkan. */
class SameLanguageException(val language: String) : Exception("Teks sudah berbahasa $language")

/** Bahasa asal tidak bisa dikenali. */
class UnknownLanguageException : Exception("Bahasa teks tidak dikenali")

/**
 * Terjemahan di perangkat memakai ML Kit (gratis, tanpa kunci API). Model tiap bahasa (± 30 MB)
 * diunduh sekali saat pertama dipakai, setelah itu terjemahan berjalan tanpa internet.
 */
object Translate {

    private val cache = ConcurrentHashMap<String, String>()
    private val translators = ConcurrentHashMap<String, Translator>()
    private val ready = ConcurrentHashMap<String, Boolean>()
    private val failedAt = ConcurrentHashMap<String, Long>()
    private val modelLock = Mutex()
    private val titleGate = Semaphore(2)

    private val detector by lazy {
        LanguageIdentification.getClient(
            LanguageIdentificationOptions.Builder().setConfidenceThreshold(0.5f).build(),
        )
    }

    /** Hasil terjemahan yang sudah tersimpan, atau null. */
    fun cached(text: String, target: String): String? = cache["$target|$text"]

    /** Kode bahasa dasar teks ("en", "id", ...), atau null bila tidak dikenali. */
    suspend fun detect(text: String): String? = withContext(Dispatchers.IO) {
        val tag = Tasks.await(detector.identifyLanguage(text), 15, TimeUnit.SECONDS)
        if (tag == null || tag == "und" || tag.contains("-Latn")) null else Languages.baseOf(tag)
    }

    private suspend fun translatorFor(source: String, target: String): Translator {
        val key = "$source>$target"
        val tr = translators.getOrPut(key) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(source)
                    .setTargetLanguage(target)
                    .build(),
            )
        }
        if (ready[key] != true) {
            modelLock.withLock {
                if (ready[key] != true) {
                    withContext(Dispatchers.IO) {
                        Tasks.await(
                            tr.downloadModelIfNeeded(DownloadConditions.Builder().build()),
                            5,
                            TimeUnit.MINUTES,
                        )
                    }
                    ready[key] = true
                }
            }
        }
        return tr
    }

    /** Terjemahkan satu teks dari [source] ke [target]. Melempar exception bila gagal. */
    suspend fun run(text: String, source: String, target: String): String {
        val key = "$target|$text"
        cache[key]?.let { return it }
        val tr = translatorFor(source, target)
        val out = withContext(Dispatchers.IO) {
            Tasks.await(tr.translate(text), 30, TimeUnit.SECONDS)
        }
        cache[key] = out
        return out
    }

    /**
     * Judul video dalam bahasa [target]. Bila gagal atau bahasanya sudah sama, hasilnya teks asli.
     * Setelah satu kegagalan (mis. model belum bisa diunduh) percobaan berikutnya ditunda dua menit.
     */
    suspend fun title(text: String, target: String): String {
        cache["$target|$text"]?.let { return it }
        if (text.count { it.isLetter() } < 4) return text
        val last = failedAt[target]
        if (last != null && System.currentTimeMillis() - last < 120_000L) return text
        return try {
            titleGate.withPermit {
                val src = detect(text)
                if (src == null || src == target) {
                    cache["$target|$text"] = text
                    text
                } else {
                    run(text, src, target)
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            failedAt[target] = System.currentTimeMillis()
            text
        }
    }

    /**
     * Terjemahkan banyak baris (lirik). Baris kosong dibiarkan, baris yang sama diterjemahkan sekali.
     * Melempar [SameLanguageException] bila lirik sudah berbahasa tujuan.
     */
    suspend fun lines(lines: List<String>, target: String, onProgress: (Int) -> Unit = {}): List<String> {
        val sample = lines.filter { it.isNotBlank() }.take(24).joinToString("\n").take(600)
        val source = detect(sample) ?: throw UnknownLanguageException()
        if (source == target) throw SameLanguageException(Languages.byCode(target)?.name ?: target)
        val out = ArrayList<String>(lines.size)
        for ((i, line) in lines.withIndex()) {
            val t = line.trim()
            out.add(if (t.isEmpty() || t == "♪") line else run(t, source, target))
            if (i % 4 == 0) onProgress(i)
        }
        onProgress(lines.size)
        return out
    }
}
