package app.mixbase.data

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/**
 * Sumber metadata musik dari YouTube Music (klien "WEB_REMIX", cara yang sama dipakai InnerTune):
 * pencarian lagu/album/artis, halaman artis, dan halaman album, lengkap dengan gambar sampul.
 *
 * HANYA metadata. Setiap lagu dikembalikan sebagai [Track] dengan url halaman
 * https://www.youtube.com/watch?v=ID, jadi pemutaran audio tetap lewat sistem lama (NewPipe).
 *
 * Semua fungsi BLOKING (jaringan) — panggil dari Dispatchers.IO. Bila YouTube mengubah bentuk
 * balasan, parser sengaja longgar (mencari berdasarkan nama renderer, bukan posisi); kalau tetap
 * gagal, pemanggil jatuh kembali ke sistem lama.
 */
object MusicApi {
    /** Bahasa data YouTube Music: sengaja tetap Inggris karena pembacaan datanya bergantung pada teks Inggris. */
    private const val hl: String = "en"


    private const val BASE = "https://music.youtube.com/youtubei/v1/"
    private const val KEY = "AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
    private const val FIRST_VERSION = "1.20220606.03.00"
    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0"
    private const val CACHE_MS = 10L * 60L * 1000L

    private const val T_ALBUM = "MUSIC_PAGE_TYPE_ALBUM"
    private const val T_ARTIST = "MUSIC_PAGE_TYPE_ARTIST"
    private const val T_CHANNEL = "MUSIC_PAGE_TYPE_USER_CHANNEL"
    private const val T_PLAYLIST = "MUSIC_PAGE_TYPE_PLAYLIST"

    private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()

    private val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    class ApiException(message: String) : Exception(message)

    /** Rujukan ke artis/album dari sebuah baris teks ("Billie Eilish" yang bisa diketuk). */
    class Ref(val id: String, val name: String, val type: String)

    /** Tujuan tombol "Lihat semua" sebuah bagian. */
    class More(val browseId: String, val params: String?)

    class ArtistPage(
        val id: String,
        val name: String,
        val avatar: String?,
        val banner: String?,
        val subscribers: Long,
        val description: String,
        val songs: List<Track>,
        val albums: List<Entry>,
        val singles: List<Entry>,
        val videos: List<Track>,
        val playlists: List<Entry>,
        val similar: List<Entry>,
        val songsMore: More?,
        val albumsMore: More?,
        val singlesMore: More?,
        val videosMore: More?,
        val playlistsMore: More?,
        val pageArtist: Ref,
    )

    // ---------------- Jaringan ----------------

    @Volatile
    private var goodVersion: String = FIRST_VERSION

    @Volatile
    private var liveVersion: String? = null

    @Volatile
    private var liveTried = false

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private fun post(endpoint: String, body: JSONObject, query: String = ""): JSONObject {
        val first = goodVersion
        try {
            return postWith(endpoint, body, query, first)
        } catch (e: ApiException) {
            val live = liveVersion ?: fetchLiveVersion()
            if (live == null || live == first) throw e
            val json = postWith(endpoint, body, query, live)
            goodVersion = live
            return json
        }
    }

    private fun postWith(endpoint: String, body: JSONObject, query: String, version: String): JSONObject {
        val cl = JSONObject()
            .put("clientName", "WEB_REMIX")
            .put("clientVersion", version)
            .put("hl", hl)
            .put("gl", "ID")
        body.put("context", JSONObject().put("client", cl))
        val req = Request.Builder()
            .url("$BASE$endpoint?key=$KEY&prettyPrint=false$query")
            .post(body.toString().toRequestBody(JSON_TYPE))
            .header("User-Agent", UA)
            .header("Accept", "*/*")
            .header("X-Goog-Api-Format-Version", "1")
            .header("X-YouTube-Client-Name", "67")
            .header("X-YouTube-Client-Version", version)
            .header("x-origin", "https://music.youtube.com")
            .header("Referer", "https://music.youtube.com/")
            .build()
        return http.newCall(req).execute().use { resp ->
            val text = resp.body?.string() ?: ""
            if (!resp.isSuccessful) throw ApiException("YouTube Music HTTP ${resp.code}")
            try {
                JSONObject(text)
            } catch (e: Exception) {
                throw ApiException("Balasan YouTube Music tidak terbaca")
            }
        }
    }

    /** Versi klien terbaru dari halaman music.youtube.com (dipakai bila versi bawaan ditolak). */
    private fun fetchLiveVersion(): String? {
        if (liveTried) return liveVersion
        liveTried = true
        return try {
            val req = Request.Builder()
                .url("https://music.youtube.com/")
                .header("User-Agent", UA)
                .header("Accept-Language", "en-US,en;q=0.9")
                .build()
            val html = http.newCall(req).execute().use { it.body?.string() ?: "" }
            val m = Regex("\"INNERTUBE_CONTEXT_CLIENT_VERSION\"\\s*:\\s*\"([0-9][0-9.]*)\"").find(html)
                ?: Regex("\"clientVersion\"\\s*:\\s*\"(1\\.[0-9.]+)\"").find(html)
            val v = m?.groupValues?.get(1)
            liveVersion = v
            v
        } catch (e: Exception) {
            null
        }
    }

    // ---------------- Cache kecil ----------------

    private class CachedPage(val value: Any, val at: Long)

    private val pages = HashMap<String, CachedPage>()

    @Suppress("UNCHECKED_CAST")
    private fun <T : Any> cachedPage(key: String, load: () -> T): T {
        val now = System.currentTimeMillis()
        synchronized(pages) {
            val c = pages[key]
            if (c != null && now - c.at < CACHE_MS) return c.value as T
        }
        val v = load()
        synchronized(pages) {
            pages[key] = CachedPage(v, now)
            if (pages.size > 40) {
                val oldest = pages.entries.minByOrNull { it.value.at }
                if (oldest != null) pages.remove(oldest.key)
            }
        }
        return v
    }

    // ---------------- Alat baca JSON ----------------

    /** Ambil nilai di jalur [path] (String = kunci objek, Int = indeks larik); null bila tidak ada. */
    private fun at(root: Any?, vararg path: Any): Any? {
        var cur: Any? = root
        for (p in path) {
            val next: Any? = when {
                p is String && cur is JSONObject -> cur.opt(p)
                p is Int && cur is JSONArray -> cur.opt(p)
                else -> null
            }
            if (next == null || next == JSONObject.NULL) return null
            cur = next
        }
        return cur
    }

    private fun str(root: Any?, vararg path: Any): String? = at(root, *path) as? String

    private class Found(val key: String, val node: JSONObject)

    /** Cari semua objek bernama salah satu [keys] (urutan dokumen); tidak masuk ke dalam yang ditemukan. */
    private fun walkKeys(node: Any?, keys: Set<String>): List<Found> {
        val out = ArrayList<Found>()
        walk(node, keys, out, 0)
        return out
    }

    private fun walk(node: Any?, keys: Set<String>, out: MutableList<Found>, depth: Int) {
        if (depth > 60) return
        if (node is JSONObject) {
            val names = node.keys()
            while (names.hasNext()) {
                val k = names.next()
                val v = node.opt(k)
                if (v is JSONObject && k in keys) {
                    out.add(Found(k, v))
                } else {
                    walk(v, keys, out, depth + 1)
                }
            }
        } else if (node is JSONArray) {
            for (i in 0 until node.length()) {
                walk(node.opt(i), keys, out, depth + 1)
            }
        }
    }

    private fun firstArray(node: Any?, key: String, depth: Int = 0): JSONArray? {
        if (depth > 12) return null
        if (node is JSONObject) {
            val direct = node.optJSONArray(key)
            if (direct != null) return direct
            val names = node.keys()
            while (names.hasNext()) {
                val found = firstArray(node.opt(names.next()), key, depth + 1)
                if (found != null) return found
            }
        } else if (node is JSONArray) {
            for (i in 0 until node.length()) {
                val found = firstArray(node.opt(i), key, depth + 1)
                if (found != null) return found
            }
        }
        return null
    }

    private fun runsOf(node: Any?): List<JSONObject> {
        val arr = at(node, "runs") as? JSONArray ?: return emptyList()
        val out = ArrayList<JSONObject>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            if (o != null) out.add(o)
        }
        return out
    }

    private fun textOf(node: Any?): String {
        val runs = runsOf(node)
        if (runs.isNotEmpty()) return runs.joinToString("") { it.optString("text") }
        return (node as? JSONObject)?.optString("simpleText") ?: ""
    }

    // ---------------- Gambar ----------------

    /** Gambar terbesar dari sebuah simpul (mencari larik "thumbnails"). Gambar Google dibesarkan ke [px]. */
    private fun bestThumb(node: Any?, px: Int = 544): String? {
        val arr = firstArray(node, "thumbnails") ?: return null
        var best: String? = null
        var bestWidth = -1
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val u = o.optString("url")
            if (u.isEmpty()) continue
            val w = o.optInt("width", 0)
            if (w >= bestWidth) {
                bestWidth = w
                best = u
            }
        }
        val url = best ?: return null
        val full = if (url.startsWith("//")) "https:$url" else url
        return if (full.contains("googleusercontent.com") || full.contains("ggpht.com")) {
            hdArt(full, px) ?: full
        } else {
            full
        }
    }

    private fun thumbOf(item: JSONObject, px: Int = 544): String? {
        val src = item.opt("thumbnail") ?: item.opt("thumbnailRenderer") ?: item.opt("foregroundThumbnail")
        return bestThumb(src, px)
    }

    // ---------------- URL ----------------

    fun watchUrl(videoId: String): String = "https://www.youtube.com/watch?v=$videoId"

    fun channelUrl(id: String): String = "https://www.youtube.com/channel/" + id.removePrefix("MPLA")

    private fun playlistUrl(id: String): String = "https://www.youtube.com/playlist?list=$id"

    private fun albumUrl(browseId: String, playlistId: String?): String {
        val base = "https://music.youtube.com/browse/$browseId"
        return if (playlistId.isNullOrEmpty()) base else "$base?list=$playlistId"
    }

    private fun browseIdOf(url: String): String? =
        Regex("/browse/([A-Za-z0-9_-]+)").find(url)?.groupValues?.get(1)

    private fun playlistIdOf(url: String): String? =
        Regex("[?&]list=([A-Za-z0-9_-]+)").find(url)?.groupValues?.get(1)

    private fun channelIdOf(url: String): String? =
        Regex("/channel/([A-Za-z0-9_-]+)").find(url)?.groupValues?.get(1)

    // ---------------- Baris teks (artis • album • durasi ...) ----------------

    private val DURATION = Regex("^\\d{1,2}(:\\d{2}){1,2}$")
    private val COUNTED = Regex("(?i)^[\\d][\\d.,]*\\s*[KMB]?\\s+(views?|plays?)$")
    private val PLAIN_NUMBER = Regex("^[\\d.,]+\\s*[KMBkmb]?$")
    private val SEPARATORS = setOf("•", "&", ",", "·", "and")
    private val TYPE_LABELS = setOf(
        "Song", "Video", "Single", "Album", "EP", "Playlist", "Episode", "Podcast", "Artist", "Profile",
    )
    private val RELEASE_TYPES = setOf("Album", "Single", "EP")

    private class Meta(
        val artists: List<Ref>,
        val album: Ref?,
        val duration: Long,
        val views: Long,
        val loose: List<String>,
    )

    private fun pageTypeOf(be: JSONObject?): String =
        str(be, "browseEndpointContextSupportedConfigs", "browseEndpointContextMusicConfig", "pageType") ?: ""

    private fun refOf(run: JSONObject): Ref? {
        val be = at(run, "navigationEndpoint", "browseEndpoint") as? JSONObject ?: return null
        val id = be.optString("browseId")
        if (id.isEmpty()) return null
        return Ref(id, run.optString("text").trim(), pageTypeOf(be))
    }

    private fun isArtistType(type: String, id: String): Boolean =
        type == T_ARTIST || type == T_CHANNEL || (type.isEmpty() && id.startsWith("UC"))

    private fun parseDuration(text: String): Long {
        var total = 0L
        for (part in text.split(":")) {
            total = total * 60L + (part.toLongOrNull() ?: 0L)
        }
        return total
    }

    /** "1.2M" -> 1200000, "523K" -> 523000, "12,345,678" -> 12345678; -1 bila tidak ada angka. */
    fun parseCount(text: String): Long {
        val m = Regex("([0-9][0-9.,]*)\\s*([KkMmBb])?").find(text) ?: return -1L
        val num = m.groupValues[1]
        val unit = m.groupValues[2].uppercase()
        if (unit.isEmpty()) {
            return num.replace(".", "").replace(",", "").toLongOrNull() ?: -1L
        }
        val value = num.replace(",", "").toDoubleOrNull() ?: return -1L
        val mult = when (unit) {
            "K" -> 1_000.0
            "M" -> 1_000_000.0
            else -> 1_000_000_000.0
        }
        return (value * mult).toLong()
    }

    private fun metaOf(runs: List<JSONObject>): Meta {
        val artists = ArrayList<Ref>()
        var album: Ref? = null
        var duration = -1L
        var views = -1L
        val loose = ArrayList<String>()
        for (r in runs) {
            val text = r.optString("text").trim()
            if (text.isEmpty() || text in SEPARATORS) continue
            val ref = refOf(r)
            if (ref != null) {
                if (ref.type == T_ALBUM) {
                    album = ref
                } else if (isArtistType(ref.type, ref.id)) {
                    artists.add(ref)
                } else {
                    loose.add(text)
                }
                continue
            }
            if (DURATION.matches(text)) {
                duration = parseDuration(text)
                continue
            }
            if (COUNTED.matches(text)) {
                views = parseCount(text)
                continue
            }
            loose.add(text)
        }
        return Meta(artists, album, duration, views, loose)
    }

    /** Terjemahan ringan teks keterangan ("12 songs" -> "12 lagu", "1.2M views" -> "1,2 jt x ditonton"). */
    private fun localize(t: String): String {
        if (COUNTED.matches(t)) {
            val n = parseCount(t)
            if (n >= 0L) {
                return compactCount(n) + if (t.trim().endsWith("plays", true) || t.trim().endsWith("play", true)) {
                    " x diputar"
                } else {
                    " x ditonton"
                }
            }
        }
        return t.replace(Regex("(?i)\\b(\\d[\\d,.]*)\\s+(songs?|tracks?)\\b"), "$1 lagu")
    }

    private fun subOf(m: Meta, pageArtist: Ref?): String {
        val parts = ArrayList<String>()
        if (m.artists.isNotEmpty()) {
            parts.add(m.artists.joinToString(", ") { it.name })
        } else if (pageArtist != null && pageArtist.name.isNotBlank()) {
            parts.add(pageArtist.name)
        }
        for (t in m.loose) {
            if (t in TYPE_LABELS) continue
            parts.add(localize(t))
        }
        return parts.joinToString(" • ")
    }

    private fun artistSub(runs: List<JSONObject>): String {
        for (r in runs) {
            val t = r.optString("text").trim()
            val low = t.lowercase()
            if (low.contains("subscriber")) {
                val n = parseCount(t)
                if (n >= 0L) return compactCount(n) + " subscriber"
            }
            if (low.contains("monthly audience") || low.contains("listeners")) {
                val n = parseCount(t)
                if (n >= 0L) return compactCount(n) + " pendengar bulanan"
            }
        }
        return ""
    }

    // ---------------- Item -> Track / Entry ----------------

    private fun flexRuns(r: JSONObject, col: Int): List<JSONObject> =
        runsOf(at(r, "flexColumns", col, "musicResponsiveListItemFlexColumnRenderer", "text"))

    private fun flexCount(r: JSONObject): Int = r.optJSONArray("flexColumns")?.length() ?: 0

    private fun videoIdOf(r: JSONObject): String? {
        val a = str(r, "playlistItemData", "videoId")
        if (!a.isNullOrEmpty()) return a
        val b = str(
            r, "flexColumns", 0, "musicResponsiveListItemFlexColumnRenderer", "text", "runs", 0,
            "navigationEndpoint", "watchEndpoint", "videoId",
        )
        if (!b.isNullOrEmpty()) return b
        val c = str(
            r, "overlay", "musicItemThumbnailOverlayRenderer", "content", "musicPlayButtonRenderer",
            "playNavigationEndpoint", "watchEndpoint", "videoId",
        )
        return if (c.isNullOrEmpty()) null else c
    }

    /** ID playlist album (OLAK5uy_...) dari tombol putar sebuah kartu; ID radio/mix diabaikan. */
    private fun playlistIdIn(node: JSONObject): String? {
        for (f in walkKeys(node, setOf("watchPlaylistEndpoint"))) {
            val id = f.node.optString("playlistId")
            if (id.startsWith("OLAK5uy_")) return id
        }
        return null
    }

    private fun trackOf(
        id: String,
        title: String,
        m: Meta,
        pageArtist: Ref?,
        thumb: String?,
        fixedDuration: Long,
    ): Track {
        val artists = m.artists
        val artistName = when {
            artists.isNotEmpty() -> artists.joinToString(", ") { it.name }
            pageArtist != null && pageArtist.name.isNotBlank() -> pageArtist.name
            else -> m.loose.firstOrNull { it !in TYPE_LABELS && !PLAIN_NUMBER.matches(it) } ?: ""
        }
        val owner = artists.firstOrNull { it.id.startsWith("UC") } ?: pageArtist
        val duration = if (m.duration >= 0L) m.duration else if (fixedDuration >= 0L) fixedDuration else 0L
        return Track(
            url = watchUrl(id),
            title = title,
            artist = artistName,
            durationSec = duration,
            thumb = thumb,
            uploaderUrl = if (owner != null && owner.id.startsWith("UC")) channelUrl(owner.id) else null,
            views = m.views,
        )
    }

    private fun songFrom(r: JSONObject, id: String, pageArtist: Ref?): Track? {
        val title = flexRuns(r, 0).joinToString("") { it.optString("text") }.trim()
        if (title.isEmpty()) return null
        val rest = ArrayList<JSONObject>()
        for (c in 1 until flexCount(r)) rest.addAll(flexRuns(r, c))
        val m = metaOf(rest)
        val fixed = runsOf(
            at(r, "fixedColumns", 0, "musicResponsiveListItemFixedColumnRenderer", "text"),
        ).joinToString("") { it.optString("text") }.trim()
        val fixedDuration = if (DURATION.matches(fixed)) parseDuration(fixed) else -1L
        return trackOf(id, title, m, pageArtist, thumbOf(r), fixedDuration)
    }

    private fun entryOf(
        id: String,
        type: String,
        title: String,
        runs: List<JSONObject>,
        thumb: String?,
        playlistId: String?,
        pageArtist: Ref?,
    ): Entry? {
        if (id.isEmpty() || title.isEmpty()) return null
        val label = runs.map { it.optString("text").trim() }.firstOrNull { it in RELEASE_TYPES } ?: ""
        return when {
            type == T_ALBUM || id.startsWith("MPREb_") ->
                Entry(Entry.ALBUM, albumUrl(id, playlistId), title, subOf(metaOf(runs), pageArtist), thumb, label)
            isArtistType(type, id) ->
                Entry(Entry.ARTIST, channelUrl(id), title, artistSub(runs), thumb)
            type == T_PLAYLIST || id.startsWith("VL") ->
                Entry(Entry.PLAYLIST, playlistUrl(id.removePrefix("VL")), title, subOf(metaOf(runs), null), thumb)
            else -> null
        }
    }

    /** Baris daftar (hasil pencarian, isi rak lagu, isi album): lagu/video atau album/artis/playlist. */
    private fun fromList(r: JSONObject, pageArtist: Ref?): Any? {
        val vid = videoIdOf(r)
        if (vid != null) return songFrom(r, vid, pageArtist)
        val be = at(r, "navigationEndpoint", "browseEndpoint") as? JSONObject ?: return null
        val title = flexRuns(r, 0).joinToString("") { it.optString("text") }.trim()
        val rest = ArrayList<JSONObject>()
        for (c in 1 until flexCount(r)) rest.addAll(flexRuns(r, c))
        return entryOf(be.optString("browseId"), pageTypeOf(be), title, rest, thumbOf(r), playlistIdIn(r), pageArtist)
    }

    /** Kartu persegi (rak di halaman artis): album, single, artis, playlist, atau video. */
    private fun fromTwoRow(r: JSONObject, pageArtist: Ref?): Any? {
        val title = textOf(r.opt("title")).trim()
        if (title.isEmpty()) return null
        val runs = runsOf(r.opt("subtitle"))
        val nav = r.optJSONObject("navigationEndpoint")
        val watch = nav?.optJSONObject("watchEndpoint")
        if (watch != null) {
            val vid = watch.optString("videoId")
            if (vid.isEmpty()) return null
            return trackOf(vid, title, metaOf(runs), pageArtist, thumbOf(r), -1L)
        }
        val be = nav?.optJSONObject("browseEndpoint") ?: return null
        return entryOf(be.optString("browseId"), pageTypeOf(be), title, runs, thumbOf(r), playlistIdIn(r), pageArtist)
    }

    private val ITEM_KEYS = setOf("musicResponsiveListItemRenderer", "musicTwoRowItemRenderer")

    private fun parseBatch(json: Any?, pageArtist: Ref?): Batch {
        val tracks = ArrayList<Track>()
        val entries = ArrayList<Entry>()
        val seenTracks = HashSet<String>()
        val seenEntries = HashSet<String>()
        for (f in walkKeys(json, ITEM_KEYS)) {
            val v = if (f.key == "musicTwoRowItemRenderer") {
                fromTwoRow(f.node, pageArtist)
            } else {
                fromList(f.node, pageArtist)
            }
            if (v is Track) {
                if (seenTracks.add(v.url)) tracks.add(v)
            } else if (v is Entry) {
                if (seenEntries.add(v.url)) entries.add(v)
            }
        }
        return Batch(tracks, entries)
    }

    private fun continuationOf(json: Any?): String? {
        for (f in walkKeys(json, setOf("nextContinuationData"))) {
            val t = f.node.optString("continuation")
            if (t.isNotEmpty()) return t
        }
        for (f in walkKeys(json, setOf("continuationCommand"))) {
            val t = f.node.optString("token")
            if (t.isNotEmpty()) return t
        }
        return null
    }

    // ---------------- Pencarian ----------------

    private fun searchParams(filter: String): String? = when (filter) {
        Engine.FILTER_MUSIC -> "EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D"
        Engine.FILTER_MUSIC_VIDEO -> "EgWKAQIQAWoKEAkQChAFEAMQBA%3D%3D"
        Engine.FILTER_ALBUM -> "EgWKAQIYAWoKEAkQChAFEAMQBA%3D%3D"
        Engine.FILTER_ARTIST -> "EgWKAQIgAWoKEAkQChAFEAMQBA%3D%3D"
        else -> null
    }

    /** true bila [filter] bisa dilayani YouTube Music. */
    fun supports(filter: String): Boolean = searchParams(filter) != null

    /** Pencarian berhalaman; [filter] salah satu Engine.FILTER_MUSIC / ALBUM / ARTIST / MUSIC_VIDEO. */
    fun searchPager(query: String, filter: String): Engine.Pager {
        val params = searchParams(filter) ?: throw ApiException("Filter tidak didukung")
        return SearchPager(query, params)
    }

    private class SearchPager(private val query: String, private val params: String) : Engine.Pager {
        private var token: String? = null

        override var hasMore: Boolean = false
            private set

        override fun first(): Batch {
            val json = post("search", JSONObject().put("query", query).put("params", params))
            return consume(json)
        }

        override fun more(): Batch {
            val t = token ?: return Batch(emptyList(), emptyList())
            val json = post("search", JSONObject(), "&ctoken=${enc(t)}&continuation=${enc(t)}&type=next")
            return consume(json)
        }

        private fun consume(json: JSONObject): Batch {
            val b = parseBatch(json, null)
            token = continuationOf(json)
            hasMore = token != null
            return b
        }
    }

    // ---------------- Beranda (FEmusic_home) ----------------

    /**
     * Satu rak di beranda YouTube Music: judul, teks kecil di atas judul ([overline]), isi, dan tujuan
     * panah "lihat semua". [list] = true bila isinya baris daftar lagu (bukan kartu persegi).
     */
    class HomeShelf(
        val title: String,
        val overline: String,
        val tracks: List<Track>,
        val entries: List<Entry>,
        val list: Boolean,
        val more: More?,
    )

    /** Satu halaman beranda: rak-rak di dalamnya dan token halaman berikutnya (null bila habis). */
    class HomePage(val shelves: List<HomeShelf>, val next: String?)

    private val SHELF_KEYS = setOf(
        "musicCarouselShelfRenderer",
        "musicImmersiveCarouselShelfRenderer",
        "musicShelfRenderer",
    )

    /**
     * Beranda YouTube Music (tanpa akun): rak-rak seperti "Quick picks", "Today's hits", "New releases".
     * [continuation] = token dari halaman sebelumnya untuk mengambil rak berikutnya. BLOKING.
     */
    fun home(continuation: String? = null): HomePage {
        val json = if (continuation == null) {
            post("browse", JSONObject().put("browseId", "FEmusic_home"))
        } else {
            post(
                "browse",
                JSONObject(),
                "&ctoken=${enc(continuation)}&continuation=${enc(continuation)}&type=next",
            )
        }
        val shelves = ArrayList<HomeShelf>()
        for (f in walkKeys(json, SHELF_KEYS)) {
            val s = homeShelf(f.node) ?: continue
            shelves.add(s)
        }
        val next = str(
            json, "contents", "singleColumnBrowseResultsRenderer", "tabs", 0, "tabRenderer", "content",
            "sectionListRenderer", "continuations", 0, "nextContinuationData", "continuation",
        ) ?: str(
            json, "continuationContents", "sectionListContinuation", "continuations", 0,
            "nextContinuationData", "continuation",
        ) ?: continuationOf(json)
        return HomePage(shelves, next)
    }

    private fun homeShelf(node: JSONObject): HomeShelf? {
        val head = at(node, "header", "musicCarouselShelfBasicHeaderRenderer") as? JSONObject
        val title = textOf(head?.opt("title") ?: node.opt("title")).trim()
        val overline = textOf(head?.opt("strapline")).trim()
        val contents = node.optJSONArray("contents") ?: return null
        var list = false
        for (i in 0 until contents.length()) {
            if (contents.optJSONObject(i)?.has("musicResponsiveListItemRenderer") == true) {
                list = true
                break
            }
        }
        val batch = parseBatch(contents, null)
        if (title.isEmpty() || (batch.tracks.isEmpty() && batch.entries.isEmpty())) return null
        return HomeShelf(title, overline, batch.tracks, batch.entries, list, moreOf(node))
    }

    // ---------------- Halaman artis ----------------

    private val HEADER_KEYS = setOf(
        "musicImmersiveHeaderRenderer",
        "musicVisualHeaderRenderer",
        "musicResponsiveHeaderRenderer",
        "musicDetailHeaderRenderer",
        "musicEditablePlaylistDetailHeaderRenderer",
        "musicHeaderRenderer",
    )

    private val SECTION_KEYS = setOf(
        "musicShelfRenderer",
        "musicCarouselShelfRenderer",
        "musicDescriptionShelfRenderer",
    )

    private fun headerOf(json: JSONObject): JSONObject? {
        val top = json.optJSONObject("header")
        if (top != null) {
            val f = walkKeys(top, HEADER_KEYS).firstOrNull()
            if (f != null) return f.node
        }
        return walkKeys(json, HEADER_KEYS).firstOrNull()?.node
    }

    private fun moreOf(node: JSONObject): More? {
        val be = at(
            node, "header", "musicCarouselShelfBasicHeaderRenderer", "moreContentButton", "buttonRenderer",
            "navigationEndpoint", "browseEndpoint",
        ) as? JSONObject
            ?: at(node, "bottomEndpoint", "browseEndpoint") as? JSONObject
            ?: at(node, "title", "runs", 0, "navigationEndpoint", "browseEndpoint") as? JSONObject
            ?: return null
        val id = be.optString("browseId")
        if (id.isEmpty()) return null
        val params = be.optString("params")
        return More(id, if (params.isEmpty()) null else params)
    }

    private fun browseBody(more: More): JSONObject {
        val b = JSONObject().put("browseId", more.browseId)
        if (more.params != null) b.put("params", more.params)
        return b
    }

    /** Halaman artis lengkap: lagu teratas, album, single & EP, video, playlist, dan artis serupa. */
    fun artist(url: String): ArtistPage = cachedPage("ar|$url") {
        val id = channelIdOf(url) ?: browseIdOf(url) ?: throw ApiException("URL artis tidak dikenali")
        val json = post("browse", JSONObject().put("browseId", id))
        parseArtist(id, json)
    }

    private fun parseArtist(id: String, json: JSONObject): ArtistPage {
        val header = headerOf(json)
        val name = textOf(header?.opt("title")).trim()
        var description = textOf(header?.opt("description")).trim()
        val subText = textOf(at(header, "subscriptionButton", "subscribeButtonRenderer", "subscriberCountText"))
            .ifBlank { textOf(at(header, "subscriptionButton", "subscribeButtonRenderer", "longSubscriberCountText")) }
        val subscribers = if (subText.isBlank()) -1L else parseCount(subText)
        val hero = if (header != null) bestThumb(header.opt("thumbnail"), 1080) else null
        val face = if (header != null) bestThumb(header.opt("foregroundThumbnail"), 800) else null
        val me = Ref(id, name, T_ARTIST)

        var songs: List<Track> = emptyList()
        var songsMore: More? = null
        var videos: List<Track> = emptyList()
        var videosMore: More? = null
        val albums = ArrayList<Entry>()
        val singles = ArrayList<Entry>()
        val playlists = ArrayList<Entry>()
        val similar = ArrayList<Entry>()
        var albumsMore: More? = null
        var singlesMore: More? = null
        var playlistsMore: More? = null

        for (f in walkKeys(json, SECTION_KEYS)) {
            if (f.key == "musicDescriptionShelfRenderer") {
                if (description.isBlank()) description = textOf(f.node.opt("description")).trim()
                continue
            }
            if (f.key == "musicShelfRenderer") {
                if (songs.isEmpty()) {
                    val list = parseBatch(f.node.opt("contents"), me).tracks
                    if (list.isNotEmpty()) {
                        songs = list
                        songsMore = moreOf(f.node)
                    }
                }
                continue
            }
            // musicCarouselShelfRenderer: kelompokkan menurut isinya
            val title = textOf(
                at(f.node, "header", "musicCarouselShelfBasicHeaderRenderer", "title"),
            ).lowercase()
            val batch = parseBatch(f.node.opt("contents"), me)
            val more = moreOf(f.node)
            if (batch.entries.isEmpty() && batch.tracks.isNotEmpty()) {
                if (videos.isEmpty()) {
                    videos = batch.tracks
                    videosMore = more
                }
                continue
            }
            if (batch.entries.isEmpty()) continue
            if (batch.entries.all { it.kind == Entry.ARTIST }) {
                similar.addAll(batch.entries)
            } else if (batch.entries.all { it.kind == Entry.PLAYLIST }) {
                playlists.addAll(batch.entries)
                if (playlistsMore == null) playlistsMore = more
            } else {
                val singleSection = title.contains("single")
                for (e in batch.entries) {
                    if (e.kind != Entry.ALBUM) continue
                    if (singleSection || e.type == "Single" || e.type == "EP") singles.add(e) else albums.add(e)
                }
                if (singleSection) {
                    if (singlesMore == null) singlesMore = more
                } else if (albumsMore == null) {
                    albumsMore = more
                }
            }
        }

        return ArtistPage(
            id = id,
            name = name,
            avatar = hero ?: face,
            banner = hero,
            subscribers = subscribers,
            description = description,
            songs = songs,
            albums = albums.distinctBy { it.url },
            singles = singles.distinctBy { it.url },
            videos = videos,
            playlists = playlists.distinctBy { it.url },
            similar = similar.distinctBy { it.url },
            songsMore = songsMore,
            albumsMore = albumsMore,
            singlesMore = singlesMore,
            videosMore = videosMore,
            playlistsMore = playlistsMore,
            pageArtist = me,
        )
    }

    /** Lagu-lagu tambahan artis (daftar "lihat semua"), tanpa yang sudah ada di rak lagu teratas. */
    fun moreSongs(p: ArtistPage, limit: Int = 30): List<Track> {
        val more = p.songsMore ?: return emptyList()
        val json = post("browse", browseBody(more))
        return parseBatch(json, p.pageArtist).tracks.take(limit)
    }

    private class StaticPager(private val batch: Batch) : Engine.Pager {
        override val hasMore: Boolean
            get() = false

        override fun first(): Batch = batch

        override fun more(): Batch = Batch(emptyList(), emptyList())
    }

    /** Pager untuk halaman "Lihat semua": ikuti tautan "lihat semua" bila ada, kalau tidak pakai isi rak. */
    private class BrowsePager(
        private val more: More,
        private val pageArtist: Ref?,
        private val seed: Batch,
    ) : Engine.Pager {
        private var token: String? = null

        override var hasMore: Boolean = false
            private set

        override fun first(): Batch {
            val json = try {
                post("browse", browseBody(more))
            } catch (e: ApiException) {
                null
            }
            if (json != null) {
                val b = parseBatch(json, pageArtist)
                if (b.tracks.isNotEmpty() || b.entries.isNotEmpty()) {
                    token = continuationOf(json)
                    hasMore = token != null
                    return b
                }
            }
            hasMore = false
            return seed
        }

        override fun more(): Batch {
            val t = token ?: return Batch(emptyList(), emptyList())
            val json = post("browse", JSONObject(), "&ctoken=${enc(t)}&continuation=${enc(t)}&type=next")
            val b = parseBatch(json, pageArtist)
            token = continuationOf(json)
            hasMore = token != null
            return b
        }
    }

    /** Daftar penuh satu jenis isi artis (Artist.ALBUMS / SINGLES / VIDEOS / PLAYLISTS); null bila kosong. */
    fun artistPager(url: String, kind: Int): Engine.Pager? {
        if (kind == Artist.MORE) {
            // Panah "lihat semua" di beranda: url = "more:<browseId>|<params>".
            val spec = url.removePrefix("more:")
            val browseId = spec.substringBefore('|')
            val params = spec.substringAfter('|', "")
            if (browseId.isEmpty()) return null
            return BrowsePager(More(browseId, params.ifEmpty { null }), null, Batch(emptyList(), emptyList()))
        }
        val p = artist(url)
        val more: More?
        val seed: Batch
        when (kind) {
            Artist.ALBUMS -> {
                more = p.albumsMore
                seed = Batch(emptyList(), p.albums)
            }
            Artist.SINGLES -> {
                more = p.singlesMore
                seed = Batch(emptyList(), p.singles)
            }
            Artist.VIDEOS -> {
                more = p.videosMore
                seed = Batch(p.videos, emptyList())
            }
            else -> {
                more = p.playlistsMore
                seed = Batch(emptyList(), p.playlists)
            }
        }
        if (more != null) return BrowsePager(more, p.pageArtist, seed)
        if (seed.tracks.isEmpty() && seed.entries.isEmpty()) return null
        return StaticPager(seed)
    }

    // ---------------- Halaman album / playlist ----------------

    /** Album atau playlist lengkap (judul, artis, sampul HD, daftar lagu). */
    fun album(url: String): Engine.AlbumDetails = cachedPage("al|$url") {
        val id = browseIdOf(url)
            ?: playlistIdOf(url)?.let { "VL$it" }
            ?: throw ApiException("URL album tidak dikenali")
        val json = post("browse", JSONObject().put("browseId", id))
        parseAlbum(id, json)
    }

    private fun parseAlbum(id: String, json: JSONObject): Engine.AlbumDetails {
        val header = headerOf(json) ?: throw ApiException("Header album tidak ada")
        val title = textOf(header.opt("title")).trim()
        if (title.isEmpty()) throw ApiException("Judul album kosong")
        val subRuns = ArrayList<JSONObject>()
        subRuns.addAll(runsOf(header.opt("straplineTextOne")))
        subRuns.addAll(runsOf(header.opt("subtitle")))
        val m = metaOf(subRuns)
        val firstArtist = m.artists.firstOrNull()
        val artistName = if (m.artists.isNotEmpty()) {
            m.artists.joinToString(", ") { it.name }
        } else {
            m.loose.firstOrNull { it !in TYPE_LABELS && !it.matches(Regex("^\\d{4}$")) } ?: ""
        }
        val cover = bestThumb(header.opt("thumbnail"), 1200)
        val me = Ref(firstArtist?.id ?: "", artistName, T_ARTIST)
        val forceCover = id.startsWith("MPREb_") || id.startsWith("VLOLAK5uy_")

        val tracks = ArrayList<Track>()
        val seen = HashSet<String>()
        val shelves = walkKeys(json, setOf("musicShelfRenderer", "musicPlaylistShelfRenderer"))
        for (shelf in shelves) {
            for (f in walkKeys(shelf.node, setOf("musicResponsiveListItemRenderer"))) {
                val v = fromList(f.node, me)
                if (v is Track && seen.add(v.url)) {
                    tracks.add(
                        v.copy(
                            thumb = if (forceCover) (cover ?: v.thumb) else (v.thumb ?: cover),
                            artist = if (v.artist.isBlank()) artistName else v.artist,
                        ),
                    )
                }
            }
        }
        if (tracks.isEmpty()) throw ApiException("Album tidak berisi lagu")
        return Engine.AlbumDetails(
            title = title,
            artist = artistName,
            artistUrl = if (firstArtist != null && firstArtist.id.startsWith("UC")) channelUrl(firstArtist.id) else null,
            thumb = cover,
            tracks = tracks,
        )
    }
}
