package app.mixbase.data

import java.util.Locale

/** Daftar bahasa yang bisa dipilih untuk konten (judul, deskripsi), suara dan terjemahan subtitle. */
object Languages {

    class Lang(
        /** Kode bahasa (ISO 639-1), mis. "id". */
        val code: String,
        /** Kode negara pasangan bahasa ini (untuk pengaturan lokal YouTube), mis. "ID". */
        val country: String,
        /** Nama bahasa dalam bahasanya sendiri. */
        val name: String,
    )

    val ALL: List<Lang> = listOf(
        Lang("id", "ID", "Indonesia"),
        Lang("en", "US", "English"),
        Lang("es", "ES", "Español"),
        Lang("pt", "BR", "Português"),
        Lang("fr", "FR", "Français"),
        Lang("de", "DE", "Deutsch"),
        Lang("ja", "JP", "日本語"),
        Lang("ko", "KR", "한국어"),
        Lang("zh", "CN", "中文"),
        Lang("ar", "SA", "العربية"),
        Lang("hi", "IN", "हिन्दी"),
        Lang("th", "TH", "ไทย"),
        Lang("vi", "VN", "Tiếng Việt"),
        Lang("tr", "TR", "Türkçe"),
        Lang("ru", "RU", "Русский"),
    )

    fun byCode(code: String): Lang? = ALL.firstOrNull { it.code == code }

    /** Bahasa dasar dari tag seperti "pt-BR" → "pt". */
    fun baseOf(tag: String): String = tag.substringBefore('-').substringBefore('_').lowercase()

    /** Nama bahasa untuk ditampilkan ("Inggris", "Jepang", ...) memakai nama dalam bahasa Indonesia. */
    fun nameOf(tag: String): String {
        if (tag.isBlank()) return ""
        return try {
            val name = Locale.forLanguageTag(tag.replace('_', '-')).getDisplayLanguage(Locale.forLanguageTag("id"))
            if (name.isNullOrBlank()) tag else name.replaceFirstChar { it.uppercase() }
        } catch (e: Exception) {
            tag
        }
    }
}
