package app.mixbase.data

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateRemoteModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Model bahasa ML Kit untuk menerjemahkan lirik di perangkat. Model tiap bahasa (± 30 MB) diunduh sekali,
 * setelah itu terjemahan berjalan tanpa internet. Dipakai saat memilih bahasa pertama kali dan di Setelan.
 */
object LangModels {

    /**
     * Bahasa yang perlu diunduh agar lirik bisa diterjemahkan ke [main]: bahasa utama, Inggris
     * (ML Kit memakainya sebagai perantara bila bahasa asal bukan Inggris), dan bahasa tambahan.
     */
    fun needed(main: String, extras: Collection<String>): List<String> =
        (listOf(main, "en") + extras).distinct()

    /** true bila model bahasa [code] sudah ada di perangkat. */
    suspend fun isDownloaded(code: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val model = TranslateRemoteModel.Builder(code).build()
            val task = RemoteModelManager.getInstance().isModelDownloaded(model)
            Tasks.await(task, 20, TimeUnit.SECONDS) == true
        } catch (e: Exception) {
            false
        }
    }

    /** Unduh model bahasa [code]. Melempar exception bila gagal (mis. tidak ada internet). */
    suspend fun download(code: String) {
        withContext(Dispatchers.IO) {
            val model = TranslateRemoteModel.Builder(code).build()
            val task = RemoteModelManager.getInstance().download(model, DownloadConditions.Builder().build())
            Tasks.await(task, 10, TimeUnit.MINUTES)
        }
    }
}
