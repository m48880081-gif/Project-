package app.mixbase.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Penyimpanan sederhana (SharedPreferences + JSON): pengaturan, favorit, riwayat. */
class Store(context: Context) {

    private val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var themeMode: Int
        get() = sp.getInt("theme", 0) // 0 = ikuti sistem, 1 = terang, 2 = gelap
        set(value) {
            sp.edit().putInt("theme", value).apply()
        }

    var dynamicColor: Boolean
        get() = sp.getBoolean("dynamic", true)
        set(value) {
            sp.edit().putBoolean("dynamic", value).apply()
        }

    var highQuality: Boolean
        get() = sp.getBoolean(KEY_HQ, true)
        set(value) {
            sp.edit().putBoolean(KEY_HQ, value).apply()
        }

    fun loadFavorites(): List<Track> = load("fav")

    fun saveFavorites(list: List<Track>) = save("fav", list)

    fun loadHistory(): List<Track> = load("hist")

    fun saveHistory(list: List<Track>) = save("hist", list)

    private fun load(key: String): List<Track> {
        val raw = sp.getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Track>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val thumb = o.optString("i", "")
                out.add(
                    Track(
                        url = o.getString("u"),
                        title = o.optString("t", ""),
                        artist = o.optString("a", ""),
                        durationSec = o.optLong("d", 0L),
                        thumb = if (thumb.isEmpty()) null else thumb,
                    ),
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(key: String, list: List<Track>) {
        val arr = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("u", t.url)
            o.put("t", t.title)
            o.put("a", t.artist)
            o.put("d", t.durationSec)
            o.put("i", t.thumb ?: "")
            arr.put(o)
        }
        sp.edit().putString(key, arr.toString()).apply()
    }

    companion object {
        const val PREFS = "mixbase"
        const val KEY_HQ = "hq"
        const val KEY_VIDEO_MODE = "video_mode"
        const val KEY_VIDEO_H = "video_h"
    }
}
