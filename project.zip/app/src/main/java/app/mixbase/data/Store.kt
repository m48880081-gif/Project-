package app.mixbase.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Penyimpanan sederhana (SharedPreferences + JSON): pengaturan, favorit, riwayat. */
class Store(context: Context) {

    private val sp = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var themeMode: Int
        get() = sp.getInt("theme", 1) // 0 = ikuti sistem, 1 = terang (default), 2 = gelap
        set(value) {
            sp.edit().putInt("theme", value).apply()
        }

    var dynamicColor: Boolean
        get() = sp.getBoolean("dynamic", false)
        set(value) {
            sp.edit().putBoolean("dynamic", value).apply()
        }

    /** Mode aplikasi: 0 = Musik (default), 1 = Video. */
    var mode: Int
        get() = sp.getInt("mode", 0)
        set(value) {
            sp.edit().putInt("mode", value).apply()
        }

    var highQuality: Boolean
        get() = sp.getBoolean(KEY_HQ, true)
        set(value) {
            sp.edit().putBoolean(KEY_HQ, value).apply()
        }

    /** Tinggi maksimum video default (piksel). Bisa diganti manual di pemutar. */
    var maxHeight: Int
        get() = sp.getInt("maxh", 1080)
        set(value) {
            sp.edit().putInt("maxh", value).apply()
        }

    /** Utamakan 60 fps bila tersedia di resolusi yang sama. */
    var prefer60: Boolean
        get() = sp.getBoolean("fps60", true)
        set(value) {
            sp.edit().putBoolean("fps60", value).apply()
        }

    /** Bahasa konten (judul, deskripsi, dll) dan bahasa pilihan untuk suara/subtitle. Kode ISO, mis. "id". */
    var contentLang: String
        get() = sp.getString("clang", "id") ?: "id"
        set(value) {
            sp.edit().putString("clang", value).apply()
        }

    /** Terjemahkan judul video otomatis ke bahasa aplikasi (di perangkat). */
    var translateTitles: Boolean
        get() = sp.getBoolean("trtitle", true)
        set(value) {
            sp.edit().putBoolean("trtitle", value).apply()
        }

    /** Bahasa terjemahan lirik terakhir yang dipilih ("" = mati). */
    var lyricsLang: String
        get() = sp.getString("lyrlang", "") ?: ""
        set(value) {
            sp.edit().putString("lyrlang", value).apply()
        }

    /** Suara video: 0 = asli (bawaan), 1 = utamakan dubbing bahasa konten bila video menyediakan. */
    var audioPref: Int
        get() = sp.getInt("apref", 0)
        set(value) {
            sp.edit().putInt("apref", value).apply()
        }

    /** Nyalakan subtitle otomatis (bahasa konten) saat bahasa video berbeda. */
    var subtitleAuto: Boolean
        get() = sp.getBoolean("subauto", false)
        set(value) {
            sp.edit().putBoolean("subauto", value).apply()
        }

    fun loadFavorites(): List<Track> = load("fav")

    fun saveFavorites(list: List<Track>) = save("fav", list)

    fun loadHistory(): List<Track> = load("hist")

    fun saveHistory(list: List<Track>) = save("hist", list)

    fun loadVideoHistory(): List<Track> = load("vhist")

    fun saveVideoHistory(list: List<Track>) = save("vhist", list)

    /** Riwayat kata kunci pencarian (terbaru dulu). [key] membedakan mode Video dan Musik. */
    fun loadQueries(key: String): List<String> {
        val raw = sp.getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<String>(arr.length())
            for (i in 0 until arr.length()) {
                val q = arr.optString(i, "")
                if (q.isNotBlank()) out.add(q)
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveQueries(key: String, list: List<String>) {
        val arr = JSONArray()
        for (q in list) arr.put(q)
        sp.edit().putString(key, arr.toString()).apply()
    }

    fun loadSubscriptions(): List<Channel> {
        val raw = sp.getString("subs", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Channel>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val a = o.optString("a", "")
                out.add(Channel(o.getString("u"), o.optString("n", ""), if (a.isEmpty()) null else a))
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveSubscriptions(list: List<Channel>) {
        val arr = JSONArray()
        for (c in list) {
            val o = JSONObject()
            o.put("u", c.url)
            o.put("n", c.name)
            o.put("a", c.avatar ?: "")
            arr.put(o)
        }
        sp.edit().putString("subs", arr.toString()).apply()
    }

    private fun load(key: String): List<Track> {
        val raw = sp.getString(key, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Track>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val thumb = o.optString("i", "")
                val cu = o.optString("cu", "")
                val up = o.optString("up", "")
                val av = o.optString("av", "")
                out.add(
                    Track(
                        url = o.getString("u"),
                        title = o.optString("t", ""),
                        artist = o.optString("a", ""),
                        durationSec = o.optLong("d", 0L),
                        thumb = if (thumb.isEmpty()) null else thumb,
                        uploaderUrl = if (cu.isEmpty()) null else cu,
                        views = o.optLong("v", -1L),
                        uploaded = if (up.isEmpty()) null else up,
                        live = o.optBoolean("lv", false),
                        avatar = if (av.isEmpty()) null else av,
                    ),
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(key: String, list: List<Track>) {
        val arr = JSONArray()
        for (t in list) {
            val o = JSONObject()
            o.put("u", t.url)
            o.put("t", t.title)
            o.put("a", t.artist)
            o.put("d", t.durationSec)
            o.put("i", t.thumb ?: "")
            o.put("cu", t.uploaderUrl ?: "")
            o.put("v", t.views)
            o.put("up", t.uploaded ?: "")
            o.put("lv", t.live)
            o.put("av", t.avatar ?: "")
            arr.put(o)
        }
        sp.edit().putString(key, arr.toString()).apply()
    }

    companion object {
        const val PREFS = "mixbase"
        const val KEY_HQ = "hq"
    }
}
