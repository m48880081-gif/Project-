package app.mixbase.data

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import app.mixbase.R
import app.mixbase.ui.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Layanan latar depan yang menampilkan progres unduhan di bilah notifikasi dan menjaga proses
 * aplikasi tetap hidup selama ada unduhan berjalan (jadi unduhan tidak putus saat layar dimatikan
 * atau aplikasi dipindah ke latar belakang). Pekerjaan unduhnya sendiri ada di [Downloads].
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannels(this)
        if (intent?.action == ACTION_CANCEL) {
            Downloads.cancelAll()
        }
        // Wajib segera memanggil startForeground setelah startForegroundService.
        startForeground(PROGRESS_ID, progressNotification(Downloads.snapshot()))
        if (watcher?.isActive != true) {
            watcher = scope.launch { watch() }
        }
        return START_NOT_STICKY
    }

    private suspend fun watch() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        while (true) {
            val snap = Downloads.snapshot()
            if (snap.active == 0) break
            nm.notify(PROGRESS_ID, progressNotification(snap))
            delay(700)
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        showFinished(nm)
        stopSelf()
    }

    private fun openAppIntent(): PendingIntent {
        val open = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun progressNotification(snap: Downloads.Snapshot): android.app.Notification {
        val percent = (snap.progress * 100f).toInt().coerceIn(0, 100)
        val title = if (snap.active > 1) "Mengunduh ${snap.active} file" else "Mengunduh"
        val text = if (snap.active > 1) "$percent%" else "${snap.title} • $percent%"
        val cancel = PendingIntent.getService(
            this,
            1,
            Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(title)
            .setContentText(text)
            .setProgress(100, percent, snap.active > 0 && snap.progress <= 0f)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openAppIntent())
            .addAction(0, "Batalkan", cancel)
            .build()
    }

    private fun showFinished(nm: NotificationManager) {
        val done = Downloads.sessionDone.get()
        val failed = Downloads.sessionFailed.get()
        if (done == 0 && failed == 0) return
        val title = if (failed == 0) "Unduhan selesai" else "Unduhan selesai dengan masalah"
        val text = buildString {
            if (done == 1 && failed == 0) {
                append(Downloads.sessionLastTitle)
            } else {
                if (done > 0) append("$done file berhasil")
                if (failed > 0) {
                    if (isNotEmpty()) append(", ")
                    append("$failed gagal")
                }
            }
        }
        val n = NotificationCompat.Builder(this, CHANNEL_DONE)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(title)
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openAppIntent())
            .build()
        nm.notify(DONE_ID, n)
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_CANCEL = "app.mixbase.DOWNLOAD_CANCEL"
        private const val CHANNEL_PROGRESS = "unduhan"
        private const val CHANNEL_DONE = "unduhan_selesai"
        private const val PROGRESS_ID = 4101
        private const val DONE_ID = 4102

        fun createChannels(c: Context) {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_PROGRESS, "Unduhan berjalan", NotificationManager.IMPORTANCE_LOW),
            )
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_DONE, "Unduhan selesai", NotificationManager.IMPORTANCE_DEFAULT),
            )
        }

        /** Nyalakan layanan (dipanggil saat unduhan dimulai). Gagal diam-diam bila dilarang sistem. */
        fun start(c: Context) {
            try {
                ContextCompat.startForegroundService(c, Intent(c, DownloadService::class.java))
            } catch (e: Exception) {
                // Unduhan tetap berjalan di dalam proses aplikasi, hanya tanpa notifikasi.
            }
        }
    }
}
