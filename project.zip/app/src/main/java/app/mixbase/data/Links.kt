package app.mixbase.data

import android.net.Uri

/** Hasil mengenali link YouTube / YouTube Music. [music] true bila berasal dari music.youtube.com. */
sealed interface LinkTarget {
    data class Video(val url: String, val music: Boolean) : LinkTarget
    data class Channel(val url: String, val music: Boolean) : LinkTarget
    data class Playlist(val url: String, val music: Boolean) : LinkTarget
}

/** Pengenal link YouTube: dipakai saat app dibuka dari link/Bagikan dan saat link ditempel di kolom Cari. */
object Links {
    private val URL_REGEX = Regex("https?://[^\\s<>\"']+")
    private val ID_REGEX = Regex("^[A-Za-z0-9_-]{11}$")

    /** Link pertama dalam teks (mis. teks Bagikan "Judul https://youtu.be/…"), atau null. */
    fun find(text: String): String? {
        val m = URL_REGEX.find(text) ?: return null
        return m.value.trimEnd('.', ',', ')', ']', '!', '?')
    }

    private fun isYoutubeHost(h: String): Boolean =
        h == "youtube.com" || h.endsWith(".youtube.com") || h == "youtu.be" || h == "www.youtu.be"

    /** Kenali [text] (link polos atau teks yang memuat link). Null bila bukan link YouTube yang dikenal. */
    fun parse(text: String): LinkTarget? {
        val raw = find(text.trim()) ?: return null
        val uri = try {
            Uri.parse(raw)
        } catch (e: Exception) {
            return null
        }
        val host = (uri.host ?: return null).lowercase()
        if (!isYoutubeHost(host)) return null
        val music = host == "music.youtube.com"
        val segs = uri.pathSegments ?: emptyList()

        if (host == "youtu.be" || host == "www.youtu.be") {
            val id = segs.firstOrNull() ?: return null
            return if (ID_REGEX.matches(id)) LinkTarget.Video(watchUrl(id), false) else null
        }

        val first = segs.firstOrNull() ?: return null
        when (first) {
            "watch" -> {
                val id = uri.getQueryParameter("v")
                if (id != null && ID_REGEX.matches(id)) return LinkTarget.Video(watchUrl(id), music)
                val list = uri.getQueryParameter("list")
                if (list != null) return LinkTarget.Playlist(playlistUrl(list), music)
                return null
            }
            "shorts", "live", "embed", "v" -> {
                val id = segs.getOrNull(1) ?: return null
                return if (ID_REGEX.matches(id)) LinkTarget.Video(watchUrl(id), false) else null
            }
            "playlist" -> {
                val list = uri.getQueryParameter("list") ?: return null
                return LinkTarget.Playlist(playlistUrl(list), music)
            }
            "channel", "c", "user" -> {
                val name = segs.getOrNull(1) ?: return null
                return LinkTarget.Channel("https://www.youtube.com/$first/$name", music)
            }
        }
        if (first.startsWith("@") && first.length > 1) {
            return LinkTarget.Channel("https://www.youtube.com/$first", music)
        }
        return null
    }

    private fun watchUrl(id: String) = "https://www.youtube.com/watch?v=$id"

    private fun playlistUrl(list: String) = "https://www.youtube.com/playlist?list=$list"
}
