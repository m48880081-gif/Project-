package app.mixbase.data

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.HttpDataSource
import app.mixbase.player.YoutubeStreams
import app.mixbase.player.isForbidden
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicInteger

/**
 * Unduhan di perangkat: audio (m4a/webm) dan video (MP4). Berkas disimpan di folder khusus aplikasi
 * (Android/data/app.mixbase/files/Download/PlayTube) sehingga tidak butuh izin penyimpanan.
 *
 * Unduhan berjalan di dalam proses aplikasi: jangan tutup paksa aplikasi sebelum selesai.
 * Video HD: video-saja (H.264) dan audio AAC diunduh terpisah lalu digabung jadi satu MP4;
 * bila penggabungan gagal, dipakai video gabungan bawaan YouTube (biasanya 360p).
 */
@OptIn(UnstableApi::class)
object Downloads {

    const val QUEUED = 0
    const val RUNNING = 1
    const val DONE = 2
    const val FAILED = 3

    class Item(
        val url: String,
        val title: String,
        val artist: String,
        val thumb: String?,
        val durationSec: Long,
        val video: Boolean,
        label: String,
    ) {
        /** Jalur berkas hasil unduhan (diisi setelah jenis stream diketahui). */
        var path: String = ""
        var label by mutableStateOf(label)
        var state by mutableIntStateOf(QUEUED)
        var progress by mutableFloatStateOf(0f)
        var sizeBytes by mutableLongStateOf(0L)
        var error by mutableStateOf<String?>(null)

        val id: String
            get() = (if (video) "v|" else "a|") + url

        fun toTrack(): Track = Track(
            url = url,
            title = title,
            artist = artist,
            durationSec = durationSec,
            thumb = thumb,
        )
    }

    val items = mutableStateListOf<Item>()

    /** Ringkasan untuk notifikasi: berapa yang sedang berjalan, progres rata-rata, dan judulnya. */
    class Snapshot(val active: Int, val progress: Float, val title: String)

    // Hitungan sejak unduhan terakhir mulai dari keadaan "diam" — untuk notifikasi selesai.
    val sessionDone = AtomicInteger(0)
    val sessionFailed = AtomicInteger(0)

    @Volatile
    var sessionLastTitle: String = ""

    fun snapshot(): Snapshot {
        var active = 0
        var sum = 0f
        var title = ""
        for (i in items.toList()) {
            if (i.state == QUEUED || i.state == RUNNING) {
                active += 1
                sum += i.progress
                if (title.isEmpty()) title = i.title
            }
        }
        val avg = if (active == 0) 0f else (sum / active.toFloat()).coerceIn(0f, 1f)
        return Snapshot(active, avg, title)
    }

    /** Batalkan semua unduhan yang sedang berjalan/menunggu (dipanggil dari tombol di notifikasi). */
    fun cancelAll() {
        for (i in items.toList()) {
            if (i.state == QUEUED || i.state == RUNNING) remove(i)
        }
    }

    private var app: Context? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val jobs = HashMap<String, Job>()

    fun init(context: Context) {
        if (app != null) return
        app = context.applicationContext
        load(context.applicationContext)
    }

    // ---------------- Memulai / menghapus ----------------

    /** Mulai mengunduh [t]. Mengembalikan pesan singkat untuk ditampilkan ke pengguna. */
    fun start(t: Track, video: Boolean): String {
        val c = app ?: return "Unduhan belum siap"
        val id = (if (video) "v|" else "a|") + t.url
        val old = items.firstOrNull { it.id == id }
        if (old != null) {
            if (old.state == DONE) return "Sudah diunduh"
            if (old.state == QUEUED || old.state == RUNNING) return "Sedang diunduh"
            remove(old) // gagal sebelumnya: ulangi dari awal
        }
        val item = Item(
            url = t.url,
            title = t.title,
            artist = t.artist,
            thumb = t.thumb,
            durationSec = t.durationSec,
            video = video,
            label = if (video) "Video" else "Audio",
        )
        if (snapshot().active == 0) {
            sessionDone.set(0)
            sessionFailed.set(0)
            sessionLastTitle = ""
        }
        items.add(0, item)
        jobs[item.id] = scope.launch { execute(c, item) }
        DownloadService.start(c)
        return if (video) "Mulai mengunduh video" else "Mulai mengunduh audio"
    }

    /** Batalkan (bila sedang berjalan) dan hapus dari daftar beserta berkasnya. */
    fun remove(item: Item) {
        jobs.remove(item.id)?.cancel()
        items.remove(item)
        val p = item.path
        scope.launch { cleanFiles(p) }
        save()
    }

    private fun cleanFiles(path: String) {
        if (path.isEmpty()) return
        try {
            File(path).delete()
            File("$path.v.part").delete()
            File("$path.a.part").delete()
        } catch (e: Exception) {
            // abaikan
        }
    }

    // ---------------- Untuk pemutaran offline ----------------

    private fun local(url: String, video: Boolean): String? {
        for (i in items.toList()) {
            if (i.state == DONE && i.video == video && i.url == url && File(i.path).exists()) return i.path
        }
        return null
    }

    /** Berkas lokal untuk memutar [url] sebagai audio (unduhan audio, atau suara dari unduhan video). */
    fun localAudio(url: String): String? = local(url, false) ?: local(url, true)

    /** Berkas lokal video untuk [url], atau null bila belum diunduh. */
    fun localVideo(url: String): String? = local(url, true)

    // ---------------- Proses unduh ----------------

    private fun dir(c: Context): File {
        val base = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: c.filesDir
        val d = File(base, "PlayTube")
        d.mkdirs()
        return d
    }

    private fun fileName(item: Item, ext: String): String {
        val safe = item.title
            .replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_")
            .trim()
            .take(80)
            .ifEmpty { "unduhan" }
        val tag = Integer.toHexString(item.url.hashCode())
        return "$safe [$tag].$ext"
    }

    private suspend fun execute(c: Context, item: Item) {
        item.state = RUNNING
        try {
            if (item.video) downloadVideo(c, item) else downloadAudio(c, item)
            item.progress = 1f
            item.state = DONE
            sessionLastTitle = item.title
            sessionDone.incrementAndGet()
        } catch (e: CancellationException) {
            cleanFiles(item.path)
            throw e
        } catch (e: Exception) {
            cleanFiles(item.path)
            item.error = e.message ?: e.javaClass.simpleName
            item.state = FAILED
            sessionFailed.incrementAndGet()
        } finally {
            save()
        }
    }

    private suspend fun downloadAudio(c: Context, item: Item) {
        val a = Engine.audioForDownload(item.url)
        val out = File(dir(c), fileName(item, a.ext))
        item.path = out.absolutePath
        item.label = if (a.ext == "m4a") "Audio M4A" else "Audio WEBM"
        fetch(a.url, out) { item.progress = it }
        item.sizeBytes = out.length()
    }

    private fun pickAvc(d: Engine.VideoDetails, cap: Int, prefer60: Boolean): Engine.Quality? {
        val limit = if (cap < 1080) cap else 1080
        val avc = d.qualities.filter { it.codec.lowercase().startsWith("avc") && it.height <= limit }
        if (avc.isEmpty()) return null
        val top = avc.maxOf { it.height }
        val atTop = avc.filter { it.height == top }
        return if (prefer60) atTop.maxByOrNull { it.fps } else atTop.minByOrNull { it.fps }
    }

    private suspend fun downloadVideo(c: Context, item: Item) {
        val d = Engine.videoDetails(item.url)
        if (d.live) throw IllegalStateException("Siaran langsung tidak bisa diunduh")

        val st = Store(c)
        val pick = pickAvc(d, st.maxHeight, st.prefer60)
        val aac = d.aacUrl
        val out = File(dir(c), fileName(item, "mp4"))
        item.path = out.absolutePath

        var done = false
        if (pick != null && aac != null) {
            val tmpV = File("${out.absolutePath}.v.part")
            val tmpA = File("${out.absolutePath}.a.part")
            try {
                item.label = pick.label
                fetch(pick.url, tmpV) { item.progress = it * 0.82f }
                fetch(aac, tmpA) { item.progress = 0.82f + it * 0.12f }
                item.progress = 0.94f
                mux(tmpV, tmpA, out)
                done = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                out.delete()
                if (d.muxedUrl == null) throw e
            } finally {
                tmpV.delete()
                tmpA.delete()
            }
        }

        if (!done) {
            val m = d.muxedUrl ?: throw IllegalStateException("Tidak ada stream video yang bisa diunduh")
            item.label = "${d.muxedHeight}p"
            item.progress = 0f
            fetch(m, out) { item.progress = it }
        }
        item.sizeBytes = out.length()
    }

    /** Unduh [url] ke [out]. Mencoba cara NewPipe dulu; bila ditolak 403, mencoba GET biasa. */
    private suspend fun fetch(url: String, out: File, onProgress: (Float) -> Unit) {
        try {
            fetchWith(false, url, out, onProgress)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            if (!isForbidden(e)) throw e
            fetchWith(true, url, out, onProgress)
        }
    }

    private fun totalFrom(headers: Map<String, List<String>>): Long {
        for (e in headers.entries) {
            if (e.key.equals("Content-Range", ignoreCase = true)) {
                val raw = e.value.firstOrNull() ?: continue
                val n = raw.substringAfter('/', "").trim().toLongOrNull()
                if (n != null) return n
            }
        }
        return -1L
    }

    private suspend fun fetchWith(legacy: Boolean, url: String, out: File, onProgress: (Float) -> Unit) {
        val factory = YoutubeStreams.factory(legacy)
        val chunk = 4L * 1024L * 1024L
        val buf = ByteArray(64 * 1024)
        var pos = 0L
        var total = -1L

        FileOutputStream(out).use { os ->
            while (true) {
                currentCoroutineContext().ensureActive()
                val ds = factory.createDataSource()
                var got = 0L
                try {
                    val spec = DataSpec.Builder()
                        .setUri(Uri.parse(url))
                        .setPosition(pos)
                        .setLength(chunk)
                        .build()
                    ds.open(spec)
                    if (total < 0L) total = totalFrom(ds.responseHeaders)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = ds.read(buf, 0, buf.size)
                        if (n == C.RESULT_END_OF_INPUT) break
                        os.write(buf, 0, n)
                        got += n.toLong()
                        pos += n.toLong()
                        if (total > 0L) onProgress((pos.toFloat() / total.toFloat()).coerceIn(0f, 1f))
                    }
                } catch (e: HttpDataSource.InvalidResponseCodeException) {
                    // 416 = permintaan melewati ujung berkas: selesai.
                    if (e.responseCode == 416 && pos > 0L) break
                    throw e
                } finally {
                    ds.close()
                }
                if (got <= 0L) break
                if (total > 0L && pos >= total) break
                if (total < 0L && got < chunk) break
            }
        }
        onProgress(1f)
    }

    /** Gabungkan video-saja (H.264) dan audio-saja (AAC) menjadi satu berkas MP4 tanpa mengubah kualitas. */
    private fun mux(video: File, audio: File, out: File) {
        val vEx = MediaExtractor()
        val aEx = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            vEx.setDataSource(video.absolutePath)
            aEx.setDataSource(audio.absolutePath)
            val vt = pickTrack(vEx, "video/")
            val at = pickTrack(aEx, "audio/")
            if (vt < 0 || at < 0) throw IllegalStateException("Trek video/audio tidak ditemukan")
            vEx.selectTrack(vt)
            aEx.selectTrack(at)

            val m = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = m
            val vi = m.addTrack(vEx.getTrackFormat(vt))
            val ai = m.addTrack(aEx.getTrackFormat(at))
            m.start()
            started = true

            val buf = ByteBuffer.allocate(4 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var vDone = false
            var aDone = false
            while (!vDone || !aDone) {
                val vTime = if (vDone) Long.MAX_VALUE else vEx.sampleTime
                val aTime = if (aDone) Long.MAX_VALUE else aEx.sampleTime
                if (!vDone && vTime < 0L) {
                    vDone = true
                    continue
                }
                if (!aDone && aTime < 0L) {
                    aDone = true
                    continue
                }
                val useVideo = vTime <= aTime
                val ex = if (useVideo) vEx else aEx
                val track = if (useVideo) vi else ai
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) {
                    if (useVideo) vDone = true else aDone = true
                    continue
                }
                info.set(0, size, ex.sampleTime, ex.sampleFlags)
                m.writeSampleData(track, buf, info)
                ex.advance()
            }
        } finally {
            try {
                if (started) muxer?.stop()
            } catch (e: Exception) {
                // abaikan
            }
            try {
                muxer?.release()
            } catch (e: Exception) {
                // abaikan
            }
            vEx.release()
            aEx.release()
        }
    }

    private fun pickTrack(ex: MediaExtractor, prefix: String): Int {
        for (i in 0 until ex.trackCount) {
            val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith(prefix)) return i
        }
        return -1
    }

    // ---------------- Simpan / muat daftar ----------------

    private fun prefs(c: Context) = c.getSharedPreferences(Store.PREFS, Context.MODE_PRIVATE)

    private fun save() {
        val c = app ?: return
        val arr = JSONArray()
        for (i in items.toList()) {
            if (i.state != DONE) continue
            val o = JSONObject()
            o.put("u", i.url)
            o.put("t", i.title)
            o.put("a", i.artist)
            o.put("i", i.thumb ?: "")
            o.put("d", i.durationSec)
            o.put("v", i.video)
            o.put("p", i.path)
            o.put("l", i.label)
            o.put("s", i.sizeBytes)
            arr.put(o)
        }
        prefs(c).edit().putString("dl", arr.toString()).apply()
    }

    private fun load(c: Context) {
        val raw = prefs(c).getString("dl", null) ?: return
        try {
            val arr = JSONArray(raw)
            for (n in 0 until arr.length()) {
                val o = arr.getJSONObject(n)
                val path = o.optString("p", "")
                if (path.isEmpty() || !File(path).exists()) continue
                val thumb = o.optString("i", "")
                val item = Item(
                    url = o.getString("u"),
                    title = o.optString("t", ""),
                    artist = o.optString("a", ""),
                    thumb = if (thumb.isEmpty()) null else thumb,
                    durationSec = o.optLong("d", 0L),
                    video = o.optBoolean("v", false),
                    label = o.optString("l", ""),
                )
                item.path = path
                item.sizeBytes = o.optLong("s", 0L)
                item.progress = 1f
                item.state = DONE
                items.add(item)
            }
        } catch (e: Exception) {
            // daftar rusak: abaikan
        }
    }
}
