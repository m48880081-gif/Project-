package app.mixbase.data

/** Satu lagu / video yang bisa diputar. [url] adalah URL halaman (bukan URL stream). */
data class Track(
    val url: String,
    val title: String,
    val artist: String,
    val durationSec: Long,
    val thumb: String?,
)

/** Format detik menjadi m:ss atau h:mm:ss. */
fun clock(totalSec: Long): String {
    val s = if (totalSec < 0) 0L else totalSec
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) {
        String.format("%d:%02d:%02d", h, m, sec)
    } else {
        String.format("%d:%02d", m, sec)
    }
}
