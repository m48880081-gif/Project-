package app.mixbase.data

import java.util.Locale

/** Satu lagu / video yang bisa diputar. [url] adalah URL halaman (bukan URL stream). */
data class Track(
    val url: String,
    val title: String,
    val artist: String,
    val durationSec: Long,
    val thumb: String?,
    /** URL channel/artis pembuatnya (untuk membuka halaman akun). */
    val uploaderUrl: String? = null,
    /** Jumlah tonton, -1 bila tidak diketahui. */
    val views: Long = -1L,
    /** Teks tanggal unggah dari sumber, mis. "1 tahun lalu". */
    val uploaded: String? = null,
    val live: Boolean = false,
    /** Foto profil channel (bila diketahui). */
    val avatar: String? = null,
)

/** Item non-lagu dari hasil pencarian: album, artis, atau playlist. */
data class Entry(
    val kind: Int,
    val url: String,
    val title: String,
    val sub: String,
    val thumb: String?,
) {
    companion object {
        const val ALBUM = 0
        const val ARTIST = 1
        const val PLAYLIST = 2
    }
}

/** Channel yang dilanggani (disimpan lokal di perangkat). */
data class Channel(
    val url: String,
    val name: String,
    val avatar: String?,
)

/** Satu halaman hasil: lagu/video dan item koleksi (album/artis/playlist). */
class Batch(val tracks: List<Track>, val entries: List<Entry>)

/** Format detik menjadi m:ss atau h:mm:ss. */
fun clock(totalSec: Long): String {
    val s = if (totalSec < 0) 0L else totalSec
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) {
        String.format("%d:%02d:%02d", h, m, sec)
    } else {
        String.format("%d:%02d", m, sec)
    }
}

private val ID_LOCALE: Locale = Locale.forLanguageTag("id-ID")

/** 4300 → "4,3 rb", 1400000 → "1,4 jt", 2100000000 → "2,1 M". */
fun compactCount(n: Long): String {
    if (n < 1000L) return n.toString()
    val (value, unit) = when {
        n < 1_000_000L -> Pair(n / 1000.0, "rb")
        n < 1_000_000_000L -> Pair(n / 1_000_000.0, "jt")
        else -> Pair(n / 1_000_000_000.0, "M")
    }
    val text = if (value >= 100.0) {
        String.format(ID_LOCALE, "%.0f", value)
    } else {
        String.format(ID_LOCALE, "%.1f", value).removeSuffix(",0")
    }
    return "$text $unit"
}

/**
 * Ubah URL gambar kecil menjadi versi resolusi tinggi bila polanya dikenal:
 *  - gambar album (googleusercontent): ganti ukuran di akhir URL (=w120-h120... → =w1200-h1200...)
 *  - thumbnail video (ytimg): pakai maxresdefault
 * URL yang polanya tidak dikenal dikembalikan apa adanya.
 */
fun hdArt(url: String?, px: Int = 1200): String? {
    if (url == null) return null
    if (url.contains("googleusercontent.com") || url.contains("ggpht.com")) {
        val m = Regex("=(w\\d+-h\\d+|s\\d+)([-a-zA-Z0-9]*)$").find(url) ?: return url
        val head = url.substring(0, m.range.first)
        val size = m.groupValues[1]
        val tail = m.groupValues[2]
        return if (size.startsWith("s")) "$head=s$px$tail" else "$head=w$px-h$px$tail"
    }
    if (url.contains("ytimg.com/vi")) {
        val m = Regex("^(https://i\\.ytimg\\.com/vi(?:_webp)?/[^/]+/)[a-z0-9_]+\\.(?:jpg|webp)").find(url)
        if (m != null) return m.groupValues[1] + "maxresdefault.jpg"
    }
    return url
}
