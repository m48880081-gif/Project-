package app.mixbase.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Satu akun lokal di perangkat ini. */
class Account(
    val id: String,
    val name: String,
    val username: String,
    /**
     * Akun pertama memakai berkas penyimpanan lama ("mixbase") dan folder unduhan lama ("PlayTube"),
     * sehingga langganan, favorit, riwayat, dan unduhan yang sudah ada tidak hilang.
     */
    val legacy: Boolean,
)

/** Hasil masuk / daftar. [error] berisi pesan bila gagal. [restart] true bila aplikasi harus dimulai ulang. */
class AuthResult(val account: Account?, val error: String?, val restart: Boolean = false)

/**
 * Akun lokal (tersimpan di perangkat, sandi di-hash PBKDF2). Tiap akun punya penyimpanan sendiri
 * (langganan, favorit, riwayat, daftar unduhan, setelan) dan folder unduhan sendiri. Keluar lalu masuk
 * lagi dengan akun yang sama mengembalikan semuanya; sesi diingat sampai pengguna memilih Keluar.
 *
 * Catatan: ini BUKAN akun cloud, jadi tidak ikut berpindah ke HP lain. Untuk memindahkan data dipakai
 * Cadangkan / Pulihkan (lihat [Backup]).
 */
object Accounts {

    private const val FILE = "mixbase_accounts"
    private const val KEY_LIST = "list"
    private const val KEY_SESSION = "session"
    private const val ITERATIONS = 40_000

    private var sp: SharedPreferences? = null

    /** Penyimpanan yang dipakai proses ini saat dimulai; bila berubah setelah masuk, aplikasi dimulai ulang. */
    private var bootPrefs: String = Store.PREFS

    /** Akun yang sedang masuk, atau null (belum masuk). */
    var current by mutableStateOf<Account?>(null)
        private set

    fun init(context: Context) {
        val p = context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        sp = p
        current = readSession(p)
        bootPrefs = prefsName()
    }

    /** Nama berkas SharedPreferences milik akun yang sedang masuk (akun pertama = berkas lama). */
    fun prefsName(): String {
        val a = current ?: return Store.PREFS
        return if (a.legacy) Store.PREFS else Store.PREFS + "_" + a.id
    }

    /** Nama folder unduhan milik akun yang sedang masuk. */
    fun dirName(): String {
        val a = current ?: return "PlayTube"
        return if (a.legacy) "PlayTube" else "PlayTube-" + a.id
    }

    fun hasAccounts(): Boolean {
        val p = sp ?: return false
        return readList(p).length() > 0
    }

    // ---------------- Daftar ----------------

    suspend fun register(name: String, username: String, password: String): AuthResult {
        val p = sp ?: return AuthResult(null, "Penyimpanan akun belum siap")
        val n = name.trim()
        val u = username.trim().lowercase()
        if (n.isEmpty()) return AuthResult(null, "Nama tidak boleh kosong")
        if (n.length > 40) return AuthResult(null, "Nama terlalu panjang (maksimal 40 huruf)")
        if (u.length < 3) return AuthResult(null, "Nama pengguna minimal 3 karakter")
        if (!USERNAME.matches(u)) return AuthResult(null, "Nama pengguna hanya boleh huruf, angka, titik, garis bawah, dan strip")
        if (password.length < 6) return AuthResult(null, "Kata sandi minimal 6 karakter")

        val list = readList(p)
        for (i in 0 until list.length()) {
            if (list.getJSONObject(i).optString("user") == u) {
                return AuthResult(null, "Nama pengguna sudah dipakai")
            }
        }

        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val hash = withContext(Dispatchers.Default) { hash(password, salt) }

        val first = list.length() == 0
        val id = randomId()
        val o = JSONObject()
        o.put("id", id)
        o.put("name", n)
        o.put("user", u)
        o.put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
        o.put("hash", Base64.encodeToString(hash, Base64.NO_WRAP))
        o.put("legacy", first)
        list.put(o)
        p.edit().putString(KEY_LIST, list.toString()).putString(KEY_SESSION, id).commit()

        val account = Account(id, n, u, first)
        current = account
        return AuthResult(account, null, prefsName() != bootPrefs)
    }

    // ---------------- Masuk / keluar ----------------

    suspend fun login(username: String, password: String): AuthResult {
        val p = sp ?: return AuthResult(null, "Penyimpanan akun belum siap")
        val u = username.trim().lowercase()
        if (u.isEmpty() || password.isEmpty()) return AuthResult(null, "Isi nama pengguna dan kata sandi")

        val list = readList(p)
        var found: JSONObject? = null
        for (i in 0 until list.length()) {
            val o = list.getJSONObject(i)
            if (o.optString("user") == u) {
                found = o
                break
            }
        }
        val o = found ?: return AuthResult(null, "Akun tidak ditemukan")

        val ok = withContext(Dispatchers.Default) {
            try {
                val salt = Base64.decode(o.optString("salt"), Base64.NO_WRAP)
                val expected = Base64.decode(o.optString("hash"), Base64.NO_WRAP)
                MessageDigest.isEqual(hash(password, salt), expected)
            } catch (e: Exception) {
                false
            }
        }
        if (!ok) return AuthResult(null, "Kata sandi salah")

        val account = toAccount(o)
        p.edit().putString(KEY_SESSION, account.id).commit()
        current = account
        return AuthResult(account, null, prefsName() != bootPrefs)
    }

    /** Keluar: sesi dihapus, data akun TETAP tersimpan. Setelah ini aplikasi dimulai ulang. */
    fun logout() {
        sp?.edit()?.remove(KEY_SESSION)?.commit()
        current = null
    }

    // ---------------- Bantu ----------------

    private val USERNAME = Regex("^[a-z0-9._-]+$")

    private fun randomId(): String {
        val b = ByteArray(4)
        SecureRandom().nextBytes(b)
        val sb = StringBuilder()
        for (x in b) sb.append(String.format("%02x", x))
        return sb.toString()
    }

    private fun hash(password: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } catch (e: Exception) {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(spec).encoded
        }
    }

    private fun readList(p: SharedPreferences): JSONArray {
        val raw = p.getString(KEY_LIST, null) ?: return JSONArray()
        return try {
            JSONArray(raw)
        } catch (e: Exception) {
            JSONArray()
        }
    }

    private fun toAccount(o: JSONObject): Account =
        Account(
            id = o.optString("id"),
            name = o.optString("name"),
            username = o.optString("user"),
            legacy = o.optBoolean("legacy", false),
        )

    private fun readSession(p: SharedPreferences): Account? {
        val id = p.getString(KEY_SESSION, null) ?: return null
        val list = readList(p)
        for (i in 0 until list.length()) {
            val o = list.getJSONObject(i)
            if (o.optString("id") == id) return toAccount(o)
        }
        return null
    }
}
