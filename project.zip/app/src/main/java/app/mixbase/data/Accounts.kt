package app.mixbase.data

import android.content.Context

/**
 * Penyimpanan yang dipakai aplikasi: satu berkas setelan ("mixbase") dan satu folder unduhan ("PlayTube").
 * (Halaman masuk/login sudah dihapus; nama ini dipertahankan supaya Store, Downloads, dan Backup tetap sama.)
 */
object Accounts {

    @Suppress("UNUSED_PARAMETER")
    fun init(context: Context) {
        // tidak ada yang perlu disiapkan
    }

    /** Nama berkas SharedPreferences. */
    fun prefsName(): String = Store.PREFS

    /** Nama folder unduhan. */
    fun dirName(): String = "PlayTube"
}
