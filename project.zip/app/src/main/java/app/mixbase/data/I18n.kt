package app.mixbase.data

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Bahasa tampilan aplikasi. Teks di kode ditulis dalam bahasa Indonesia; [tr] menerjemahkannya
 * saat ditampilkan (lewat Text buatan di ui/I18nText.kt, Toast, dan notifikasi).
 * Tampilan penuh tersedia untuk Indonesia dan Inggris; bahasa lain memakai tampilan Inggris.
 */
object I18n {

    /** Bahasa aplikasi terpilih (kode ISO). Berupa state sehingga layar langsung menyesuaikan. */
    var lang by mutableStateOf("id")

    /** Terjemahkan judul video otomatis ke [lang] (di perangkat). */
    var translateTitles by mutableStateOf(true)

    /** Tampilan penuh tersedia untuk bahasa ini. */
    fun hasFullUi(code: String): Boolean = code == "id" || code == "en"

    private val SEPARATORS = listOf(" • ", " · ")

    fun tr(text: String): String {
        if (text.isEmpty()) return text
        val en = lang != "id"
        if (en) EN[text]?.let { return it }
        for (sep in SEPARATORS) {
            if (text.contains(sep)) return text.split(sep).joinToString(sep) { tr(it) }
        }
        if (text.length > 160) return text
        return (if (en) toEnglish(text) else toIndonesian(text)) ?: text
    }

    // ---------- Indonesia → Inggris untuk kalimat yang disusun kode ----------

    private class Rule(val re: Regex, val out: String)

    private val RULES_EN = listOf(
        Rule(Regex("^(.+) x ditonton$"), "$1 views"),
        Rule(Regex("^(.+) menonton$"), "$1 watching"),
        Rule(Regex("^(.+) pemutaran$"), "$1 plays"),
        Rule(Regex("^(.+) (?:pelanggan|subscriber)$"), "$1 subscribers"),
        Rule(Regex("^(\\d+) lagu$"), "$1 songs"),
        Rule(Regex("^Langganan {2}(.+)$"), "Subscribe  $1"),
        Rule(Regex("^Komentar {2}(.+)$"), "Comments  $1"),
        Rule(Regex("^Antrean \\((\\d+)\\)$"), "Queue ($1)"),
        Rule(Regex("^Versi (.+)$"), "Version $1"),
        Rule(Regex("^Pengembang: (.+)$"), "Developer: $1"),
        Rule(Regex("^Mengunduh (\\d+) file$"), "Downloading $1 file(s)"),
        Rule(Regex("^(\\d+) file berhasil$"), "$1 file(s) succeeded"),
        Rule(Regex("^(\\d+) gagal$"), "$1 failed"),
        Rule(Regex("^Gagal: (.+)$"), "Failed: $1"),
        Rule(Regex("^Gagal memuat ?(album|artis|channel|isi|video)?:? ?(.+)$"), "Couldn't load: $2"),
        Rule(Regex("^Gagal memutar: (.+)$"), "Couldn't play: $1"),
        Rule(Regex("^Video gagal diputar: (.+)$"), "Video couldn't be played: $1"),
        Rule(Regex("^Pemutar gagal terhubung: (.+)$"), "Player couldn't connect: $1"),
        Rule(Regex("^Subtitle tidak bisa dimuat \\((.+)\\)\\. YouTube kadang menolak permintaan subtitle\\.$"), "Couldn't load subtitles ($1). YouTube sometimes refuses subtitle requests."),
        Rule(Regex("^Album belum bisa dimuat \\((.+)\\)\\. Buka ulang halaman ini untuk mencoba lagi\\.$"), "The album couldn't be loaded ($1). Reopen this page to try again."),
        Rule(Regex("^Tidak ada hasil untuk \"(.*)\"$"), "No results for \"$1\""),
        Rule(Regex("^Lagu untuk \"(.*)\"$"), "Songs for \"$1\""),
        Rule(Regex("^Video untuk \"(.*)\"$"), "Videos for \"$1\""),
        Rule(Regex("^Playlist dari (.+)$"), "Playlist by $1"),
        Rule(Regex("^Sedang diputar: (.+)$"), "Now playing: $1"),
        Rule(Regex("^Otomatis (\\d+p.*)$"), "Auto $1"),
        Rule(Regex("^Otomatis$"), "Auto"),
        Rule(Regex("^(\\d+) (detik|menit|jam|hari|minggu|bulan|tahun) lalu$"), "\$AGO"),
        Rule(Regex("^Mode (\\d+)$"), "Mode $1"),
        Rule(Regex("^Lirik ini sudah dalam bahasa (.+)\\.$"), "These lyrics are already in $1."),
        Rule(Regex("^Terjemahan gagal: (.+)$"), "Translation failed: $1"),
    )

    /** Nama bahasa dalam bahasa Indonesia → Inggris ("Jepang" → "Japanese"), dibuat saat pertama dipakai. */
    private val LANGUAGE_NAMES: Map<String, String> by lazy {
        val idLocale = java.util.Locale.forLanguageTag("id")
        val map = HashMap<String, String>()
        for (code in java.util.Locale.getISOLanguages()) {
            val loc = java.util.Locale.forLanguageTag(code)
            val idName = loc.getDisplayLanguage(idLocale)
            val enName = loc.getDisplayLanguage(java.util.Locale.ENGLISH)
            if (idName.isNotBlank() && enName.isNotBlank() && idName != code) {
                map[idName.replaceFirstChar { it.uppercase() }] = enName
            }
        }
        map
    }

    private val AUTO_SUFFIX = Regex("^(.+) \\(otomatis\\)$")

    private val UNIT_EN = mapOf(
        "detik" to "second", "menit" to "minute", "jam" to "hour", "hari" to "day",
        "minggu" to "week", "bulan" to "month", "tahun" to "year",
    )

    private fun toEnglish(text: String): String? {
        AUTO_SUFFIX.find(text)?.let { return tr(it.groupValues[1]) + " (auto-generated)" }
        LANGUAGE_NAMES[text]?.let { return it }
        for (r in RULES_EN) {
            val m = r.re.find(text) ?: continue
            if (r.out == "\$AGO") {
                val n = m.groupValues[1].toLong()
                val unit = UNIT_EN[m.groupValues[2]] ?: return null
                return "$n $unit${if (n == 1L) "" else "s"} ago"
            }
            return r.re.replace(text, r.out)
        }
        return null
    }

    // ---------- Inggris → Indonesia: tanggal relatif dari YouTube ("2 years ago") ----------

    private val AGO_EN = Regex("^(Streamed |Premiered )?(\\d+) (second|minute|hour|day|week|month|year)s? ago$")

    private val UNIT_ID = mapOf(
        "second" to "detik", "minute" to "menit", "hour" to "jam", "day" to "hari",
        "week" to "minggu", "month" to "bulan", "year" to "tahun",
    )

    private fun toIndonesian(text: String): String? {
        val m = AGO_EN.find(text) ?: return null
        val prefix = when (m.groupValues[1].trim()) {
            "Streamed" -> "Disiarkan "
            "Premiered" -> "Tayang perdana "
            else -> ""
        }
        val unit = UNIT_ID[m.groupValues[3]] ?: return null
        return "$prefix${m.groupValues[2]} $unit lalu"
    }
}
