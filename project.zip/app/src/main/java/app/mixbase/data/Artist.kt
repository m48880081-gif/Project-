package app.mixbase.data

/**
 * Bahan untuk halaman artis: lagu teratas, album, single & EP, video, playlist, dan artis serupa.
 * Semua fungsi BLOKING (jaringan) — panggil dari Dispatchers.IO.
 *
 * Catatan: YouTube tidak menyediakan "single" dan "EP" sebagai kelompok terpisah di halaman channel,
 * jadi rilis dibagi dengan perkiraan jumlah lagu: sampai 6 lagu = Single & EP, lebih dari itu = Album.
 */
object Artist {

    const val ALBUMS = 0
    const val SINGLES = 1
    const val VIDEOS = 2
    const val PLAYLISTS = 3

    /** Huruf kecil tanpa spasi/tanda baca, untuk mencocokkan nama artis. */
    fun key(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    /** "Album • Billie • 12 lagu" -> 12; -1 bila tidak ada angkanya. */
    fun trackCount(sub: String): Int {
        val m = Regex("(\\d+)\\s+lagu").find(sub) ?: return -1
        return m.groupValues[1].toIntOrNull() ?: -1
    }

    /** Perkiraan: rilis dengan 1–6 lagu dianggap Single/EP. */
    fun isSingle(e: Entry): Boolean {
        val n = trackCount(e.sub)
        return n in 1..6
    }

    /**
     * Semua rilis artis (album + single + EP) apa adanya: dari tab rilis channel; bila channel
     * tidak punya tab itu, dari pencarian album yang disaring ke nama artis.
     */
    fun releases(d: Engine.ChannelDetails): Engine.Pager {
        val tab = d.tabs.firstOrNull { it.id == "albums" }
        if (tab != null) return Engine.openTab(tab)
        val me = key(d.name)
        return Engine.FilteredPager(
            Engine.newSearch(d.name, Engine.FILTER_ALBUM),
            { e -> me.isNotEmpty() && key(e.sub).contains(me) },
            { false },
        )
    }

    /** Pager untuk satu jenis isi artis; null bila artis ini tidak punya tab tersebut. */
    fun pager(d: Engine.ChannelDetails, kind: Int): Engine.Pager? {
        if (kind == VIDEOS) {
            val tab = d.tabs.firstOrNull { it.id == "videos" } ?: return null
            return Engine.FilteredPager(Engine.openTab(tab), { true }, { !it.live })
        }
        if (kind == PLAYLISTS) {
            val tab = d.tabs.firstOrNull { it.id == "playlists" } ?: return null
            return Engine.openTab(tab)
        }
        val wantSingles = kind == SINGLES
        return Engine.FilteredPager(
            releases(d),
            { e -> isSingle(e) == wantSingles },
            { false },
        )
    }

    /** Lagu-lagu artis (maks. 10), dari pencarian musik lalu disaring ke artis ini. */
    fun songs(d: Engine.ChannelDetails): List<Track> {
        val batch = Engine.newSearch(d.name, Engine.FILTER_MUSIC).first()
        val me = key(d.name)
        val mine = batch.tracks.filter { t ->
            t.uploaderUrl == d.url || (me.isNotEmpty() && key(t.artist).contains(me))
        }
        val list = if (mine.size >= 3) mine else batch.tracks
        return list.take(10)
    }

    /** Artis lain yang mirip (hasil pencarian artis dengan nama yang sama), tanpa artis ini sendiri. */
    fun similar(d: Engine.ChannelDetails): List<Entry> {
        val batch = Engine.newSearch(d.name, Engine.FILTER_ARTIST).first()
        val me = key(d.name)
        return batch.entries
            .filter { it.kind == Entry.ARTIST && it.url != d.url && key(it.title) != me }
            .take(12)
    }
}
