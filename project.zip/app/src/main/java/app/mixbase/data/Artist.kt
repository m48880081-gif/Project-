package app.mixbase.data

/**
 * Bahan untuk halaman artis: lagu teratas, album, single & EP, video, playlist, dan artis serupa.
 * Semua fungsi BLOKING (jaringan) — panggil dari Dispatchers.IO.
 *
 * Catatan: YouTube tidak menyediakan "single" dan "EP" sebagai kelompok terpisah di halaman channel,
 * jadi rilis dibagi dengan perkiraan jumlah lagu: sampai 6 lagu = Single & EP, lebih dari itu = Album.
 */
object Artist {

    const val ALBUMS = 0
    const val SINGLES = 1
    const val VIDEOS = 2
    const val PLAYLISTS = 3

    /** Huruf kecil tanpa spasi/tanda baca, untuk mencocokkan nama artis. */
    fun key(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    /** "Album • Billie • 12 lagu" -> 12; -1 bila tidak ada angkanya. */
    fun trackCount(sub: String): Int {
        val m = Regex("(\\d+)\\s+lagu").find(sub) ?: return -1
        return m.groupValues[1].toIntOrNull() ?: -1
    }

    /** Perkiraan: rilis dengan 1–6 lagu dianggap Single/EP. */
    fun isSingle(e: Entry): Boolean {
        val n = trackCount(e.sub)
        return n in 1..6
    }

    /** Seperti [key], tetapi membuang tambahan umum pada nama channel artis ("- Topic", "Official", "VEVO"). */
    fun nameKey(s: String): String =
        key(s.lowercase().replace("- topic", "").replace("official", "").replace("vevo", ""))

    /** Judul lagu disederhanakan untuk mencocokkan versi lagu dan versi video musiknya. */
    fun titleKey(s: String): String {
        var x = s.lowercase()
        x = x.replace(Regex("\\([^)]*\\)|\\[[^\\]]*\\]"), " ")
        for (w in listOf("official", "music video", "video clip", "video", "lyrics", "lyric", "audio", "klip", "resmi")) {
            x = x.replace(w, " ")
        }
        return key(x)
    }

    /**
     * Pager yang mencoba beberapa sumber berurutan: yang pertama menghasilkan isi (tidak kosong)
     * dipakai; sumber yang gagal atau kosong dilewati. Dipakai supaya daftar album tetap muncul
     * walau satu sumber (mis. tab rilis channel) kosong atau berubah bentuk.
     */
    class FallbackPager(private val makers: List<() -> Engine.Pager>) : Engine.Pager {
        private var active: Engine.Pager? = null

        override val hasMore: Boolean
            get() = active?.hasMore ?: false

        override fun first(): Batch {
            var last: Exception? = null
            for (make in makers) {
                try {
                    val p = make()
                    val b = p.first()
                    if (b.entries.isNotEmpty() || b.tracks.isNotEmpty()) {
                        active = p
                        return b
                    }
                } catch (e: Exception) {
                    last = e
                }
            }
            active = null
            if (last != null) throw last
            return Batch(emptyList(), emptyList())
        }

        override fun more(): Batch = active?.more() ?: Batch(emptyList(), emptyList())
    }

    /** Rilis ini milik artis [me]? Pemilik yang tidak terbaca dianggap cocok (pencarian sudah memakai nama artis). */
    private fun isMine(e: Entry, me: String): Boolean =
        me.isEmpty() || e.sub.isBlank() || key(e.sub).contains(me) || key(e.title).contains(me)

    /**
     * Semua rilis artis (album + single + EP): dari tab rilis channel bila ada dan berisi;
     * bila tidak, dari pencarian album YouTube Music yang disaring ke nama artis.
     */
    fun releases(d: Engine.ChannelDetails): Engine.Pager {
        val me = nameKey(d.name)
        val makers = ArrayList<() -> Engine.Pager>()
        val tab = d.tabs.firstOrNull { it.id == "albums" }
        if (tab != null) makers.add { Engine.openTab(tab) }
        makers.add {
            Engine.FilteredPager(
                Engine.newSearch(d.name, Engine.FILTER_ALBUM),
                { e -> isMine(e, me) },
                { false },
            )
        }
        return FallbackPager(makers)
    }

    /** Kumpulkan sampai [pages] halaman dari [p]. */
    fun collectEntries(p: Engine.Pager, pages: Int): List<Entry> {
        val out = ArrayList<Entry>()
        out.addAll(p.first().entries)
        var n = 1
        while (p.hasMore && n < pages) {
            out.addAll(p.more().entries)
            n += 1
        }
        return out
    }

    /** Pager untuk satu jenis isi artis; null bila artis ini tidak punya tab tersebut. */
    fun pager(d: Engine.ChannelDetails, kind: Int): Engine.Pager? {
        if (kind == VIDEOS) {
            val tab = d.tabs.firstOrNull { it.id == "videos" } ?: return null
            return Engine.FilteredPager(Engine.openTab(tab), { true }, { !it.live })
        }
        if (kind == PLAYLISTS) {
            val tab = d.tabs.firstOrNull { it.id == "playlists" } ?: return null
            return Engine.openTab(tab)
        }
        val wantSingles = kind == SINGLES
        return Engine.FilteredPager(
            releases(d),
            { e -> isSingle(e) == wantSingles },
            { false },
        )
    }

    private fun collectTracks(p: Engine.Pager, pages: Int): List<Track> {
        val out = ArrayList<Track>()
        out.addAll(p.first().tracks)
        var n = 1
        while (p.hasMore && n < pages) {
            out.addAll(p.more().tracks)
            n += 1
        }
        return out
    }

    private fun mineTracks(all: List<Track>, d: Engine.ChannelDetails): List<Track> {
        val me = nameKey(d.name)
        val mine = all.filter { t ->
            t.uploaderUrl == d.url || (me.isNotEmpty() && key(t.artist).contains(me))
        }
        return if (mine.size >= 3) mine else all
    }

    /** Kumpulan lagu artis dari pencarian lagu YouTube Music (urutan relevansi, tanpa jumlah putar). */
    fun songPool(d: Engine.ChannelDetails): List<Track> =
        mineTracks(collectTracks(Engine.newSearch(d.name, Engine.FILTER_MUSIC), 3), d)

    /** Kumpulan video musik artis (punya jumlah penonton) — dipakai untuk mengurutkan lagu teratas. */
    fun videoPool(d: Engine.ChannelDetails): List<Track> =
        mineTracks(collectTracks(Engine.newSearch(d.name, Engine.FILTER_MUSIC_VIDEO), 2), d)

    /**
     * Lagu teratas = yang paling sering diputar orang. Jumlah putar hanya tersedia di video musik,
     * jadi tiap lagu dicocokkan dengan video musiknya (lewat judul) dan diurutkan dari penonton
     * terbanyak. Lagu tanpa data penonton diletakkan setelahnya, sesuai urutan relevansi.
     */
    fun rank(songs: List<Track>, videos: List<Track>, limit: Int = 10): List<Track> {
        val views = HashMap<String, Long>()
        for (v in videos) {
            val k = titleKey(v.title)
            if (k.isEmpty() || v.views < 0L) continue
            val old = views[k]
            if (old == null || v.views > old) views[k] = v.views
        }
        // Daftar kandidat: versi lagu (sampul album) lebih disukai daripada versi video musik.
        val byKey = LinkedHashMap<String, Track>()
        for (s in songs) {
            val k = titleKey(s.title)
            if (k.isNotEmpty() && !byKey.containsKey(k)) byKey[k] = s
        }
        for (v in videos) {
            val k = titleKey(v.title)
            if (k.isNotEmpty() && !byKey.containsKey(k)) byKey[k] = v
        }
        val known = byKey.entries.filter { views.containsKey(it.key) }
            .sortedByDescending { views[it.key] ?: 0L }
            .map { it.value }
        val unknown = byKey.entries.filter { !views.containsKey(it.key) }.map { it.value }
        return (known + unknown).take(limit)
    }

    /** Artis lain yang mirip (hasil pencarian artis dengan nama yang sama), tanpa artis ini sendiri. */
    fun similar(d: Engine.ChannelDetails): List<Entry> {
        val batch = Engine.newSearch(d.name, Engine.FILTER_ARTIST).first()
        val me = nameKey(d.name)
        return batch.entries
            .filter { it.kind == Entry.ARTIST && it.url != d.url && key(it.title) != me }
            .take(12)
    }
}
