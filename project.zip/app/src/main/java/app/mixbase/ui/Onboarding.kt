package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.I18n
import app.mixbase.data.LangModels
import app.mixbase.data.Languages
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private const val STEP_COUNT = 2

/** Teks dua bahasa untuk string dinamis (yang tidak ada di peta terjemahan). */
@Composable
private fun t(id: String, en: String): String = if (I18n.lang == "id") id else en

/**
 * Alur pengenalan setelah masuk pertama kali: (1) pilih bahasa sekaligus mengunduh model terjemahan lirik,
 * (2) pilih format audio unduhan. Selesai → [AppViewModel.completeOnboarding].
 */
@Composable
fun OnboardingFlow(vm: AppViewModel) {
    val scheme = MaterialTheme.colorScheme
    var step by rememberSaveable { mutableIntStateOf(0) }

    BackHandler(enabled = step > 0) { step = step - 1 }

    Box(
        Modifier
            .fillMaxSize()
            .background(scheme.surface),
    ) {
        MorphBlob(
            modifier = Modifier
                .size(280.dp)
                .align(Alignment.TopEnd)
                .offset(x = 110.dp, y = (-90).dp)
                .alpha(0.45f),
            color = scheme.primaryContainer,
            lobes = 7,
        )
        MorphBlob(
            modifier = Modifier
                .size(200.dp)
                .align(Alignment.BottomStart)
                .offset(x = (-90).dp, y = 80.dp)
                .alpha(0.4f),
            color = scheme.tertiaryContainer,
            lobes = 9,
        )

        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding(),
        ) {
            StepDots(current = step, total = STEP_COUNT)

            AnimatedContent(
                targetState = step,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally(spring(dampingRatio = 0.9f, stiffness = 380f)) { it } + fadeIn()) togetherWith
                            (slideOutHorizontally(spring(dampingRatio = 1f, stiffness = 500f)) { -it / 3 } + fadeOut())
                    } else {
                        (slideInHorizontally(spring(dampingRatio = 0.9f, stiffness = 380f)) { -it } + fadeIn()) togetherWith
                            (slideOutHorizontally(spring(dampingRatio = 1f, stiffness = 500f)) { it / 3 } + fadeOut())
                    }
                },
                label = "onboarding",
            ) { s ->
                if (s == 0) {
                    LanguageStep(vm = vm, onNext = { step = 1 })
                } else {
                    FormatStep(vm = vm, onBack = { step = 0 }, onDone = { vm.completeOnboarding() })
                }
            }
        }
    }
}

/** Titik langkah: titik aktif melebar menjadi pil. */
@Composable
private fun StepDots(current: Int, total: Int) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 20.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 0 until total) {
            val on = i == current
            val w by animateDpAsState(
                targetValue = if (on) 32.dp else 10.dp,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 450f),
                label = "dotw",
            )
            val c by animateColorAsState(
                targetValue = if (on) scheme.primary else scheme.outlineVariant,
                animationSpec = tween(250),
                label = "dotc",
            )
            Box(
                Modifier
                    .padding(horizontal = 4.dp)
                    .width(w)
                    .height(10.dp)
                    .clip(RoundedCornerShape(percent = 50))
                    .background(c),
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Langkah 1: bahasa + unduh model terjemahan lirik
// ---------------------------------------------------------------------------------------------

@Composable
private fun LanguageStep(vm: AppViewModel, onNext: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()

    var translate by rememberSaveable { mutableStateOf(true) }
    val extras = remember { mutableStateListOf<String>() }
    // code -> 0 menunggu, 1 mengunduh, 2 selesai, 3 gagal
    val status = remember { mutableStateMapOf<String, Int>() }
    var running by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }

    fun finish() {
        vm.translateLyrics(if (translate) vm.contentLang else "")
        onNext()
    }

    fun startDownload() {
        if (running) return
        val codes = LangModels.needed(vm.contentLang, if (translate) extras.toList() else emptyList())
        running = true
        failed = false
        status.clear()
        for (c in codes) status[c] = 0
        scope.launch {
            var ok = true
            for (c in codes) {
                status[c] = 1
                try {
                    if (!LangModels.isDownloaded(c)) LangModels.download(c)
                    status[c] = 2
                } catch (e: Exception) {
                    status[c] = 3
                    ok = false
                }
            }
            running = false
            failed = !ok
            if (ok) finish()
        }
    }

    Column(Modifier.fillMaxSize()) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.appear(delayMillis = 0, offsetY = 16.dp)) {
                    Text(
                        text = "Pilih bahasamu",
                        style = MaterialTheme.typography.headlineLarge,
                        color = scheme.onSurface,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Dipakai untuk tampilan aplikasi, judul video, dan terjemahan lirik lagu. Model bahasanya langsung diunduh supaya lirik bisa diterjemahkan tanpa internet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                }
            }

            itemsIndexed(Languages.ALL, key = { _, l -> l.code }) { index, lang ->
                LangTile(
                    name = lang.name,
                    code = lang.code,
                    selected = vm.contentLang == lang.code,
                    enabled = !running,
                    onClick = { vm.updateContentLang(lang.code) },
                    modifier = Modifier.appear(delayMillis = index.coerceAtMost(8) * 40, offsetY = 18.dp),
                )
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .fillMaxWidth()
                        .clip(MaterialTheme.shapes.large)
                        .background(scheme.secondaryContainer)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "Terjemahkan lirik otomatis",
                            style = MaterialTheme.typography.titleMedium,
                            color = scheme.onSecondaryContainer,
                        )
                        Text(
                            text = "Terjemahan muncul di bawah tiap baris lirik",
                            style = MaterialTheme.typography.bodySmall,
                            color = scheme.onSecondaryContainer.copy(alpha = 0.8f),
                        )
                    }
                    Switch(
                        checked = translate,
                        onCheckedChange = { if (!running) translate = it },
                    )
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                AnimatedVisibility(
                    visible = translate,
                    enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeIn(),
                    exit = shrinkVertically(spring(stiffness = 500f)) + fadeOut(),
                ) {
                    Column {
                        Spacer(Modifier.height(10.dp))
                        Text(
                            text = "Bahasa lagu yang sering kamu dengar (opsional)",
                            style = MaterialTheme.typography.titleSmall,
                            color = scheme.onSurface,
                        )
                        Text(
                            text = "Inggris otomatis ikut diunduh. Tambah bahasa lain agar lagunya bisa diterjemahkan tanpa internet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = scheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            for (l in Languages.ALL) {
                                if (l.code == vm.contentLang || l.code == "en") continue
                                FilterChip(
                                    selected = extras.contains(l.code),
                                    onClick = {
                                        if (!running) {
                                            if (extras.contains(l.code)) extras.remove(l.code) else extras.add(l.code)
                                        }
                                    },
                                    label = { Text(l.name) },
                                    shape = RoundedCornerShape(percent = 50),
                                )
                            }
                        }
                    }
                }
            }

            item(span = { GridItemSpan(maxLineSpan) }) {
                AnimatedVisibility(
                    visible = status.isNotEmpty(),
                    enter = expandVertically(spring(dampingRatio = 0.75f, stiffness = 400f)) + fadeIn(),
                    exit = shrinkVertically(spring(stiffness = 500f)) + fadeOut(),
                ) {
                    DownloadStatusCard(status = status, running = running, failed = failed)
                }
            }
        }

        // Tombol aksi (tetap di bawah).
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ExpressiveButton(
                text = when {
                    failed -> "Coba lagi"
                    translate -> "Unduh & lanjut"
                    else -> "Lanjut"
                },
                onClick = { if (translate) startDownload() else finish() },
                modifier = Modifier.fillMaxWidth(),
                loading = running,
            )
            if (translate && !running) {
                ExpressiveButton(
                    text = if (failed) "Lewati, unduh nanti" else "Lewati unduhan",
                    onClick = { finish() },
                    modifier = Modifier.fillMaxWidth(),
                    style = PillStyle.TONAL,
                    minHeight = 48.dp,
                )
            }
            Text(
                text = "Sekitar 30 MB per bahasa. Disarankan memakai Wi-Fi.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

@Composable
private fun LangTile(
    name: String,
    code: String,
    selected: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val pct by animateFloatAsState(
        targetValue = if (selected) 50f else 26f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 420f),
        label = "tileshape",
    )
    val bg by animateColorAsState(
        targetValue = if (selected) scheme.primaryContainer else scheme.surfaceContainerLow,
        animationSpec = tween(220),
        label = "tilebg",
    )
    val fg by animateColorAsState(
        targetValue = if (selected) scheme.onPrimaryContainer else scheme.onSurface,
        animationSpec = tween(220),
        label = "tilefg",
    )
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(64.dp)
            .clip(RoundedCornerShape(percent = pct.roundToInt().coerceIn(0, 50)))
            .background(bg)
            .bounceClickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                text = name,
                style = MaterialTheme.typography.titleMedium,
                color = fg,
                maxLines = 1,
            )
            Text(
                text = code.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = fg.copy(alpha = 0.7f),
            )
        }
        AnimatedVisibility(
            visible = selected,
            enter = scaleIn(spring(dampingRatio = 0.5f, stiffness = 500f)) + fadeIn(),
            exit = scaleOut() + fadeOut(),
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_check),
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(22.dp),
            )
        }
    }
}

/** Kartu status unduhan model: gelombang progres + status tiap bahasa. */
@Composable
private fun DownloadStatusCard(status: Map<String, Int>, running: Boolean, failed: Boolean) {
    val scheme = MaterialTheme.colorScheme
    val total = status.size
    val done = status.values.count { it == 2 }
    val title = when {
        running -> t("Mengunduh model bahasa…", "Downloading language models…")
        failed -> t("Sebagian gagal diunduh", "Some downloads failed")
        else -> t("Model bahasa siap", "Language models ready")
    }
    val target = if (total == 0) 0f else done.toFloat() / total.toFloat()
    val animated by animateFloatAsState(
        targetValue = target,
        animationSpec = spring(dampingRatio = 1f, stiffness = 200f),
        label = "modelprogress",
    )
    Column(
        modifier = Modifier
            .padding(top = 6.dp)
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.large)
            .background(scheme.surfaceContainerHigh)
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            color = if (failed && !running) scheme.error else scheme.onSurface,
        )
        WavyProgress(progress = { animated }, animate = running)
        for ((code, st) in status) {
            val name = Languages.byCode(code)?.name ?: code
            val label = when (st) {
                1 -> t("Mengunduh…", "Downloading…")
                2 -> t("Selesai", "Done")
                3 -> t("Gagal (periksa internet)", "Failed (check internet)")
                else -> t("Menunggu", "Waiting")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurface,
                    modifier = Modifier.weight(1f),
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (st == 3) scheme.error else scheme.onSurfaceVariant,
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Langkah 2: format audio unduhan
// ---------------------------------------------------------------------------------------------

@Composable
private fun FormatStep(vm: AppViewModel, onBack: () -> Unit, onDone: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.appear(delayMillis = 0, offsetY = 16.dp)) {
                Text(
                    text = "Format audio unduhan",
                    style = MaterialTheme.typography.headlineLarge,
                    color = scheme.onSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Pilih format berkas saat kamu mengunduh lagu. Bisa diubah kapan saja di Setelan.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                )
            }

            FormatCard(
                title = "M4A (AAC)",
                badge = "Disarankan",
                description = "Bisa diputar di hampir semua pemutar musik, HP, dan perangkat lain.",
                selected = vm.audioFormat == 0,
                onClick = { vm.updateAudioFormat(0) },
                modifier = Modifier.appear(delayMillis = 80, offsetY = 20.dp),
            )
            FormatCard(
                title = "WEBM (Opus)",
                badge = "Hemat ruang",
                description = "Ukuran lebih kecil dengan kualitas suara bagus, tapi tidak semua pemutar musik mendukungnya.",
                selected = vm.audioFormat == 1,
                onClick = { vm.updateAudioFormat(1) },
                modifier = Modifier.appear(delayMillis = 160, offsetY = 20.dp),
            )

            Spacer(Modifier.height(4.dp))
            Text(
                text = "Kualitas",
                style = MaterialTheme.typography.titleMedium,
                color = scheme.onSurface,
                modifier = Modifier.appear(delayMillis = 220, offsetY = 12.dp),
            )
            SegmentedPill(
                options = listOf("Tertinggi", "Seimbang", "Hemat"),
                selected = vm.audioQuality,
                onSelect = { vm.updateAudioQuality(it) },
                modifier = Modifier.appear(delayMillis = 260, offsetY = 12.dp),
            )

            Text(
                text = "MP3 belum tersedia: YouTube tidak menyediakan audio MP3, dan mengubahnya butuh pustaka konversi tambahan.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                modifier = Modifier
                    .padding(top = 4.dp)
                    .appear(delayMillis = 300, offsetY = 12.dp),
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ExpressiveButton(
                text = "Mulai pakai PlayTube",
                onClick = onDone,
                modifier = Modifier.fillMaxWidth(),
            )
            ExpressiveButton(
                text = "Kembali",
                onClick = onBack,
                modifier = Modifier.fillMaxWidth(),
                style = PillStyle.TONAL,
                minHeight = 48.dp,
            )
        }
    }
}

@Composable
private fun FormatCard(
    title: String,
    badge: String,
    description: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val corner by animateFloatAsState(
        targetValue = if (selected) 40f else 24f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 420f),
        label = "fmtshape",
    )
    val bg by animateColorAsState(
        targetValue = if (selected) scheme.primaryContainer else scheme.surfaceContainerLow,
        animationSpec = tween(220),
        label = "fmtbg",
    )
    val fg by animateColorAsState(
        targetValue = if (selected) scheme.onPrimaryContainer else scheme.onSurface,
        animationSpec = tween(220),
        label = "fmtfg",
    )
    Row(
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 92.dp)
            .clip(RoundedCornerShape(corner.dp))
            .background(bg)
            .bounceClickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = fg,
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = badge,
                    style = MaterialTheme.typography.labelSmall,
                    color = scheme.onTertiaryContainer,
                    modifier = Modifier
                        .clip(RoundedCornerShape(percent = 50))
                        .background(scheme.tertiaryContainer)
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = fg.copy(alpha = 0.85f),
            )
        }
        AnimatedVisibility(
            visible = selected,
            enter = scaleIn(spring(dampingRatio = 0.5f, stiffness = 500f)) + fadeIn(),
            exit = scaleOut() + fadeOut(),
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_check),
                contentDescription = null,
                tint = fg,
                modifier = Modifier
                    .padding(start = 12.dp)
                    .size(26.dp),
            )
        }
    }
}
