package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Halaman album/playlist: sampul HD besar, tombol putar, dan daftar lagu. */
@Composable
fun AlbumScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    page: Screen.AlbumPage,
    onBack: () -> Unit,
    onOpenArtist: (url: String, name: String) -> Unit,
) {
    var details by remember(page.url) { mutableStateOf<Engine.AlbumDetails?>(null) }
    var error by remember(page.url) { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    LaunchedEffect(page.url) {
        try {
            details = withContext(Dispatchers.IO) { Engine.album(page.url) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            error = "Gagal memuat album: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    val d = details
    val cover = d?.thumb ?: page.thumb
    val title = d?.title?.ifBlank { null } ?: page.title
    val artist = d?.artist?.ifBlank { null } ?: page.artist
    val tracks: List<Track> = d?.tracks ?: emptyList()

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 4.dp),
                ) {
                    IconButton(onClick = onBack) {
                        Icon(
                            painter = painterResource(R.drawable.ic_arrow_back),
                            contentDescription = "Kembali",
                        )
                    }
                }
            }

            // Sampul HD
            item {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.72f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        HdImage(cover, Modifier.fillMaxSize(), px = 1200)
                    }
                }
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                    )
                    val aUrl = d?.artistUrl
                    Text(
                        text = buildString {
                            append("Album")
                            if (artist.isNotBlank()) append(" • ").append(artist)
                            if (tracks.isNotEmpty()) append(" • ").append(tracks.size).append(" lagu")
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .then(
                                if (aUrl != null) {
                                    Modifier.clickable { onOpenArtist(aUrl, artist) }
                                } else {
                                    Modifier
                                },
                            ),
                    )
                    Row(
                        modifier = Modifier.padding(top = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Button(
                            onClick = { player.playQueue(tracks, 0) },
                            enabled = tracks.isNotEmpty(),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_play),
                                contentDescription = null,
                                modifier = Modifier.width(20.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Putar")
                        }
                        OutlinedButton(
                            onClick = { player.playQueue(tracks.shuffled(), 0) },
                            enabled = tracks.isNotEmpty(),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_shuffle),
                                contentDescription = null,
                                modifier = Modifier.width(20.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Acak")
                        }
                    }
                }
            }

            if (d == null && error == null) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        PlayLoader()
                    }
                }
            }

            if (error != null) {
                item {
                    Text(
                        text = error ?: "",
                        modifier = Modifier.padding(24.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            itemsIndexed(tracks, key = { i, t -> "${t.url}#$i" }) { i, t ->
                AlbumTrackRow(vm, player, i + 1, t) { player.playQueue(tracks, i) }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun AlbumTrackRow(
    vm: AppViewModel,
    player: PlayerConnection,
    number: Int,
    t: Track,
    onPlay: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val download = rememberDownloader()
    val playing = player.current?.url == t.url

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
            .padding(start = 20.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = number.toString(),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.width(32.dp),
        )
        Column(Modifier.weight(1f)) {
            Text(
                text = t.title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            val sub = buildString {
                append(t.artist)
                if (t.durationSec > 0L) {
                    if (isNotEmpty()) append(" • ")
                    append(clock(t.durationSec))
                }
            }
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menu = false
                        player.playNext(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menu = false
                        player.addToQueue(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (vm.isFavorite(t.url)) "Hapus dari favorit" else "Tambah ke favorit") },
                    onClick = {
                        menu = false
                        vm.toggleFavorite(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text("Unduh audio") },
                    onClick = {
                        menu = false
                        download(t, false)
                    },
                )
            }
        }
    }
}

/** Baris album/playlist/artis (hasil pencarian atau isi channel). */
@Composable
fun EntryRow(e: Entry, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (e.kind == Entry.ARTIST) {
            Avatar(url = e.thumb, name = e.title, size = 56.dp)
        } else {
            Thumb(e.thumb, 56.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = e.title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            val label = when (e.kind) {
                Entry.ARTIST -> "Artis"
                Entry.PLAYLIST -> "Playlist"
                else -> e.type.ifBlank { "Album" }
            }
            Text(
                text = if (e.sub.isBlank()) label else "$label • ${e.sub}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
