package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * Bilah atas dan bawah berupa kotak padat (tanpa efek fade). Bilah bawah diletakkan di atas isi dan
 * mengukur tingginya sendiri (termasuk area tombol navigasi sistem), lalu tiap layar memberi ruang kosong
 * sebesar itu di bawah daftarnya lewat [LocalBarPadding].
 */

/** Tinggi bilah bawah (navigasi + mini player). Layar tab memakainya sebagai ruang kosong di bawah. */
val LocalBarPadding = compositionLocalOf { 0.dp }

/**
 * Bilah atas berupa kotak padat berwarna latar. [onHeight] melaporkan tingginya (dp) supaya daftar di
 * bawahnya memberi ruang kosong di atas isi pertama; isi daftar bergulir di bawah kotak ini.
 */
@Composable
fun TopBar(
    onHeight: (Dp) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val density = LocalDensity.current
    Box(
        modifier = modifier
            .fillMaxWidth()
            .onSizeChanged { onHeight(with(density) { it.height.toDp() }) }
            .background(ambientTopTint(MaterialTheme.colorScheme.background)),
    ) {
        content()
    }
}

/** Bilah navigasi bawah tidak punya latar sendiri (pil kaca melayang); fungsi ini hanya pembungkus. */
@Composable
fun BottomBarBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier = modifier.fillMaxWidth()) {
        content()
    }
}

/** Gradasi tipis di belakang bilah bawah: isi yang bergulir di bawah pil memudar ke warna latar. */
@Composable
fun bottomScrimBrush(): Brush {
    val bg = MaterialTheme.colorScheme.background
    return Brush.verticalGradient(
        0f to Color.Transparent,
        0.45f to bg.copy(alpha = 0.55f),
        1f to bg.copy(alpha = 0.92f),
    )
}
