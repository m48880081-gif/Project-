package app.mixbase.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * Pengganti `AlertDialog` Material3 dengan gerak: kartu tumbuh dari kecil ke besar sambil
 * memudar masuk, dan mengecil lagi saat ditutup. Pemakaian sama dengan aslinya; tambahan
 * [visible] membuat dialog tetap ada selama animasi keluar (kalau dipanggil tanpa
 * `if`, bukan dihapus dari komposisi).
 */
@Composable
fun AlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: @Composable (() -> Unit)? = null,
    icon: @Composable (() -> Unit)? = null,
    title: @Composable (() -> Unit)? = null,
    text: @Composable (() -> Unit)? = null,
    visible: Boolean = true,
) {
    val p = remember { Animatable(0f) }
    var shown by remember { mutableStateOf(visible) }
    LaunchedEffect(visible) {
        if (visible) {
            shown = true
            p.animateTo(1f, spring(dampingRatio = 0.78f, stiffness = 420f))
        } else {
            p.animateTo(0f, tween(160, easing = FastOutSlowInEasing))
            shown = false
        }
    }
    if (shown) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = onDismissRequest,
            confirmButton = confirmButton,
            modifier = modifier.graphicsLayer {
                val v = p.value
                val s = 0.8f + 0.2f * v
                scaleX = s
                scaleY = s
                alpha = v.coerceIn(0f, 1f)
            },
            dismissButton = dismissButton,
            icon = icon,
            title = title,
            text = text,
        )
    }
}
