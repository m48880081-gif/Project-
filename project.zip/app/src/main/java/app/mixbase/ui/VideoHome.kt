package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R

private val CATEGORIES = listOf("Beranda", "Langganan", "Musik", "Live")

/** Tab "Video": beranda ala YouTube dengan kategori dan feed kartu video besar. */
@Composable
fun VideoHomeScreen(
    vm: AppViewModel,
    actions: VideoActions,
    onSearch: () -> Unit,
) {
    var cat by rememberSaveable { mutableIntStateOf(0) }

    val feed = when (cat) {
        0 -> vm.homeFeed
        1 -> vm.subscriptionsFeed
        2 -> vm.musicVideoFeed
        else -> vm.liveFeed
    }

    LaunchedEffect(cat, vm.subscriptions.size) {
        if (cat != 1 || vm.subscriptions.isNotEmpty()) feed.load()
    }

    Column(Modifier.fillMaxSize()) {
        // Bilah atas (sama dengan Musik)
        AppHeader(
            onSearch = onSearch,
            actions = {
                IconButton(onClick = { feed.load(force = true) }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Muat ulang")
                }
            },
        )

        // Kategori (chip)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            CATEGORIES.forEachIndexed { i, label ->
                FilterChip(
                    selected = i == cat,
                    onClick = { cat = i },
                    label = { Text(label) },
                )
            }
        }

        Box(Modifier.weight(1f)) {
            if (cat == 1 && vm.subscriptions.isEmpty()) {
                EmptyNote(
                    title = "Belum ada langganan",
                    body = "Buka channel dari video lalu tekan Langganan. Video terbarunya muncul di sini.",
                )
            } else {
                FeedList(
                    vm = vm,
                    feed = feed,
                    actions = actions,
                    showSubscriptions = cat == 1,
                )
            }
        }
    }
}

@Composable
private fun SubscriptionStrip(vm: AppViewModel, actions: VideoActions) {
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        itemsIndexed(vm.subscriptions.toList(), key = { _, c -> c.url }) { _, c ->
            Column(
                modifier = Modifier
                    .width(64.dp)
                    .clickable { actions.channel(c.url, c.name) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Avatar(url = c.avatar, name = c.name, size = 52.dp)
                Text(
                    text = c.name,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}

@Composable
private fun FeedList(
    vm: AppViewModel,
    feed: VideoFeed,
    actions: VideoActions,
    showSubscriptions: Boolean,
) {
    val listState = rememberLazyListState()
    val nearEnd by remember(feed) {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            feed.items.isNotEmpty() && last >= feed.items.size - 2
        }
    }
    LaunchedEffect(nearEnd, feed.items.size) {
        if (nearEnd) feed.loadMore()
    }

    when {
        feed.loading && feed.items.isEmpty() -> {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                PlayLoader()
            }
        }

        feed.error != null && feed.items.isEmpty() -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = feed.error ?: "",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                )
                Button(
                    onClick = { feed.load(force = true) },
                    modifier = Modifier.padding(top = 16.dp),
                ) {
                    Text("Coba lagi")
                }
            }
        }

        else -> {
            LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                if (showSubscriptions) {
                    item { SubscriptionStrip(vm, actions) }
                }
                itemsIndexed(feed.items, key = { i, t -> "${t.url}#$i" }) { _, t ->
                    VideoCardFor(t, actions)
                }
                if (feed.loadingMore) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            PlayLoader()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyNote(title: String, body: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}
