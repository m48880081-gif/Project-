package app.mixbase.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.data.Track

/** Jumlah video per baris geser di Beranda. */
private const val ROW_SIZE = 6

/** Beranda mode Video: gaya YouTube, header melayang dan feed kartu video yang tiap barisnya bisa digeser ke samping. */
@Composable
fun VideoHomeScreen(
    vm: AppViewModel,
    actions: VideoActions,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val feed = vm.homeFeed

    LaunchedEffect(Unit) {
        feed.load()
    }

    // Bilah atas (header) berupa kotak padat dan selalu tampil; video bergulir di bawahnya.
    var topH by remember { mutableStateOf(0.dp) }
    val barPad = LocalBarPadding.current

    Box(Modifier.fillMaxSize()) {
        FeedList(
            feed = feed,
            actions = actions,
            rowSize = ROW_SIZE,
            contentPadding = PaddingValues(top = topH, bottom = barPad),
        )

        TopBar(
            onHeight = { topH = it },
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            AppHeader(
                onMenu = onMenu,
                onSearch = onSearch,
                tag = "Video",
                actions = {
                    IconButton(onClick = { feed.load(force = true) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Muat ulang")
                    }
                },
            )
        }
    }
}

/** Deretan foto channel yang dilanggani (di atas feed tab Langganan). */
@Composable
fun SubscriptionStrip(vm: AppViewModel, actions: VideoActions) {
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        itemsIndexed(vm.subscriptions.toList(), key = { _, c -> c.url }) { _, c ->
            Column(
                modifier = Modifier
                    .width(64.dp)
                    .clickable { actions.channel(c.url, c.name) },
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Avatar(url = c.avatar, name = c.name, size = 52.dp)
                Text(
                    text = c.name,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
}

/**
 * Daftar kartu video dengan pemuatan bertahap. [header] (opsional) tampil di paling atas daftar.
 * [rowSize] > 1: video dikelompokkan per baris; setiap baris bisa digeser ke samping (kiri/kanan),
 * sedangkan daftar tetap bisa digulir ke bawah. [rowSize] = 1: satu video per baris seperti biasa.
 */
@Composable
fun FeedList(
    feed: VideoFeed,
    actions: VideoActions,
    modifier: Modifier = Modifier,
    header: (@Composable () -> Unit)? = null,
    rowSize: Int = 1,
    contentPadding: PaddingValues = PaddingValues(0.dp),
) {
    val listState = rememberLazyListState()
    val size = if (rowSize < 1) 1 else rowSize
    val nearEnd by remember(feed, size) {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val rows = (feed.items.size + size - 1) / size
            feed.items.isNotEmpty() && last >= rows - 1
        }
    }
    LaunchedEffect(nearEnd, feed.items.size) {
        if (nearEnd) feed.loadMore()
    }

    when {
        feed.loading && feed.items.isEmpty() -> {
            Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                PlayLoader()
            }
        }

        feed.error != null && feed.items.isEmpty() -> {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = feed.error ?: "",
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                )
                Button(
                    onClick = { feed.load(force = true) },
                    modifier = Modifier.padding(top = 16.dp),
                ) {
                    Text("Coba lagi")
                }
            }
        }

        else -> {
            val cardWidth = rowCardWidth()
            LazyColumn(
                state = listState,
                modifier = modifier.fillMaxSize(),
                contentPadding = contentPadding,
            ) {
                if (header != null) {
                    item { header() }
                }
                if (size == 1) {
                    itemsIndexed(feed.items, key = { i, t -> "${t.url}#$i" }) { i, t ->
                        Box(Modifier.appear(i)) { VideoCardFor(t, actions) }
                    }
                } else {
                    val rows = feed.items.toList().chunked(size)
                    itemsIndexed(rows, key = { i, r -> "row$i:${r.first().url}" }) { i, row ->
                        Box(Modifier.appear(i)) { VideoRow(row, actions, cardWidth) }
                    }
                }
                if (feed.loadingMore) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            PlayLoader()
                        }
                    }
                }
            }
        }
    }
}

/** Lebar kartu dalam baris geser: sisakan sedikit video berikutnya di tepi kanan supaya jelas bisa digeser. */
@Composable
private fun rowCardWidth(): Dp {
    val w = LocalConfiguration.current.screenWidthDp
    val dp = (w * 0.86f).toInt()
    return (if (dp > 440) 440 else dp).dp
}

/** Satu baris video yang bisa digeser ke samping. */
@Composable
private fun VideoRow(items: List<Track>, actions: VideoActions, cardWidth: Dp) {
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        itemsIndexed(items, key = { i, t -> "${t.url}#$i" }) { _, t ->
            Box(Modifier.width(cardWidth)) {
                VideoCardFor(t, actions)
            }
        }
    }
}

@Composable
fun EmptyNote(title: String, body: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            text = body,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}
