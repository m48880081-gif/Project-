package app.mixbase.ui

import android.graphics.Bitmap
import android.graphics.Color as AColor
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.ColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.drawable.toBitmap
import coil.imageLoader
import coil.request.ImageRequest
import coil.request.SuccessResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Warna layar pemutar yang diambil dari sampul lagu. */
class ArtPalette(
    /** Warna latar bagian atas (lebih terang). */
    val top: Color,
    /** Warna latar bagian bawah (gelap). */
    val bottom: Color,
    /** Warna aksen: tombol putar, slider, item aktif. */
    val accent: Color,
    /** Warna ikon/teks di atas aksen. */
    val onAccent: Color,
    /** Rona (0-360) dan kejenuhan (0-1) sampul; kejenuhan 0 berarti sampul netral/abu-abu. */
    val hue: Float = 0f,
    val sat: Float = 0f,
)

val DefaultArtPalette = ArtPalette(
    top = Color(0xFF2B2D31),
    bottom = Color(0xFF111214),
    accent = Color(0xFFE3E3E3),
    onAccent = Color(0xFF1B1B1B),
)

/**
 * Mengambil warna dominan sampul [thumb]. Selama sampul baru dimuat, palet lagu sebelumnya
 * dipertahankan supaya perpindahan warna mulus (dianimasikan oleh pemanggil).
 */
@Composable
fun rememberArtPalette(thumb: String?, pageUrl: String?): ArtPalette {
    val context = LocalContext.current
    var palette by remember { mutableStateOf(DefaultArtPalette) }
    LaunchedEffect(thumb, pageUrl) {
        if (thumb == null) {
            palette = DefaultArtPalette
        } else {
            val p = withContext(Dispatchers.IO) {
                var out: ArtPalette? = null
                for (u in thumbCandidates(thumb, pageUrl, false, 300)) {
                    val req = ImageRequest.Builder(context)
                        .data(u)
                        .size(96, 96)
                        .allowHardware(false)
                        .build()
                    val res = context.imageLoader.execute(req)
                    if (res is SuccessResult) {
                        out = try {
                            paletteOf(res.drawable.toBitmap())
                        } catch (e: Exception) {
                            null
                        }
                        if (out != null) break
                    }
                }
                out
            }
            if (p != null) palette = p
        }
    }
    return palette
}

private fun hsv(h: Float, s: Float, v: Float): Color =
    Color(AColor.HSVToColor(floatArrayOf(h, s.coerceIn(0f, 1f), v.coerceIn(0f, 1f))))

/** Cari rona (hue) yang paling dominan; sampul nyaris abu-abu menghasilkan palet netral. */
private fun paletteOf(src: Bitmap): ArtPalette {
    val n = 32
    val b = Bitmap.createScaledBitmap(src, n, n, true)
    val px = IntArray(n * n)
    b.getPixels(px, 0, n, 0, 0, n, n)

    val buckets = 12
    val wSum = FloatArray(buckets)
    val hSum = FloatArray(buckets)
    val sSum = FloatArray(buckets)
    var colorful = 0
    val tmp = FloatArray(3)
    for (c in px) {
        AColor.colorToHSV(c, tmp)
        if (tmp[1] < 0.18f || tmp[2] < 0.18f) continue
        colorful++
        val w = tmp[1] * (0.3f + tmp[2])
        val i = (tmp[0] / 30f).toInt().coerceIn(0, buckets - 1)
        wSum[i] += w
        hSum[i] += w * tmp[0]
        sSum[i] += w * tmp[1]
    }

    var best = 0
    for (i in 1 until buckets) if (wSum[i] > wSum[best]) best = i

    if (colorful < px.size / 10 || wSum[best] <= 0f) {
        return ArtPalette(
            top = hsv(0f, 0f, 0.26f),
            bottom = hsv(0f, 0f, 0.08f),
            accent = hsv(0f, 0f, 0.93f),
            onAccent = hsv(0f, 0f, 0.12f),
        )
    }

    val h = hSum[best] / wSum[best]
    val s = (sSum[best] / wSum[best]).coerceIn(0.35f, 0.85f)
    return ArtPalette(
        top = hsv(h, s * 0.85f, 0.42f),
        bottom = hsv(h, s * 0.9f, 0.12f),
        accent = hsv(h, 0.28f, 0.96f),
        onAccent = hsv(h, s, 0.16f),
        hue = h,
        sat = s,
    )
}

/**
 * Menurunkan skema warna seluruh aplikasi dari sampul lagu yang sedang diputar, dengan rumus yang
 * SAMA seperti layar pemutar penuh (latar dicampur rona sampul, aksen dari sampul). Dengan begitu
 * Beranda, mini player, bilah navigasi, dan layar lain berubah warna mengikuti lagu.
 *
 * @param art palet sampul, atau null untuk memakai skema asli tanpa rona (tidak ada lagu).
 * Perpindahan warna dianimasikan, jadi pergantian lagu terasa mulus.
 */
@Composable
fun rememberAdaptiveScheme(base: ColorScheme, art: ArtPalette?): ColorScheme {
    val light = base.background.luminance() > 0.5f
    val t = if (art == null) base else tintedScheme(base, art, light)
    return base.copy(
        primary = fade(t.primary),
        onPrimary = fade(t.onPrimary),
        primaryContainer = fade(t.primaryContainer),
        onPrimaryContainer = fade(t.onPrimaryContainer),
        secondary = fade(t.secondary),
        onSecondary = fade(t.onSecondary),
        secondaryContainer = fade(t.secondaryContainer),
        onSecondaryContainer = fade(t.onSecondaryContainer),
        background = fade(t.background),
        surface = fade(t.surface),
        surfaceVariant = fade(t.surfaceVariant),
        surfaceTint = fade(t.surfaceTint),
        surfaceContainerLowest = fade(t.surfaceContainerLowest),
        surfaceContainerLow = fade(t.surfaceContainerLow),
        surfaceContainer = fade(t.surfaceContainer),
        surfaceContainerHigh = fade(t.surfaceContainerHigh),
        surfaceContainerHighest = fade(t.surfaceContainerHighest),
    )
}

@Composable
private fun fade(c: Color): Color = animateColorAsState(c, tween(700), label = "art").value

private fun tintedScheme(base: ColorScheme, art: ArtPalette, light: Boolean): ColorScheme {
    val h = art.hue
    val s = art.sat
    // Rumus latar sama dengan NowPlaying: terang -> campur aksen 35%, gelap -> campur warna atas 22%.
    val tint = if (light) art.accent else art.top
    val w = if (light) 0.35f else 0.22f
    fun mix(c: Color) = lerp(c, tint, w)

    val primary = if (light) art.top else art.accent
    val onPrimary = if (light) Color.White else art.onAccent
    return base.copy(
        primary = primary,
        onPrimary = onPrimary,
        primaryContainer = if (light) hsv(h, s * 0.30f, 0.92f) else hsv(h, s * 0.60f, 0.32f),
        onPrimaryContainer = if (light) hsv(h, s, 0.20f) else hsv(h, 0.15f, 0.94f),
        secondary = if (light) hsv(h, s * 0.70f, 0.42f) else hsv(h, 0.25f, 0.90f),
        onSecondary = if (light) Color.White else hsv(h, s, 0.16f),
        secondaryContainer = if (light) hsv(h, s * 0.32f, 0.88f) else hsv(h, s * 0.50f, 0.30f),
        onSecondaryContainer = if (light) hsv(h, s, 0.22f) else hsv(h, 0.18f, 0.93f),
        background = mix(base.background),
        surface = mix(base.surface),
        surfaceVariant = mix(base.surfaceVariant),
        // Tinggi tonal (mis. mini player) memakai surfaceTint: samakan dengan warna utama sampul.
        surfaceTint = primary,
        surfaceContainerLowest = mix(base.surfaceContainerLowest),
        surfaceContainerLow = mix(base.surfaceContainerLow),
        surfaceContainer = mix(base.surfaceContainer),
        surfaceContainerHigh = mix(base.surfaceContainerHigh),
        surfaceContainerHighest = mix(base.surfaceContainerHighest),
    )
}
