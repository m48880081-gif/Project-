package app.mixbase.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Downloads
import app.mixbase.player.PlayerConnection

/**
 * Tab "Unduhan". [video] true: daftar video yang diunduh (dibuka di pemutar video);
 * false: daftar audio yang diunduh (diputar di pemutar musik). Keduanya bisa diputar tanpa internet.
 */
@Composable
fun DownloadsScreen(
    video: Boolean,
    player: PlayerConnection,
    actions: VideoActions,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val list = Downloads.items.filter { it.video == video }
    val done = list.filter { it.state == Downloads.DONE }

    Column(Modifier.fillMaxSize()) {
        AppHeader(onMenu = onMenu, onSearch = onSearch, tag = if (video) "Video" else "Musik")

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Unduhan",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f),
            )
            if (!video && done.isNotEmpty()) {
                ExpressiveButton(
                    text = "Putar semua",
                    onClick = { player.playQueue(done.map { it.toTrack() }, 0) },
                    icon = R.drawable.ic_play,
                    minHeight = 44.dp,
                )
            }
        }

        // Unduhan dari cadangan yang berkasnya belum ada di perangkat ini: bisa diunduh ulang sekali ketuk
        AnimatedVisibility(
            visible = Downloads.redoCount > 0,
            enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 380f)) + fadeIn(),
            exit = shrinkVertically(spring(stiffness = 500f)) + fadeOut(),
        ) {
            RedoBanner()
        }

        Box(Modifier.weight(1f)) {
            if (list.isEmpty()) {
                EmptyNote(
                    title = "Belum ada unduhan",
                    body = if (video) {
                        "Buka sebuah video lalu tekan Unduh. Video yang sudah diunduh bisa ditonton tanpa internet."
                    } else {
                        "Buka menu ⋮ pada lagu lalu pilih Unduh audio. Lagu yang sudah diunduh bisa diputar tanpa internet."
                    },
                )
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.id }) { item ->
                        DownloadRow(
                            item = item,
                            modifier = Modifier.animateItem(),
                            onPlay = {
                                if (item.state == Downloads.DONE) {
                                    if (video) {
                                        actions.open(item.toTrack())
                                    } else {
                                        val i = done.indexOf(item)
                                        player.playQueue(done.map { it.toTrack() }, if (i < 0) 0 else i)
                                    }
                                }
                            },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DownloadRow(item: Downloads.Item, onPlay: () -> Unit, modifier: Modifier = Modifier) {
    var menu by remember { mutableStateOf(false) }
    val state = item.state

    Row(
        modifier = modifier
            .fillMaxWidth()
            .bounceClickable(enabled = state == Downloads.DONE, onClick = onPlay)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(item.thumb, 56.dp, pageUrl = item.url)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = item.title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            val sub = when (state) {
                Downloads.QUEUED -> "Menunggu…"
                Downloads.RUNNING -> "${(item.progress * 100f).toInt()}% • ${item.label}"
                Downloads.FAILED -> "Gagal: ${item.error ?: "tidak diketahui"}"
                else -> buildString {
                    if (item.artist.isNotEmpty()) append(item.artist).append(" • ")
                    append(item.label)
                    val size = formatSize(item.sizeBytes)
                    if (size.isNotEmpty()) append(" • ").append(size)
                }
            }
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = if (state == Downloads.FAILED) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            if (state == Downloads.RUNNING) {
                WavyProgress(
                    progress = { item.progress },
                    modifier = Modifier.padding(top = 4.dp),
                    amplitude = 2.dp,
                    wavelength = 16.dp,
                    stroke = 3.dp,
                )
            } else if (state == Downloads.QUEUED) {
                LinearProgressIndicator(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                )
            }
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                if (state == Downloads.FAILED) {
                    DropdownMenuItem(
                        text = { Text("Coba lagi") },
                        onClick = {
                            menu = false
                            Downloads.start(item.toTrack(), item.video)
                        },
                    )
                }
                DropdownMenuItem(
                    text = { Text(if (state == Downloads.DONE) "Hapus unduhan" else "Batalkan") },
                    onClick = {
                        menu = false
                        Downloads.remove(item)
                    },
                )
            }
        }
    }
}

/** Spanduk: unduhan dari cadangan yang berkasnya belum ada di perangkat ini. */
@Composable
private fun RedoBanner() {
    SoftCard(
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        color = MaterialTheme.colorScheme.tertiaryContainer,
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                text = "Unduhan dari cadangan",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
            )
            Text(
                text = "Ada lagu atau video dari cadangan yang berkasnya belum ada di perangkat ini. Unduh ulang sekarang?",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.padding(top = 4.dp, bottom = 10.dp),
            )
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
                ExpressiveButton(
                    text = "Unduh ulang",
                    onClick = { Downloads.redoAll() },
                    minHeight = 44.dp,
                )
                ExpressiveButton(
                    text = "Abaikan",
                    onClick = { Downloads.dismissRedo() },
                    style = PillStyle.OUTLINED,
                    minHeight = 44.dp,
                )
            }
        }
    }
}
