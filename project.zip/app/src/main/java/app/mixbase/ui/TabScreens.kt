package app.mixbase.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import app.mixbase.ui.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection

/* Tab-tab sederhana: Langganan & Riwayat (mode Video), Playlist (mode Musik). */

/** Tab "Langganan": deretan channel yang diikuti + video terbaru dari mereka. */
@Composable
fun SubscriptionsScreen(
    vm: AppViewModel,
    actions: VideoActions,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    val feed = vm.subscriptionsFeed

    LaunchedEffect(vm.subscriptions.size) {
        if (vm.subscriptions.isNotEmpty()) feed.load()
    }

    Column(Modifier.fillMaxSize()) {
        AppHeader(
            onMenu = onMenu,
            onSearch = onSearch,
            tag = "Video",
            actions = {
                IconButton(onClick = { feed.load(force = true) }) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Muat ulang")
                }
            },
        )
        Box(Modifier.weight(1f)) {
            if (vm.subscriptions.isEmpty()) {
                EmptyNote(
                    title = "Belum ada langganan",
                    body = "Buka channel dari sebuah video lalu tekan Langganan. Video terbarunya muncul di sini.",
                )
            } else {
                FeedList(
                    feed = feed,
                    actions = actions,
                    header = { SubscriptionStrip(vm, actions) },
                )
            }
        }
    }
}

/** Tab "Riwayat": video yang pernah ditonton. */
@Composable
fun VideoHistoryScreen(
    vm: AppViewModel,
    actions: VideoActions,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        AppHeader(onMenu = onMenu, onSearch = onSearch, tag = "Video")
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Riwayat",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            TextButton(
                onClick = { vm.clearVideoHistory() },
                enabled = vm.videoHistory.isNotEmpty(),
            ) {
                Text("Hapus riwayat")
            }
        }
        Box(Modifier.weight(1f)) {
            if (vm.videoHistory.isEmpty()) {
                EmptyNote(
                    title = "Belum ada riwayat",
                    body = "Video yang kamu tonton akan muncul di sini.",
                )
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(vm.videoHistory.toList(), key = { i, t -> "${t.url}#$i" }) { _, t ->
                        VideoCardFor(t, actions)
                    }
                }
            }
        }
    }
}

/** Tab "Playlist" (mode Musik): Favorit dan Riwayat putar. */
@Composable
fun MusicPlaylistScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
) {
    // 0 = Favorit, 1 = Riwayat putar
    var sel by rememberSaveable { mutableIntStateOf(0) }
    val list: List<Track> = if (sel == 0) vm.favorites.toList() else vm.history.toList()

    Column(Modifier.fillMaxSize()) {
        AppHeader(onMenu = onMenu, onSearch = onSearch, tag = "Musik")

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            PillChip(selected = sel == 0, onClick = { sel = 0 }, label = { Text("Favorit") })
            PillChip(selected = sel == 1, onClick = { sel = 1 }, label = { Text("Riwayat") })
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(
                onClick = { player.playQueue(list, 0) },
                enabled = list.isNotEmpty(),
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_play),
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text("Putar semua")
            }
            if (sel == 1) {
                TextButton(
                    onClick = { vm.clearHistory() },
                    enabled = list.isNotEmpty(),
                ) {
                    Text("Hapus riwayat")
                }
            }
        }

        Box(Modifier.weight(1f)) {
            if (list.isEmpty()) {
                EmptyNote(
                    title = if (sel == 0) "Belum ada favorit" else "Belum ada riwayat",
                    body = if (sel == 0) {
                        "Buka menu ⋮ pada lagu lalu pilih \"Tambah ke favorit\"."
                    } else {
                        "Lagu yang kamu putar akan muncul di sini."
                    },
                )
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(list, key = { i, t -> "${t.url}#$i" }) { i, t ->
                        TrackItem(vm, player, t) { player.playQueue(list, i) }
                    }
                }
            }
        }
    }
}
