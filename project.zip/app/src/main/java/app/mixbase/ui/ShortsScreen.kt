package app.mixbase.ui

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.view.TextureView
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import app.mixbase.R
import app.mixbase.data.Engine
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection
import app.mixbase.player.VideoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Shorts: video pendek satu per layar, digeser atas-bawah seperti TikTok. Satu pemutar ([shorts])
 * dipakai bergantian; video berikutnya disiapkan lebih dulu. Ketuk layar untuk jeda/lanjut; video
 * diputar ulang otomatis. [active] false (tab lain / halaman lain di atasnya) = dijeda.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ShortsScreen(
    vm: AppViewModel,
    shorts: VideoPlayer,
    video: VideoPlayer,
    player: PlayerConnection,
    actions: VideoActions,
    active: Boolean,
) {
    val feed = vm.shortsFeed
    val items = feed.items
    val barPad = LocalBarPadding.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        feed.load()
    }

    // Meninggalkan layar ini (pindah tab/mode): jeda.
    DisposableEffect(Unit) {
        onDispose { shorts.pause() }
    }

    Box(
        Modifier
            .fillMaxSize()
            .padding(bottom = barPad)
            .background(Color.Black),
    ) {
        if (items.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                val err = feed.error
                if (err != null && !feed.loading) {
                    Text(
                        text = err,
                        color = Color.White,
                        style = MaterialTheme.typography.bodyLarge,
                        textAlign = TextAlign.Center,
                    )
                    Button(
                        onClick = { feed.load(force = true) },
                        modifier = Modifier.padding(top = 16.dp),
                    ) {
                        Text("Coba lagi")
                    }
                } else {
                    PlayLoader()
                }
            }
        } else {
            val pagerState = rememberPagerState(
                initialPage = if (vm.shortsPage < items.size) vm.shortsPage else 0,
                pageCount = { items.size },
            )
            var settled by remember { mutableIntStateOf(pagerState.currentPage) }

            // Halaman "menetap" = halaman yang terlihat setelah geseran selesai.
            LaunchedEffect(pagerState) {
                snapshotFlow { pagerState.currentPage to pagerState.isScrollInProgress }
                    .collect { pair ->
                        if (!pair.second) settled = pair.first
                    }
            }

            // Putar video halaman aktif; jeda bila tab/halaman tidak aktif. Hanya satu yang boleh bersuara.
            val currentUrl = items.getOrNull(settled)?.url
            LaunchedEffect(active, settled, currentUrl) {
                val t = items.getOrNull(settled)
                if (t != null && active) {
                    vm.shortsPage = settled
                    video.pause()
                    player.pause()
                    if (shorts.track?.url != t.url) shorts.open(t) else shorts.play()
                } else {
                    shorts.pause()
                }
            }

            // Siapkan video berikutnya dan muat daftar tambahan.
            LaunchedEffect(settled, currentUrl) {
                if (settled >= items.size - 4) feed.loadMore()
                val next = items.getOrNull(settled + 1)
                if (next != null) {
                    delay(800)
                    withContext(Dispatchers.IO) { Engine.prefetchDetails(next.url) }
                }
            }

            // Perbarui posisi (progres) selagi aktif.
            LaunchedEffect(active) {
                while (active) {
                    delay(250)
                    shorts.tick()
                }
            }

            // Putar ulang otomatis setelah selesai.
            LaunchedEffect(shorts.ended, active) {
                if (active && shorts.ended) shorts.play()
            }

            // Aplikasi ke latar belakang: jeda; kembali: lanjut.
            val context = LocalContext.current
            DisposableEffect(context, active) {
                var c: Context? = context
                while (c != null && c !is LifecycleOwner) {
                    c = if (c is ContextWrapper) c.baseContext else null
                }
                val owner = c as? LifecycleOwner
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_STOP) {
                        shorts.pause()
                    } else if (event == Lifecycle.Event.ON_START && active && shorts.track != null) {
                        shorts.play()
                    }
                }
                owner?.lifecycle?.addObserver(observer)
                onDispose { owner?.lifecycle?.removeObserver(observer) }
            }

            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize(),
                key = { index -> items.getOrNull(index)?.url ?: index },
            ) { page ->
                val t = items.getOrNull(page)
                if (t != null) {
                    ShortPage(
                        t = t,
                        current = page == settled,
                        shorts = shorts,
                        actions = actions,
                        onNext = {
                            if (page + 1 < items.size) {
                                scope.launch { pagerState.animateScrollToPage(page + 1) }
                            }
                        },
                    )
                }
            }

            // Judul dan muat ulang di atas video.
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 4.dp, top = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Shorts",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier
                        .weight(1f)
                        .padding(vertical = 8.dp),
                )
                IconButton(
                    onClick = {
                        vm.shortsPage = 0
                        feed.load(force = true)
                        scope.launch { pagerState.scrollToPage(0) }
                    },
                ) {
                    Icon(Icons.Filled.Refresh, contentDescription = "Muat ulang", tint = Color.White)
                }
            }
        }
    }
}

/** Satu halaman Shorts: video (atau gambar sampul sebelum mulai), info, dan tombol di sisi kanan. */
@Composable
private fun ShortPage(
    t: Track,
    current: Boolean,
    shorts: VideoPlayer,
    actions: VideoActions,
    onNext: () -> Unit,
) {
    val context = LocalContext.current
    val live = current && shorts.track?.url == t.url
    val failed = live && (shorts.error != null || shorts.useEmbed)
    val started = live && !failed && (shorts.isPlaying || shorts.positionMs > 0L)
    val fraction = if (live && shorts.durationMs > 0L) {
        (shorts.positionMs.toFloat() / shorts.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black),
    ) {
        // Video, ukurannya mengikuti rasio (tidak melar), dipusatkan.
        if (live && !failed) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) { shorts.togglePlay() },
                contentAlignment = Alignment.Center,
            ) {
                ShortSurface(shorts)
            }
        }

        // Gambar sampul sampai video benar-benar mulai.
        if (!started) {
            ThumbImage(
                thumb = t.thumb,
                pageUrl = t.url,
                modifier = Modifier.fillMaxSize(),
                hd = true,
                contentScale = ContentScale.Fit,
            )
        }

        if (current && !failed && !started) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                PlayLoader()
            }
        }

        // Ikon putar saat dijeda.
        if (started && !shorts.isPlaying && !shorts.buffering) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Icon(
                    painter = painterResource(R.drawable.ic_play),
                    contentDescription = "Jeda",
                    tint = Color.White.copy(alpha = 0.85f),
                    modifier = Modifier.size(72.dp),
                )
            }
        }

        if (failed) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = if (shorts.useEmbed) {
                        "Video ini tidak bisa diputar di Shorts. Buka di halaman tonton."
                    } else {
                        shorts.error ?: ""
                    },
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                )
                Row(
                    modifier = Modifier.padding(top = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    if (shorts.useEmbed) {
                        Button(onClick = { actions.open(t) }) { Text("Buka") }
                    } else {
                        Button(onClick = { shorts.retry() }) { Text("Coba lagi") }
                    }
                    OutlinedButton(onClick = onNext) { Text("Lewati", color = Color.White) }
                }
            }
        }

        // Bayangan di bawah supaya tulisan putih terbaca.
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(220.dp)
                .background(
                    Brush.verticalGradient(
                        0f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.7f),
                    ),
                ),
        )

        // Info video (kiri bawah)
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth(0.78f)
                .padding(start = 16.dp, bottom = 22.dp),
        ) {
            val ch = t.uploaderUrl
            Row(
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(enabled = ch != null) {
                        if (ch != null) actions.channel(ch, t.artist)
                    },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (t.avatar != null) {
                    ThumbImage(
                        thumb = t.avatar,
                        pageUrl = null,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape),
                    )
                }
                Text(
                    text = t.artist,
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(start = if (t.avatar != null) 10.dp else 0.dp),
                )
            }
            Text(
                text = t.title,
                color = Color.White,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 8.dp),
            )
        }

        // Tombol (kanan bawah)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 10.dp, bottom = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            ShortButton(R.drawable.ic_video, "Tonton") { actions.open(t) }
            ShortButton(R.drawable.ic_headphones, "Audio") { actions.audio(t) }
            ShortButton(R.drawable.ic_share, "Bagikan") {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, t.title + "\n" + t.url)
                }
                try {
                    context.startActivity(Intent.createChooser(send, "Bagikan"))
                } catch (e: Exception) {
                    // tidak ada aplikasi untuk berbagi
                }
            }
        }

        // Progres tipis di dasar layar
        if (live) {
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(2.dp),
                color = Color.White,
                trackColor = Color.White.copy(alpha = 0.25f),
            )
        }
    }
}

@Composable
private fun ShortButton(icon: Int, label: String, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(CircleShape)
            .clickable(onClick = onClick)
            .padding(2.dp),
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color.Black.copy(alpha = 0.35f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(icon),
                contentDescription = label,
                tint = Color.White,
                modifier = Modifier.size(24.dp),
            )
        }
        Text(
            text = label,
            color = Color.White,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 3.dp),
        )
    }
}

/** TextureView yang ukurannya mengikuti rasio video (tidak melar). */
@Composable
private fun ShortSurface(shorts: VideoPlayer) {
    val a = shorts.aspect
    // Video tegak (rasio < 1) mengisi tinggi layar; video lebar mengisi lebar layar.
    val m = if (a < 1f) {
        Modifier
            .fillMaxHeight()
            .aspectRatio(a, matchHeightConstraintsFirst = true)
    } else {
        Modifier
            .fillMaxWidth()
            .aspectRatio(a)
    }
    AndroidView(
        factory = { ctx ->
            val v = TextureView(ctx)
            shorts.attach(v)
            v
        },
        modifier = m,
        onRelease = { v -> shorts.detach(v) },
    )
}
