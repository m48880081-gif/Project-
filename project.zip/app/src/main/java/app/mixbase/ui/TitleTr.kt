package app.mixbase.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import app.mixbase.data.I18n
import app.mixbase.data.Translate

/**
 * Judul video dalam bahasa aplikasi. Awalnya tampil judul asli; begitu terjemahan di perangkat
 * selesai, judul diganti. Hanya untuk video (judul lagu tidak diterjemahkan).
 */
@Composable
fun videoTitle(title: String): String {
    val target = I18n.lang
    val on = I18n.translateTitles
    if (!on || title.isBlank()) return title
    val state = remember(title, target) { mutableStateOf(Translate.cached(title, target) ?: title) }
    LaunchedEffect(title, target) {
        if (Translate.cached(title, target) == null) {
            state.value = Translate.title(title, target)
        }
    }
    return state.value
}
