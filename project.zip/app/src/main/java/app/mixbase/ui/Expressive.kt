package app.mixbase.ui

import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/*
 * Bahan dasar desain Material 3 Expressive yang dipakai seluruh aplikasi:
 *  - gerak berbasis spring (memantul halus) untuk posisi/ukuran/bentuk, tanpa pantulan untuk warna/transparansi
 *  - tombol & baris yang "menekan" saat disentuh (skala + bentuk berubah)
 *  - bilah navigasi dengan indikator pil yang melar
 *  - progres & slider bergelombang
 *  - bentuk kue (cookie) dan blob yang berubah bentuk
 */

/** Spesifikasi gerak. Spasial = sedikit memantul, efek = halus. */
object Motion {
    /** Masuk dari bawah (lembar penuh: pemutar, tonton). */
    fun sheetIn(): EnterTransition =
        slideInVertically(animationSpec = spring(dampingRatio = 0.86f, stiffness = 330f)) { it } +
            fadeIn(animationSpec = spring(stiffness = 600f))

    fun sheetOut(): ExitTransition =
        slideOutVertically(animationSpec = spring(dampingRatio = 1f, stiffness = 500f)) { it } +
            fadeOut(animationSpec = spring(stiffness = 700f))

    /** Masuk dari kanan (Setelan dan halaman tumpuk). */
    fun pageIn(): EnterTransition =
        slideInHorizontally(animationSpec = spring(dampingRatio = 0.9f, stiffness = 380f)) { it / 3 } +
            fadeIn(animationSpec = spring(stiffness = 600f)) +
            scaleIn(animationSpec = spring(dampingRatio = 0.9f, stiffness = 380f), initialScale = 0.96f)

    fun pageOut(): ExitTransition =
        slideOutHorizontally(animationSpec = spring(dampingRatio = 1f, stiffness = 500f)) { it / 3 } +
            fadeOut(animationSpec = spring(stiffness = 700f)) +
            scaleOut(animationSpec = spring(dampingRatio = 1f, stiffness = 500f), targetScale = 0.96f)

    /** Muncul dengan membesar (mini player, banner). */
    fun popIn(): EnterTransition =
        scaleIn(animationSpec = spring(dampingRatio = 0.6f, stiffness = 420f), initialScale = 0.85f) +
            fadeIn(animationSpec = spring(stiffness = 700f))

    fun popOut(): ExitTransition =
        scaleOut(animationSpec = spring(dampingRatio = 1f, stiffness = 600f), targetScale = 0.9f) +
            fadeOut(animationSpec = spring(stiffness = 800f))
}

/**
 * Pengganti `clickable` yang memberi efek tekan: bagian yang disentuh mengecil sedikit lalu memantul
 * kembali (spring), selain riak bawaan.
 */
fun Modifier.bounceClickable(
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    onClick: () -> Unit,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed && enabled) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 520f),
        label = "bounce",
    )
    Modifier
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(
            interactionSource = source,
            indication = LocalIndication.current,
            enabled = enabled,
            onClickLabel = onClickLabel,
            role = role,
            onClick = onClick,
        )
}

/**
 * Efek muncul: transparan → jelas sambil naik dan membesar sedikit (spring). [delayMillis] untuk
 * memunculkan beberapa elemen berurutan (stagger). Hanya berjalan sekali saat elemen pertama tampil.
 */
fun Modifier.appear(
    delayMillis: Int = 0,
    offsetY: Dp = 24.dp,
    startScale: Float = 0.94f,
): Modifier = composed {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (delayMillis > 0) delay(delayMillis.toLong())
        progress.animateTo(1f, spring(dampingRatio = 0.78f, stiffness = 260f))
    }
    val offsetPx = with(LocalDensity.current) { offsetY.toPx() }
    Modifier.graphicsLayer {
        val v = progress.value
        alpha = v.coerceIn(0f, 1f)
        translationY = (1f - v) * offsetPx
        val s = startScale + (1f - startScale) * v
        scaleX = s
        scaleY = s
    }
}

/** Bentuk "kue" bergerigi halus (dipakai untuk avatar dan penanda). */
class CookieShape(
    private val lobes: Int = 9,
    private val depth: Float = 0.06f,
) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val path = Path()
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = min(cx, cy)
        val steps = 180
        for (i in 0..steps) {
            val th = 2.0 * PI * i / steps
            val r = radius * (1f + depth * cos(lobes * th).toFloat()) / (1f + depth)
            val x = cx + r * cos(th).toFloat()
            val y = cy + r * sin(th).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return Outline.Generic(path)
    }
}

/** Blob dekoratif yang terus berputar dan "bernapas" (latar halaman masuk). */
@Composable
fun MorphBlob(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primaryContainer,
    lobes: Int = 8,
) {
    val transition = rememberInfiniteTransition(label = "blob")
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(14000, easing = LinearEasing)),
        label = "spin",
    )
    val depth by transition.animateFloat(
        initialValue = 0.05f,
        targetValue = 0.17f,
        animationSpec = infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "depth",
    )
    Canvas(modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val radius = min(size.width, size.height) / 2f
        val path = Path()
        val steps = 180
        for (i in 0..steps) {
            val th = 2.0 * PI * i / steps
            val r = radius * (1f + depth * cos(lobes * th + spin).toFloat()) / (1f + depth)
            val x = c.x + r * cos(th).toFloat()
            val y = c.y + r * sin(th).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path = path, color = color)
    }
}

/** Avatar bentuk kue berisi huruf pertama nama. */
@Composable
fun CookieAvatar(name: String, size: Dp, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val shape = remember { CookieShape(lobes = 10, depth = 0.05f) }
    Box(
        modifier = modifier
            .size(size)
            .clip(shape)
            .background(scheme.tertiaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = name.trim().take(1).uppercase(),
            color = scheme.onTertiaryContainer,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp,
        )
    }
}

/**
 * Tombol besar Expressive: bentuknya berubah dari pil penuh menjadi lebih kotak saat ditekan,
 * lalu memantul kembali. [loading] menampilkan indikator memuat dan menonaktifkan klik.
 */
@Composable
fun ExpressiveButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: PillStyle = PillStyle.FILLED,
    icon: Int? = null,
    enabled: Boolean = true,
    loading: Boolean = false,
    minHeight: Dp = 56.dp,
) {
    val scheme = MaterialTheme.colorScheme
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val pct by animateFloatAsState(
        targetValue = if (pressed) 24f else 50f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 520f),
        label = "btnshape",
    )
    val press by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 520f),
        label = "btnpress",
    )
    val shape = RoundedCornerShape(percent = pct.roundToInt().coerceIn(0, 50))
    val bg = when (style) {
        PillStyle.FILLED -> scheme.primary
        PillStyle.TONAL -> scheme.secondaryContainer
        PillStyle.OUTLINED -> Color.Transparent
    }
    val fg = when (style) {
        PillStyle.FILLED -> scheme.onPrimary
        PillStyle.TONAL -> scheme.onSecondaryContainer
        PillStyle.OUTLINED -> scheme.primary
    }
    val enabledAlpha = if (enabled) 1f else 0.5f
    var m = modifier
        .graphicsLayer {
            scaleX = press
            scaleY = press
            alpha = enabledAlpha
        }
        .heightIn(min = minHeight)
        .clip(shape)
        .background(bg)
    if (style == PillStyle.OUTLINED) {
        m = m.border(1.dp, scheme.outline, shape)
    }
    Row(
        modifier = m
            .clickable(
                interactionSource = source,
                indication = LocalIndication.current,
                enabled = enabled && !loading,
                onClick = onClick,
            )
            .padding(horizontal = 24.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (loading) {
            PlayLoader(diameter = 26.dp, containerColor = Color.Transparent, color = fg)
            Spacer(Modifier.width(10.dp))
        } else if (icon != null) {
            Icon(
                painter = painterResource(icon),
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(10.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            color = fg,
            maxLines = 1,
        )
    }
}

/** Pilihan 2+ segmen (mis. Masuk / Daftar): segmen terpilih berbentuk pil penuh, yang lain lebih kotak. */
@Composable
fun SegmentedPill(
    options: List<String>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            val pct by animateFloatAsState(
                targetValue = if (on) 50f else 28f,
                animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
                label = "seg",
            )
            val bg by animateColorAsState(
                targetValue = if (on) scheme.primary else scheme.surfaceContainerHigh,
                animationSpec = tween(220),
                label = "segbg",
            )
            val fg by animateColorAsState(
                targetValue = if (on) scheme.onPrimary else scheme.onSurfaceVariant,
                animationSpec = tween(220),
                label = "segfg",
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .clip(RoundedCornerShape(percent = pct.roundToInt().coerceIn(0, 50)))
                    .background(bg)
                    .bounceClickable { onSelect(i) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelLarge,
                    color = fg,
                    maxLines = 1,
                )
            }
        }
    }
}

/** Latar bagian pengaturan/kartu: kotak sangat membulat berwarna permukaan. */
@Composable
fun SoftCard(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.surfaceContainer,
    content: @Composable () -> Unit,
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.large)
            .background(color),
    ) {
        content()
    }
}

// ---------------------------------------------------------------------------------------------
// Bilah navigasi bawah
// ---------------------------------------------------------------------------------------------

/** Wadah bilah navigasi bawah (tinggi tetap + ruang untuk tombol navigasi sistem). */
@Composable
fun ExpressiveNavBar(
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .height(76.dp)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

/**
 * Satu tab: indikator pil melebar dengan pantulan saat dipilih, ikon membesar sedikit,
 * dan menyusut saat ditekan.
 */
@Composable
fun RowScope.ExpressiveNavItem(
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    small: Boolean = false,
    icon: @Composable () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val sel by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 380f),
        label = "navsel",
    )
    val press by animateFloatAsState(
        targetValue = if (pressed) 0.88f else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 600f),
        label = "navpress",
    )
    val tint by animateColorAsState(
        targetValue = if (selected) scheme.onSecondaryContainer else scheme.onSurfaceVariant,
        animationSpec = tween(220),
        label = "navtint",
    )
    val labelColor by animateColorAsState(
        targetValue = if (selected) scheme.onSurface else scheme.onSurfaceVariant,
        animationSpec = tween(220),
        label = "navlabel",
    )
    Column(
        modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable(
                interactionSource = source,
                indication = null,
                role = Role.Tab,
                onClick = onClick,
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            modifier = Modifier
                .graphicsLayer {
                    scaleX = press
                    scaleY = press
                }
                .width((44f + 28f * sel.coerceIn(0f, 1.15f)).dp)
                .height(32.dp)
                .clip(RoundedCornerShape(percent = 50))
                .background(scheme.secondaryContainer.copy(alpha = sel.coerceIn(0f, 1f))),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier.graphicsLayer {
                    val s = 1f + 0.14f * sel
                    scaleX = s
                    scaleY = s
                },
            ) {
                CompositionLocalProvider(LocalContentColor provides tint) { icon() }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            fontSize = if (small) 10.sp else 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            letterSpacing = 0.sp,
            color = labelColor,
            maxLines = 1,
            softWrap = false,
        )
    }
}

// ---------------------------------------------------------------------------------------------
// Progres & slider bergelombang
// ---------------------------------------------------------------------------------------------

/**
 * Bilah progres bergelombang ala Material 3 Expressive. Bagian yang sudah berjalan berombak (dan
 * bergerak bila [animate]), sisanya garis lurus.
 */
@Composable
fun WavyProgress(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceContainerHighest,
    animate: Boolean = true,
    amplitude: Dp = 3.dp,
    wavelength: Dp = 22.dp,
    stroke: Dp = 4.dp,
) {
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(animate) {
        if (animate) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                phase = (phase + (now - last) / 1_000_000_000f * 5f) % (2f * PI.toFloat())
                last = now
            }
        }
    }
    Canvas(
        modifier
            .fillMaxWidth()
            .height(amplitude * 2 + stroke),
    ) {
        val w = size.width
        val mid = size.height / 2f
        val sw = stroke.toPx()
        val amp = amplitude.toPx()
        val len = wavelength.toPx()
        val p = progress().coerceIn(0f, 1f)
        val startX = sw / 2f
        val endX = startX + (w - sw) * p

        if (p < 1f) {
            drawLine(
                color = trackColor,
                start = Offset(endX + sw, mid),
                end = Offset(w - sw / 2f, mid),
                strokeWidth = sw,
                cap = StrokeCap.Round,
            )
        }

        val path = Path()
        val step = 4.dp.toPx()
        var x = startX
        path.moveTo(x, mid + amp * sin(-phase))
        while (x < endX) {
            x = min(x + step, endX)
            val y = mid + amp * sin((x / len) * 2f * PI.toFloat() - phase)
            path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round),
        )
    }
}

/**
 * Slider dengan jalur bergelombang dan pegangan tipis (gaya Expressive). Gestur tetap ditangani
 * oleh Slider Material 3.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpressiveSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    onValueChangeFinished: () -> Unit,
    modifier: Modifier = Modifier,
    animate: Boolean = true,
    color: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceContainerHighest,
) {
    Slider(
        value = value,
        onValueChange = onValueChange,
        onValueChangeFinished = onValueChangeFinished,
        modifier = modifier,
        thumb = { _ ->
            Box(
                Modifier
                    .width(4.dp)
                    .height(36.dp)
                    .clip(RoundedCornerShape(percent = 50))
                    .background(color),
            )
        },
        track = { _ ->
            WavyProgress(
                progress = { value },
                animate = animate,
                color = color,
                trackColor = trackColor,
            )
        },
    )
}

// ---------------------------------------------------------------------------------------------
// Ekualiser kecil (penanda lagu yang sedang diputar)
// ---------------------------------------------------------------------------------------------

@Composable
fun EqualizerBars(
    playing: Boolean,
    color: Color,
    modifier: Modifier = Modifier.size(18.dp),
) {
    val transition = rememberInfiniteTransition(label = "eq")
    val a by transition.animateFloat(
        initialValue = 0.25f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "eqa",
    )
    val b by transition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(560, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "eqb",
    )
    val c by transition.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(360, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "eqc",
    )
    Canvas(modifier) {
        val barW = size.width / 5f
        for (i in 0 until 3) {
            val f = if (playing) {
                when (i) {
                    0 -> a
                    1 -> b
                    else -> c
                }
            } else {
                when (i) {
                    0 -> 0.4f
                    1 -> 0.75f
                    else -> 0.5f
                }
            }
            val h = size.height * f
            drawRoundRect(
                color = color,
                topLeft = Offset(i * 2f * barW, size.height - h),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f),
            )
        }
    }
}
