@file:OptIn(ExperimentalSharedTransitionApi::class, ExperimentalAnimationApi::class)

package app.mixbase.ui

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.TransformOrigin

/** Lama dan kurva animasi terbang antara mini player dan layar pemutar (sama untuk semua elemen). */
private const val FlyMs = 450

/** Ruang transisi bersama (dipasang di AppRoot) supaya sampul bisa "terbang" antar layar. */
val LocalSharedTransition = compositionLocalOf<SharedTransitionScope?> { null }

/** Ruang animasi (AnimatedVisibility) tempat komponen saat ini sedang tampil. */
val LocalVisibilityScope = compositionLocalOf<AnimatedVisibilityScope?> { null }

/**
 * Menandai gambar sampul sebagai elemen bersama: ukuran dan posisinya berubah pelan-pelan dari
 * mini player ke layar pemutar penuh (dan sebaliknya) alih-alih muncul/hilang tiba-tiba.
 * Pasang paling depan di rangkaian modifier, sebelum ukuran. Tanpa ruang transisi, tidak berpengaruh.
 */
@Composable
fun Modifier.sharedCover(key: String): Modifier {
    val shared = LocalSharedTransition.current
    val visibility = LocalVisibilityScope.current
    if (shared == null || visibility == null) return this
    val self = this
    return with(shared) {
        self.sharedElement(
            state = rememberSharedContentState(key = key),
            animatedVisibilityScope = visibility,
            boundsTransform = { _, _ -> tween<Rect>(durationMillis = FlyMs, easing = FastOutSlowInEasing) },
        )
    }
}

/**
 * Seperti [sharedCover], tapi untuk tombol dan teks yang ada di mini player DAN di layar pemutar
 * (judul, artis, putar/jeda, berikutnya): ukuran dan posisinya ikut berubah pelan-pelan, persis
 * seperti sampul. Pasang paling depan di rangkaian modifier, sebelum ukuran/padding.
 * [key] harus sama di kedua sisi dan unik per elemen.
 */
@Composable
fun Modifier.sharedPart(key: String): Modifier {
    val shared = LocalSharedTransition.current
    val visibility = LocalVisibilityScope.current
    if (shared == null || visibility == null) return this
    val self = this
    return with(shared) {
        self.sharedBounds(
            sharedContentState = rememberSharedContentState(key = key),
            animatedVisibilityScope = visibility,
            enter = fadeIn(tween(300)),
            exit = fadeOut(tween(300)),
            boundsTransform = { _, _ -> tween<Rect>(durationMillis = FlyMs, easing = FastOutSlowInEasing) },
        )
    }
}

/**
 * Untuk elemen layar pemutar yang TIDAK punya pasangan di mini player (tombol acak/sebelumnya/ulangi,
 * seek bar, tombol Antrean/Lirik, header): saat layar dibuka elemen ini tumbuh dari kecil sambil
 * bergeser ke tempatnya, saat ditutup mengecil lagi, dengan lama dan kurva yang sama seperti sampul.
 * [fromTop] untuk elemen di bagian atas layar (bergeser dari atas), selain itu dari bawah.
 */
@Composable
fun Modifier.flyInOut(fromTop: Boolean = false): Modifier {
    val visibility = LocalVisibilityScope.current ?: return this
    val self = this
    val origin = TransformOrigin(0.5f, if (fromTop) 0f else 1f)
    return with(visibility) {
        self.animateEnterExit(
            enter = fadeIn(tween(300, delayMillis = 100)) +
                scaleIn(tween(FlyMs, easing = FastOutSlowInEasing), initialScale = 0.5f, transformOrigin = origin) +
                slideInVertically(tween(FlyMs, easing = FastOutSlowInEasing)) { if (fromTop) -it else it },
            exit = fadeOut(tween(200)) +
                scaleOut(tween(FlyMs, easing = FastOutSlowInEasing), targetScale = 0.5f, transformOrigin = origin) +
                slideOutVertically(tween(FlyMs, easing = FastOutSlowInEasing)) { if (fromTop) -it else it },
        )
    }
}
