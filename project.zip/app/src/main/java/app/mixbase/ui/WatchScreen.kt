package app.mixbase.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.TextureView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.darkColorScheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import app.mixbase.data.I18n
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.mixbase.R
import app.mixbase.data.Channel
import app.mixbase.data.Engine
import app.mixbase.data.Downloads
import app.mixbase.data.Languages
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.data.compactCount
import app.mixbase.player.VideoPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * Halaman tonton ala YouTube + jendela video mengambang.
 *
 * Hanya ada SATU pemutar ([PlayerArea]) selama video aktif, tidak pernah dibongkar-pasang, jadi
 * video terus jalan. Saat [expanded] ia berada di atas halaman (16:9, atau layar penuh); saat
 * diminimalkan ia mengecil jadi jendela kecil yang bisa digeser. Ukuran dan posisinya dianimasikan
 * oleh `progress` (0 = jendela kecil, 1 = terbuka) dengan lama dan kurva yang sama seperti animasi
 * sampul di pemutar musik; tombol di dalamnya ikut menata ulang diri mengikuti ukuran.
 */
@Composable
fun WatchScreen(
    vm: AppViewModel,
    video: VideoPlayer,
    expanded: Boolean,
    barPad: Dp,
    onExpand: () -> Unit,
    onMinimize: () -> Unit,
    onOpenChannel: (url: String, name: String) -> Unit,
    onPlayAudio: (queue: List<Track>, startMs: Long) -> Unit,
    onQueueAudio: (Track) -> Unit,
) {
    val t = video.track ?: return
    val d = video.details
    val context = LocalContext.current
    val view = LocalView.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    var fullscreen by remember { mutableStateOf(false) }
    var panel by remember { mutableIntStateOf(0) } // 0 = tidak ada, 1 = komentar, 2 = deskripsi
    var showQuality by remember { mutableStateOf(false) }
    var showLang by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val embedActive = video.useEmbed && video.embedVideoId() != null

    // Pemutar tersemat tidak bisa lanjut di jendela kecil: menutupnya menghentikan video.
    val minimize: () -> Unit = {
        if (video.useEmbed) video.stop()
        onMinimize()
    }

    // Tombol kembali hanya diurus di sini saat halaman terbuka; saat jadi jendela kecil, biarkan layar lain.
    BackHandler(enabled = expanded) {
        when {
            fullscreen -> fullscreen = false
            panel != 0 -> panel = 0
            else -> minimize()
        }
    }

    LaunchedEffect(embedActive) {
        if (embedActive) fullscreen = false
    }
    LaunchedEffect(expanded) {
        if (!expanded) fullscreen = false
    }

    // Ikon status bar terang saat pemutar hitam berada di bawah status bar (hanya saat halaman terbuka).
    DisposableEffect(expanded) {
        val window = context.findActivity()?.window
        if (expanded && window != null) {
            val c = WindowCompat.getInsetsController(window, view)
            val old = c.isAppearanceLightStatusBars
            c.isAppearanceLightStatusBars = false
            onDispose { c.isAppearanceLightStatusBars = old }
        } else {
            onDispose { }
        }
    }

    // Layar penuh: landscape + sembunyikan bilah sistem.
    DisposableEffect(fullscreen) {
        val act = context.findActivity()
        if (act != null) {
            val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
            if (fullscreen) {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                c.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose { }
    }
    DisposableEffect(Unit) {
        onDispose {
            val act = context.findActivity()
            if (act != null) {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(act.window, act.window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Komentar dimuat segera setelah detail video siap.
    LaunchedEffect(d?.url, embedActive) {
        if (d != null || embedActive) video.loadComments()
    }

    // Putar otomatis video berikutnya saat selesai.
    LaunchedEffect(video.ended) {
        if (video.ended) {
            val next = d?.related?.firstOrNull { !it.live }
            if (next != null) video.open(next)
        }
    }

    // Video baru → kembali ke atas dan tutup panel.
    LaunchedEffect(t.url) {
        panel = 0
        listState.scrollToItem(0)
    }

    val nextTrack: Track? = d?.related?.firstOrNull { !it.live }
    val onNext: (() -> Unit)? = if (nextTrack != null) ({ video.open(nextTrack) }) else null

    // 0 = jendela kecil, 1 = halaman terbuka. Mulai dari 0 supaya video pertama kali dibuka pun
    // "tumbuh" dari jendela kecil.
    val progress = remember { Animatable(0f) }
    LaunchedEffect(expanded) {
        progress.animateTo(if (expanded) 1f else 0f, tween(450, easing = FastOutSlowInEasing))
    }
    val showPage by remember { derivedStateOf { progress.value > 0.001f } }
    val miniMode by remember { derivedStateOf { progress.value < 0.5f } }

    // Posisi jendela kecil: selisih dari tempat awal (kanan bawah, di atas bilah navigasi).
    var offX by remember { mutableFloatStateOf(0f) }
    var offY by remember { mutableFloatStateOf(0f) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val fullW = constraints.maxWidth.toFloat()
        val fullH = constraints.maxHeight.toFloat()
        val statusTop = WindowInsets.statusBars.getTop(density).toFloat()
        val margin = with(density) { 12.dp.toPx() }
        val barPx = with(density) { barPad.toPx() }
        val miniW = minOf(fullW * 0.5f, with(density) { 260.dp.toPx() })
        val miniH = miniW * 9f / 16f
        val defX = fullW - miniW - margin
        val defY = fullH - barPx - miniH - margin
        val minX = minOf(0f, margin - defX) // batas geser ke kiri
        val minY = minOf(0f, statusTop + margin - defY) // batas geser ke atas

        // ---- Halaman (judul, aksi, komentar, video terkait): memudar masuk saat terbuka ----
        if (showPage && !(fullscreen && !embedActive)) {
            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { alpha = progress.value },
                color = MaterialTheme.colorScheme.background,
            ) {
                Column(Modifier.fillMaxSize()) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .background(Color.Black)
                            .statusBarsPadding(),
                    ) {
                        if (embedActive) {
                            EmbedArea(video = video, onMinimize = minimize)
                        } else {
                            // Tempat kosong untuk pemutar; pemutarnya sendiri digambar di lapisan atas.
                            Spacer(
                                Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f),
                            )
                        }
                    }

                    Box(
                        Modifier
                            .weight(1f)
                            .navigationBarsPadding()
                            .graphicsLayer { translationY = (1f - progress.value) * 40.dp.toPx() },
                    ) {
                        when (panel) {
                            1 -> CommentsPanel(video = video, onClose = { panel = 0 })
                            2 -> DescriptionPanel(track = t, d = d, onClose = { panel = 0 })
                            else -> WatchContent(
                                vm = vm,
                                video = video,
                                listState = listState,
                                onOpenChannel = onOpenChannel,
                                onOpenComments = {
                                    video.loadComments()
                                    panel = 1
                                },
                                onOpenDescription = { panel = 2 },
                                onPlayAudio = onPlayAudio,
                                onQueueAudio = onQueueAudio,
                            )
                        }
                    }
                }
            }
        }

        // ---- Pemutar: satu saja, ukuran/posisinya mengikuti progress ----
        if (!embedActive) {
            val dragMod = Modifier.pointerInput(miniMode, fullW, fullH, barPx, statusTop) {
                if (miniMode) {
                    detectDragGestures(
                        onDrag = { change, drag ->
                            change.consume()
                            offX = (offX + drag.x).coerceIn(minX, 0f)
                            offY = (offY + drag.y).coerceIn(minY, 0f)
                        },
                        onDragEnd = {
                            // Menempel ke sisi kiri atau kanan yang terdekat.
                            val toX = if (defX + offX + miniW / 2f < fullW / 2f) minX else 0f
                            val fromX = offX
                            scope.launch {
                                animate(0f, 1f, animationSpec = tween(250, easing = FastOutSlowInEasing)) { f, _ ->
                                    offX = lerp(fromX, toX, f)
                                }
                            }
                        },
                    )
                }
            }

            Layout(
                content = {
                    PlayerArea(
                        video = video,
                        modifier = dragMod.graphicsLayer {
                            val p = progress.value
                            shadowElevation = (1f - p) * 10.dp.toPx()
                            shape = RoundedCornerShape((1f - p) * 14.dp.toPx())
                            clip = true
                        },
                        fullscreen = fullscreen,
                        onFullscreen = { fullscreen = !fullscreen },
                        onMinimize = if (fullscreen) ({ fullscreen = false }) else minimize,
                        onQuality = { showQuality = true },
                        onLanguage = { showLang = true },
                        onNext = onNext,
                        liked = vm.isFavorite(t.url),
                        related = d?.related?.filter { !it.live } ?: emptyList(),
                        onLike = { vm.toggleFavorite(t) },
                        onDislike = {
                            Toast.makeText(context, I18n.tr("Tidak ada akun masuk, jadi tidak dikirim"), Toast.LENGTH_SHORT).show()
                        },
                        onPickRelated = { video.open(it) },
                        mini = miniMode,
                        onExpand = onExpand,
                        onClose = { video.stop() },
                        onPip = { (context.findActivity() as? MainActivity)?.enterPip() },
                    )
                },
                modifier = Modifier.fillMaxSize(),
            ) { measurables, c ->
                val p = progress.value
                val mg = 12.dp.toPx()
                val bar = barPad.toPx()
                val mW = minOf(c.maxWidth * 0.5f, 260.dp.toPx())
                val mH = mW * 9f / 16f
                val dX = c.maxWidth - mW - mg
                val dY = c.maxHeight - bar - mH - mg
                val top = statusTop + mg
                val mx = (dX + offX).coerceIn(minOf(mg, dX), maxOf(mg, dX))
                val my = (dY + offY).coerceIn(minOf(top, dY), maxOf(top, dY))

                val bigW = c.maxWidth.toFloat()
                val bigH = if (fullscreen) c.maxHeight.toFloat() else bigW * 9f / 16f
                val bigY = if (fullscreen) 0f else statusTop

                val w = lerp(mW, bigW, p).toInt()
                val h = lerp(mH, bigH, p).toInt()
                val x = lerp(mx, 0f, p).toInt()
                val y = lerp(my, bigY, p).toInt()

                val placeable = measurables[0].measure(Constraints.fixed(w, h))
                layout(c.maxWidth, c.maxHeight) { placeable.place(x, y) }
            }
        }
    }

    if (showQuality) {
        QualityDialog(video = video, onDismiss = { showQuality = false })
    }
    if (showLang) {
        LanguageDialog(video = video, onDismiss = { showLang = false })
    }
}

// =====================================================================
// Isi di bawah pemutar
// =====================================================================

@Composable
private fun WatchContent(
    vm: AppViewModel,
    video: VideoPlayer,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onOpenChannel: (String, String) -> Unit,
    onOpenComments: () -> Unit,
    onOpenDescription: () -> Unit,
    onPlayAudio: (List<Track>, Long) -> Unit,
    onQueueAudio: (Track) -> Unit,
) {
    val t = video.track ?: return
    val d = video.details
    val context = LocalContext.current

    val chUrl: String? = d?.uploaderUrl ?: t.uploaderUrl
    val chName: String = d?.uploader ?: t.artist
    val avatar: String? = d?.avatar ?: t.avatar
    val subscribed = chUrl != null && vm.isSubscribed(chUrl)
    val liked = vm.isFavorite(t.url)

    val likes = d?.likes ?: -1L
    val views = if (d != null && d.views >= 0L) d.views else t.views

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
    ) {
        // Judul (panah = buka deskripsi) + ringkasan
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onOpenDescription),
                    verticalAlignment = Alignment.Top,
                ) {
                    Text(
                        text = videoTitle(d?.title ?: t.title),
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        imageVector = Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Deskripsi",
                        modifier = Modifier
                            .padding(start = 8.dp, top = 2.dp)
                            .size(28.dp),
                    )
                }
                val upText = d?.uploaded?.takeIf { it.isNotBlank() } ?: t.uploaded
                val meta = buildString {
                    if (views >= 0L) append("${compactCount(views)} x ditonton")
                    if (!upText.isNullOrBlank()) {
                        if (isNotEmpty()) append(" • ")
                        append(upText)
                    }
                }
                if (meta.isNotEmpty()) {
                    Text(
                        text = meta,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }
        }

        // Tombol aksi (geser samping)
        item {
            var showDownload by remember { mutableStateOf(false) }
            if (showDownload) {
                DownloadChoiceDialog(
                    track = t,
                    onDismiss = { showDownload = false },
                    onPick = { asVideo ->
                        showDownload = false
                        val msg = Downloads.start(t, asVideo)
                        Toast.makeText(context, I18n.tr(msg), Toast.LENGTH_SHORT).show()
                    },
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ActionPill(
                    icon = R.drawable.ic_thumb_up,
                    label = if (likes >= 0L) compactCount(likes) else "Suka",
                    active = liked,
                    onClick = { vm.toggleFavorite(t) },
                )
                ActionPill(
                    icon = R.drawable.ic_thumb_down,
                    label = null,
                    active = false,
                    onClick = {
                        Toast.makeText(context, I18n.tr("Tidak ada akun masuk, jadi tidak dikirim"), Toast.LENGTH_SHORT).show()
                    },
                )
                ActionPill(
                    icon = R.drawable.ic_share,
                    label = "Bagikan",
                    active = false,
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, t.url)
                        }
                        context.startActivity(Intent.createChooser(send, "Bagikan video"))
                    },
                )
                ActionPill(
                    icon = R.drawable.ic_headphones,
                    label = "Audio",
                    active = false,
                    onClick = {
                        val queue = ArrayList<Track>()
                        queue.add(t)
                        if (d != null) queue.addAll(d.related.filter { !it.live }.take(15))
                        onPlayAudio(queue, video.positionMs)
                    },
                )
                ActionPill(
                    icon = R.drawable.ic_download,
                    label = "Unduh",
                    active = false,
                    onClick = { showDownload = true },
                )
            }
        }

        // Kanal + tombol langganan
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .then(
                            if (chUrl != null) {
                                Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onOpenChannel(chUrl, chName) }
                            } else {
                                Modifier
                            },
                        ),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(url = avatar, name = chName, size = 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = chName,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        val subs = d?.subscribers ?: -1L
                        if (subs >= 0L) {
                            Text(
                                text = compactCount(subs) + " pelanggan",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                if (chUrl != null) {
                    Spacer(Modifier.width(8.dp))
                    PillButton(
                        text = if (subscribed) "Berlangganan" else "Langganan\u200B",
                        style = if (subscribed) PillStyle.TONAL else PillStyle.FILLED,
                        onClick = { vm.toggleSubscribe(Channel(chUrl, chName, avatar)) },
                    )
                }
            }
        }

        // Kartu komentar
        item {
            CommentCard(video = video, onClick = onOpenComments)
        }

        // Video terkait
        if (d == null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (video.error == null && !video.useEmbed) PlayLoader()
                }
            }
        } else {
            itemsIndexed(d.related, key = { i, r -> "${r.url}#$i" }) { _, r ->
                val ch = r.uploaderUrl
                val chClick: (() -> Unit)? = if (ch != null) ({ onOpenChannel(ch, r.artist) }) else null
                VideoCard(
                    track = r,
                    onOpen = { video.open(r) },
                    onOpenChannel = chClick,
                    onPlayAudio = { onPlayAudio(listOf(r), 0L) },
                    onQueueAudio = { onQueueAudio(r) },
                )
            }
        }
    }
}

@Composable
private fun CommentCard(video: VideoPlayer, onClick: () -> Unit) {
    val first = video.comments.firstOrNull()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(softSurface())
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Komentar",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
            )
            if (video.commentsTotal >= 0) {
                Text(
                    text = "  " + compactCount(video.commentsTotal.toLong()),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.weight(1f))
            Icon(
                painter = painterResource(R.drawable.ic_expand),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp),
            )
        }
        when {
            video.commentsDisabled -> {
                Text(
                    text = "Komentar dinonaktifkan",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            first != null -> {
                Row(
                    modifier = Modifier.padding(top = 10.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    Avatar(url = first.avatar, name = first.author, size = 26.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = first.text,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            video.commentsLoading || !video.commentsLoaded -> {
                Text(
                    text = "Memuat komentar…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            else -> {
                Text(
                    text = "Belum ada komentar",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun Pill(
    onClick: () -> Unit,
    background: Color,
    content: @Composable RowScope.() -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

@Composable
private fun ActionPill(icon: Int, label: String?, active: Boolean, onClick: () -> Unit) {
    Pill(onClick = onClick, background = softSurface()) {
        Icon(
            painter = painterResource(icon),
            contentDescription = label,
            modifier = Modifier.size(20.dp),
            tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        )
        if (label != null) {
            Spacer(Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
            )
        }
    }
}

// =====================================================================
// Panel komentar & deskripsi
// =====================================================================

@Composable
private fun CommentsPanel(video: VideoPlayer, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = if (video.commentsTotal >= 0) {
                    "Komentar  " + compactCount(video.commentsTotal.toLong())
                } else {
                    "Komentar"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Tutup")
            }
        }
        HorizontalDivider()
        when {
            video.commentsDisabled -> {
                Text(
                    text = "Komentar dinonaktifkan untuk video ini.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            video.comments.isEmpty() && (video.commentsLoading || !video.commentsLoaded) -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    PlayLoader()
                }
            }

            video.comments.isEmpty() -> {
                Text(
                    text = "Belum ada komentar.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            else -> {
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(video.comments) { _, c ->
                        CommentRow(c)
                    }
                    if (video.commentsMore) {
                        item {
                            LaunchedEffect(video.comments.size) { video.loadMoreComments() }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                PlayLoader()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CommentRow(c: Engine.CommentItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Avatar(url = c.avatar, name = c.author, size = 36.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            val head = buildString {
                if (c.pinned) append("📌 ")
                append("@").append(c.author)
                if (c.date.isNotBlank()) append("  ").append(c.date)
            }
            Text(
                text = head,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            LinkText(
                text = c.text,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 2.dp),
            )
            if (c.likes > 0L) {
                Text(
                    text = "👍 " + compactCount(c.likes),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun DescriptionPanel(track: Track, d: Engine.VideoDetails?, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Deskripsi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Tutup")
            }
        }
        HorizontalDivider()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            Text(
                text = videoTitle(d?.title ?: track.title),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            val likes = d?.likes ?: -1L
            val views = if (d != null && d.views >= 0L) d.views else track.views
            Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                if (likes >= 0L) Stat(compactCount(likes), "Suka")
                if (views >= 0L) Stat(compactCount(views), "Ditonton")
                val up = d?.uploaded ?: track.uploaded ?: ""
                if (up.isNotBlank()) Stat(up, "Diunggah")
            }
            HorizontalDivider()
            val desc = d?.description ?: ""
            LinkText(
                text = if (desc.isBlank()) "Tidak ada deskripsi." else desc,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 14.dp),
            )
        }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column {
        Text(text = value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// =====================================================================
// Pemutar (permukaan video + kontrol overlay)
// =====================================================================

/** Pemutar cadangan: bilah kecil di atas + pemutar tersemat YouTube 16:9. */
@Composable
private fun EmbedArea(video: VideoPlayer, onMinimize: () -> Unit) {
    val id = video.embedVideoId() ?: return
    val context = LocalContext.current
    var mode by remember(id) { mutableIntStateOf(0) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onMinimize) {
                Icon(
                    Icons.Filled.KeyboardArrowDown,
                    contentDescription = "Perkecil",
                    tint = Color.White,
                )
            }
            Spacer(Modifier.weight(1f))
            TextButton(
                onClick = {
                    // Jalan keluar bila pemutar tersemat tampil hitam: buka di aplikasi YouTube/peramban.
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$id"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    } catch (e: Exception) {
                        // tidak ada aplikasi yang bisa membuka
                    }
                },
            ) {
                Text("Buka di YouTube", color = Color.White)
            }
            TextButton(onClick = { mode = (mode + 1) % 2 }) {
                Text("Mode ${(mode + 1) % 2 + 1}", color = Color.White)
            }
            TextButton(onClick = { video.retry() }) {
                Text("PlayTube", color = Color.White)
            }
        }
        key(id, mode) {
            EmbedPlayer(
                videoId = id,
                mode = mode,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f),
            )
        }
    }
}

@Composable
private fun PlayerArea(
    video: VideoPlayer,
    modifier: Modifier,
    fullscreen: Boolean,
    onFullscreen: () -> Unit,
    onMinimize: () -> Unit,
    onQuality: () -> Unit,
    onLanguage: () -> Unit,
    onNext: (() -> Unit)?,
    liked: Boolean = false,
    related: List<Track> = emptyList(),
    onLike: () -> Unit = {},
    onDislike: () -> Unit = {},
    onPickRelated: (Track) -> Unit = {},
    mini: Boolean = false,
    onExpand: () -> Unit = {},
    onClose: () -> Unit = {},
    onPip: (() -> Unit)? = null,
) {
    var controls by remember { mutableStateOf(true) }
    // Panel di layar penuh: 0 = tidak ada, 1 = komentar, 2 = video lainnya.
    var sidePanel by remember { mutableIntStateOf(0) }
    // Tahan sisi kiri/kanan layar = putar 2x selama ditahan.
    var boost by remember { mutableStateOf(false) }
    var speedBefore by remember { mutableFloatStateOf(1f) }
    var touch by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf<String?>(null) }
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    // Sembunyikan kontrol otomatis setelah 3 detik saat memutar.
    LaunchedEffect(controls, touch, video.isPlaying, dragging) {
        if (controls && video.isPlaying && !dragging) {
            delay(3000)
            controls = false
        }
    }
    LaunchedEffect(hint) {
        if (hint != null) {
            delay(700)
            hint = null
        }
    }
    LaunchedEffect(fullscreen) {
        if (!fullscreen) sidePanel = 0
    }
    BackHandler(enabled = sidePanel != 0) { sidePanel = 0 }

    BoxWithConstraints(
        modifier = modifier
            .background(Color.Black)
            .pointerInput(mini) {
                detectTapGestures(
                    onPress = {
                        tryAwaitRelease()
                        // Dilepas: kembalikan kecepatan semula.
                        if (boost) {
                            boost = false
                            video.changeSpeed(speedBefore)
                        }
                    },
                    onLongPress = { offset ->
                        // Ditahan di sisi kiri atau kanan: percepat 2x selama ditahan.
                        val w = size.width.toFloat()
                        if (!mini && (offset.x < w * 0.35f || offset.x > w * 0.65f)) {
                            speedBefore = video.speed
                            boost = true
                            controls = false
                            video.changeSpeed(2f)
                        }
                    },
                    onTap = {
                        // Di jendela kecil, ketuk = buka halaman tonton.
                        if (mini) {
                            onExpand()
                        } else {
                            controls = !controls
                            touch += 1
                        }
                    },
                    onDoubleTap = { offset ->
                        if (!mini) {
                            if (offset.x < size.width / 2f) {
                                video.seekBy(-10_000L)
                                hint = "−10 detik"
                            } else {
                                video.seekBy(10_000L)
                                hint = "+10 detik"
                            }
                            controls = true
                            touch += 1
                        }
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        val boxAspect = maxWidth / maxHeight
        VideoSurface(video = video, boxAspect = boxAspect)

        val subtitle = video.subtitleText
        if (subtitle.isNotEmpty() && !mini) {
            Text(
                text = subtitle,
                color = Color.White,
                textAlign = TextAlign.Center,
                style = if (fullscreen) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(start = 24.dp, end = 24.dp, bottom = if (controls) (if (fullscreen) 132.dp else 84.dp) else 12.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color.Black.copy(alpha = 0.7f))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }

        val err = video.error
        val busy = video.loading || video.buffering

        if (busy && err == null) {
            PlayLoader(
                modifier = Modifier.align(Alignment.Center),
                diameter = if (mini) 30.dp else 52.dp,
                containerColor = Color.Black.copy(alpha = 0.55f),
                color = Color.White,
            )
        }

        if (err != null && !mini) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = err,
                    color = Color.White,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(onClick = { video.retry() }) {
                        Text("Coba lagi")
                    }
                    if (video.embedVideoId() != null) {
                        Button(onClick = { video.startEmbed() }) {
                            Text("Putar lewat YouTube")
                        }
                    }
                }
            }
        }

        val liveNow = video.details?.live == true

        if (controls && !mini) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.38f)),
            ) {
                IconButton(
                    onClick = onMinimize,
                    modifier = Modifier.align(Alignment.TopStart),
                ) {
                    Icon(
                        Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Perkecil",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp),
                    )
                }
                Row(
                    modifier = Modifier.align(Alignment.TopEnd),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val det = video.details
                    if (det != null && (det.subtitles.isNotEmpty() || det.audioTracks.size >= 2)) {
                        IconButton(onClick = onLanguage) {
                            Icon(
                                painter = painterResource(R.drawable.ic_subtitles),
                                contentDescription = "Subtitle dan bahasa suara",
                                tint = if (video.subtitleKey.isNotEmpty() || video.audioId != null) PlayerAccent else Color.White,
                            )
                        }
                    }
                    IconButton(onClick = onQuality) {
                        Icon(
                            painter = painterResource(R.drawable.ic_settings_gear),
                            contentDescription = "Kualitas dan kecepatan",
                            tint = Color.White,
                        )
                    }
                }

                if (!busy && err == null) {
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(28.dp),
                    ) {
                        IconButton(onClick = { video.seekTo(0L) }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_skip_previous),
                                contentDescription = "Dari awal",
                                tint = Color.White,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                        IconButton(
                            onClick = {
                                video.togglePlay()
                                touch += 1
                            },
                            modifier = Modifier.size(64.dp),
                        ) {
                            Icon(
                                painter = painterResource(
                                    if (video.isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                                ),
                                contentDescription = "Putar atau jeda",
                                tint = Color.White,
                                modifier = Modifier.size(52.dp),
                            )
                        }
                        if (onNext != null) {
                            IconButton(onClick = onNext) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_skip_next),
                                    contentDescription = "Berikutnya",
                                    tint = Color.White,
                                    modifier = Modifier.size(30.dp),
                                )
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 14.dp, end = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (liveNow) {
                            Text(
                                text = "LIVE",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(LiveRed)
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        } else {
                            Text(
                                text = clock(video.positionMs / 1000L) + " / " + clock(video.durationMs / 1000L),
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        if (video.activeLabel.isNotBlank()) {
                            Text(
                                text = video.activeLabel,
                                color = Color.White.copy(alpha = 0.75f),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        if (onPip != null) {
                            IconButton(onClick = onPip) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_pip_enter),
                                    contentDescription = "Jendela mengambang (PiP)",
                                    tint = Color.White,
                                )
                            }
                        }
                        IconButton(onClick = onFullscreen) {
                            Icon(
                                painter = painterResource(
                                    if (fullscreen) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen,
                                ),
                                contentDescription = "Layar penuh",
                                tint = Color.White,
                            )
                        }
                    }
                    if (!liveNow && video.durationMs > 0L) {
                        val fraction = (video.positionMs.toFloat() / video.durationMs.toFloat()).coerceIn(0f, 1f)
                        Slider(
                            value = if (dragging) dragValue else fraction,
                            onValueChange = {
                                dragging = true
                                dragValue = it
                            },
                            onValueChangeFinished = {
                                video.seekTo((dragValue * video.durationMs.toFloat()).toLong())
                                dragging = false
                                touch += 1
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = PlayerAccent,
                                activeTrackColor = PlayerAccent,
                                inactiveTrackColor = Color.White.copy(alpha = 0.35f),
                            ),
                        )
                    }
                    if (fullscreen) {
                        FullscreenActions(
                            liked = liked,
                            related = related,
                            onComments = {
                                video.loadComments()
                                controls = false
                                sidePanel = 1
                            },
                            onLike = {
                                onLike()
                                touch += 1
                            },
                            onDislike = {
                                onDislike()
                                touch += 1
                            },
                            onRelated = {
                                controls = false
                                sidePanel = 2
                            },
                        )
                    }
                }
            }
        }

        val h = hint
        if (h != null) {
            Text(
                text = h,
                color = Color.White,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }

        if (boost && !mini) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 24.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(text = "2x", color = Color.White, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.width(6.dp))
                Icon(
                    painter = painterResource(R.drawable.ic_fast_forward),
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(22.dp),
                )
            }
        }

        if (fullscreen && !mini) {
            if (sidePanel == 1) {
                FullscreenCommentsPanel(
                    video = video,
                    onClose = { sidePanel = 0 },
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .fillMaxHeight()
                        .width(maxWidth * 0.45f),
                )
            }
            if (sidePanel == 2) {
                RelatedPanel(
                    related = related,
                    onClose = { sidePanel = 0 },
                    onPick = {
                        sidePanel = 0
                        onPickRelated(it)
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }

        if (mini) {
            MiniOverlay(video = video, onClose = onClose)
        }
    }
}

// =====================================================================
// Layar penuh: baris tombol di bawah durasi + panelnya
// =====================================================================

/** Baris tombol di bawah seek bar: komentar, suka, tidak suka (kiri) dan Video lainnya (kanan). */
@Composable
private fun FullscreenActions(
    liked: Boolean,
    related: List<Track>,
    onComments: () -> Unit,
    onLike: () -> Unit,
    onDislike: () -> Unit,
    onRelated: () -> Unit,
) {
    val bg = Color.Black.copy(alpha = 0.45f)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(bg)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onComments) {
                Icon(painterResource(R.drawable.ic_comment), contentDescription = "Komentar", tint = Color.White)
            }
            IconButton(onClick = onLike) {
                Icon(
                    painter = painterResource(R.drawable.ic_thumb_up),
                    contentDescription = "Suka",
                    tint = if (liked) PlayerAccent else Color.White,
                )
            }
            IconButton(onClick = onDislike) {
                Icon(painterResource(R.drawable.ic_thumb_down), contentDescription = "Tidak suka", tint = Color.White)
            }
        }
        Spacer(Modifier.weight(1f))
        val first = related.firstOrNull()
        if (first != null) {
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(bg)
                    .clickable(onClick = onRelated)
                    .padding(start = 18.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Video lainnya",
                    color = Color.White,
                    style = MaterialTheme.typography.titleSmall,
                )
                Spacer(Modifier.width(12.dp))
                Box(
                    modifier = Modifier
                        .size(width = 64.dp, height = 36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.DarkGray),
                ) {
                    ThumbImage(first.thumb, first.url, Modifier.fillMaxSize())
                }
            }
        }
    }
}

/** Panel komentar di sisi kanan layar penuh (tema gelap, bisa digulir ke bawah). */
@Composable
private fun FullscreenCommentsPanel(video: VideoPlayer, onClose: () -> Unit, modifier: Modifier = Modifier) {
    MaterialTheme(
        colorScheme = darkColorScheme(),
        typography = MaterialTheme.typography,
        shapes = MaterialTheme.shapes,
    ) {
        Surface(
            modifier = modifier.pointerInput(Unit) { detectTapGestures { } },
            color = Color(0xFF1B1B1B),
            contentColor = Color.White,
        ) {
            CommentsPanel(video = video, onClose = onClose)
        }
    }
}

/**
 * Panel "Video lainnya" di layar penuh: kartu video dalam kisi yang bisa digulir ke bawah
 * (bukan hanya ke kiri/kanan). Ketuk kartu untuk memutar videonya.
 */
@Composable
private fun RelatedPanel(
    related: List<Track>,
    onClose: () -> Unit,
    onPick: (Track) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .background(Color.Black.copy(alpha = 0.82f))
            .pointerInput(Unit) { detectTapGestures { } },
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 24.dp, end = 12.dp, top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Video lainnya",
                color = Color.White,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Tutup", tint = Color.White)
            }
        }
        Row(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text(
                text = "Semua",
                color = Color.Black,
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White)
                    .padding(horizontal = 18.dp, vertical = 8.dp),
            )
        }
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 240.dp),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 24.dp, end = 24.dp, top = 8.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            items(related.size, key = { "${related[it].url}#$it" }) { i ->
                RelatedCard(t = related[i], onClick = { onPick(related[i]) })
            }
        }
    }
}

@Composable
private fun RelatedCard(t: Track, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(14.dp))
                .background(Color.DarkGray),
        ) {
            ThumbImage(t.thumb, t.url, Modifier.fillMaxSize())
            if (t.live) {
                Text(
                    text = "LIVE",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(LiveRed)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            } else if (t.durationSec > 0L) {
                Text(
                    text = clock(t.durationSec),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.8f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }
        Row(
            modifier = Modifier.padding(top = 8.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Avatar(url = t.avatar, name = t.artist, size = 32.dp)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = videoTitle(t.title),
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = videoMeta(t),
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
        }
    }
}

/** Kontrol jendela video kecil: putar/jeda (kiri atas), tutup (kanan atas), mundur/maju 10 detik. */
@Composable
private fun MiniOverlay(video: VideoPlayer, onClose: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        MiniButton(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(6.dp),
            onClick = { video.togglePlay() },
        ) {
            Icon(
                painter = painterResource(if (video.isPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                contentDescription = "Putar atau jeda",
                tint = Color.White,
                modifier = Modifier.size(18.dp),
            )
        }
        MiniButton(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp),
            onClick = onClose,
        ) {
            Icon(
                Icons.Filled.Close,
                contentDescription = "Tutup",
                tint = Color.White,
                modifier = Modifier.size(18.dp),
            )
        }
        if (video.details?.live != true) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                MiniButton(modifier = Modifier, onClick = { video.seekBy(-10_000L) }) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            painter = painterResource(R.drawable.ic_replay_arc),
                            contentDescription = "Mundur 10 detik",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp),
                        )
                        Text("10", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                    }
                }
                MiniButton(modifier = Modifier, onClick = { video.seekBy(10_000L) }) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            painter = painterResource(R.drawable.ic_forward_arc),
                            contentDescription = "Maju 10 detik",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp),
                        )
                        Text("10", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (video.durationMs > 0L && video.details?.live != true) {
            LinearProgressIndicator(
                progress = { (video.positionMs.toFloat() / video.durationMs.toFloat()).coerceIn(0f, 1f) },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(2.dp),
                color = PlayerAccent,
                trackColor = Color.White.copy(alpha = 0.3f),
            )
        }
    }
}

@Composable
private fun MiniButton(modifier: Modifier, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** TextureView yang ukurannya mengikuti rasio video (tidak melar), dipusatkan dalam area hitam. */
@Composable
internal fun VideoSurface(video: VideoPlayer, boxAspect: Float) {
    val a = video.aspect
    val m = if (a >= boxAspect) {
        Modifier
            .fillMaxWidth()
            .aspectRatio(a)
    } else {
        Modifier
            .fillMaxHeight()
            .aspectRatio(a)
    }
    AndroidView(
        factory = { ctx ->
            val v = TextureView(ctx)
            video.attach(v)
            v
        },
        modifier = m,
        onRelease = { v -> video.detach(v) },
    )
}

// =====================================================================
// Dialog kualitas & kecepatan
// =====================================================================

@Composable
private fun QualityDialog(video: VideoPlayer, onDismiss: () -> Unit) {
    val d = video.details
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Selesai") }
        },
        title = { Text("Pengaturan video") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Kualitas",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                QualityRow(
                    label = "Otomatis (ikut internet)",
                    selected = video.chosen == null,
                    onClick = { video.chooseQuality(null) },
                )
                Text(
                    text = "Turun ke resolusi lebih rendah saat internet lambat, naik lagi (sampai 1080p) saat lancar.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 36.dp, bottom = 6.dp),
                )
                for (q in d?.qualities.orEmpty()) {
                    QualityRow(
                        label = if (q.hd) q.label + "   HD" else q.label,
                        selected = video.chosen === q,
                        onClick = { video.chooseQuality(q) },
                    )
                }
                if (video.activeLabel.isNotBlank()) {
                    Text(
                        text = "Sedang diputar: ${video.activeLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
                Text(
                    text = "Kecepatan",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for (s in listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)) {
                        FilterChip(
                            selected = video.speed == s,
                            onClick = { video.changeSpeed(s) },
                            label = { Text(if (s == 1f) "Normal" else "${s}x") },
                        )
                    }
                }
            }
        },
    )
}

// =====================================================================
// Dialog subtitle & bahasa suara
// =====================================================================

@Composable
private fun LanguageDialog(video: VideoPlayer, onDismiss: () -> Unit) {
    val d = video.details
    val subs = d?.subtitles.orEmpty()
    val tracks = d?.audioTracks.orEmpty()
    val key = video.subtitleKey
    val currentCode = key.substringBefore('>')
    val translated = key.substringAfter('>', "")
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Selesai") }
        },
        title = { Text("Subtitle dan suara") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Subtitle",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                if (subs.isEmpty()) {
                    Text(
                        text = "Video ini tidak punya subtitle.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 6.dp),
                    )
                } else {
                    QualityRow(
                        label = "Mati",
                        selected = key.isEmpty(),
                        onClick = { video.chooseSubtitle(null) },
                    )
                    for (o in subs) {
                        QualityRow(
                            label = o.label,
                            selected = currentCode == o.code && translated.isEmpty() && key.isNotEmpty(),
                            onClick = { video.chooseSubtitle(o, null) },
                        )
                    }
                    Text(
                        text = "Terjemahkan otomatis ke",
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp),
                    )
                    val source = subs.firstOrNull { it.code == currentCode && key.isNotEmpty() }
                        ?: subs.firstOrNull { !it.auto }
                        ?: subs.first()
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        for (l in Languages.ALL) {
                            FilterChip(
                                selected = translated == l.code,
                                onClick = { video.chooseSubtitle(source, l.code) },
                                label = { Text(l.name) },
                            )
                        }
                    }
                    if (video.subtitleLoading) {
                        Text(
                            text = "Memuat subtitle…",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                    val subErr = video.subtitleError
                    if (subErr != null) {
                        Text(
                            text = subErr,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }

                Text(
                    text = "Suara",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 16.dp),
                )
                if (tracks.size < 2) {
                    Text(
                        text = "Video ini hanya punya satu suara. Pilihan suara muncul bila pembuat video " +
                            "menambahkan dubbing atau suara multi-bahasa (mis. dubbing AI).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 6.dp),
                    )
                } else {
                    val defaultId = (tracks.firstOrNull { it.original } ?: tracks.first()).id
                    for (t in tracks) {
                        QualityRow(
                            label = t.label,
                            selected = (video.audioId ?: defaultId) == t.id,
                            onClick = { video.chooseAudio(if (t.id == defaultId) null else t) },
                        )
                    }
                }
                Text(
                    text = "Bahasa judul dan deskripsi diatur di Setelan → Bahasa.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 14.dp),
                )
            }
        },
    )
}

@Composable
private fun QualityRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(text = label, style = MaterialTheme.typography.bodyLarge)
    }
}
