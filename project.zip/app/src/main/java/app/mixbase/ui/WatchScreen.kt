package app.mixbase.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.view.TextureView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import app.mixbase.R
import app.mixbase.data.Channel
import app.mixbase.data.Engine
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.data.compactCount
import app.mixbase.player.VideoPlayer
import kotlinx.coroutines.delay

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/**
 * Halaman tonton ala YouTube: pemutar di atas (kontrol overlay, layar penuh), lalu judul,
 * info channel, aksi, kartu komentar, dan video terkait.
 */
@Composable
fun WatchScreen(
    vm: AppViewModel,
    video: VideoPlayer,
    onMinimize: () -> Unit,
    onOpenChannel: (url: String, name: String) -> Unit,
    onPlayAudio: (queue: List<Track>, startMs: Long) -> Unit,
    onQueueAudio: (Track) -> Unit,
) {
    val t = video.track ?: return
    val d = video.details
    val context = LocalContext.current
    val view = LocalView.current

    var fullscreen by remember { mutableStateOf(false) }
    var panel by remember { mutableIntStateOf(0) } // 0 = tidak ada, 1 = komentar, 2 = deskripsi
    var showQuality by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val embedActive = video.useEmbed && video.embedVideoId() != null

    // Pemutar tersemat tidak bisa lanjut di mini bar: menutupnya menghentikan video.
    val minimize: () -> Unit = {
        if (video.useEmbed) video.stop()
        onMinimize()
    }

    BackHandler {
        when {
            fullscreen -> fullscreen = false
            panel != 0 -> panel = 0
            else -> minimize()
        }
    }

    LaunchedEffect(embedActive) {
        if (embedActive) fullscreen = false
    }

    // Ikon status bar terang saat pemutar hitam berada di bawah status bar.
    DisposableEffect(Unit) {
        val window = context.findActivity()?.window
        if (window != null) {
            val c = WindowCompat.getInsetsController(window, view)
            val old = c.isAppearanceLightStatusBars
            c.isAppearanceLightStatusBars = false
            onDispose { c.isAppearanceLightStatusBars = old }
        } else {
            onDispose { }
        }
    }

    // Layar penuh: landscape + sembunyikan bilah sistem.
    DisposableEffect(fullscreen) {
        val act = context.findActivity()
        if (act != null) {
            val c = WindowCompat.getInsetsController(act.window, act.window.decorView)
            if (fullscreen) {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                c.show(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose { }
    }
    DisposableEffect(Unit) {
        onDispose {
            val act = context.findActivity()
            if (act != null) {
                act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(act.window, act.window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    // Komentar dimuat segera setelah detail video siap.
    LaunchedEffect(d?.url, embedActive) {
        if (d != null || embedActive) video.loadComments()
    }

    // Putar otomatis video berikutnya saat selesai.
    LaunchedEffect(video.ended) {
        if (video.ended) {
            val next = d?.related?.firstOrNull { !it.live }
            if (next != null) video.open(next)
        }
    }

    // Video baru → kembali ke atas dan tutup panel.
    LaunchedEffect(t.url) {
        panel = 0
        listState.scrollToItem(0)
    }

    val nextTrack: Track? = d?.related?.firstOrNull { !it.live }
    val onNext: (() -> Unit)? = if (nextTrack != null) ({ video.open(nextTrack) }) else null

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        if (fullscreen && !embedActive) {
            PlayerArea(
                video = video,
                modifier = Modifier.fillMaxSize(),
                fullscreen = true,
                onFullscreen = { fullscreen = false },
                onMinimize = { fullscreen = false },
                onQuality = { showQuality = true },
                onNext = onNext,
            )
        } else {
            Column(Modifier.fillMaxSize()) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .background(Color.Black)
                        .statusBarsPadding(),
                ) {
                    if (embedActive) {
                        EmbedArea(video = video, onMinimize = minimize)
                    } else {
                        PlayerArea(
                            video = video,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 9f),
                            fullscreen = false,
                            onFullscreen = { fullscreen = true },
                            onMinimize = minimize,
                            onQuality = { showQuality = true },
                            onNext = onNext,
                        )
                    }
                }

                Box(
                    Modifier
                        .weight(1f)
                        .navigationBarsPadding(),
                ) {
                    when (panel) {
                        1 -> CommentsPanel(video = video, onClose = { panel = 0 })
                        2 -> DescriptionPanel(track = t, d = d, onClose = { panel = 0 })
                        else -> WatchContent(
                            vm = vm,
                            video = video,
                            listState = listState,
                            onOpenChannel = onOpenChannel,
                            onOpenComments = {
                                video.loadComments()
                                panel = 1
                            },
                            onOpenDescription = { panel = 2 },
                            onPlayAudio = onPlayAudio,
                            onQueueAudio = onQueueAudio,
                        )
                    }
                }
            }
        }
    }

    if (showQuality) {
        QualityDialog(video = video, onDismiss = { showQuality = false })
    }
}

// =====================================================================
// Isi di bawah pemutar
// =====================================================================

@Composable
private fun WatchContent(
    vm: AppViewModel,
    video: VideoPlayer,
    listState: androidx.compose.foundation.lazy.LazyListState,
    onOpenChannel: (String, String) -> Unit,
    onOpenComments: () -> Unit,
    onOpenDescription: () -> Unit,
    onPlayAudio: (List<Track>, Long) -> Unit,
    onQueueAudio: (Track) -> Unit,
) {
    val t = video.track ?: return
    val d = video.details
    val context = LocalContext.current

    val chUrl: String? = d?.uploaderUrl ?: t.uploaderUrl
    val chName: String = d?.uploader ?: t.artist
    val avatar: String? = d?.avatar ?: t.avatar
    val subscribed = chUrl != null && vm.isSubscribed(chUrl)
    val liked = vm.isFavorite(t.url)

    val likes = d?.likes ?: -1L
    val views = if (d != null && d.views >= 0L) d.views else t.views

    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
    ) {
        // Judul (panah = buka deskripsi) + ringkasan
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onOpenDescription),
                    verticalAlignment = Alignment.Top,
                ) {
                    Text(
                        text = d?.title ?: t.title,
                        style = MaterialTheme.typography.titleLarge,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Icon(
                        imageVector = Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Deskripsi",
                        modifier = Modifier
                            .padding(start = 8.dp, top = 2.dp)
                            .size(28.dp),
                    )
                }
                val upText = d?.uploaded?.takeIf { it.isNotBlank() } ?: t.uploaded
                val meta = buildString {
                    if (views >= 0L) append("${compactCount(views)} x ditonton")
                    if (!upText.isNullOrBlank()) {
                        if (isNotEmpty()) append(" • ")
                        append(upText)
                    }
                }
                if (meta.isNotEmpty()) {
                    Text(
                        text = meta,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }
        }

        // Tombol aksi (geser samping)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ActionPill(
                    icon = R.drawable.ic_thumb_up,
                    label = if (likes >= 0L) compactCount(likes) else "Suka",
                    active = liked,
                    onClick = { vm.toggleFavorite(t) },
                )
                ActionPill(
                    icon = R.drawable.ic_thumb_down,
                    label = null,
                    active = false,
                    onClick = {
                        Toast.makeText(context, "Tidak ada akun masuk, jadi tidak dikirim", Toast.LENGTH_SHORT).show()
                    },
                )
                ActionPill(
                    icon = R.drawable.ic_share,
                    label = "Bagikan",
                    active = false,
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, t.url)
                        }
                        context.startActivity(Intent.createChooser(send, "Bagikan video"))
                    },
                )
                ActionPill(
                    icon = R.drawable.ic_headphones,
                    label = "Audio",
                    active = false,
                    onClick = {
                        val queue = ArrayList<Track>()
                        queue.add(t)
                        if (d != null) queue.addAll(d.related.filter { !it.live }.take(15))
                        onPlayAudio(queue, video.positionMs)
                    },
                )
            }
        }

        // Kanal + tombol langganan
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .then(
                            if (chUrl != null) {
                                Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onOpenChannel(chUrl, chName) }
                            } else {
                                Modifier
                            },
                        ),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(url = avatar, name = chName, size = 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = chName,
                            style = MaterialTheme.typography.titleMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        val subs = d?.subscribers ?: -1L
                        if (subs >= 0L) {
                            Text(
                                text = compactCount(subs) + " pelanggan",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
                if (chUrl != null) {
                    Spacer(Modifier.width(8.dp))
                    PillButton(
                        text = if (subscribed) "Berlangganan" else "Langganan",
                        style = if (subscribed) PillStyle.TONAL else PillStyle.FILLED,
                        onClick = { vm.toggleSubscribe(Channel(chUrl, chName, avatar)) },
                    )
                }
            }
        }

        // Kartu komentar
        item {
            CommentCard(video = video, onClick = onOpenComments)
        }

        // Video terkait
        if (d == null) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    if (video.error == null && !video.useEmbed) PlayLoader()
                }
            }
        } else {
            itemsIndexed(d.related, key = { i, r -> "${r.url}#$i" }) { _, r ->
                val ch = r.uploaderUrl
                val chClick: (() -> Unit)? = if (ch != null) ({ onOpenChannel(ch, r.artist) }) else null
                VideoCard(
                    track = r,
                    onOpen = { video.open(r) },
                    onOpenChannel = chClick,
                    onPlayAudio = { onPlayAudio(listOf(r), 0L) },
                    onQueueAudio = { onQueueAudio(r) },
                )
            }
        }
    }
}

@Composable
private fun CommentCard(video: VideoPlayer, onClick: () -> Unit) {
    val first = video.comments.firstOrNull()
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(softSurface())
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Komentar",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
            )
            if (video.commentsTotal >= 0) {
                Text(
                    text = "  " + compactCount(video.commentsTotal.toLong()),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.weight(1f))
            Icon(
                painter = painterResource(R.drawable.ic_expand),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp),
            )
        }
        when {
            video.commentsDisabled -> {
                Text(
                    text = "Komentar dinonaktifkan",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            first != null -> {
                Row(
                    modifier = Modifier.padding(top = 10.dp),
                    verticalAlignment = Alignment.Top,
                ) {
                    Avatar(url = first.avatar, name = first.author, size = 26.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = first.text,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            video.commentsLoading || !video.commentsLoaded -> {
                Text(
                    text = "Memuat komentar…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            else -> {
                Text(
                    text = "Belum ada komentar",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

@Composable
private fun Pill(
    onClick: () -> Unit,
    background: Color,
    content: @Composable RowScope.() -> Unit,
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content,
    )
}

@Composable
private fun ActionPill(icon: Int, label: String?, active: Boolean, onClick: () -> Unit) {
    Pill(onClick = onClick, background = softSurface()) {
        Icon(
            painter = painterResource(icon),
            contentDescription = label,
            modifier = Modifier.size(20.dp),
            tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
        )
        if (label != null) {
            Spacer(Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
            )
        }
    }
}

// =====================================================================
// Panel komentar & deskripsi
// =====================================================================

@Composable
private fun CommentsPanel(video: VideoPlayer, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = if (video.commentsTotal >= 0) {
                    "Komentar  " + compactCount(video.commentsTotal.toLong())
                } else {
                    "Komentar"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Tutup")
            }
        }
        HorizontalDivider()
        when {
            video.commentsDisabled -> {
                Text(
                    text = "Komentar dinonaktifkan untuk video ini.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            video.comments.isEmpty() && (video.commentsLoading || !video.commentsLoaded) -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    PlayLoader()
                }
            }

            video.comments.isEmpty() -> {
                Text(
                    text = "Belum ada komentar.",
                    modifier = Modifier.padding(16.dp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            else -> {
                LazyColumn(Modifier.fillMaxSize()) {
                    itemsIndexed(video.comments) { _, c ->
                        CommentRow(c)
                    }
                    if (video.commentsMore) {
                        item {
                            LaunchedEffect(video.comments.size) { video.loadMoreComments() }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                PlayLoader()
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CommentRow(c: Engine.CommentItem) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Avatar(url = c.avatar, name = c.author, size = 36.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            val head = buildString {
                if (c.pinned) append("📌 ")
                append("@").append(c.author)
                if (c.date.isNotBlank()) append("  ").append(c.date)
            }
            Text(
                text = head,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
                text = c.text,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 2.dp),
            )
            if (c.likes > 0L) {
                Text(
                    text = "👍 " + compactCount(c.likes),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun DescriptionPanel(track: Track, d: Engine.VideoDetails?, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 4.dp, top = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "Deskripsi",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f),
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Filled.Close, contentDescription = "Tutup")
            }
        }
        HorizontalDivider()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            Text(
                text = d?.title ?: track.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
            )
            val likes = d?.likes ?: -1L
            val views = if (d != null && d.views >= 0L) d.views else track.views
            Row(Modifier.padding(vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                if (likes >= 0L) Stat(compactCount(likes), "Suka")
                if (views >= 0L) Stat(compactCount(views), "Ditonton")
                val up = d?.uploaded ?: track.uploaded ?: ""
                if (up.isNotBlank()) Stat(up, "Diunggah")
            }
            HorizontalDivider()
            val desc = d?.description ?: ""
            Text(
                text = if (desc.isBlank()) "Tidak ada deskripsi." else desc,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(top = 14.dp),
            )
        }
    }
}

@Composable
private fun Stat(value: String, label: String) {
    Column {
        Text(text = value, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

// =====================================================================
// Pemutar (permukaan video + kontrol overlay)
// =====================================================================

/** Pemutar cadangan: bilah kecil di atas + pemutar tersemat YouTube 16:9. */
@Composable
private fun EmbedArea(video: VideoPlayer, onMinimize: () -> Unit) {
    val id = video.embedVideoId() ?: return
    val context = LocalContext.current
    var mode by remember(id) { mutableIntStateOf(0) }
    Column(Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onMinimize) {
                Icon(
                    Icons.Filled.KeyboardArrowDown,
                    contentDescription = "Perkecil",
                    tint = Color.White,
                )
            }
            Spacer(Modifier.weight(1f))
            TextButton(
                onClick = {
                    // Jalan keluar bila pemutar tersemat tampil hitam: buka di aplikasi YouTube/peramban.
                    try {
                        context.startActivity(
                            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$id"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    } catch (e: Exception) {
                        // tidak ada aplikasi yang bisa membuka
                    }
                },
            ) {
                Text("Buka di YouTube", color = Color.White)
            }
            TextButton(onClick = { mode = (mode + 1) % 2 }) {
                Text("Mode ${(mode + 1) % 2 + 1}", color = Color.White)
            }
            TextButton(onClick = { video.retry() }) {
                Text("PlayTube", color = Color.White)
            }
        }
        key(id, mode) {
            EmbedPlayer(
                videoId = id,
                mode = mode,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f),
            )
        }
    }
}

@Composable
private fun PlayerArea(
    video: VideoPlayer,
    modifier: Modifier,
    fullscreen: Boolean,
    onFullscreen: () -> Unit,
    onMinimize: () -> Unit,
    onQuality: () -> Unit,
    onNext: (() -> Unit)?,
) {
    var controls by remember { mutableStateOf(true) }
    var touch by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf<String?>(null) }
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    // Sembunyikan kontrol otomatis setelah 3 detik saat memutar.
    LaunchedEffect(controls, touch, video.isPlaying, dragging) {
        if (controls && video.isPlaying && !dragging) {
            delay(3000)
            controls = false
        }
    }
    LaunchedEffect(hint) {
        if (hint != null) {
            delay(700)
            hint = null
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        controls = !controls
                        touch += 1
                    },
                    onDoubleTap = { offset ->
                        if (offset.x < size.width / 2f) {
                            video.seekBy(-10_000L)
                            hint = "−10 detik"
                        } else {
                            video.seekBy(10_000L)
                            hint = "+10 detik"
                        }
                        controls = true
                        touch += 1
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        val boxAspect = maxWidth / maxHeight
        VideoSurface(video = video, boxAspect = boxAspect)

        val err = video.error
        val busy = video.loading || video.buffering

        if (busy && err == null) {
            PlayLoader(
                modifier = Modifier.align(Alignment.Center),
                diameter = 52.dp,
                containerColor = Color.Black.copy(alpha = 0.55f),
                color = Color.White,
            )
        }

        if (err != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = err,
                    color = Color.White,
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                )
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Button(onClick = { video.retry() }) {
                        Text("Coba lagi")
                    }
                    if (video.embedVideoId() != null) {
                        Button(onClick = { video.startEmbed() }) {
                            Text("Putar lewat YouTube")
                        }
                    }
                }
            }
        }

        val liveNow = video.details?.live == true

        if (controls) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.38f)),
            ) {
                IconButton(
                    onClick = onMinimize,
                    modifier = Modifier.align(Alignment.TopStart),
                ) {
                    Icon(
                        Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Perkecil",
                        tint = Color.White,
                        modifier = Modifier.size(32.dp),
                    )
                }
                IconButton(
                    onClick = onQuality,
                    modifier = Modifier.align(Alignment.TopEnd),
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_settings_gear),
                        contentDescription = "Kualitas dan kecepatan",
                        tint = Color.White,
                    )
                }

                if (!busy && err == null) {
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(28.dp),
                    ) {
                        IconButton(onClick = { video.seekTo(0L) }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_skip_previous),
                                contentDescription = "Dari awal",
                                tint = Color.White,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                        IconButton(
                            onClick = {
                                video.togglePlay()
                                touch += 1
                            },
                            modifier = Modifier.size(64.dp),
                        ) {
                            Icon(
                                painter = painterResource(
                                    if (video.isPlaying) R.drawable.ic_pause else R.drawable.ic_play,
                                ),
                                contentDescription = "Putar atau jeda",
                                tint = Color.White,
                                modifier = Modifier.size(52.dp),
                            )
                        }
                        if (onNext != null) {
                            IconButton(onClick = onNext) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_skip_next),
                                    contentDescription = "Berikutnya",
                                    tint = Color.White,
                                    modifier = Modifier.size(30.dp),
                                )
                            }
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 14.dp, end = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        if (liveNow) {
                            Text(
                                text = "LIVE",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(LiveRed)
                                    .padding(horizontal = 6.dp, vertical = 2.dp),
                            )
                        } else {
                            Text(
                                text = clock(video.positionMs / 1000L) + " / " + clock(video.durationMs / 1000L),
                                color = Color.White,
                                style = MaterialTheme.typography.labelMedium,
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        if (video.activeLabel.isNotBlank()) {
                            Text(
                                text = video.activeLabel,
                                color = Color.White.copy(alpha = 0.75f),
                                style = MaterialTheme.typography.labelSmall,
                            )
                        }
                        IconButton(onClick = onFullscreen) {
                            Icon(
                                painter = painterResource(
                                    if (fullscreen) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen,
                                ),
                                contentDescription = "Layar penuh",
                                tint = Color.White,
                            )
                        }
                    }
                    if (!liveNow && video.durationMs > 0L) {
                        val fraction = (video.positionMs.toFloat() / video.durationMs.toFloat()).coerceIn(0f, 1f)
                        Slider(
                            value = if (dragging) dragValue else fraction,
                            onValueChange = {
                                dragging = true
                                dragValue = it
                            },
                            onValueChangeFinished = {
                                video.seekTo((dragValue * video.durationMs.toFloat()).toLong())
                                dragging = false
                                touch += 1
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 6.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = PlayerAccent,
                                activeTrackColor = PlayerAccent,
                                inactiveTrackColor = Color.White.copy(alpha = 0.35f),
                            ),
                        )
                    }
                }
            }
        }

        val h = hint
        if (h != null) {
            Text(
                text = h,
                color = Color.White,
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(50))
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(horizontal = 14.dp, vertical = 8.dp),
            )
        }
    }
}

/** TextureView yang ukurannya mengikuti rasio video (tidak melar), dipusatkan dalam area hitam. */
@Composable
private fun VideoSurface(video: VideoPlayer, boxAspect: Float) {
    val a = video.aspect
    val m = if (a >= boxAspect) {
        Modifier
            .fillMaxWidth()
            .aspectRatio(a)
    } else {
        Modifier
            .fillMaxHeight()
            .aspectRatio(a)
    }
    AndroidView(
        factory = { ctx ->
            val v = TextureView(ctx)
            video.attach(v)
            v
        },
        modifier = m,
        onRelease = { v -> video.detach(v) },
    )
}

// =====================================================================
// Dialog kualitas & kecepatan
// =====================================================================

@Composable
private fun QualityDialog(video: VideoPlayer, onDismiss: () -> Unit) {
    val d = video.details
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Selesai") }
        },
        title = { Text("Pengaturan video") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Kualitas",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                )
                QualityRow(
                    label = "Otomatis (ikut internet)",
                    selected = video.chosen == null,
                    onClick = { video.chooseQuality(null) },
                )
                Text(
                    text = "Turun ke resolusi lebih rendah saat internet lambat, naik lagi (sampai 1080p) saat lancar.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 36.dp, bottom = 6.dp),
                )
                for (q in d?.qualities.orEmpty()) {
                    QualityRow(
                        label = if (q.hd) q.label + "   HD" else q.label,
                        selected = video.chosen === q,
                        onClick = { video.chooseQuality(q) },
                    )
                }
                if (video.activeLabel.isNotBlank()) {
                    Text(
                        text = "Sedang diputar: ${video.activeLabel}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
                Text(
                    text = "Kecepatan",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 16.dp, bottom = 4.dp),
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    for (s in listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)) {
                        FilterChip(
                            selected = video.speed == s,
                            onClick = { video.changeSpeed(s) },
                            label = { Text(if (s == 1f) "Normal" else "${s}x") },
                        )
                    }
                }
            }
        },
    )
}

@Composable
private fun QualityRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(text = label, style = MaterialTheme.typography.bodyLarge)
    }
}
