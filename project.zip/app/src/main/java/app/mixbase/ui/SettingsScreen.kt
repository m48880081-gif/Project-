package app.mixbase.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import app.mixbase.data.Backup
import app.mixbase.data.I18n
import app.mixbase.data.LangModels
import app.mixbase.data.Languages
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.mixbase.R

/** Halaman Setelan layar penuh (dibuka dari laci samping). */
@Composable
fun SettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        SettingsContent(vm, onBack)
    }
}

@Composable
private fun SettingsContent(vm: AppViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val version = remember(context) { appVersion(context) }
    var showLangPicker by remember { mutableStateOf(false) }
    var showLangModels by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 4.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    painter = painterResource(R.drawable.ic_arrow_back),
                    contentDescription = "Kembali",
                )
            }
            Text(
                text = "Setelan",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
            )
        }

        SettingsCard(0) { DataSection() }
        SettingsCard(1) {
        SectionTitle("Tampilan")
        RadioRow("Ikuti sistem", vm.themeMode == 0) { vm.updateThemeMode(0) }
        RadioRow("Terang", vm.themeMode == 1) { vm.updateThemeMode(1) }
        RadioRow("Gelap", vm.themeMode == 2) { vm.updateThemeMode(2) }
        SwitchRow(
            title = "Warna dinamis",
            subtitle = "Ikuti warna wallpaper (Android 12 ke atas)",
            checked = vm.dynamicColor,
            enabled = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S,
            onChange = { vm.updateDynamicColor(it) },
        )

        }

        SettingsCard(2) {
        SectionTitle("Audio")
        SwitchRow(
            title = "Kualitas audio tertinggi",
            subtitle = "Matikan untuk hemat kuota",
            checked = vm.highQuality,
            enabled = true,
            onChange = { vm.updateHighQuality(it) },
        )

        SectionTitle("Format audio unduhan")
        RadioRow("M4A (AAC) — paling kompatibel", vm.audioFormat == 0) { vm.updateAudioFormat(0) }
        RadioRow("WEBM (Opus) — lebih hemat ruang", vm.audioFormat == 1) { vm.updateAudioFormat(1) }
        Text(
            text = "Berlaku untuk unduhan berikutnya. MP3 tidak tersedia karena YouTube hanya menyediakan M4A dan WEBM.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        SectionTitle("Kualitas audio unduhan")
        SegmentedPill(
            options = listOf("Tertinggi", "Seimbang", "Hemat"),
            selected = vm.audioQuality.coerceIn(0, 2),
            onSelect = { vm.updateAudioQuality(it) },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
        }

        SettingsCard(3) {
        SectionTitle("Video")
        Text(
            text = "Kualitas tertinggi",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        val heights = listOf(
            2160 to "4K (2160p)",
            1440 to "1440p",
            1080 to "1080p (HD penuh)",
            720 to "720p (HD)",
            480 to "480p",
            360 to "360p",
        )
        for ((h, label) in heights) {
            RadioRow(label, vm.maxHeight == h) { vm.updateMaxHeight(h) }
        }
        SwitchRow(
            title = "Utamakan 60 fps",
            subtitle = "Pakai versi 60 fps bila tersedia di resolusi yang sama",
            checked = vm.prefer60,
            enabled = true,
            onChange = { vm.updatePrefer60(it) },
        )
        Text(
            text = "Mode Otomatis menurunkan dan menaikkan resolusi sendiri mengikuti internet, tidak melebihi batas ini. Bisa diganti kapan saja lewat ikon roda gigi di pemutar.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )

        }

        SettingsCard(4) {
        SectionTitle("Bahasa")
        if (showLangModels) {
            LangModelsDialog(
                main = vm.contentLang,
                onDismiss = { showLangModels = false },
            )
        }
        if (showLangPicker) {
            AlertDialog(
                onDismissRequest = { showLangPicker = false },
                confirmButton = {
                    TextButton(onClick = { showLangPicker = false }) { Text("Tutup") }
                },
                title = { Text("Bahasa aplikasi dan konten") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Text(
                            text = "Tampilan aplikasi tersedia penuh dalam Indonesia dan Inggris. Bahasa lain memakai " +
                                "tampilan Inggris, tetapi judul video, subtitle, dan lirik tetap diterjemahkan ke bahasa itu.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(bottom = 8.dp),
                        )
                        for (l in Languages.ALL) {
                            RadioRow(l.name, vm.contentLang == l.code) {
                                vm.updateContentLang(l.code)
                                showLangPicker = false
                            }
                        }
                    }
                },
            )
        }
        Text(
            text = "Bahasa aplikasi dan konten",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp),
        )
        Text(
            text = (Languages.byCode(vm.contentLang)?.name ?: "Indonesia") + " · Ketuk untuk ganti",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .fillMaxWidth()
                .bounceClickable { showLangPicker = true }
                .padding(horizontal = 16.dp, vertical = 8.dp),
        )
        Text(
            text = "Mengubah bahasa tampilan aplikasi, judul video, subtitle, dan terjemahan lirik.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Text(
            text = "Kelola model terjemahan lirik",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .fillMaxWidth()
                .bounceClickable { showLangModels = true }
                .padding(horizontal = 16.dp, vertical = 12.dp),
        )
        SwitchRow(
            title = "Terjemahkan judul video",
            subtitle = "Judul video berbahasa lain diterjemahkan di HP supaya sama dengan bahasa aplikasi. " +
                "Model bahasa (± 30 MB) diunduh sekali; matikan untuk hemat kuota",
            checked = vm.translateTitles,
            enabled = true,
            onChange = { vm.updateTranslateTitles(it) },
        )
        SwitchRow(
            title = "Utamakan suara dubbing",
            subtitle = "Bila video punya suara dubbing (mis. dubbing AI) dalam bahasa konten, putar itu",
            checked = vm.preferDub,
            enabled = true,
            onChange = { vm.updatePreferDub(it) },
        )
        SwitchRow(
            title = "Subtitle otomatis",
            subtitle = "Nyalakan subtitle dalam bahasa konten bila bahasa video berbeda (diterjemahkan bila perlu)",
            checked = vm.subtitleAuto,
            enabled = true,
            onChange = { vm.updateSubtitleAuto(it) },
        )
        Text(
            text = "Subtitle dan pilihan suara per video ada di ikon CC pada pemutar. Hanya tersedia bila YouTube menyediakannya untuk video itu.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )

        }

        SettingsCard(5) {
        SectionTitle("Link YouTube")
        Text(
            text = "Ketuk link YouTube di aplikasi lain atau pakai menu Bagikan untuk membukanya di sini. " +
                "Bila link masih terbuka di browser, aktifkan \"Buka link yang didukung\" lalu pilih semua link.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Text(
            text = "Atur buka link di aplikasi ini",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier
                .fillMaxWidth()
                .bounceClickable { openLinkSettings(context) }
                .padding(horizontal = 16.dp, vertical = 12.dp),
        )

        }

        SettingsCard(6) {
        SectionTitle("Tentang")
        Text(
            text = "${stringResource(R.string.app_name)} $version",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Text(
            text = "Pengembang: ${stringResource(R.string.developer_name)}",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
        )
        Text(
            text = "Mesin ekstraksi: NewPipeExtractor (GPLv3). Aplikasi ini mengikuti lisensi yang sama. Lirik dari LRCLIB.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.navigationBarsPadding().height(16.dp))
    }
}

/** Kartu satu bagian setelan: sudut besar, muncul berurutan dengan gerak spring. */
@Composable
private fun SettingsCard(index: Int, content: @Composable () -> Unit) {
    SoftCard(
        modifier = Modifier
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .appear(delayMillis = index * 55, offsetY = 20.dp),
        content = content,
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
    )
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(text = label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClickable(enabled = enabled) { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

/** Buka halaman sistem "Buka secara default" untuk app ini (Android 12+), atau info aplikasi. */
private fun openLinkSettings(context: Context) {
    val pkg = Uri.parse("package:" + context.packageName)
    val list = ArrayList<Intent>()
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        list.add(Intent(Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, pkg))
    }
    list.add(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
    for (i in list) {
        try {
            context.startActivity(i)
            return
        } catch (e: Exception) {
            // coba cara berikutnya
        }
    }
}

/** Bagian Data: Cadangkan / Pulihkan. */
@Composable
private fun DataSection() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json"),
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val ok = withContext(Dispatchers.IO) {
                    try {
                        val text = Backup.export(context)
                        context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                busy = false
                Toast.makeText(
                    context,
                    if (ok) tx("Cadangan tersimpan", "Backup saved") else tx("Gagal menyimpan cadangan", "Failed to save backup"),
                    Toast.LENGTH_SHORT,
                ).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri ->
        if (uri != null) {
            scope.launch {
                busy = true
                val count = withContext(Dispatchers.IO) {
                    try {
                        val text = context.contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) }
                        if (text == null) -1 else Backup.import(context, text)
                    } catch (e: Exception) {
                        -1
                    }
                }
                busy = false
                if (count < 0) {
                    Toast.makeText(
                        context,
                        tx("Berkas bukan cadangan PlayTube", "That file is not a PlayTube backup"),
                        Toast.LENGTH_LONG,
                    ).show()
                } else {
                    Toast.makeText(
                        context,
                        tx("Data dipulihkan, memulai ulang…", "Data restored, restarting…"),
                        Toast.LENGTH_SHORT,
                    ).show()
                    val activity = context.findActivity()
                    if (activity != null) restartApp(activity)
                }
            }
        }
    }

    SectionTitle("Data")
    Text(
        text = "Langganan, favorit, riwayat, dan daftar unduhan tersimpan di perangkat ini. " +
            "Untuk pindah HP atau setelah pasang ulang aplikasi, pakai Cadangkan lalu Pulihkan.",
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
    ) {
        ExpressiveButton(
            text = "Cadangkan",
            onClick = { exportLauncher.launch("playtube-cadangan.json") },
            modifier = Modifier.weight(1f),
            style = PillStyle.TONAL,
            enabled = !busy,
            minHeight = 48.dp,
        )
        ExpressiveButton(
            text = "Pulihkan",
            onClick = { importLauncher.launch(arrayOf("*/*")) },
            modifier = Modifier.weight(1f),
            style = PillStyle.TONAL,
            enabled = !busy,
            minHeight = 48.dp,
        )
    }
    Spacer(Modifier.height(8.dp))
}

/** Daftar model bahasa terjemahan lirik: status terpasang dan tombol unduh per bahasa. */
@Composable
private fun LangModelsDialog(main: String, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val codes = remember(main) { LangModels.needed(main, emptyList()) }
    // 0 = belum, 1 = sedang diunduh, 2 = sudah ada, 3 = gagal
    val status = remember { mutableStateMapOf<String, Int>() }

    androidx.compose.runtime.LaunchedEffect(codes) {
        for (c in codes) {
            status[c] = if (LangModels.isDownloaded(c)) 2 else 0
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Model terjemahan lirik") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Model diunduh sekali (± 30 MB per bahasa), setelah itu lirik diterjemahkan tanpa internet. " +
                        "Bahasa Inggris dipakai sebagai perantara.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                for (c in codes) {
                    val st = status[c] ?: 0
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = Languages.byCode(c)?.name ?: c,
                                style = MaterialTheme.typography.bodyLarge,
                            )
                            Text(
                                text = when (st) {
                                    1 -> "Mengunduh…"
                                    2 -> "Sudah terpasang"
                                    3 -> "Gagal, periksa internet"
                                    else -> "Belum diunduh"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = if (st == 3) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        if (st == 1) {
                            PlayLoader(diameter = 28.dp)
                        } else if (st != 2) {
                            TextButton(
                                onClick = {
                                    status[c] = 1
                                    scope.launch {
                                        try {
                                            LangModels.download(c)
                                            status[c] = 2
                                        } catch (e: Exception) {
                                            status[c] = 3
                                        }
                                    }
                                },
                            ) { Text("Unduh") }
                        }
                    }
                }
            }
        },
    )
}

/** Teks dua bahasa untuk string yang dibuat di luar komposisi (mis. Toast). */
private fun tx(id: String, en: String): String = if (I18n.lang == "id") id else en
