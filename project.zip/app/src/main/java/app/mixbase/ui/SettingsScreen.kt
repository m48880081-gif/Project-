package app.mixbase.ui

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mixbase.data.Engine
import app.mixbase.player.PlayerConnection

/** Video yang dipakai untuk "Tes koneksi" kalau belum ada lagu yang diputar. */
private const val TEST_VIDEO_ID = "jNQXAC9IVRw"

@Composable
fun SettingsScreen(vm: AppViewModel, player: PlayerConnection) {
    val clipboard = LocalClipboardManager.current
    var logShown by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        Text(
            text = "Setelan",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp),
        )

        SectionTitle("Tampilan")
        RadioRow("Ikuti sistem", vm.themeMode == 0) { vm.updateThemeMode(0) }
        RadioRow("Terang", vm.themeMode == 1) { vm.updateThemeMode(1) }
        RadioRow("Gelap", vm.themeMode == 2) { vm.updateThemeMode(2) }
        SwitchRow(
            title = "Warna dinamis",
            subtitle = "Ikuti warna wallpaper (Android 12 ke atas)",
            checked = vm.dynamicColor,
            enabled = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S,
            onChange = { vm.updateDynamicColor(it) },
        )

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        SectionTitle("Audio")
        SwitchRow(
            title = "Kualitas audio tertinggi",
            subtitle = "Matikan untuk hemat kuota",
            checked = vm.highQuality,
            enabled = true,
            onChange = { vm.updateHighQuality(it) },
        )

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        SectionTitle("Video")
        Text(
            text = "Pilih filter \"Video\" di pencarian untuk menonton. Kualitas di bawah dipakai sebagai batas tertinggi; " +
                "bisa juga diganti langsung di layar pemutar.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        RadioRow("Otomatis (maks 1080p)", player.videoHeight == 0) { player.setVideoHeight(0) }
        RadioRow("360p (hemat kuota)", player.videoHeight == 360) { player.setVideoHeight(360) }
        RadioRow("480p", player.videoHeight == 480) { player.setVideoHeight(480) }
        RadioRow("720p HD", player.videoHeight == 720) { player.setVideoHeight(720) }
        RadioRow("1080p Full HD", player.videoHeight == 1080) { player.setVideoHeight(1080) }
        RadioRow("1440p / 4K (jika HP kuat)", player.videoHeight == 2160) { player.setVideoHeight(2160) }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        SectionTitle("Diagnostik")
        Text(
            text = "Kalau ada video atau lagu yang gagal diputar, jalankan tes ini lalu salin hasilnya.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Button(
                enabled = !vm.testRunning,
                onClick = {
                    val id = player.current?.url?.let { Engine.videoIdOf(it) } ?: TEST_VIDEO_ID
                    vm.runSelfTest(id)
                },
            ) {
                Text(if (vm.testRunning) "Menguji..." else "Tes koneksi YouTube")
            }
            OutlinedButton(onClick = { logShown = Engine.logText() }) {
                Text("Tampilkan log")
            }
        }
        if (vm.testResult.isNotEmpty()) {
            MonoBlock(vm.testResult)
        }
        if (logShown.isNotEmpty()) {
            MonoBlock(logShown)
        }
        if (vm.testResult.isNotEmpty() || logShown.isNotEmpty()) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                OutlinedButton(
                    onClick = {
                        val all = vm.testResult + "\n\n" + logShown
                        clipboard.setText(AnnotatedString(all.trim()))
                    },
                ) { Text("Salin") }
                OutlinedButton(
                    onClick = {
                        Engine.clearLog()
                        logShown = ""
                    },
                ) { Text("Hapus log") }
            }
        }

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        SectionTitle("Tentang")
        Text(
            text = "MixBase 0.2.0",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Text(
            text = "Mesin ekstraksi: NewPipeExtractor (GPLv3). Aplikasi ini mengikuti lisensi yang sama.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Spacer(Modifier.padding(bottom = 16.dp))
    }
}

@Composable
private fun MonoBlock(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodySmall,
        fontFamily = FontFamily.Monospace,
        fontSize = 11.sp,
        lineHeight = 15.sp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
    )
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(text = label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
