package app.mixbase.ui

import android.os.Build
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(vm: AppViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
    ) {
        Text(
            text = "Setelan",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp),
        )

        SectionTitle("Tampilan")
        RadioRow("Ikuti sistem", vm.themeMode == 0) { vm.updateThemeMode(0) }
        RadioRow("Terang", vm.themeMode == 1) { vm.updateThemeMode(1) }
        RadioRow("Gelap", vm.themeMode == 2) { vm.updateThemeMode(2) }
        SwitchRow(
            title = "Warna dinamis",
            subtitle = "Ikuti warna wallpaper (Android 12 ke atas)",
            checked = vm.dynamicColor,
            enabled = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S,
            onChange = { vm.updateDynamicColor(it) },
        )

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        SectionTitle("Audio")
        SwitchRow(
            title = "Kualitas audio tertinggi",
            subtitle = "Matikan untuk hemat kuota",
            checked = vm.highQuality,
            enabled = true,
            onChange = { vm.updateHighQuality(it) },
        )

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        SectionTitle("Video")
        Text(
            text = "Kualitas awal (maksimum)",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        val heights = listOf(
            2160 to "4K (2160p)",
            1440 to "1440p",
            1080 to "1080p (HD penuh)",
            720 to "720p (HD)",
            480 to "480p",
            360 to "360p",
        )
        for ((h, label) in heights) {
            RadioRow(label, vm.maxHeight == h) { vm.updateMaxHeight(h) }
        }
        SwitchRow(
            title = "Utamakan 60 fps",
            subtitle = "Pakai versi 60 fps bila tersedia di resolusi yang sama",
            checked = vm.prefer60,
            enabled = true,
            onChange = { vm.updatePrefer60(it) },
        )
        Text(
            text = "Kualitas bisa diganti kapan saja lewat ikon roda gigi di pemutar.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )

        HorizontalDivider(Modifier.padding(vertical = 8.dp))

        SectionTitle("Tentang")
        Text(
            text = "MixBase 0.2.3",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        Text(
            text = "Mesin ekstraksi: NewPipeExtractor (GPLv3). Aplikasi ini mengikuti lisensi yang sama. Lirik dari LRCLIB.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
    )
}

@Composable
private fun RadioRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null)
        Spacer(Modifier.width(12.dp))
        Text(text = label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled) { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(text = title, style = MaterialTheme.typography.bodyLarge)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}
