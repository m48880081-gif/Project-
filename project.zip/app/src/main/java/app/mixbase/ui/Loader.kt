package app.mixbase.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

/** Satu bentuk "gelombang": jumlah tonjolan, kedalamannya, dan pipihnya (1 = bulat). */
private class Blob(val lobes: Int, val amp: Float, val squash: Float)

private val BLOBS = listOf(
    Blob(10, 0.10f, 1f), // semburat lembut
    Blob(9, 0.07f, 1f), // kue 9 sisi
    Blob(5, 0.10f, 1f), // segi lima membulat
    Blob(1, 0.00f, 0.62f), // pil / oval
    Blob(8, 0.14f, 1f), // matahari
    Blob(4, 0.12f, 1f), // kue 4 sisi
    Blob(7, 0.09f, 1f),
)

private const val STEPS = 120
private const val HOLD_MS = 760

/**
 * Indikator memuat gaya Material 3 Expressive: bentuk bergelombang yang berputar dan berubah
 * bentuk di dalam lingkaran. Dipakai di semua layar yang sedang memuat.
 */
@Composable
fun PlayLoader(
    modifier: Modifier = Modifier,
    diameter: Dp = 48.dp,
    containerColor: Color = MaterialTheme.colorScheme.primaryContainer,
    color: Color = MaterialTheme.colorScheme.onPrimaryContainer,
) {
    val transition = rememberInfiniteTransition(label = "playloader")
    val count = BLOBS.size
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = count.toFloat(),
        animationSpec = infiniteRepeatable(tween(count * HOLD_MS, easing = LinearEasing)),
        label = "morph",
    )
    val turn by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(count * HOLD_MS, easing = LinearEasing)),
        label = "turn",
    )

    Canvas(modifier.size(diameter)) {
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        drawCircle(color = containerColor, radius = this.size.minDimension / 2f, center = c)

        val idx = floor(phase).toInt().coerceIn(0, count - 1)
        val frac = phase - floor(phase)
        // Diam sebentar di tiap bentuk, lalu berubah halus ke bentuk berikutnya.
        val raw = ((frac - 0.3f) / 0.7f).coerceIn(0f, 1f)
        val t = raw * raw * (3f - 2f * raw)
        val a = BLOBS[idx]
        val b = BLOBS[(idx + 1) % count]
        val radius = this.size.minDimension * 0.34f

        val path = Path()
        for (i in 0 until STEPS) {
            val th = 2.0 * PI * i / STEPS
            val fromX = blobX(a, th)
            val fromY = blobY(a, th)
            val toX = blobX(b, th)
            val toY = blobY(b, th)
            val x = c.x + radius * (fromX + (toX - fromX) * t)
            val y = c.y + radius * (fromY + (toY - fromY) * t)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        rotate(degrees = turn, pivot = c) {
            drawPath(path = path, color = color)
        }
    }
}

private fun blobR(b: Blob, th: Double): Float {
    val peak = 1f + b.amp
    return (1f + b.amp * cos(b.lobes * th).toFloat()) / peak
}

private fun blobX(b: Blob, th: Double): Float = blobR(b, th) * cos(th).toFloat()

private fun blobY(b: Blob, th: Double): Float = blobR(b, th) * sin(th).toFloat() * b.squash

/** Loading di tengah seluruh area (layar yang masih kosong). */
@Composable
fun LoaderBox(modifier: Modifier = Modifier.fillMaxSize(), diameter: Dp = 56.dp) {
    Box(modifier, contentAlignment = Alignment.Center) {
        PlayLoader(diameter = diameter)
    }
}

/** Loading satu baris di dalam daftar (memuat halaman berikutnya). */
@Composable
fun LoaderRow(modifier: Modifier = Modifier, diameter: Dp = 44.dp) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(20.dp),
        contentAlignment = Alignment.Center,
    ) {
        PlayLoader(diameter = diameter)
    }
}
