package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import app.mixbase.data.hdArt
import coil.compose.AsyncImage

/**
 * Gambar resolusi tinggi: mencoba versi HD dari [url] lebih dulu (lihat [hdArt]);
 * bila gagal dimuat, otomatis kembali ke [url] aslinya.
 */
@Composable
fun HdImage(
    url: String?,
    modifier: Modifier = Modifier,
    px: Int = 1200,
    contentScale: ContentScale = ContentScale.Crop,
) {
    if (url == null) return
    val hd = remember(url, px) { hdArt(url, px) ?: url }
    var failed by remember(url, px) { mutableStateOf(false) }
    AsyncImage(
        model = if (failed) url else hd,
        contentDescription = null,
        modifier = modifier,
        contentScale = contentScale,
        onError = {
            if (hd != url) failed = true
        },
    )
}

/** Foto profil bulat; bila tidak ada gambar, tampilkan huruf pertama nama. */
@Composable
fun Avatar(url: String?, name: String, size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(avatarColor(name)),
        contentAlignment = Alignment.Center,
    ) {
        val letter = name.trim().removePrefix("@").take(1).uppercase()
        Text(
            text = letter,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp,
        )
        if (url != null) {
            AsyncImage(
                model = url,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
    }
}

private val AVATAR_COLORS = listOf(
    Color(0xFF5B4BDB), Color(0xFF00897B), Color(0xFFC2185B), Color(0xFFEF6C00),
    Color(0xFF3949AB), Color(0xFF6D4C41), Color(0xFF2E7D32), Color(0xFF8E24AA),
)

private fun avatarColor(name: String): Color {
    if (name.isEmpty()) return AVATAR_COLORS[0]
    val i = (name.hashCode() and 0x7fffffff) % AVATAR_COLORS.size
    return AVATAR_COLORS[i]
}

/** Merah untuk lencana LIVE. */
val LiveRed = Color(0xFFD93025)

/** Biru muda untuk bilah geser/kontrol di atas video gelap. */
val PlayerAccent = Color(0xFF8AB4F8)

/** Latar abu-abu muda untuk kartu/tombol di halaman video. */
@Composable
fun softSurface(): Color = MaterialTheme.colorScheme.surfaceContainer
