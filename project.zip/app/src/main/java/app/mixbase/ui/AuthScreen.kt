package app.mixbase.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.mixbase.data.Accounts
import kotlinx.coroutines.launch

/** Cari Activity dari Context (yang bisa terbungkus ContextWrapper). */
tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * Mulai ulang aplikasi dari awal (proses baru). Dipakai setelah Keluar, ganti akun, atau memulihkan
 * cadangan, supaya semua yang di memori dimuat ulang dari penyimpanan akun yang benar.
 */
fun restartApp(activity: Activity) {
    val launch = activity.packageManager.getLaunchIntentForPackage(activity.packageName)
    if (launch != null) {
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        activity.startActivity(launch)
    }
    activity.finishAffinity()
    Runtime.getRuntime().exit(0)
}

/**
 * Halaman masuk / daftar. Akun tersimpan di perangkat; setelah masuk, sesi diingat sehingga halaman ini
 * hanya tampil lagi bila pengguna memilih Keluar. [onAuthenticated] dipanggil dengan `restart = true`
 * bila aplikasi perlu dimulai ulang (akun kedua dst. memakai penyimpanan terpisah).
 */
@Composable
fun AuthScreen(onAuthenticated: (restart: Boolean) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    var register by rememberSaveable { mutableStateOf(!Accounts.hasAccounts()) }
    var name by rememberSaveable { mutableStateOf("") }
    var username by rememberSaveable { mutableStateOf("") }
    // Kata sandi sengaja tidak disimpan di state instance (rememberSaveable).
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var errorShown by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf("") }
    val shake = remember { Animatable(0f) }

    fun fail(message: String) {
        errorText = message
        errorShown = true
        scope.launch {
            for (x in listOf(-16f, 14f, -10f, 7f, -3f, 0f)) {
                shake.animateTo(x, spring(dampingRatio = 0.4f, stiffness = 900f))
            }
        }
    }

    fun submit() {
        if (busy) return
        errorShown = false
        if (register && password != confirm) {
            fail("Konfirmasi kata sandi tidak sama")
            return
        }
        busy = true
        scope.launch {
            val result = if (register) {
                Accounts.register(name, username, password)
            } else {
                Accounts.login(username, password)
            }
            busy = false
            val err = result.error
            if (err != null) fail(err) else onAuthenticated(result.restart)
        }
    }

    val fieldShape = RoundedCornerShape(20.dp)
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedContainerColor = scheme.surfaceContainerLowest,
        unfocusedContainerColor = scheme.surfaceContainerLowest,
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(scheme.surface),
    ) {
        // Dekorasi: dua blob besar yang pelan-pelan berubah bentuk.
        MorphBlob(
            modifier = Modifier
                .size(340.dp)
                .align(Alignment.TopEnd)
                .offset(x = 120.dp, y = (-100).dp)
                .alpha(0.55f),
            color = scheme.primaryContainer,
            lobes = 7,
        )
        MorphBlob(
            modifier = Modifier
                .size(240.dp)
                .align(Alignment.BottomStart)
                .offset(x = (-100).dp, y = 90.dp)
                .alpha(0.5f),
            color = scheme.tertiaryContainer,
            lobes = 9,
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(24.dp))

            Box(
                modifier = Modifier.size(176.dp),
                contentAlignment = Alignment.Center,
            ) {
                MorphBlob(Modifier.fillMaxSize(), color = scheme.primaryContainer, lobes = 8)
                PlayTubeMark(
                    size = 84.dp,
                    modifier = Modifier.appear(delayMillis = 120, offsetY = 0.dp, startScale = 0.35f),
                )
            }

            Spacer(Modifier.height(8.dp))

            AnimatedContent(
                targetState = register,
                transitionSpec = { fadeIn(spring(stiffness = 500f)) togetherWith fadeOut(spring(stiffness = 700f)) },
                label = "authtitle",
            ) { isRegister ->
                Text(
                    text = if (isRegister) "Buat akunmu" else "Selamat datang kembali",
                    style = MaterialTheme.typography.headlineMedium,
                    color = scheme.onSurface,
                    textAlign = TextAlign.Center,
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = "Langganan, favorit, dan unduhanmu tersimpan di akun ini, jadi tidak perlu mengulang dari awal.",
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp),
            )

            Spacer(Modifier.height(20.dp))

            SegmentedPill(
                options = listOf("Masuk", "Daftar"),
                selected = if (register) 1 else 0,
                onSelect = {
                    register = it == 1
                    errorShown = false
                },
                modifier = Modifier.appear(delayMillis = 60, offsetY = 16.dp),
            )

            Spacer(Modifier.height(16.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .graphicsLayer { translationX = shake.value }
                    .appear(delayMillis = 140, offsetY = 28.dp)
                    .clip(MaterialTheme.shapes.large)
                    .background(scheme.surfaceContainerLow)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                AnimatedVisibility(
                    visible = register,
                    enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeIn(),
                    exit = shrinkVertically(spring(stiffness = 500f)) + fadeOut(),
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it.take(40) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Nama") },
                        singleLine = true,
                        shape = fieldShape,
                        colors = fieldColors,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                        keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) }),
                    )
                }

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.replace(" ", "").take(30) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Nama pengguna") },
                    singleLine = true,
                    shape = fieldShape,
                    colors = fieldColors,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { focus.moveFocus(FocusDirection.Down) }),
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it.take(64) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Kata sandi") },
                    singleLine = true,
                    shape = fieldShape,
                    colors = fieldColors,
                    visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = if (register) ImeAction.Next else ImeAction.Done,
                    ),
                    keyboardActions = KeyboardActions(
                        onNext = { focus.moveFocus(FocusDirection.Down) },
                        onDone = {
                            focus.clearFocus()
                            submit()
                        },
                    ),
                    trailingIcon = {
                        Text(
                            text = if (showPassword) "Sembunyikan" else "Tampilkan",
                            style = MaterialTheme.typography.labelMedium,
                            color = scheme.primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(percent = 50))
                                .bounceClickable { showPassword = !showPassword }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                        )
                    },
                )

                AnimatedVisibility(
                    visible = register,
                    enter = expandVertically(spring(dampingRatio = 0.8f, stiffness = 400f)) + fadeIn(),
                    exit = shrinkVertically(spring(stiffness = 500f)) + fadeOut(),
                ) {
                    OutlinedTextField(
                        value = confirm,
                        onValueChange = { confirm = it.take(64) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Ulangi kata sandi") },
                        singleLine = true,
                        shape = fieldShape,
                        colors = fieldColors,
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Password,
                            imeAction = ImeAction.Done,
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = {
                                focus.clearFocus()
                                submit()
                            },
                        ),
                    )
                }

                AnimatedVisibility(
                    visible = errorShown,
                    enter = expandVertically(spring(dampingRatio = 0.7f, stiffness = 500f)) + fadeIn(),
                    exit = shrinkVertically(spring(stiffness = 600f)) + fadeOut(),
                ) {
                    Text(
                        text = errorText,
                        style = MaterialTheme.typography.bodyMedium,
                        color = scheme.error,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(MaterialTheme.shapes.small)
                            .background(scheme.errorContainer)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    )
                }

                ExpressiveButton(
                    text = if (register) "Buat akun" else "Masuk",
                    onClick = { submit() },
                    modifier = Modifier.fillMaxWidth(),
                    loading = busy,
                )
            }

            Spacer(Modifier.height(16.dp))
            Text(
                text = "Akun disimpan di perangkat ini (bukan di server). Keluar lalu masuk lagi akan mengembalikan semua datamu.",
                style = MaterialTheme.typography.bodySmall,
                color = scheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .padding(horizontal = 12.dp)
                    .appear(delayMillis = 260, offsetY = 12.dp),
            )
            Spacer(Modifier.height(32.dp))
        }
    }
}
