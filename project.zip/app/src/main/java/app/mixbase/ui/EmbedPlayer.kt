package app.mixbase.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner

/** Alamat "pengenal" aplikasi untuk YouTube (wajib ada agar embed tidak menolak: error 153). */
private const val EMBED_ORIGIN = "https://app.mixbase"

/** Mengurus layar penuh dari pemutar tersemat (tombol layar penuh milik YouTube). */
private class EmbedFullscreen(private val activity: Activity?) {
    private var customView: View? = null
    private var callback: WebChromeClient.CustomViewCallback? = null
    var showing by mutableStateOf(false)

    fun enter(view: View, cb: WebChromeClient.CustomViewCallback) {
        val act = activity
        if (customView != null || act == null) {
            cb.onCustomViewHidden()
            return
        }
        customView = view
        callback = cb
        val decor = act.window.decorView as ViewGroup
        decor.addView(
            view,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            ),
        )
        act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        WindowCompat.getInsetsController(act.window, decor).hide(WindowInsetsCompat.Type.systemBars())
        showing = true
    }

    fun exit() {
        val act = activity
        val v = customView
        if (v != null && act != null) {
            val decor = act.window.decorView as ViewGroup
            decor.removeView(v)
            act.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            WindowCompat.getInsetsController(act.window, decor).show(WindowInsetsCompat.Type.systemBars())
        }
        customView = null
        callback?.onCustomViewHidden()
        callback = null
        showing = false
    }
}

/**
 * Pemutar tersemat resmi YouTube di dalam WebView. Dipakai sebagai cadangan untuk video yang
 * stream langsungnya ditolak (mis. video "dibuat untuk anak-anak"). Kualitas diatur otomatis
 * oleh YouTube (bisa HD/60 fps) dan lewat menu setelan di dalam pemutarnya.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun EmbedPlayer(videoId: String, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val activity = context.findActivity()
    val fullscreen = remember { EmbedFullscreen(activity) }

    val webView = remember(videoId) {
        WebView(context).apply {
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            setBackgroundColor(AndroidColor.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View?, cb: WebChromeClient.CustomViewCallback?) {
                    if (view != null && cb != null) fullscreen.enter(view, cb) else cb?.onCustomViewHidden()
                }

                override fun onHideCustomView() {
                    fullscreen.exit()
                }
            }
            val id = videoId.filter { it.isLetterOrDigit() || it == '-' || it == '_' }
            val src = "https://www.youtube.com/embed/$id" +
                "?autoplay=1&playsinline=1&rel=0&fs=1&origin=https%3A%2F%2Fapp.mixbase"
            val html = "<!DOCTYPE html><html><head>" +
                "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">" +
                "<style>html,body{margin:0;height:100%;background:#000}" +
                "iframe{position:absolute;top:0;left:0;width:100%;height:100%;border:0}</style>" +
                "</head><body><iframe src=\"$src\" referrerpolicy=\"strict-origin\" " +
                "allow=\"autoplay; encrypted-media; picture-in-picture; fullscreen\" " +
                "allowfullscreen></iframe></body></html>"
            // Muat setelah WebView menempel ke jendela: bila video mulai sebelum itu, hasilnya
            // sering layar hitam dengan suara saja.
            var started = false
            addOnAttachStateChangeListener(
                object : View.OnAttachStateChangeListener {
                    override fun onViewAttachedToWindow(v: View) {
                        if (!started) {
                            started = true
                            loadDataWithBaseURL(EMBED_ORIGIN, html, "text/html", "utf-8", null)
                        }
                    }

                    override fun onViewDetachedFromWindow(v: View) {}
                },
            )
        }
    }

    // Tombol kembali menutup layar penuh dulu.
    BackHandler(enabled = fullscreen.showing) { fullscreen.exit() }

    // Berhenti saat aplikasi ke latar belakang (sama seperti pemutar video biasa).
    DisposableEffect(webView) {
        val owner = activity as? LifecycleOwner
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) webView.onPause()
            if (event == Lifecycle.Event.ON_RESUME) webView.onResume()
        }
        owner?.lifecycle?.addObserver(observer)
        onDispose {
            owner?.lifecycle?.removeObserver(observer)
            fullscreen.exit()
        }
    }

    AndroidView(
        factory = { webView },
        modifier = modifier,
        onRelease = { v ->
            v.stopLoading()
            v.loadUrl("about:blank")
            v.destroy()
        },
    )
}
