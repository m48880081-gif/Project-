package app.mixbase.ui

import android.app.Activity
import android.content.Intent

/**
 * Mulai ulang aplikasi dari awal (proses baru). Dipakai setelah memulihkan cadangan, supaya semua
 * yang ada di memori dimuat ulang dari penyimpanan.
 */
fun restartApp(activity: Activity) {
    val launch = activity.packageManager.getLaunchIntentForPackage(activity.packageName)
    if (launch != null) {
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        activity.startActivity(launch)
    }
    activity.finishAffinity()
    Runtime.getRuntime().exit(0)
}
