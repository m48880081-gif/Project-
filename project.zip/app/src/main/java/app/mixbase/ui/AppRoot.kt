package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import app.mixbase.R
import app.mixbase.data.Entry
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection
import app.mixbase.player.VideoPlayer
import kotlinx.coroutines.delay

/** "Dewa 19 • 12 lagu" → "Dewa 19" */
private fun albumArtist(sub: String): String =
    sub.split(" • ").firstOrNull { it.isNotBlank() && !it.endsWith(" lagu") } ?: ""

@Composable
fun AppRoot(vm: AppViewModel, player: PlayerConnection, video: VideoPlayer) {
    val nav = remember { Nav() }

    // Perbarui posisi musik tiap 0,5 detik selama memutar.
    LaunchedEffect(player.isPlaying) {
        while (player.isPlaying) {
            player.tick()
            delay(500)
        }
        player.tick()
    }

    // Perbarui posisi video lebih rapat supaya bilah geser halus.
    LaunchedEffect(video.isPlaying) {
        while (video.isPlaying) {
            video.tick()
            delay(250)
        }
        video.tick()
    }

    val actions = remember(vm, player, video, nav) {
        VideoActions(
            open = { t: Track ->
                player.pause()
                video.open(t)
                nav.watch = true
            },
            channel = { url: String, name: String ->
                nav.watch = false
                nav.push(Screen.ChannelPage(url, name, false))
            },
            audio = { t: Track -> player.playQueue(listOf(t), 0) },
            queue = { t: Track -> player.addToQueue(t) },
        )
    }

    val openEntry: (Entry, Boolean) -> Unit = { e, music ->
        if (e.kind == Entry.ARTIST) {
            nav.push(Screen.ChannelPage(e.url, e.title, music))
        } else {
            nav.push(Screen.AlbumPage(e.url, e.title, e.thumb, albumArtist(e.sub)))
        }
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                Column {
                    if (video.active && !nav.watch) {
                        MiniVideoBar(video) { nav.watch = true }
                    } else if (player.current != null) {
                        MiniPlayer(player) { nav.nowPlaying = true }
                    }
                    NavigationBar {
                        NavigationBarItem(
                            selected = nav.tab == 0,
                            onClick = {
                                nav.stack.clear()
                                nav.tab = 0
                            },
                            icon = { Icon(painterResource(R.drawable.ic_music_note), contentDescription = null) },
                            label = { Text("Musik") },
                        )
                        NavigationBarItem(
                            selected = nav.tab == 1,
                            onClick = {
                                nav.stack.clear()
                                nav.tab = 1
                            },
                            icon = { Icon(painterResource(R.drawable.ic_video), contentDescription = null) },
                            label = { Text("Video") },
                        )
                        NavigationBarItem(
                            selected = nav.tab == 2,
                            onClick = {
                                nav.stack.clear()
                                nav.tab = 2
                            },
                            icon = { Icon(painterResource(R.drawable.ic_library), contentDescription = null) },
                            label = { Text("Pustaka") },
                        )
                        NavigationBarItem(
                            selected = nav.tab == 3,
                            onClick = {
                                nav.stack.clear()
                                nav.tab = 3
                            },
                            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                            label = { Text("Setelan") },
                        )
                    }
                }
            },
        ) { inner ->
            Box(Modifier.padding(inner)) {
                when (nav.tab) {
                    0 -> MusicHomeScreen(
                        vm = vm,
                        player = player,
                        onSearch = { nav.push(Screen.SearchPage(true)) },
                        onOpenAlbum = { e -> openEntry(e, true) },
                        onOpenArtist = { e -> openEntry(e, true) },
                    )

                    1 -> VideoHomeScreen(
                        vm = vm,
                        actions = actions,
                        onSearch = { nav.push(Screen.SearchPage(false)) },
                    )

                    2 -> LibraryScreen(vm, player, actions)
                    else -> SettingsScreen(vm)
                }

                // Layar yang ditumpuk di atas tab (pencarian, channel, album)
                val top = nav.top
                if (top is Screen.SearchPage) {
                    SearchScreen(
                        vm = vm,
                        player = player,
                        actions = actions,
                        music = top.music,
                        onBack = { nav.pop() },
                        onOpenEntry = { e -> openEntry(e, top.music) },
                    )
                } else if (top is Screen.ChannelPage) {
                    ChannelScreen(
                        vm = vm,
                        player = player,
                        actions = actions,
                        page = top,
                        onBack = { nav.pop() },
                        onOpenCollection = { e -> openEntry(e, top.music) },
                    )
                } else if (top is Screen.AlbumPage) {
                    AlbumScreen(
                        vm = vm,
                        player = player,
                        page = top,
                        onBack = { nav.pop() },
                        onOpenArtist = { url, name -> nav.push(Screen.ChannelPage(url, name, true)) },
                    )
                }
            }
        }

        // Halaman tonton video
        AnimatedVisibility(
            visible = nav.watch && video.active,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
        ) {
            WatchScreen(
                vm = vm,
                video = video,
                onMinimize = { nav.watch = false },
                onOpenChannel = { url, name ->
                    nav.watch = false
                    nav.push(Screen.ChannelPage(url, name, false))
                },
                onPlayAudio = { queue, startMs ->
                    nav.watch = false
                    player.playQueue(queue, 0, startMs)
                },
                onQueueAudio = { t -> player.addToQueue(t) },
            )
        }

        // Pemutar musik penuh
        AnimatedVisibility(
            visible = nav.nowPlaying,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
        ) {
            NowPlayingScreen(
                vm = vm,
                player = player,
                onClose = { nav.nowPlaying = false },
                onOpenChannel = { url, name ->
                    nav.nowPlaying = false
                    nav.push(Screen.ChannelPage(url, name, true))
                },
            )
        }

        BackHandler(enabled = nav.nowPlaying) { nav.nowPlaying = false }
    }
}
