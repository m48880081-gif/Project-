@file:OptIn(ExperimentalSharedTransitionApi::class)

package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import app.mixbase.ui.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mixbase.R
import app.mixbase.data.Artist
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.LinkTarget
import app.mixbase.data.Links
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection
import app.mixbase.player.VideoPlayer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "Dewa 19 • 12 lagu" → "Dewa 19" */
private fun albumArtist(sub: String): String =
    sub.split(" • ").firstOrNull { it.isNotBlank() && !it.endsWith(" lagu") } ?: ""

@Composable
fun AppRoot(vm: AppViewModel, player: PlayerConnection, video: VideoPlayer, shorts: List<VideoPlayer>) {
    val nav = remember { Nav() }
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Mode aktif: 0 = Musik, 1 = Video. Masing-masing punya bilah navigasi bawah sendiri.
    val music = vm.mode == 0

    // Perbarui posisi musik tiap 0,5 detik selama memutar.
    LaunchedEffect(player.isPlaying) {
        while (player.isPlaying) {
            player.tick()
            delay(500)
        }
        player.tick()
    }

    // Perbarui posisi video lebih rapat supaya bilah geser halus.
    LaunchedEffect(video.isPlaying) {
        while (video.isPlaying) {
            video.tick()
            delay(250)
        }
        video.tick()
    }

    val actions = remember(vm, player, video, nav) {
        VideoActions(
            open = { t: Track ->
                player.pause()
                video.open(t)
                nav.watch = true
            },
            channel = { url: String, name: String ->
                nav.watch = false
                nav.push(Screen.ChannelPage(url, name, false))
            },
            audio = { t: Track -> player.playQueue(listOf(t), 0) },
            queue = { t: Track -> player.addToQueue(t) },
        )
    }

    // Link YouTube dari luar (ketuk link, Bagikan, atau ditempel di kolom Cari).
    val pendingLink = vm.pendingLink
    LaunchedEffect(pendingLink) {
        val raw = pendingLink ?: return@LaunchedEffect
        vm.consumeLink()
        val target = Links.parse(raw) ?: return@LaunchedEffect
        when (target) {
            is LinkTarget.Video -> {
                nav.settings = false
                nav.nowPlaying = false
                if (target.music) {
                    // Link YouTube Music: putar sebagai lagu di pemutar musik.
                    try {
                        val d = withContext(Dispatchers.IO) { Engine.videoDetails(target.url) }
                        val t = Track(
                            url = target.url,
                            title = d.title,
                            artist = d.uploader,
                            durationSec = d.durationSec,
                            thumb = d.thumb,
                            uploaderUrl = d.uploaderUrl,
                            avatar = d.avatar,
                        )
                        video.pause()
                        nav.watch = false
                        player.playQueue(listOf(t), 0)
                        nav.nowPlaying = true
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // Gagal membaca link: abaikan.
                    }
                } else {
                    actions.open(Track(url = target.url, title = "", artist = "", durationSec = 0L, thumb = null))
                }
            }

            is LinkTarget.Channel -> {
                nav.settings = false
                nav.nowPlaying = false
                nav.watch = false
                nav.push(Screen.ChannelPage(target.url, "", target.music))
            }

            is LinkTarget.Playlist -> {
                nav.settings = false
                nav.nowPlaying = false
                nav.watch = false
                nav.push(Screen.AlbumPage(target.url, "Playlist", null, ""))
            }
        }
    }

    val openEntry: (Entry, Boolean) -> Unit = { e, isMusic ->
        if (e.kind == Entry.ARTIST) {
            nav.push(Screen.ChannelPage(e.url, e.title, isMusic))
        } else {
            nav.push(Screen.AlbumPage(e.url, e.title, e.thumb, albumArtist(e.sub)))
        }
    }

    val openMenu: () -> Unit = { scope.launch { drawerState.open() } }
    val goSearch: () -> Unit = {
        nav.stack.clear()
        if (music) nav.mtab = MTab.SEARCH else nav.vtab = VTab.SEARCH
    }
    val goHome: () -> Unit = {
        nav.stack.clear()
        if (music) nav.mtab = MTab.HOME else nav.vtab = VTab.HOME
    }

    val overlayUp = nav.watch || nav.nowPlaying || nav.settings || nav.stack.isNotEmpty()

    // Layar jangan mati sendiri selama halaman tonton video terbuka.
    val view = LocalView.current
    val keepAwake = nav.watch && video.active
    DisposableEffect(keepAwake) {
        view.keepScreenOn = keepAwake
        onDispose { view.keepScreenOn = false }
    }

    // Warna app tetap (tidak mengikuti sampul lagu), di beranda maupun layar pemutar penuh.
    // Khusus Beranda Musik (mode terang), latar memakai abu kebiruan lembut (HomeBgLight); bilah atas,
    // bilah bawah, dan fade di tepi bawah otomatis ikut karena semuanya membaca warna latar tema.
    val baseScheme = MaterialTheme.colorScheme
    val onMusicHome = music && nav.mtab == MTab.HOME && nav.stack.isEmpty()
    val scheme = if (onMusicHome && baseScheme.background.luminance() > 0.5f) {
        baseScheme.copy(background = HomeBgLight, surface = HomeBgLight)
    } else {
        baseScheme
    }

    MaterialTheme(
        colorScheme = scheme,
        typography = MaterialTheme.typography,
        shapes = MaterialTheme.shapes,
    ) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = drawerState.isOpen || !overlayUp,
            drawerContent = {
                AppDrawerContent(
                    mode = vm.mode,
                    onMode = { m ->
                        scope.launch { drawerState.close() }
                        if (m != vm.mode) {
                            nav.stack.clear()
                            vm.updateMode(m)
                        }
                    },
                    onSettings = {
                        scope.launch { drawerState.close() }
                        nav.settings = true
                    },
                )
            },
        ) {
            val density = LocalDensity.current
            var barPad by remember { mutableStateOf(0.dp) }
            val liquidBackdrop = rememberLiquidBackdrop()
            val liquidBg = MaterialTheme.colorScheme.background
            SharedTransitionLayout(Modifier.fillMaxSize()) {
                CompositionLocalProvider(LocalSharedTransition provides this) {
                    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                        CompositionLocalProvider(
                            LocalBarPadding provides barPad,
                            LocalContentColor provides MaterialTheme.colorScheme.onBackground,
                        ) {
                            Box(Modifier.fillMaxSize().liquidBackdropSource(liquidBackdrop, liquidBg).windowInsetsPadding(WindowInsets.statusBars)) {
                                if (music) {
                                    when (nav.mtab) {
                                        MTab.HOME -> MusicHomeScreen(
                                            vm = vm,
                                            player = player,
                                            onMenu = openMenu,
                                            onSearch = goSearch,
                                            onOpenAlbum = { e -> openEntry(e, true) },
                                            onOpenArtist = { e -> openEntry(e, true) },
                                            onOpenMore = { url, title -> nav.push(Screen.Collection(url, title, Artist.MORE)) },
                                        )

                                        MTab.SEARCH -> SearchScreen(
                                            vm = vm,
                                            player = player,
                                            actions = actions,
                                            music = true,
                                            onBack = goHome,
                                            onOpenEntry = { e -> openEntry(e, true) },
                                            showBack = false,
                                        )

                                        MTab.DOWNLOADS -> Box(Modifier.fillMaxSize().padding(bottom = barPad)) {
                                            DownloadsScreen(
                                                video = false,
                                                player = player,
                                                actions = actions,
                                                onMenu = openMenu,
                                                onSearch = goSearch,
                                            )
                                        }

                                        else -> Box(Modifier.fillMaxSize().padding(bottom = barPad)) {
                                            MusicPlaylistScreen(
                                                vm = vm,
                                                player = player,
                                                onMenu = openMenu,
                                                onSearch = goSearch,
                                            )
                                        }
                                    }
                                } else {
                                    when (nav.vtab) {
                                        VTab.HOME -> VideoHomeScreen(
                                            vm = vm,
                                            actions = actions,
                                            onMenu = openMenu,
                                            onSearch = goSearch,
                                        )

                                        VTab.SEARCH -> SearchScreen(
                                            vm = vm,
                                            player = player,
                                            actions = actions,
                                            music = false,
                                            onBack = goHome,
                                            onOpenEntry = { e -> openEntry(e, false) },
                                            showBack = false,
                                        )

                                        VTab.SUBS -> Box(Modifier.fillMaxSize().padding(bottom = barPad)) {
                                            SubscriptionsScreen(
                                                vm = vm,
                                                actions = actions,
                                                onMenu = openMenu,
                                                onSearch = goSearch,
                                            )
                                        }

                                        VTab.HISTORY -> Box(Modifier.fillMaxSize().padding(bottom = barPad)) {
                                            VideoHistoryScreen(
                                                vm = vm,
                                                actions = actions,
                                                onMenu = openMenu,
                                                onSearch = goSearch,
                                            )
                                        }

                                        VTab.SHORTS -> ShortsScreen(
                                            vm = vm,
                                            pool = shorts,
                                            video = video,
                                            player = player,
                                            actions = actions,
                                            active = !overlayUp && !drawerState.isOpen,
                                        )

                                        else -> Box(Modifier.fillMaxSize().padding(bottom = barPad)) {
                                            DownloadsScreen(
                                                video = true,
                                                player = player,
                                                actions = actions,
                                                onMenu = openMenu,
                                                onSearch = goSearch,
                                            )
                                        }
                                    }
                                }

                                // Layar yang ditumpuk di atas tab (channel, artis, album)
                                val top = nav.top
                                if (top != null) {
                                    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                                        Box(Modifier.fillMaxSize().padding(bottom = barPad)) {
                                if (top is Screen.ChannelPage && top.music) {
                                    ArtistScreen(
                                        vm = vm,
                                        player = player,
                                        actions = actions,
                                        page = top,
                                        onBack = { nav.pop() },
                                        onOpenEntry = { e -> openEntry(e, true) },
                                        onOpenCollection = { kind -> nav.push(Screen.Collection(top.url, top.name, kind)) },
                                    )
                                } else if (top is Screen.ChannelPage) {
                                    ChannelScreen(
                                        vm = vm,
                                        player = player,
                                        actions = actions,
                                        page = top,
                                        onBack = { nav.pop() },
                                        onOpenCollection = { e -> openEntry(e, top.music) },
                                    )
                                } else if (top is Screen.Collection) {
                                    CollectionScreen(
                                        actions = actions,
                                        page = top,
                                        onBack = { nav.pop() },
                                        onOpenEntry = { e -> openEntry(e, true) },
                                    )
                                } else if (top is Screen.AlbumPage) {
                                    AlbumScreen(
                                        vm = vm,
                                        player = player,
                                        page = top,
                                        onBack = { nav.pop() },
                                        onOpenArtist = { url, name -> nav.push(Screen.ChannelPage(url, name, true)) },
                                    )
                                }
                                        }
                                    }
                                }
                            }
                        }

                        // Fade + blur tipis di belakang tombol navigasi sistem (3 tombol maupun gestur).
                        // Dilewati di Shorts supaya video tidak tertutup warna latar.
                        if (music || nav.vtab != VTab.SHORTS) {
                            BottomEdgeFade(
                                backdrop = liquidBackdrop,
                                modifier = Modifier.align(Alignment.BottomCenter),
                            )
                        }

                        // Bilah bawah: mini player + navigasi (mengukur tingginya sendiri)
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .onSizeChanged { barPad = with(density) { it.height.toDp() } },
                        ) {
                                    // Saat ada video, yang tampil adalah jendela video mengambang (di WatchScreen).
                                    if (!video.active && player.current != null) {
                                        AnimatedVisibility(
                                        visible = !nav.nowPlaying,
                                        enter = fadeIn(tween(250)) + slideInVertically(tween(250)) { it / 2 },
                                        exit = fadeOut(tween(250)) + slideOutVertically(tween(250)) { it / 2 },
                                    ) {
                                        CompositionLocalProvider(LocalVisibilityScope provides this) {
                                            MiniPlayer(
                                                player = player,
                                                backdrop = liquidBackdrop,
                                                // Geser ke bawah: kapsul lenyap (animasi jeli), lalu lagu berhenti.
                                                onDismiss = { player.stopAndClear() },
                                            ) { nav.nowPlaying = true }
                                        }
                                    }
                                    }
                            val musicOrder = listOf(MTab.HOME, MTab.SEARCH, MTab.DOWNLOADS, MTab.PLAYLIST)
                            val videoOrder = listOf(VTab.HOME, VTab.SEARCH, VTab.SUBS, VTab.DOWNLOADS, VTab.SHORTS)
                            val liquidTabs: List<LiquidTab> = if (music) {
                                listOf(
                                    LiquidTab("Beranda") { sel, tint ->
                                        Icon(painterResource(if (sel) R.drawable.ic_nav_home_filled else R.drawable.ic_nav_home_outline), contentDescription = null, tint = tint)
                                    },
                                    LiquidTab("Cari") { _, tint -> Icon(Icons.Filled.Search, contentDescription = null, tint = tint) },
                                    LiquidTab("Unduhan") { _, tint -> Icon(painterResource(R.drawable.ic_download), contentDescription = null, tint = tint) },
                                    LiquidTab("Playlist") { sel, tint ->
                                        Icon(painterResource(if (sel) R.drawable.ic_nav_library_filled else R.drawable.ic_nav_library_outline), contentDescription = null, tint = tint)
                                    },
                                )
                            } else {
                                listOf(
                                    LiquidTab("Beranda") { sel, tint ->
                                        Icon(painterResource(if (sel) R.drawable.ic_nav_home_filled else R.drawable.ic_nav_home_outline), contentDescription = null, tint = tint)
                                    },
                                    LiquidTab("Cari") { _, tint -> Icon(Icons.Filled.Search, contentDescription = null, tint = tint) },
                                    LiquidTab("Langganan") { _, tint -> Icon(painterResource(R.drawable.ic_subscriptions), contentDescription = null, tint = tint) },
                                    LiquidTab("Unduhan") { _, tint -> Icon(painterResource(R.drawable.ic_download), contentDescription = null, tint = tint) },
                                    LiquidTab("Shorts") { sel, tint ->
                                        Icon(painterResource(if (sel) R.drawable.ic_nav_shorts_filled else R.drawable.ic_nav_shorts_outline), contentDescription = null, tint = tint)
                                    },
                                )
                            }
                            androidx.compose.runtime.key(music) {
                                LiquidNavBar(
                                    tabs = liquidTabs,
                                    backdrop = liquidBackdrop,
                                    selectedIndex = (if (music) musicOrder.indexOf(nav.mtab) else videoOrder.indexOf(nav.vtab)).coerceAtLeast(0),
                                    onSelect = { i ->
                                        nav.stack.clear()
                                        if (music) nav.mtab = musicOrder[i] else nav.vtab = videoOrder[i]
                                    },
                                )
                            }
                        }

                        // Halaman tonton video + jendela video mengambang (video tetap jalan saat diminimalkan)
                        if (video.active) {
                            WatchScreen(
                                vm = vm,
                                video = video,
                                expanded = nav.watch,
                                barPad = barPad,
                                onExpand = { nav.watch = true },
                                onMinimize = { nav.watch = false },
                                onOpenChannel = { url, name ->
                                    nav.watch = false
                                    nav.push(Screen.ChannelPage(url, name, false))
                                },
                                onPlayAudio = { queue, startMs ->
                                    nav.watch = false
                                    player.playQueue(queue, 0, startMs)
                                },
                                onQueueAudio = { t -> player.addToQueue(t) },
                            )
                        }

                        // Pemutar musik penuh
                        AnimatedVisibility(
                            visible = nav.nowPlaying,
                            enter = fadeIn(tween(350)),
                            exit = fadeOut(tween(300)),
                        ) {
                          CompositionLocalProvider(LocalVisibilityScope provides this) {
                            NowPlayingScreen(
                                vm = vm,
                                player = player,
                                onClose = { nav.nowPlaying = false },
                                onOpenChannel = { url, name ->
                                    nav.nowPlaying = false
                                    nav.push(Screen.ChannelPage(url, name, true))
                                },
                            )
                          }
                        }

                        // Setelan (dibuka dari laci samping)
                        AnimatedVisibility(
                            visible = nav.settings,
                            enter = slideInHorizontally(initialOffsetX = { it }),
                            exit = slideOutHorizontally(targetOffsetX = { it }),
                        ) {
                            SettingsScreen(vm = vm, onBack = { nav.settings = false })
                        }

                        BackHandler(enabled = nav.nowPlaying) { nav.nowPlaying = false }

                        // Tombol kembali: tutup laci dulu; di tab selain Beranda, kembali ke Beranda.
                        BackHandler(enabled = drawerState.isOpen) {
                            scope.launch { drawerState.close() }
                        }
                        val onHomeTab = if (music) nav.mtab == MTab.HOME else nav.vtab == VTab.HOME
                        BackHandler(enabled = !onHomeTab && !overlayUp && !drawerState.isOpen) {
                            goHome()
                        }
                    }
                }
            }
        }
    }
}
