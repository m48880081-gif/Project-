package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.mixbase.R
import app.mixbase.player.PlayerConnection
import kotlinx.coroutines.delay

@Composable
fun AppRoot(vm: AppViewModel, player: PlayerConnection) {
    var tab by rememberSaveable { mutableStateOf(0) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }

    // Video hanya diunduh saat aplikasi terlihat; di latar belakang hanya audio (hemat kuota).
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_START) player.setAppVisible(true)
            if (event == Lifecycle.Event.ON_STOP) player.setAppVisible(false)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Perbarui posisi lagu tiap 0,5 detik selama memutar.
    LaunchedEffect(player.isPlaying) {
        while (player.isPlaying) {
            player.tick()
            delay(500)
        }
        player.tick()
    }

    Box(Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                Column {
                    if (player.current != null) {
                        MiniPlayer(player) { showPlayer = true }
                    }
                    NavigationBar {
                        NavigationBarItem(
                            selected = tab == 0,
                            onClick = { tab = 0 },
                            icon = { Icon(Icons.Filled.Search, contentDescription = null) },
                            label = { Text("Cari") },
                        )
                        NavigationBarItem(
                            selected = tab == 1,
                            onClick = { tab = 1 },
                            icon = { Icon(painterResource(R.drawable.ic_library), contentDescription = null) },
                            label = { Text("Pustaka") },
                        )
                        NavigationBarItem(
                            selected = tab == 2,
                            onClick = { tab = 2 },
                            icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                            label = { Text("Setelan") },
                        )
                    }
                }
            },
        ) { inner ->
            Box(Modifier.padding(inner)) {
                when (tab) {
                    0 -> SearchScreen(vm, player)
                    1 -> LibraryScreen(vm, player)
                    else -> SettingsScreen(vm, player)
                }
            }
        }

        // Didaftarkan SEBELUM NowPlaying supaya BackHandler milik NowPlaying (keluar dari
        // layar penuh) yang diutamakan.
        BackHandler(enabled = showPlayer) { showPlayer = false }

        AnimatedVisibility(
            visible = showPlayer,
            enter = slideInVertically(initialOffsetY = { it }),
            exit = slideOutVertically(targetOffsetY = { it }),
        ) {
            NowPlayingScreen(vm, player) { showPlayer = false }
        }
    }
}
