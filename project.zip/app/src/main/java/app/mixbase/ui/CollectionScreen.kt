package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Artist
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.MusicApi
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Daftar penuh (semua album / single & EP / video / playlist) milik satu artis, dimuat berhalaman. */
class CollectionState(
    private val scope: CoroutineScope,
    private val url: String,
    private val kind: Int,
) {
    val entries = mutableStateListOf<Entry>()
    val tracks = mutableStateListOf<Track>()

    var loading by mutableStateOf(true)
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var canMore by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private var pager: Engine.Pager? = null

    init {
        scope.launch {
            try {
                val p = withContext(Dispatchers.IO) {
                    // Sumber utama: daftar penuh dari YouTube Music; cadangan: sistem lama.
                    val viaMusic = try {
                        MusicApi.artistPager(url, kind)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        null
                    }
                    viaMusic ?: Artist.pager(Engine.channel(url), kind)
                }
                if (p == null) {
                    error = "Tidak ada isi untuk ditampilkan."
                } else {
                    pager = p
                    var tries = 0
                    var b = withContext(Dispatchers.IO) { p.first() }
                    add(b.entries, b.tracks)
                    // Penyaringan bisa mengosongkan halaman pertama: lanjut ambil beberapa halaman lagi.
                    while (entries.isEmpty() && tracks.isEmpty() && p.hasMore && tries < 4) {
                        b = withContext(Dispatchers.IO) { p.more() }
                        add(b.entries, b.tracks)
                        tries += 1
                    }
                    canMore = p.hasMore
                    if (entries.isEmpty() && tracks.isEmpty()) error = "Tidak ada isi untuk ditampilkan."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Gagal memuat: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                loading = false
            }
        }
    }

    private fun add(es: List<Entry>, ts: List<Track>) {
        for (e in es) {
            if (entries.none { it.url == e.url }) entries.add(e)
        }
        for (t in ts) {
            if (tracks.none { it.url == t.url }) tracks.add(t)
        }
    }

    fun loadMore() {
        val p = pager ?: return
        if (loading || loadingMore || !canMore) return
        loadingMore = true
        scope.launch {
            try {
                val b = withContext(Dispatchers.IO) { p.more() }
                add(b.entries, b.tracks)
                canMore = p.hasMore
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                canMore = false
            } finally {
                loadingMore = false
            }
        }
    }
}

@Composable
fun CollectionScreen(
    actions: VideoActions,
    page: Screen.Collection,
    onBack: () -> Unit,
    onOpenEntry: (Entry) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val st = remember(page) { CollectionState(scope, page.url, page.kind) }

    BackHandler(onBack = onBack)

    val heading = when (page.kind) {
        Artist.ALBUMS -> "Album"
        Artist.SINGLES -> "Single & EP"
        Artist.VIDEOS -> "Video"
        else -> "Playlist"
    }
    val label = when (page.kind) {
        Artist.ALBUMS -> "Album"
        Artist.SINGLES -> "Single"
        else -> "Playlist"
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        painter = painterResource(R.drawable.ic_arrow_back),
                        contentDescription = "Kembali",
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        text = heading,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                    )
                    Text(
                        text = page.name,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            if (st.loading) {
                LoaderBox()
            } else if (st.error != null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = st.error ?: "",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(32.dp),
                    )
                }
            } else if (page.kind == Artist.VIDEOS) {
                val listState = rememberLazyListState()
                LaunchedEffect(listState, st) {
                    snapshotFlow {
                        val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                        last >= listState.layoutInfo.totalItemsCount - 3
                    }.collect { nearEnd -> if (nearEnd) st.loadMore() }
                }
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    itemsIndexed(st.tracks, key = { i, t -> "${t.url}#$i" }) { _, t ->
                        VideoCardFor(t, actions)
                    }
                    if (st.loadingMore) {
                        item { LoaderRow() }
                    }
                }
            } else {
                val gridState = rememberLazyGridState()
                LaunchedEffect(gridState, st) {
                    snapshotFlow {
                        val last = gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                        last >= gridState.layoutInfo.totalItemsCount - 4
                    }.collect { nearEnd -> if (nearEnd) st.loadMore() }
                }
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    state = gridState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 24.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                ) {
                    itemsIndexed(st.entries, key = { _, e -> e.url }) { _, e ->
                        CoverCard(
                            title = e.title,
                            subtitle = releaseLabel(e, label),
                            thumb = e.thumb,
                            onClick = { onOpenEntry(e) },
                        )
                    }
                    if (st.loadingMore) {
                        item(span = { GridItemSpan(maxLineSpan) }) { LoaderRow() }
                    }
                }
            }
        }
    }
}
