package app.mixbase.ui

import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.EaseOut
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.MutatorMutex
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sign

/** Satu tab pada [LiquidNavBar]. [icon] menerima status terpilih + warna ikon yang sedang berlaku. */
class LiquidTab(
    val label: String,
    val icon: @Composable (selected: Boolean, tint: Color) -> Unit,
)

/**
 * Sumber latar untuk efek blur: isi layar direkam ke [layer], lalu bilah menggambar salinannya yang diburamkan.
 * [origin] = posisi pojok kiri atas area isi di layar.
 */
class LiquidBackdrop(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
    var tick by mutableIntStateOf(0)
    var counter = 0
}

@Composable
fun rememberLiquidBackdrop(): LiquidBackdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { LiquidBackdrop(layer) }
}

/** Pasang di wadah isi layar (yang akan terlihat blur di belakang bilah). [bg] = warna latar app. */
fun Modifier.liquidBackdropSource(backdrop: LiquidBackdrop, bg: Color): Modifier =
    this
        .onGloballyPositioned { backdrop.origin = it.positionInRoot() }
        .drawWithContent {
            backdrop.layer.record {
                drawRect(bg)
                this@drawWithContent.drawContent()
            }
            drawLayer(backdrop.layer)
            backdrop.counter += 1
            backdrop.tick = backdrop.counter
        }

internal val LiquidRed = Color(0xFFFF2D55)

/** Tinggi panel bilah. Bilah tumbuh ke atas: padding bawah tetap, jadi tepi bawahnya tidak bergeser. */
internal val LiquidBarHeight = 76.dp

/** Tinggi lensa = panel dikurangi 4dp di tiap sisi. */
private val LensHeight = LiquidBarHeight - 8.dp

/** Tinggi lensa saat ditekan (90dp) dibanding tinggi diam (68dp). */
private const val PressedScale = 90f / 68f

private const val LensAgsl = """
uniform shader content;
uniform float2 size;
uniform float radius;
uniform float refractionHeight;
uniform float refractionAmount;
uniform float chroma;

float sdRoundedRect(float2 p, float2 halfSize, float r) {
    float2 q = abs(p) - (halfSize - float2(r));
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}

half4 main(float2 coord) {
    if (refractionHeight <= 0.0) {
        return content.eval(coord);
    }
    float2 halfSize = size * 0.5;
    float2 p = coord - halfSize;
    float sd = sdRoundedRect(p, halfSize, radius);
    if (-sd >= refractionHeight) {
        return content.eval(coord);
    }
    sd = min(sd, 0.0);
    float t = 1.0 - (-sd) / refractionHeight;
    float d = (1.0 - sqrt(max(1.0 - t * t, 0.0))) * refractionAmount;
    float e = 1.0;
    float2 g = float2(
        sdRoundedRect(p + float2(e, 0.0), halfSize, radius) - sdRoundedRect(p - float2(e, 0.0), halfSize, radius),
        sdRoundedRect(p + float2(0.0, e), halfSize, radius) - sdRoundedRect(p - float2(0.0, e), halfSize, radius)
    );
    float2 grad = normalize(g + float2(0.0001));
    float2 off = d * grad;
    float2 rc = coord - off;
    if (chroma < 0.5) {
        return content.eval(rc);
    }
    float di = chroma * ((p.x * p.y) / (halfSize.x * halfSize.y));
    float2 disp = off * di;
    half4 c = content.eval(rc);
    half4 r = content.eval(rc + disp);
    half4 b = content.eval(rc - disp);
    return half4(r.r, c.g, b.b, c.a);
}
"""

@RequiresApi(33)
private class LensShader {
    private val shader = RuntimeShader(LensAgsl)

    fun effect(
        width: Float,
        height: Float,
        radius: Float,
        refHeight: Float,
        refAmount: Float,
        chroma: Float,
        inner: android.graphics.RenderEffect?,
    ): androidx.compose.ui.graphics.RenderEffect {
        shader.setFloatUniform("size", width, height)
        shader.setFloatUniform("radius", radius)
        shader.setFloatUniform("refractionHeight", refHeight)
        shader.setFloatUniform("refractionAmount", refAmount)
        shader.setFloatUniform("chroma", chroma)
        val e = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "content")
        val out = if (inner != null) android.graphics.RenderEffect.createChainEffect(e, inner) else e
        return out.asComposeRenderEffect()
    }
}

/** Saturasi naik (vibrancy) lalu blur, seperti efek kaca di Auralys. */
@RequiresApi(31)
private fun blurVibrancy(blurPx: Float, saturation: Float = 1.5f): android.graphics.RenderEffect {
    val cm = android.graphics.ColorMatrix().apply { setSaturation(saturation) }
    val vib = android.graphics.RenderEffect.createColorFilterEffect(android.graphics.ColorMatrixColorFilter(cm))
    return android.graphics.RenderEffect.createBlurEffect(blurPx, blurPx, vib, android.graphics.Shader.TileMode.CLAMP)
}

private class FxState {
    var w = -1f
    var h = -1f
    var barSet = false
}

/**
 * Fisika lensa (mengikuti DampedDragAnimation milik Kyant0 AndroidLiquidGlass, Apache-2.0):
 * nilai posisi pegas kaku, progres tekan, skala X/Y pegas memantul, dan kecepatan untuk efek penyet.
 */
private class DampedThumb(
    private val scope: CoroutineScope,
    initial: Float,
    private val maxValue: Float,
) {
    private val valueSpec = spring<Float>(1f, 1000f, 0.001f)
    private val velocitySpec = spring<Float>(0.5f, 300f, 0.01f)
    private val pressSpec = spring<Float>(1f, 1000f, 0.001f)
    private val scaleXSpec = spring<Float>(0.6f, 250f, 0.001f)
    private val scaleYSpec = spring<Float>(0.7f, 250f, 0.001f)

    private val valueA = Animatable(initial, 0.001f)
    private val velocityA = Animatable(0f, 0.01f)
    private val pressA = Animatable(0f, 0.001f)
    private val scaleXA = Animatable(1f, 0.001f)
    private val scaleYA = Animatable(1f, 0.001f)
    private val mutex = MutatorMutex()

    val value: Float get() = valueA.value
    val target: Float get() = valueA.targetValue
    val pressProgress: Float get() = pressA.value
    val scaleX: Float get() = scaleXA.value
    val scaleY: Float get() = scaleYA.value
    val velocity: Float get() = velocityA.value

    fun press() {
        scope.launch {
            launch { pressA.animateTo(1f, pressSpec) }
            launch { scaleXA.animateTo(PressedScale, scaleXSpec) }
            launch { scaleYA.animateTo(PressedScale, scaleYSpec) }
        }
    }

    fun release() {
        scope.launch {
            withFrameNanos { }
            if (valueA.value != valueA.targetValue) {
                val threshold = maxValue.coerceAtLeast(1f) * 0.025f
                snapshotFlow { valueA.value }
                    .filter { abs(it - valueA.targetValue) < threshold }
                    .first()
            }
            launch { pressA.animateTo(0f, pressSpec) }
            launch { scaleXA.animateTo(1f, scaleXSpec) }
            launch { scaleYA.animateTo(1f, scaleYSpec) }
        }
    }

    fun updateValue(v: Float) {
        val t = v.coerceIn(0f, maxValue)
        scope.launch {
            valueA.animateTo(t, valueSpec) { updateVelocity() }
        }
    }

    fun animateTo(v: Float) {
        scope.launch {
            mutex.mutate {
                press()
                val t = v.coerceIn(0f, maxValue)
                launch { valueA.animateTo(t, valueSpec) }
                if (velocityA.value != 0f) {
                    launch { velocityA.animateTo(0f, velocitySpec) }
                }
                release()
            }
        }
    }

    private fun updateVelocity() {
        val tv = valueA.velocity / maxValue.coerceAtLeast(1f)
        scope.launch { velocityA.animateTo(tv, velocitySpec) }
    }
}

@Composable
private fun TabsRow(
    tabs: List<LiquidTab>,
    selectedIndex: Int,
    allSelected: Boolean,
    tint: Color,
    a11y: Boolean,
    tabScale: () -> Float,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier = modifier.fillMaxSize()) {
        tabs.forEachIndexed { i, tab ->
            // Tab yang baru dipilih penyet lalu melonjak dan bergoyang seperti jeli sampai diam.
            val pop = remember { Animatable(1f) }
            LaunchedEffect(selectedIndex) {
                if (i == selectedIndex) {
                    pop.snapTo(0.72f)
                    pop.animateTo(1f, spring(dampingRatio = 0.26f, stiffness = 380f))
                }
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .then(
                        if (a11y) {
                            Modifier.semantics(mergeDescendants = true) {
                                role = Role.Tab
                                selected = (i == selectedIndex)
                                onClick {
                                    onSelect(i)
                                    true
                                }
                            }
                        } else {
                            Modifier.clearAndSetSemantics { }
                        },
                    )
                    .graphicsLayer {
                        val s = tabScale()
                        val p = pop.value
                        scaleX = s * (1f + (1f - p) * 0.55f)
                        scaleY = s * p
                        translationY = (1f - p) * 40f
                    },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterVertically),
            ) {
                tab.icon(allSelected || i == selectedIndex, tint)
                Text(
                    text = tab.label,
                    color = tint,
                    maxLines = 1,
                    softWrap = false,
                    fontSize = 10.sp,
                    letterSpacing = 0.sp,
                )
            }
        }
    }
}

/**
 * Bilah navigasi "liquid glass" mengikuti nav bar Auralys / Kyant0 LiquidBottomTabs:
 * - panel kaca 76dp: blur + vibrancy + pembiasan di tepi, membesar sedikit saat disentuh
 * - lensa 68dp: saat diam hanya pil tipis; saat disentuh membesar (90dp, lebih tinggi dari bar), jadi kaca
 *   yang membiaskan isinya (dengan aberasi kromatik), bergetar kenyal, dan memipih sesuai kecepatan
 * - tab di dalam lensa berwarna merah dan membesar 1,2x
 * Blur butuh Android 12+, pembiasan Android 13+.
 */
@Composable
fun LiquidNavBar(
    tabs: List<LiquidTab>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    backdrop: LiquidBackdrop?,
    modifier: Modifier = Modifier,
    /** false: lensa disembunyikan saat diam (tetap muncul saat disentuh), untuk bilah yang boleh tanpa pilihan. */
    lensVisible: Boolean = true,
    /** Dipanggil saat tab yang sedang terpilih diketuk lagi. */
    onReselect: ((Int) -> Unit)? = null,
) {
    val count = tabs.size
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val containerColor =
        if (dark) Color(0xFF121212).copy(alpha = 0.4f) else Color(0xFFFAFAFA).copy(alpha = 0.4f)
    val surface = MaterialTheme.colorScheme.surfaceContainer
    val inactive = MaterialTheme.colorScheme.onSurfaceVariant
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    val currentSelected by rememberUpdatedState(selectedIndex)
    val currentOnSelect by rememberUpdatedState(onSelect)
    val currentOnReselect by rememberUpdatedState(onReselect)
    val currentLensVisible by rememberUpdatedState(lensVisible)
    val lensRest = animateFloatAsState(if (lensVisible) 1f else 0f, animationSpec = tween(220), label = "lensRest")

    val thumb = remember(scope, count) {
        DampedThumb(scope, selectedIndex.toFloat(), (count - 1).toFloat())
    }
    val offsetAnim = remember { Animatable(0f) }
    // Panel kaca ikut penyet saat disentuh (ketuk atau geser) dan membal bergoyang saat dilepas.
    val panelSX = remember { Animatable(1f) }
    val panelSY = remember { Animatable(1f) }
    val panelDown: () -> Unit = {
        scope.launch { panelSX.animateTo(1.025f, spring(dampingRatio = 0.6f, stiffness = 900f)) }
        scope.launch { panelSY.animateTo(0.93f, spring(dampingRatio = 0.6f, stiffness = 900f)) }
    }
    val panelUp: () -> Unit = {
        scope.launch { panelSX.animateTo(1f, spring(dampingRatio = 0.28f, stiffness = 380f)) }
        scope.launch { panelSY.animateTo(1f, spring(dampingRatio = 0.24f, stiffness = 420f)) }
    }
    var barSize by remember { mutableStateOf(IntSize.Zero) }
    var barOrigin by remember { mutableStateOf(Offset.Zero) }
    val panelLayer = rememberGraphicsLayer()
    val barLayer = rememberGraphicsLayer()
    val fx = remember { FxState() }
    val panelShader = remember { if (Build.VERSION.SDK_INT >= 33) LensShader() else null }
    val thumbShader = remember { if (Build.VERSION.SDK_INT >= 33) LensShader() else null }
    val pillShape = RoundedCornerShape(50)
    val rimEdge = if (dark) Color.White else Color.Black

    val padPx = with(density) { 4.dp.toPx() }
    val maxShift = with(density) { 4.dp.toPx() }
    val tabWidthPx: () -> Float = { ((barSize.width - 2f * padPx) / count).coerceAtLeast(1f) }
    val panelOffsetPx: () -> Float = {
        val w = barSize.width.toFloat()
        if (w <= 0f) {
            0f
        } else {
            val f = (offsetAnim.value / w).coerceIn(-1f, 1f)
            maxShift * sign(f) * EaseOut.transform(abs(f))
        }
    }
    // Lensa memipih/memanjang sesuai kecepatan (efek jeli).
    val thumbSX: () -> Float = {
        val v = thumb.velocity / 10f
        thumb.scaleX / (1f - (v * 0.75f).coerceIn(-0.2f, 0.2f))
    }
    val thumbSY: () -> Float = {
        val v = thumb.velocity / 10f
        thumb.scaleY * (1f - (v * 0.25f).coerceIn(-0.2f, 0.2f))
    }

    LaunchedEffect(selectedIndex) {
        if (abs(thumb.target - selectedIndex) > 0.01f) {
            thumb.animateTo(selectedIndex.toFloat())
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(start = 16.dp, end = 16.dp, top = 6.dp, bottom = 10.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(LiquidBarHeight)
                .onSizeChanged { barSize = it }
                .onGloballyPositioned { barOrigin = it.positionInRoot() }
                .pointerInput(count) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        val pad = 4.dp.toPx()
                        val tabW = ((size.width - 2f * pad) / count).coerceAtLeast(1f)
                        val thumbCenter = pad + (thumb.value + 0.5f) * tabW
                        val onThumb = currentLensVisible && abs(down.position.x - thumbCenter) <= tabW / 2f
                        val slop = viewConfiguration.touchSlop
                        val maxIdx = (count - 1).toFloat()
                        var dragging = false
                        var lastX = down.position.x
                        var pos = thumb.target
                        var lastNear = pos.roundToInt()
                        if (onThumb) thumb.press()
                        panelDown()

                        fun stopThumb() {
                            val idx = pos.roundToInt().coerceIn(0, count - 1)
                            if (idx != currentSelected) currentOnSelect(idx)
                            thumb.animateTo(idx.toFloat())
                            scope.launch { offsetAnim.animateTo(0f, spring<Float>(1f, 300f, 0.5f)) }
                        }

                        while (true) {
                            val event = awaitPointerEvent()
                            val change = event.changes.firstOrNull { it.id == down.id }
                            if (change == null || change.isConsumed) {
                                if (onThumb) stopThumb()
                                panelUp()
                                break
                            }
                            if (!change.pressed) {
                                if (onThumb) {
                                    if (!dragging && pos.roundToInt().coerceIn(0, count - 1) == currentSelected) {
                                        currentOnReselect?.invoke(currentSelected)
                                    }
                                    stopThumb()
                                } else if (abs(change.position.x - down.position.x) <= slop * 2f) {
                                    val idx = ((change.position.x - pad) / tabW).toInt().coerceIn(0, count - 1)
                                    if (idx != currentSelected) {
                                        currentOnSelect(idx)
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    } else {
                                        currentOnReselect?.invoke(idx)
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                    }
                                    thumb.animateTo(idx.toFloat())
                                }
                                panelUp()
                                break
                            }
                            if (onThumb) {
                                if (!dragging && abs(change.position.x - down.position.x) > slop) {
                                    dragging = true
                                    lastX = change.position.x
                                }
                                if (dragging) {
                                    change.consume()
                                    val dx = change.position.x - lastX
                                    lastX = change.position.x
                                    pos = (pos + dx / tabW).coerceIn(0f, maxIdx)
                                    thumb.updateValue(pos)
                                    scope.launch { offsetAnim.snapTo(offsetAnim.value + dx) }
                                    val near = pos.roundToInt()
                                    if (near != lastNear) {
                                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        lastNear = near
                                    }
                                }
                            }
                        }
                    }
                },
            contentAlignment = Alignment.CenterStart,
        ) {
            // ===== Panel kaca =====
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationX = panelOffsetPx()
                        val s = 1f + (16.dp.toPx() / size.width.coerceAtLeast(1f)) * thumb.pressProgress
                        scaleX = s * panelSX.value
                        scaleY = s * panelSY.value
                    }
                    .shadow(
                        elevation = 14.dp,
                        shape = pillShape,
                        clip = false,
                        ambientColor = Color.Black.copy(alpha = 0.30f),
                        spotColor = Color.Black.copy(alpha = 0.30f),
                    )
                    .drawBehind {
                        val w = size.width
                        val h = size.height
                        if (w > 0f && h > 0f) {
                            val m = 24.dp.toPx()
                            val clipShape = Path().apply {
                                addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(h / 2f, h / 2f)))
                            }
                            clipPath(clipShape) {
                                if (backdrop != null) {
                                    @Suppress("UNUSED_VARIABLE")
                                    val t = backdrop.tick
                                    val off = barOrigin - backdrop.origin
                                    panelLayer.record(IntSize(w.roundToInt(), h.roundToInt())) {
                                        translate(left = -off.x, top = -off.y) { drawLayer(backdrop.layer) }
                                    }
                                    // lapisan latar lebih besar (margin m) supaya lensa yang membesar
                                    // melewati tepi bar tetap melihat latar yang blur.
                                    barLayer.record(IntSize((w + 2 * m).roundToInt(), (h + 2 * m).roundToInt())) {
                                        translate(left = -off.x + m, top = -off.y + m) { drawLayer(backdrop.layer) }
                                    }
                                    if (Build.VERSION.SDK_INT >= 31) {
                                        val blurPx = 8.dp.toPx()
                                        if (!fx.barSet) {
                                            barLayer.renderEffect = blurVibrancy(blurPx).asComposeRenderEffect()
                                            fx.barSet = true
                                        }
                                        if (fx.w != w || fx.h != h) {
                                            panelLayer.renderEffect = if (Build.VERSION.SDK_INT >= 33) {
                                                panelShader!!.effect(
                                                    w, h, h / 2f, 24.dp.toPx(), 24.dp.toPx(), 0f,
                                                    blurVibrancy(blurPx),
                                                )
                                            } else {
                                                blurVibrancy(blurPx).asComposeRenderEffect()
                                            }
                                            fx.w = w
                                            fx.h = h
                                        }
                                    }
                                    drawLayer(panelLayer)
                                } else {
                                    drawRect(surface)
                                }
                                drawRect(containerColor)
                                // kilau mengikuti lensa saat ditekan
                                val gp = thumb.pressProgress
                                if (gp > 0.001f) {
                                    drawRect(Color.White.copy(alpha = 0.08f * gp), blendMode = BlendMode.Plus)
                                    val cx = padPx + (thumb.value + 0.5f) * tabWidthPx()
                                    drawRect(
                                        brush = Brush.radialGradient(
                                            colors = listOf(Color.White.copy(alpha = 0.15f * gp), Color.Transparent),
                                            center = Offset(cx, h / 2f),
                                            radius = h * 1.5f,
                                        ),
                                        blendMode = BlendMode.Plus,
                                    )
                                }
                            }
                        }
                    }
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                Color.White.copy(alpha = if (dark) 0.50f else 0.90f),
                                rimEdge.copy(alpha = if (dark) 0.05f else 0.08f),
                                Color.White.copy(alpha = if (dark) 0.28f else 0.60f),
                            ),
                        ),
                        pillShape,
                    ),
            ) {
                TabsRow(
                    tabs = tabs,
                    selectedIndex = selectedIndex,
                    allSelected = false,
                    tint = inactive,
                    a11y = true,
                    tabScale = { 1f },
                    onSelect = { currentOnSelect(it) },
                    modifier = Modifier.padding(horizontal = 4.dp),
                )
            }

            // ===== Lensa =====
            Box(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .fillMaxWidth(1f / count)
                    .height(LensHeight)
                    .graphicsLayer {
                        val p = thumb.pressProgress
                        alpha = maxOf(lensRest.value, p.coerceIn(0f, 1f))
                        translationX = thumb.value * size.width + panelOffsetPx()
                        scaleX = thumbSX()
                        scaleY = thumbSY()
                        shadowElevation = 14.dp.toPx() * p
                        this.shape = pillShape
                        clip = false
                        ambientShadowColor = Color.Black.copy(alpha = 0.25f)
                        spotShadowColor = Color.Black.copy(alpha = 0.25f)
                    }
                    .drawWithContent {
                        drawContent()
                        // tepi bercahaya, hanya saat ditekan (digambar di luar lapisan pembiasan)
                        val p = thumb.pressProgress
                        if (p > 0.01f) {
                            val r = size.height / 2f
                            drawRoundRect(
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.White.copy(alpha = 0.95f * p),
                                        Color.White.copy(alpha = 0.10f * p),
                                        Color.White.copy(alpha = 0.55f * p),
                                    ),
                                    start = Offset(0f, 0f),
                                    end = Offset(size.width, size.height),
                                ),
                                cornerRadius = CornerRadius(r, r),
                                style = Stroke(1.5.dp.toPx()),
                            )
                        }
                    },
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            this.shape = pillShape
                            clip = true
                            val p = thumb.pressProgress
                            renderEffect = if (Build.VERSION.SDK_INT >= 33 && p > 0.01f) {
                                thumbShader!!.effect(
                                    size.width, size.height, size.height / 2f,
                                    10.dp.toPx() * p, 14.dp.toPx() * p, 1f, null,
                                )
                            } else {
                                null
                            }
                        }
                        .drawBehind {
                            val m = 24.dp.toPx()
                            val tabW = tabWidthPx()
                            val p = thumb.pressProgress
                            // latar blur digambar dengan skala kebalikan supaya tidak ikut membesar
                            scale(1f / thumbSX(), 1f / thumbSY(), pivot = center) {
                                if (backdrop != null) {
                                    translate(
                                        left = -(padPx + thumb.value * tabW) - m,
                                        top = -padPx - m,
                                    ) { drawLayer(barLayer) }
                                }
                            }
                            if (backdrop == null) drawRect(surface)
                            drawRect(containerColor)
                            drawRect(
                                (if (dark) Color.White else Color.Black).copy(alpha = 0.10f * (1f - p)),
                            )
                            drawRect(Color.Black.copy(alpha = 0.03f * p))
                        },
                ) {
                    // Tab merah: baris yang sama, digeser agar sejajar dengan bilah, hanya terlihat di dalam lensa.
                    Box(
                        modifier = Modifier
                            .layout { measurable, constraints ->
                                val w = barSize.width.coerceAtLeast(1)
                                val h = barSize.height.coerceAtLeast(1)
                                val placeable = measurable.measure(Constraints.fixed(w, h))
                                layout(constraints.maxWidth, constraints.maxHeight) {
                                    placeable.place(0, 0)
                                }
                            }
                            .graphicsLayer {
                                val tabW = tabWidthPx()
                                val v = thumb.value
                                val cx = padPx + (v + 0.5f) * tabW
                                transformOrigin = TransformOrigin(cx / size.width.coerceAtLeast(1f), 0.5f)
                                scaleX = 1f / thumbSX()
                                scaleY = 1f / thumbSY()
                                translationX = -(padPx + v * tabW)
                                translationY = -padPx
                            },
                    ) {
                        TabsRow(
                            tabs = tabs,
                            selectedIndex = selectedIndex,
                            allSelected = true,
                            tint = LiquidRed,
                            a11y = false,
                            tabScale = { 1f + 0.2f * thumb.pressProgress },
                            onSelect = {},
                            modifier = Modifier.padding(horizontal = 4.dp),
                        )
                    }
                }
            }
        }
    }
}


/**
 * Latar kapsul kaca yang sama dengan panel nav bar (blur + vibrancy + pembiasan di tepi + tepi bercahaya + bayangan).
 * Dipakai oleh pemutar mini supaya senada dengan bilah navigasi.
 */
@Composable
fun Modifier.liquidGlass(
    backdrop: LiquidBackdrop?,
    tintAlpha: Float = 0.4f,
    saturation: Float = 1.5f,
): Modifier {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val containerColor =
        if (dark) Color(0xFF121212).copy(alpha = tintAlpha) else Color(0xFFFAFAFA).copy(alpha = tintAlpha)
    val surface = MaterialTheme.colorScheme.surfaceContainer
    val rimEdge = if (dark) Color.White else Color.Black
    val layer = rememberGraphicsLayer()
    val fx = remember { FxState() }
    val shader = remember { if (Build.VERSION.SDK_INT >= 33) LensShader() else null }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val shape = RoundedCornerShape(50)
    return this
        .shadow(
            elevation = 12.dp,
            shape = shape,
            clip = false,
            ambientColor = Color.Black.copy(alpha = 0.30f),
            spotColor = Color.Black.copy(alpha = 0.30f),
        )
        .onGloballyPositioned { origin = it.positionInRoot() }
        .drawBehind {
            val w = size.width
            val h = size.height
            if (w > 0f && h > 0f) {
                val clipShape = Path().apply {
                    addRoundRect(RoundRect(0f, 0f, w, h, CornerRadius(h / 2f, h / 2f)))
                }
                clipPath(clipShape) {
                    if (backdrop != null) {
                        @Suppress("UNUSED_VARIABLE")
                        val t = backdrop.tick
                        val off = origin - backdrop.origin
                        layer.record(IntSize(w.roundToInt(), h.roundToInt())) {
                            translate(left = -off.x, top = -off.y) { drawLayer(backdrop.layer) }
                        }
                        if (Build.VERSION.SDK_INT >= 31 && (fx.w != w || fx.h != h)) {
                            val blurPx = 8.dp.toPx()
                            layer.renderEffect = if (Build.VERSION.SDK_INT >= 33) {
                                shader!!.effect(
                                    w, h, h / 2f, 24.dp.toPx(), 24.dp.toPx(), 0f,
                                    blurVibrancy(blurPx, saturation),
                                )
                            } else {
                                blurVibrancy(blurPx, saturation).asComposeRenderEffect()
                            }
                            fx.w = w
                            fx.h = h
                        }
                        drawLayer(layer)
                    } else {
                        drawRect(surface)
                    }
                    drawRect(containerColor)
                }
            }
        }
        .border(
            1.dp,
            Brush.linearGradient(
                listOf(
                    Color.White.copy(alpha = if (dark) 0.50f else 0.90f),
                    rimEdge.copy(alpha = if (dark) 0.05f else 0.08f),
                    Color.White.copy(alpha = if (dark) 0.28f else 0.60f),
                ),
            ),
            shape,
        )
}

/** Jarak bawah kapsul navigasi ke tepi area aman (lihat padding bawah di [LiquidNavBar]). */
private val FadeBarGap = 10.dp

/**
 * Fade + blur bertingkat di tepi bawah layar, tepat di belakang tombol navigasi sistem. Gayanya seperti
 * fade di tepi atas Auralys tetapi lebih pendek: tingginya = inset navigasi sistem + [FadeBarGap] + [extra],
 * jadi tipis pada navigasi gestur dan sedikit lebih tinggi pada navigasi 3 tombol. Bagian paling bawah
 * hampir penuh berwarna latar (tombol sistem terbaca), makin ke atas makin transparan dan tak berblur.
 * Blur butuh Android 12+; di bawahnya hanya gradasi warna latar. Tidak menangkap sentuhan.
 */
@Composable
fun BottomEdgeFade(
    backdrop: LiquidBackdrop?,
    modifier: Modifier = Modifier,
    extra: Dp = 14.dp,
    /** Blur butuh satu lapisan render ekstra setiap frame; dimatikan supaya scroll tetap mulus. */
    blur: Boolean = false,
) {
    val bg = MaterialTheme.colorScheme.background
    val inset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val layer = rememberGraphicsLayer()
    val fx = remember { FxState() }
    var origin by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(inset + FadeBarGap + extra)
            .onGloballyPositioned { origin = it.positionInRoot() }
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                val w = size.width
                val h = size.height
                if (w > 0f && h > 0f) {
                    if (blur && backdrop != null && Build.VERSION.SDK_INT >= 31) {
                        @Suppress("UNUSED_VARIABLE")
                        val t = backdrop.tick
                        val off = origin - backdrop.origin
                        layer.record(IntSize(w.roundToInt(), h.roundToInt())) {
                            translate(left = -off.x, top = -off.y) { drawLayer(backdrop.layer) }
                        }
                        if (fx.w != w || fx.h != h) {
                            layer.renderEffect = blurVibrancy(6.dp.toPx(), 1f).asComposeRenderEffect()
                            fx.w = w
                            fx.h = h
                        }
                        drawLayer(layer)
                    }
                    // Warna latar menutup isi di bawahnya, lebih pekat ke arah tepi bawah.
                    drawRect(
                        Brush.verticalGradient(
                            0f to bg.copy(alpha = 0.30f),
                            1f to bg.copy(alpha = 0.92f),
                        ),
                    )
                    // Topeng: transparan di atas, penuh di bagian tombol sistem.
                    drawRect(
                        brush = Brush.verticalGradient(
                            0f to Color.Transparent,
                            0.65f to Color.Black,
                            1f to Color.Black,
                        ),
                        blendMode = BlendMode.DstIn,
                    )
                }
            },
    )
}
