package app.mixbase.ui

import android.content.Context
import android.graphics.drawable.BitmapDrawable
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import coil.Coil
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/*
 * Efek latar "warna sampul": warna dominan gambar lagu/video yang sedang aktif dipakai sebagai
 * gradasi lembut yang memudar ke permukaan (dipakai di semua layar dan layar Sedang Diputar).
 */

/** Warna rata-rata (sedikit dipertegas) dari gambar [url]; null bila gagal dimuat. */
private suspend fun artColorOf(context: Context, url: String): Color? = withContext(Dispatchers.Default) {
    try {
        val request = ImageRequest.Builder(context)
            .data(url)
            .size(48)
            .allowHardware(false)
            .build()
        val result = Coil.imageLoader(context).execute(request)
        val bmp = (result.drawable as? BitmapDrawable)?.bitmap ?: return@withContext null
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0) return@withContext null
        val stepX = if (w / 24 > 1) w / 24 else 1
        val stepY = if (h / 24 > 1) h / 24 else 1
        var r = 0L
        var g = 0L
        var b = 0L
        var n = 0L
        var y = 0
        while (y < h) {
            var x = 0
            while (x < w) {
                val p = bmp.getPixel(x, y)
                r += ((p shr 16) and 0xFF).toLong()
                g += ((p shr 8) and 0xFF).toLong()
                b += (p and 0xFF).toLong()
                n += 1L
                x += stepX
            }
            y += stepY
        }
        if (n == 0L) return@withContext null
        val argb = android.graphics.Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(argb, hsv)
        hsv[1] = (hsv[1] * 1.3f).coerceAtMost(1f)
        hsv[2] = hsv[2].coerceIn(0.32f, 0.9f)
        Color(android.graphics.Color.HSVToColor(hsv))
    } catch (e: Exception) {
        null
    }
}

/**
 * Warna sampul dari [url] (berganti mulus saat lagu berganti). Selama belum ada / tidak ada gambar,
 * dipakai warna utama tema.
 */
@Composable
fun rememberArtColor(url: String?): Color {
    val context = LocalContext.current.applicationContext
    var loaded by remember { mutableStateOf(Color.Unspecified) }
    LaunchedEffect(url) {
        if (url != null) {
            val c = artColorOf(context, url)
            if (c != null) loaded = c
        }
    }
    val fallback = MaterialTheme.colorScheme.primary
    val target = if (loaded == Color.Unspecified) fallback else loaded
    val animated by animateColorAsState(targetValue = target, animationSpec = tween(700), label = "artColor")
    return animated
}

/** Warna sampul yang sedang aktif, dibaca oleh bilah atas supaya menyatu dengan gradasi latar. */
object AmbientState {
    var color by mutableStateOf(Color.Unspecified)
}

/** Warna bilah atas: warna latar [base] yang diberi sedikit warna sampul (selaras dengan [AmbientBackdrop]). */
@Composable
fun ambientTopTint(base: Color): Color {
    val c = AmbientState.color
    if (c == Color.Unspecified) return base
    val dark = base.luminance() < 0.5f
    val amount = (if (dark) 0.42f else 0.30f) * 0.85f
    return lerp(base, c, amount)
}

/** Brush gradasi latar dari warna sampul aktif (dipakai layar yang punya latar sendiri, mis. halaman tonton). */
@Composable
fun ambientBrush(): Brush {
    val c = AmbientState.color
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val a = if (dark) 0.42f else 0.30f
    val base = if (c == Color.Unspecified) Color.Transparent else c
    return Brush.verticalGradient(
        0f to base.copy(alpha = a),
        0.5f to base.copy(alpha = a * 0.35f),
        1f to Color.Transparent,
    )
}

/** Gradasi lembut dari [color] di bagian atas yang memudar ke transparan (latar semua layar). */
@Composable
fun AmbientBackdrop(color: Color, modifier: Modifier = Modifier) {
    val dark = MaterialTheme.colorScheme.background.luminance() < 0.5f
    val a = if (dark) 0.42f else 0.30f
    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0f to color.copy(alpha = a),
                    0.5f to color.copy(alpha = a * 0.35f),
                    1f to Color.Transparent,
                ),
            ),
    )
}
