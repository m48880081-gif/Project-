package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.Links
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection

/**
 * Layar pencarian (tab Cari, atau layar penuh bila [showBack]). [music] true: cari lagu/album/artis (hasil diputar di pemutar musik);
 * false: cari video (hasil dibuka di halaman tonton).
 */
@Composable
fun SearchScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
    music: Boolean,
    onBack: () -> Unit,
    onOpenEntry: (Entry) -> Unit,
    showBack: Boolean = true,
) {
    val searcher = if (music) vm.musicSearch else vm.videoSearch
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }

    // Ruang di bawah: bilah navigasi melayang, atau papan ketik bila sedang terbuka.
    val barPad = LocalBarPadding.current
    val imeBottom = WindowInsets.ime.asPaddingValues().calculateBottomPadding()
    val bottomPad = if (imeBottom > barPad) imeBottom else barPad

    BackHandler(enabled = showBack, onBack = onBack)

    // Buka dengan kolom pencarian aktif bila belum ada hasil.
    LaunchedEffect(Unit) {
        if (!searcher.searched) focusRequester.requestFocus()
    }

    // Muat halaman berikutnya saat daftar hampir habis.
    val nearEnd by remember(searcher) {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            searcher.resultCount > 0 && last >= searcher.resultCount - 4
        }
    }
    LaunchedEffect(nearEnd, searcher.resultCount) {
        if (nearEnd) searcher.loadMore()
    }

    val doSearch: (String) -> Unit = { q ->
        if (Links.parse(q) != null) {
            // Link YouTube yang ditempel: langsung dibuka, bukan dicari.
            vm.openLink(q)
            searcher.onQueryChange("")
        } else {
            searcher.search(q)
        }
        keyboard?.hide()
        focus.clearFocus()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = if (showBack) 4.dp else 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (showBack) {
                    IconButton(onClick = onBack) {
                        Icon(
                            painter = painterResource(R.drawable.ic_arrow_back),
                            contentDescription = "Kembali",
                        )
                    }
                }
                OutlinedTextField(
                    value = searcher.query,
                    onValueChange = { searcher.onQueryChange(it) },
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester)
                        .onFocusChanged { focused = it.isFocused },
                    placeholder = { Text(if (music) "Cari lagu, album, atau artis" else "Cari video") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searcher.query.isNotEmpty()) {
                            IconButton(onClick = { searcher.onQueryChange("") }) {
                                Icon(Icons.Filled.Close, contentDescription = "Hapus")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { doSearch(searcher.query) }),
                )
            }

            if (music) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = searcher.filter == Engine.FILTER_MUSIC,
                        onClick = { searcher.updateFilter(Engine.FILTER_MUSIC) },
                        label = { Text("Lagu") },
                    )
                    FilterChip(
                        selected = searcher.filter == Engine.FILTER_ALBUM,
                        onClick = { searcher.updateFilter(Engine.FILTER_ALBUM) },
                        label = { Text("Album") },
                    )
                    FilterChip(
                        selected = searcher.filter == Engine.FILTER_ARTIST,
                        onClick = { searcher.updateFilter(Engine.FILTER_ARTIST) },
                        label = { Text("Artis") },
                    )
                }
            }

            Box(Modifier.weight(1f)) {
                when {
                    searcher.loading -> {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            PlayLoader()
                        }
                    }

                    searcher.error != null -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                text = searcher.error ?: "",
                                style = MaterialTheme.typography.bodyLarge,
                                textAlign = TextAlign.Center,
                            )
                            Button(
                                onClick = { searcher.search() },
                                modifier = Modifier.padding(top = 16.dp),
                            ) {
                                Text("Coba lagi")
                            }
                        }
                    }

                    searcher.searched -> {
                        ResultList(vm, player, actions, searcher, music, listState, bottomPad, onOpenEntry)
                    }
                }

                // Panel awal / saat kolom fokus: kotak besar (riwayat pencarian + saran) dan
                // kotak kecil di bawahnya (video atau lagu yang bisa digeser ke samping).
                if (focused || !searcher.searched) {
                    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                        SearchPanel(vm, player, actions, searcher, music, bottomPad, doSearch)
                    }
                }
            }
        }
    }
}

/** Satu baris riwayat/saran pencarian. [onRemove] null = saran (tanpa tombol hapus). */
@Composable
private fun QueryRow(text: String, history: Boolean, onClick: () -> Unit, onRemove: (() -> Unit)?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .clickable(onClick = onClick)
            .padding(start = 20.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (history) {
            Icon(
                painter = painterResource(R.drawable.ic_history),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
        } else {
            Icon(
                Icons.Filled.Search,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp),
            )
        }
        Text(
            text = text,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            style = MaterialTheme.typography.bodyLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (onRemove != null) {
            IconButton(onClick = onRemove) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Hapus dari riwayat",
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

/**
 * Isi panel pencarian: kotak besar berisi riwayat pencarian dan saran; di bawahnya kotak kecil berisi
 * video (mode Video) atau lagu (mode Musik): riwayat tontonan/putar saat kolom kosong, atau pratinjau
 * hasil untuk kata kunci yang sedang diketik. Baris kecil itu bisa digeser ke samping.
 */
@Composable
private fun SearchPanel(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
    searcher: Searcher,
    music: Boolean,
    bottomPad: Dp,
    onSearch: (String) -> Unit,
) {
    val q = searcher.query.trim()
    val typing = q.length >= 2
    val hist: List<String> = if (typing) {
        searcher.history.filter { it.contains(q, ignoreCase = true) && !it.equals(q, ignoreCase = true) }.take(4)
    } else {
        searcher.history.take(10)
    }
    val sugg: List<String> = if (typing) {
        searcher.suggestions.filter { s -> hist.none { it.equals(s, ignoreCase = true) } }
    } else {
        emptyList()
    }
    val recent: List<Track> = if (music) vm.history.take(15).toList() else vm.videoHistory.take(15).toList()
    val usePreview = q.length >= 3
    val shelf: List<Track> = if (usePreview) searcher.preview.toList() else recent
    val shelfTitle = when {
        usePreview && music -> "Lagu untuk \"$q\""
        usePreview -> "Video untuk \"$q\""
        music -> "Terakhir diputar"
        else -> "Terakhir ditonton"
    }
    val shelfEmpty = when {
        usePreview -> "Tidak ada hasil."
        music -> "Lagu yang kamu putar muncul di sini."
        else -> "Video yang kamu tonton muncul di sini."
    }

    Column(
        Modifier
            .fillMaxSize()
            .padding(bottom = bottomPad),
    ) {
        // Kotak besar: riwayat pencarian + saran
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            if (!typing && hist.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(start = 20.dp, end = 8.dp, top = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "Pencarian terakhir",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { searcher.clearHistory() }) {
                            Text("Hapus semua")
                        }
                    }
                }
            }
            itemsIndexed(hist, key = { _, h -> "h:$h" }) { _, h ->
                QueryRow(h, true, { onSearch(h) }, { searcher.removeHistory(h) })
            }
            itemsIndexed(sugg, key = { i, s -> "s$i:$s" }) { _, s ->
                QueryRow(s, false, { onSearch(s) }, null)
            }
            if (hist.isEmpty() && sugg.isEmpty()) {
                item {
                    Text(
                        text = if (music) "Cari lagu, album, atau artis." else "Cari video, channel, atau film.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp),
                    )
                }
            }
        }

        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

        // Kotak kecil: video / lagu, geser ke samping
        Text(
            text = shelfTitle,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 8.dp),
        )
        if (shelf.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                contentAlignment = Alignment.Center,
            ) {
                if (usePreview && searcher.previewLoading) {
                    PlayLoader(diameter = 28.dp)
                } else {
                    Text(
                        text = shelfEmpty,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        } else {
            LazyRow(
                modifier = Modifier.padding(bottom = 10.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                itemsIndexed(shelf, key = { i, t -> "${t.url}#$i" }) { i, t ->
                    if (music) {
                        MiniSongCard(t) { player.playQueue(shelf, i) }
                    } else {
                        MiniVideoCard(t) { actions.open(t) }
                    }
                }
            }
        }
    }
}

/** Kartu video kecil (16:9) untuk baris geser samping. */
@Composable
fun MiniVideoCard(t: Track, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(168.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            ThumbImage(t.thumb, t.url, Modifier.fillMaxSize())
            if (!t.live && t.durationSec > 0L) {
                Text(
                    text = clock(t.durationSec),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(6.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.8f))
                        .padding(horizontal = 4.dp, vertical = 1.dp),
                )
            }
        }
        Text(
            text = t.title,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp),
        )
        Text(
            text = t.artist,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Kartu lagu kecil (persegi) untuk baris geser samping. */
@Composable
fun MiniSongCard(t: Track, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(120.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
    ) {
        Thumb(t.thumb, 120.dp, pageUrl = t.url)
        Text(
            text = t.title,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Medium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp),
        )
        Text(
            text = t.artist,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
private fun ResultList(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
    searcher: Searcher,
    music: Boolean,
    listState: LazyListState,
    bottomPad: Dp,
    onOpenEntry: (Entry) -> Unit,
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = bottomPad + 8.dp),
    ) {
        itemsIndexed(searcher.entries, key = { i, e -> "${e.url}#e$i" }) { _, e ->
            EntryRow(e) { onOpenEntry(e) }
        }
        itemsIndexed(searcher.tracks, key = { i, t -> "${t.url}#$i" }) { i, t ->
            if (music) {
                TrackItem(vm, player, t) {
                    player.playQueue(searcher.tracks.toList(), i)
                }
            } else {
                VideoCardFor(t, actions)
            }
        }
        if (searcher.loadingMore) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    PlayLoader()
                }
            }
        }
    }
}

@Composable
fun TrackItem(vm: AppViewModel, player: PlayerConnection, track: Track, onPlay: () -> Unit) {
    TrackRow(
        track = track,
        playing = player.current?.url == track.url,
        favorite = vm.isFavorite(track.url),
        onClick = onPlay,
        onToggleFavorite = { vm.toggleFavorite(track) },
        onPlayNext = { player.playNext(track) },
        onAddToQueue = { player.addToQueue(track) },
    )
}
