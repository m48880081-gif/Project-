package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection

/**
 * Layar pencarian penuh. [music] true: cari lagu/album/artis (hasil diputar di pemutar musik);
 * false: cari video (hasil dibuka di halaman tonton).
 */
@Composable
fun SearchScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
    music: Boolean,
    onBack: () -> Unit,
    onOpenEntry: (Entry) -> Unit,
) {
    val searcher = if (music) vm.musicSearch else vm.videoSearch
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    var focused by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    // Buka dengan kolom pencarian aktif bila belum ada hasil.
    LaunchedEffect(Unit) {
        if (!searcher.searched) focusRequester.requestFocus()
    }

    // Muat halaman berikutnya saat daftar hampir habis.
    val nearEnd by remember(searcher) {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            searcher.resultCount > 0 && last >= searcher.resultCount - 4
        }
    }
    LaunchedEffect(nearEnd, searcher.resultCount) {
        if (nearEnd) searcher.loadMore()
    }

    val doSearch: (String) -> Unit = { q ->
        searcher.search(q)
        keyboard?.hide()
        focus.clearFocus()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier.fillMaxSize(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 4.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        painter = painterResource(R.drawable.ic_arrow_back),
                        contentDescription = "Kembali",
                    )
                }
                OutlinedTextField(
                    value = searcher.query,
                    onValueChange = { searcher.onQueryChange(it) },
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester)
                        .onFocusChanged { focused = it.isFocused },
                    placeholder = { Text(if (music) "Cari lagu, album, atau artis" else "Cari video") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searcher.query.isNotEmpty()) {
                            IconButton(onClick = { searcher.onQueryChange("") }) {
                                Icon(Icons.Filled.Close, contentDescription = "Hapus")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { doSearch(searcher.query) }),
                )
            }

            if (music) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = searcher.filter == Engine.FILTER_MUSIC,
                        onClick = { searcher.updateFilter(Engine.FILTER_MUSIC) },
                        label = { Text("Lagu") },
                    )
                    FilterChip(
                        selected = searcher.filter == Engine.FILTER_ALBUM,
                        onClick = { searcher.updateFilter(Engine.FILTER_ALBUM) },
                        label = { Text("Album") },
                    )
                    FilterChip(
                        selected = searcher.filter == Engine.FILTER_ARTIST,
                        onClick = { searcher.updateFilter(Engine.FILTER_ARTIST) },
                        label = { Text("Artis") },
                    )
                }
            }

            Box(Modifier.weight(1f)) {
                when {
                    searcher.loading -> {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator()
                        }
                    }

                    searcher.error != null -> {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(
                                text = searcher.error ?: "",
                                style = MaterialTheme.typography.bodyLarge,
                                textAlign = TextAlign.Center,
                            )
                            Button(
                                onClick = { searcher.search() },
                                modifier = Modifier.padding(top = 16.dp),
                            ) {
                                Text("Coba lagi")
                            }
                        }
                    }

                    !searcher.searched -> {
                        StartContent(vm, player, actions, music)
                    }

                    else -> {
                        ResultList(vm, player, actions, searcher, music, listState, onOpenEntry)
                    }
                }

                // Saran pencarian menimpa daftar saat kolom sedang fokus
                if (focused && searcher.suggestions.isNotEmpty()) {
                    Surface(Modifier.fillMaxSize()) {
                        LazyColumn(Modifier.fillMaxSize()) {
                            itemsIndexed(searcher.suggestions) { _, s ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { doSearch(s) }
                                        .padding(horizontal = 20.dp, vertical = 14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Icon(
                                        Icons.Filled.Search,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    Text(
                                        text = s,
                                        modifier = Modifier.padding(start = 16.dp),
                                        style = MaterialTheme.typography.bodyLarge,
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultList(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
    searcher: Searcher,
    music: Boolean,
    listState: LazyListState,
    onOpenEntry: (Entry) -> Unit,
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 8.dp),
    ) {
        itemsIndexed(searcher.entries, key = { i, e -> "${e.url}#e$i" }) { _, e ->
            EntryRow(e) { onOpenEntry(e) }
        }
        itemsIndexed(searcher.tracks, key = { i, t -> "${t.url}#$i" }) { i, t ->
            if (music) {
                TrackItem(vm, player, t) {
                    player.playQueue(searcher.tracks.toList(), i)
                }
            } else {
                VideoCardFor(t, actions)
            }
        }
        if (searcher.loadingMore) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}

/** Layar awal sebelum mencari: riwayat terakhir (jika ada). */
@Composable
private fun StartContent(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
    music: Boolean,
) {
    val recentTracks: List<Track> = if (music) vm.history.take(15).toList() else vm.videoHistory.take(10).toList()

    if (recentTracks.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = if (music) "Mulai dengan mencari lagu atau artis" else "Mulai dengan mencari video",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Text(
                text = if (music) {
                    "Hasil pencarian diputar sebagai antrean, dan tetap berjalan di latar belakang."
                } else {
                    "Video dibuka di halaman tonton dengan kualitas HD."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    } else {
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Text(
                    text = if (music) "Terakhir diputar" else "Terakhir ditonton",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
                )
            }
            itemsIndexed(recentTracks, key = { i, t -> "${t.url}#$i" }) { i, t ->
                if (music) {
                    TrackItem(vm, player, t) {
                        player.playQueue(recentTracks, i)
                    }
                } else {
                    VideoCardFor(t, actions)
                }
            }
        }
    }
}

@Composable
fun TrackItem(vm: AppViewModel, player: PlayerConnection, track: Track, onPlay: () -> Unit) {
    TrackRow(
        track = track,
        playing = player.current?.url == track.url,
        favorite = vm.isFavorite(track.url),
        onClick = onPlay,
        onToggleFavorite = { vm.toggleFavorite(track) },
        onPlayNext = { player.playNext(track) },
        onAddToQueue = { player.addToQueue(track) },
    )
}
