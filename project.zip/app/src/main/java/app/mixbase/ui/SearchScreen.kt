package app.mixbase.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.mixbase.data.Engine
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(vm: AppViewModel, player: PlayerConnection) {
    val keyboard = LocalSoftwareKeyboardController.current
    val focus = LocalFocusManager.current
    val listState = rememberLazyListState()
    var focused by remember { mutableStateOf(false) }

    // Muat halaman berikutnya saat daftar hampir habis.
    val nearEnd by remember {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            vm.results.isNotEmpty() && last >= vm.results.size - 4
        }
    }
    LaunchedEffect(nearEnd, vm.results.size) {
        if (nearEnd) vm.loadMore()
    }

    val doSearch: (String) -> Unit = { q ->
        vm.search(q)
        keyboard?.hide()
        focus.clearFocus()
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.onQueryChange(it) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp)
                .onFocusChanged { focused = it.isFocused },
            placeholder = { Text("Cari lagu, artis, atau video") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (vm.query.isNotEmpty()) {
                    IconButton(onClick = { vm.onQueryChange("") }) {
                        Icon(Icons.Filled.Close, contentDescription = "Hapus")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { doSearch(vm.query) }),
        )

        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = vm.filter == Engine.FILTER_MUSIC,
                onClick = { vm.setFilter(Engine.FILTER_MUSIC) },
                label = { Text("Musik") },
            )
            FilterChip(
                selected = vm.filter == Engine.FILTER_VIDEO,
                onClick = { vm.setFilter(Engine.FILTER_VIDEO) },
                label = { Text("Video") },
            )
        }

        Box(Modifier.weight(1f)) {
            when {
                vm.loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                }

                vm.error != null -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(32.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = vm.error ?: "",
                            style = MaterialTheme.typography.bodyLarge,
                            textAlign = TextAlign.Center,
                        )
                        Button(
                            onClick = { vm.search() },
                            modifier = Modifier.padding(top = 16.dp),
                        ) {
                            Text("Coba lagi")
                        }
                    }
                }

                !vm.searched -> {
                    StartContent(vm, player)
                }

                else -> {
                    ResultList(vm, player, listState)
                }
            }

            // Saran pencarian menimpa daftar saat kolom sedang fokus
            if (focused && vm.suggestions.isNotEmpty()) {
                Surface(Modifier.fillMaxSize()) {
                    LazyColumn(Modifier.fillMaxSize()) {
                        itemsIndexed(vm.suggestions) { _, s ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { doSearch(s) }
                                    .padding(horizontal = 20.dp, vertical = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Icon(
                                    Icons.Filled.Search,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                                Text(
                                    text = s,
                                    modifier = Modifier.padding(start = 16.dp),
                                    style = MaterialTheme.typography.bodyLarge,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultList(
    vm: AppViewModel,
    player: PlayerConnection,
    listState: androidx.compose.foundation.lazy.LazyListState,
) {
    LazyColumn(
        state = listState,
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 8.dp),
    ) {
        itemsIndexed(vm.results, key = { i, t -> "${t.url}#$i" }) { i, t ->
            TrackItem(vm, player, t) {
                player.playQueue(vm.results.toList(), i)
            }
        }
        if (vm.loadingMore) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}

/** Layar awal sebelum mencari: tampilkan lagu yang terakhir diputar (jika ada). */
@Composable
private fun StartContent(vm: AppViewModel, player: PlayerConnection) {
    if (vm.history.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                text = "Mulai dengan mencari lagu atau artis",
                style = MaterialTheme.typography.titleMedium,
                textAlign = TextAlign.Center,
            )
            Text(
                text = "Hasil pencarian diputar sebagai antrean, dan tetap berjalan di latar belakang.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp),
            )
        }
    } else {
        val recent = vm.history.take(15)
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Text(
                    text = "Terakhir diputar",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp),
                )
            }
            itemsIndexed(recent, key = { i, t -> "${t.url}#$i" }) { i, t ->
                TrackItem(vm, player, t) {
                    player.playQueue(recent, i)
                }
            }
        }
    }
}

@Composable
fun TrackItem(vm: AppViewModel, player: PlayerConnection, track: Track, onPlay: () -> Unit) {
    TrackRow(
        track = track,
        playing = player.current?.url == track.url,
        favorite = vm.isFavorite(track.url),
        onClick = onPlay,
        onToggleFavorite = { vm.toggleFavorite(track) },
        onPlayNext = { player.playNext(track) },
        onAddToQueue = { player.addToQueue(track) },
    )
}
