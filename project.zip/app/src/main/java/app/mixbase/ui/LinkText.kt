package app.mixbase.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import app.mixbase.data.Links

private val URL_REGEX = Regex("https?://[^\\s<>\"']+")
private const val TAG = "URL"

/**
 * Teks dengan link yang bisa diketuk (komentar, deskripsi video). Link YouTube dibuka di dalam app ini,
 * link lain dibuka di browser.
 */
@Suppress("DEPRECATION")
@Composable
fun LinkText(text: String, style: TextStyle, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val linkColor = MaterialTheme.colorScheme.primary
    val baseColor = if (style.color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else style.color

    val annotated = remember(text, linkColor) {
        buildAnnotatedString {
            var last = 0
            for (m in URL_REGEX.findAll(text)) {
                val url = m.value.trimEnd('.', ',', ')', ']', '!', '?', ';', ':')
                if (url.length < 8) continue
                val start = m.range.first
                if (start < last) continue
                append(text.substring(last, start))
                pushStringAnnotation(TAG, url)
                withStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)) {
                    append(url)
                }
                pop()
                last = start + url.length
            }
            append(text.substring(last))
        }
    }

    ClickableText(
        text = annotated,
        modifier = modifier,
        style = style.copy(color = baseColor),
        onClick = { offset ->
            val hit = annotated.getStringAnnotations(TAG, offset, offset).firstOrNull()
            if (hit != null) openLink(context, hit.item)
        },
    )
}

/** Link YouTube dikirim kembali ke app ini sendiri; link lain ke browser. */
fun openLink(context: Context, url: String) {
    val uri = Uri.parse(url)
    if (Links.parse(url) != null) {
        try {
            val own = Intent(Intent.ACTION_VIEW, uri).setPackage(context.packageName)
            context.startActivity(own)
            return
        } catch (e: Exception) {
            // jatuh ke browser
        }
    }
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
    } catch (e: Exception) {
        // tidak ada aplikasi untuk membuka link
    }
}
