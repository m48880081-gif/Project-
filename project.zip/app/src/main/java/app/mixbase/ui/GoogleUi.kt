package app.mixbase.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R

/*
 * Komponen bersama gaya Google: dipakai oleh layar musik DAN video supaya tampilannya serasi.
 */

/** Logo PlayTube (buatan sendiri): kotak biru bergradasi + segitiga putar dengan gelombang suara. */
@Composable
fun PlayTubeMark(size: Dp = 30.dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f))
            .background(Brush.linearGradient(listOf(Color(0xFF6CA2FF), Color(0xFF0B4FC4)))),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.ic_logo_glyph),
            contentDescription = null,
            modifier = Modifier.size(size * 0.92f),
        )
    }
}

/** Tulisan "PlayTube": "Play" warna teks, "Tube" warna utama. */
@Composable
fun Wordmark(modifier: Modifier = Modifier) {
    val base = MaterialTheme.colorScheme.onSurface
    val accent = MaterialTheme.colorScheme.primary
    Text(
        text = buildAnnotatedString {
            withStyle(SpanStyle(color = base)) { append("Play") }
            withStyle(SpanStyle(color = accent)) { append("Tube") }
        },
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = modifier,
    )
}

/**
 * Bilah atas (musik dan video memakai yang sama), gaya melayang ala Gemini: tombol menu bulat di kiri,
 * nama aplikasi + penanda mode di tengah, dan aksi (muat ulang, cari) dalam satu pil di kanan.
 * Latarnya transparan sehingga cocok ditaruh di dalam [TopBar].
 */
@Composable
fun AppHeader(
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier,
    tag: String? = null,
    actions: @Composable RowScope.() -> Unit = {},
) {
    val pill = MaterialTheme.colorScheme.surfaceContainerHigh
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(pill)
                .clickable(onClick = onMenu),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Filled.Menu, contentDescription = "Menu")
        }
        Spacer(Modifier.width(12.dp))
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Wordmark()
            if (tag != null) {
                Spacer(Modifier.width(8.dp))
                Text(
                    text = tag,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.secondaryContainer)
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                )
            }
        }
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(pill)
                .padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            actions()
            IconButton(onClick = onSearch) {
                Icon(Icons.Filled.Search, contentDescription = "Cari")
            }
        }
    }
}

/** Judul bagian (rak) dengan tombol panah opsional untuk "lihat semua". */
@Composable
fun ShelfHeader(
    title: String,
    modifier: Modifier = Modifier,
    overline: String? = null,
    onMore: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            if (overline != null) {
                Text(
                    text = overline,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (trailing != null) {
            trailing()
        }
        if (onMore != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                    .clickable(onClick = onMore),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.KeyboardArrowRight,
                    contentDescription = "Lihat semua",
                    modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}

enum class PillStyle { FILLED, TONAL, OUTLINED }

/** Tombol pil bergaya Google: terisi (warna utama), tonal (biru muda), atau berbingkai. */
@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: PillStyle = PillStyle.TONAL,
    icon: Int? = null,
    content: (@Composable RowScope.() -> Unit)? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val bg = when (style) {
        PillStyle.FILLED -> scheme.primary
        PillStyle.TONAL -> scheme.secondaryContainer
        PillStyle.OUTLINED -> Color.Transparent
    }
    val fg = when (style) {
        PillStyle.FILLED -> scheme.onPrimary
        PillStyle.TONAL -> scheme.onSecondaryContainer
        PillStyle.OUTLINED -> scheme.onSurface
    }
    var m = modifier.clip(RoundedCornerShape(50)).background(bg)
    if (style == PillStyle.OUTLINED) {
        m = m.border(1.dp, scheme.outline, RoundedCornerShape(50))
    }
    Row(
        modifier = m
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(
                painter = painterResource(icon),
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = fg,
            maxLines = 1,
        )
        if (content != null) content()
    }
}
