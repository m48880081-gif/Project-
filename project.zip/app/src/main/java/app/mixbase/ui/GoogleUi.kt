package app.mixbase.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R

/*
 * Komponen bersama gaya Google: dipakai oleh layar musik DAN video supaya tampilannya serasi.
 */

/** Logo PlayTube (buatan sendiri): kotak biru bergradasi + segitiga putar dengan gelombang suara. */
@Composable
fun PlayTubeMark(size: Dp = 30.dp, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f))
            .background(Brush.linearGradient(listOf(Color(0xFF6CA2FF), Color(0xFF0B4FC4)))),
        contentAlignment = Alignment.Center,
    ) {
        Image(
            painter = painterResource(R.drawable.ic_logo_glyph),
            contentDescription = null,
            modifier = Modifier.size(size * 0.92f),
        )
    }
}

/** Tulisan "PlayTube": "Play" warna teks, "Tube" warna utama. */
@Composable
fun Wordmark(modifier: Modifier = Modifier) {
    val base = MaterialTheme.colorScheme.onSurface
    val accent = MaterialTheme.colorScheme.primary
    Text(
        text = buildAnnotatedString {
            withStyle(SpanStyle(color = base)) { append("Play") }
            withStyle(SpanStyle(color = accent)) { append("Tube") }
        },
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = modifier,
    )
}

/** Bilah atas beranda (musik dan video memakai yang sama): logo, nama, aksi, cari. */
@Composable
fun AppHeader(
    onSearch: () -> Unit,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {},
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 4.dp, top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PlayTubeMark(32.dp)
        Spacer(Modifier.width(10.dp))
        Wordmark(Modifier.weight(1f))
        actions()
        IconButton(onClick = onSearch) {
            Icon(Icons.Filled.Search, contentDescription = "Cari")
        }
    }
}

/** Judul bagian (rak) dengan tombol panah opsional untuk "lihat semua". */
@Composable
fun ShelfHeader(
    title: String,
    modifier: Modifier = Modifier,
    overline: String? = null,
    onMore: (() -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 24.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            if (overline != null) {
                Text(
                    text = overline,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (trailing != null) {
            trailing()
        }
        if (onMore != null) {
            Spacer(Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                    .clickable(onClick = onMore),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    Icons.Filled.KeyboardArrowRight,
                    contentDescription = "Lihat semua",
                    modifier = Modifier.size(22.dp),
                )
            }
        }
    }
}

enum class PillStyle { FILLED, TONAL, OUTLINED }

/** Tombol pil bergaya Google: terisi (warna utama), tonal (biru muda), atau berbingkai. */
@Composable
fun PillButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    style: PillStyle = PillStyle.TONAL,
    icon: Int? = null,
    content: (@Composable RowScope.() -> Unit)? = null,
) {
    val scheme = MaterialTheme.colorScheme
    val bg = when (style) {
        PillStyle.FILLED -> scheme.primary
        PillStyle.TONAL -> scheme.secondaryContainer
        PillStyle.OUTLINED -> Color.Transparent
    }
    val fg = when (style) {
        PillStyle.FILLED -> scheme.onPrimary
        PillStyle.TONAL -> scheme.onSecondaryContainer
        PillStyle.OUTLINED -> scheme.onSurface
    }
    var m = modifier.clip(RoundedCornerShape(50)).background(bg)
    if (style == PillStyle.OUTLINED) {
        m = m.border(1.dp, scheme.outline, RoundedCornerShape(50))
    }
    Row(
        modifier = m
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(
                painter = painterResource(icon),
                contentDescription = null,
                tint = fg,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            color = fg,
            maxLines = 1,
        )
        if (content != null) content()
    }
}
