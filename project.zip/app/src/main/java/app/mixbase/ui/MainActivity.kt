package app.mixbase.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.runtime.remember
import app.mixbase.MixApp
import app.mixbase.data.Accounts
import app.mixbase.data.Links
import app.mixbase.data.Store

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    /** Link yang dibuka saat belum masuk; dibuka setelah masuk. */
    private var deferredLink: String? = null

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Bilah status dan bilah navigasi sistem transparan: bilah bawah app menyatu sampai ke tepi layar,
        // juga pada navigasi 3 tombol (tanpa latar abu-abu bawaan sistem).
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }

        val app = application as MixApp
        val player = app.player
        val video = app.video
        player.onTrackStarted = { track -> vm.addHistory(track) }
        video.onOpened = { track -> vm.addVideoHistory(track) }
        player.connect()

        // Video tidak berjalan di latar belakang (itu tugas pemutar musik): jeda saat app disembunyikan.
        lifecycle.addObserver(
            LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_STOP) video.pause()
            },
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            // Gerbang: belum masuk → halaman masuk/daftar; sudah masuk tapi belum memilih bahasa & format
            // audio → pengenalan awal; selebihnya → aplikasi. `vm` baru dibuat setelah akun ada, supaya
            // membaca penyimpanan milik akun yang benar.
            if (Accounts.current == null) {
                val authTheme = remember { Store(applicationContext).themeMode }
                MixTheme(mode = authTheme, dynamic = false) {
                    AuthScreen(onAuthenticated = { restart -> onAuthenticated(restart) })
                }
            } else {
                MixTheme(mode = vm.themeMode, dynamic = vm.dynamicColor) {
                    if (vm.onboarded) {
                        AppRoot(vm, player, video, app.shorts)
                    } else {
                        OnboardingFlow(vm)
                    }
                }
            }
        }
    }

    private fun onAuthenticated(restart: Boolean) {
        if (restart) {
            // Akun ini memakai penyimpanan terpisah: mulai ulang agar semua dimuat dari akun yang benar.
            restartApp(this)
            return
        }
        val link = deferredLink
        if (link != null) {
            deferredLink = null
            vm.openLink(link)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Buka link YouTube yang dikirim sistem (ketuk link, atau Bagikan ke aplikasi ini). */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val text = when (i.action) {
            Intent.ACTION_VIEW -> i.dataString
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        } ?: return
        if (Links.parse(text) != null) {
            if (Accounts.current != null) vm.openLink(text) else deferredLink = text
        }
    }
}
