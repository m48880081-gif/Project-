package app.mixbase.ui

import android.Manifest
import android.app.PendingIntent
import android.app.PictureInPictureParams
import android.app.RemoteAction
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.drawable.Icon
import android.util.Rational
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import app.mixbase.MixApp
import app.mixbase.R
import app.mixbase.data.Links
import app.mixbase.data.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    private val video get() = (application as MixApp).video
    private val pipScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val pipReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.getIntExtra(PIP_EXTRA, 0)) {
                1 -> {
                    val prev = vm.videoHistory.getOrNull(1)
                    if (video.positionMs > 3000L || prev == null) video.seekTo(0L) else video.open(prev)
                }
                2 -> video.togglePlay()
                3 -> nextVideo()?.let { video.open(it) }
            }
        }
    }

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Bilah status dan bilah navigasi sistem transparan: bilah bawah app menyatu sampai ke tepi layar,
        // juga pada navigasi 3 tombol (tanpa latar abu-abu bawaan sistem).
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.auto(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }

        val app = application as MixApp
        val player = app.player
        val video = app.video
        player.onTrackStarted = { track -> vm.addHistory(track) }
        video.onOpened = { track -> vm.addVideoHistory(track) }
        player.connect()

        // PiP: tombol kontrol di jendela mengambang + pembaruan otomatis (rasio, putar/jeda, berikutnya).
        ContextCompat.registerReceiver(
            this, pipReceiver, IntentFilter(PIP_ACTION), ContextCompat.RECEIVER_NOT_EXPORTED,
        )
        pipScope.launch {
            snapshotFlow {
                listOf(video.active, video.isPlaying, video.useEmbed, video.aspect, nextVideo()?.url)
            }.collect { refreshPip() }
        }

        // Video tidak berjalan di latar belakang (itu tugas pemutar musik): jeda saat app disembunyikan.
        lifecycle.addObserver(
            LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_STOP) video.pause()
            },
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        if (savedInstanceState == null) handleIntent(intent)

        setContent {
            MixTheme(mode = vm.themeMode, dynamic = vm.dynamicColor) {
                Box(Modifier.fillMaxSize()) {
                    AppRoot(vm, player, video, app.shorts)
                    PipOverlay(video)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        PipState.inPip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isInPictureInPictureMode else false
    }

    override fun onResume() {
        super.onResume()
        PipState.inPip = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) isInPictureInPictureMode else false
    }

    override fun onDestroy() {
        pipScope.cancel()
        try {
            unregisterReceiver(pipReceiver)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    // Android 8–11: masuk PiP saat tombol Beranda ditekan. Android 12+: otomatis lewat setAutoEnterEnabled.
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT in Build.VERSION_CODES.O until Build.VERSION_CODES.S &&
            canPip() && video.isPlaying
        ) {
            enterPip()
        }
    }

    @Suppress("DEPRECATION")
    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        PipState.inPip = isInPictureInPictureMode
        if (isInPictureInPictureMode) refreshPip()
    }

    private fun canPip(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE) &&
            video.active && !video.useEmbed

    private fun nextVideo(): Track? = video.details?.related?.firstOrNull { !it.live }

    /** Masuk mode PiP (dipanggil juga dari tombol di pemutar). */
    fun enterPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !canPip()) return
        try {
            enterPictureInPictureMode(pipParams())
        } catch (_: Exception) {
        }
    }

    private fun refreshPip() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        try {
            setPictureInPictureParams(pipParams())
        } catch (_: Exception) {
        }
    }

    private fun pipAction(icon: Int, title: String, code: Int, enabled: Boolean = true): RemoteAction {
        val pi = PendingIntent.getBroadcast(
            this,
            code,
            Intent(PIP_ACTION).setPackage(packageName).putExtra(PIP_EXTRA, code),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val a = RemoteAction(Icon.createWithResource(this, icon), title, title, pi)
        a.isEnabled = enabled
        return a
    }

    private fun pipParams(): PictureInPictureParams {
        val ratio = video.aspect.coerceIn(0.5f, 2.3f)
        val playing = video.isPlaying
        val actions = listOf(
            pipAction(R.drawable.ic_pip_prev, "Sebelumnya", 1),
            pipAction(
                if (playing) R.drawable.ic_pip_pause else R.drawable.ic_pip_play,
                if (playing) "Jeda" else "Putar",
                2,
            ),
            pipAction(R.drawable.ic_pip_next, "Berikutnya", 3, nextVideo() != null),
        )
        val b = PictureInPictureParams.Builder()
            .setAspectRatio(Rational((ratio * 1000).toInt(), 1000))
            .setActions(actions)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            b.setAutoEnterEnabled(canPip() && video.isPlaying)
        }
        return b.build()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    /** Buka link YouTube yang dikirim sistem (ketuk link, atau Bagikan ke aplikasi ini). */
    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val text = when (i.action) {
            Intent.ACTION_VIEW -> i.dataString
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            else -> null
        } ?: return
        if (Links.parse(text) != null) vm.openLink(text)
    }

    private companion object {
        const val PIP_ACTION = "app.mixbase.PIP_CONTROL"
        const val PIP_EXTRA = "pip_code"
    }
}
