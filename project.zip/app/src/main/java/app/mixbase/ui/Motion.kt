package app.mixbase.ui

import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay

/**
 * Gerak yang dipakai bersama di seluruh aplikasi: tidak ada yang muncul atau hilang tiba-tiba.
 * Layar dan kartu tumbuh dari kecil ke besar sambil memudar masuk, lalu mengecil saat ditutup.
 */
object Motion {
    val BottomOrigin = TransformOrigin(0.5f, 1f)
    val TopOrigin = TransformOrigin(0.5f, 0f)

    /** Tumbuh dari kecil ke ukuran penuh (dialog, kartu, layar tumpuk). */
    fun growIn(origin: TransformOrigin = TransformOrigin.Center, from: Float = 0.86f): EnterTransition =
        fadeIn(tween(220, easing = FastOutSlowInEasing)) +
            scaleIn(
                animationSpec = spring(dampingRatio = 0.82f, stiffness = 380f),
                initialScale = from,
                transformOrigin = origin,
            )

    /** Mengecil sambil memudar. */
    fun shrinkOut(origin: TransformOrigin = TransformOrigin.Center, to: Float = 0.9f): ExitTransition =
        fadeOut(tween(170, easing = FastOutSlowInEasing)) +
            scaleOut(
                animationSpec = tween(220, easing = FastOutSlowInEasing),
                targetScale = to,
                transformOrigin = origin,
            )

    /** Layar penuh yang naik dari bawah (pemutar, halaman tonton). */
    fun risingIn(): EnterTransition =
        growIn(BottomOrigin, 0.9f) +
            slideInVertically(animationSpec = tween(360, easing = FastOutSlowInEasing)) { full -> full / 6 }

    fun sinkingOut(): ExitTransition =
        shrinkOut(BottomOrigin, 0.9f) +
            slideOutVertically(animationSpec = tween(280, easing = FastOutSlowInEasing)) { full -> full / 6 }

    /** Layar dari samping (Setelan): geser sedikit + tumbuh dari kecil. */
    fun sideIn(): EnterTransition =
        slideInHorizontally(animationSpec = tween(340, easing = FastOutSlowInEasing)) { full -> full / 3 } +
            fadeIn(tween(260)) +
            scaleIn(animationSpec = tween(340, easing = FastOutSlowInEasing), initialScale = 0.94f)

    fun sideOut(): ExitTransition =
        slideOutHorizontally(animationSpec = tween(260, easing = FastOutSlowInEasing)) { full -> full / 3 } +
            fadeOut(tween(200)) +
            scaleOut(animationSpec = tween(260, easing = FastOutSlowInEasing), targetScale = 0.94f)

    /** Ganti tab: tab baru tumbuh halus sambil memudar masuk, yang lama memudar keluar. */
    fun tabTransition(): ContentTransform =
        (
            fadeIn(tween(240, delayMillis = 70)) +
                scaleIn(animationSpec = tween(300, easing = FastOutSlowInEasing), initialScale = 0.96f)
            ) togetherWith fadeOut(tween(110))
}

/**
 * Klik dengan umpan balik sentuhan: elemen sedikit mengecil saat ditekan lalu memantul kembali.
 */
fun Modifier.bouncyClick(
    enabled: Boolean = true,
    shape: Shape = RectangleShape,
    onClick: () -> Unit,
): Modifier = composed {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 520f),
        label = "press",
    )
    this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .then(if (shape === RectangleShape) Modifier else Modifier.clip(shape))
        .clickable(
            interactionSource = source,
            indication = LocalIndication.current,
            enabled = enabled,
            onClick = onClick,
        )
}

/**
 * Muncul bertahap saat pertama kali tampil: dari kecil + transparan menjadi ukuran penuh.
 * Hanya 10 baris pertama ([index] 0..9) yang beranimasi, berurutan, supaya daftar panjang
 * tetap ringan saat digulir.
 */
@Composable
fun Modifier.appear(index: Int = 0): Modifier {
    val enabled = index in 0..9
    val p = remember { Animatable(if (enabled) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (enabled) {
            delay(index * 40L)
            p.animateTo(1f, spring(dampingRatio = 0.85f, stiffness = 300f))
        }
    }
    return if (enabled) {
        this.graphicsLayer {
            val v = p.value
            alpha = v.coerceIn(0f, 1f)
            val s = 0.9f + 0.1f * v
            scaleX = s
            scaleY = s
        }
    } else {
        this
    }
}
