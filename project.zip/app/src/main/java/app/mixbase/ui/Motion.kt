@file:OptIn(ExperimentalSharedTransitionApi::class)

package app.mixbase.ui

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.BoundsTransform
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import kotlinx.coroutines.delay

/*
 * Perangkat animasi bersama untuk seluruh UI (musik dan video).
 * Aturannya: tidak ada yang muncul atau hilang mendadak. Semuanya tumbuh dari kecil ke besar
 * (skala + pudar, dengan pegas) lalu mengecil lagi saat ditutup.
 */

/** Titik tumbuh dari tengah bawah layar (arah mini player / bilah bawah). */
val OriginBottom = TransformOrigin(0.5f, 1f)

/** Titik tumbuh dari sisi kiri (arah menu samping). */
val OriginStart = TransformOrigin(0f, 0.5f)

/** Masuk: tumbuh dari kecil ke ukuran penuh sambil memudar masuk. */
fun popEnter(
    origin: TransformOrigin = TransformOrigin.Center,
    from: Float = 0.8f,
): EnterTransition =
    fadeIn(animationSpec = tween(220)) +
        scaleIn(
            animationSpec = spring(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow),
            initialScale = from,
            transformOrigin = origin,
        )

/** Keluar: mengecil sambil memudar. */
fun popExit(
    origin: TransformOrigin = TransformOrigin.Center,
    target: Float = 0.85f,
): ExitTransition =
    fadeOut(animationSpec = tween(170)) +
        scaleOut(
            animationSpec = tween(200, easing = FastOutSlowInEasing),
            targetScale = target,
            transformOrigin = origin,
        )

/** Layar penuh yang tumbuh dari bilah bawah (pemutar musik, halaman tonton video). */
fun sheetEnter(): EnterTransition =
    fadeIn(animationSpec = tween(260)) +
        scaleIn(
            animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
            initialScale = 0.6f,
            transformOrigin = OriginBottom,
        ) +
        slideInVertically(animationSpec = tween(380, easing = FastOutSlowInEasing)) { it / 4 }

/** Kebalikan [sheetEnter]: layar penuh mengecil kembali ke bilah bawah. */
fun sheetExit(): ExitTransition =
    fadeOut(animationSpec = tween(220, delayMillis = 40)) +
        scaleOut(
            animationSpec = tween(300, easing = FastOutSlowInEasing),
            targetScale = 0.6f,
            transformOrigin = OriginBottom,
        ) +
        slideOutVertically(animationSpec = tween(300, easing = FastOutSlowInEasing)) { it / 4 }

// ---------------------------------------------------------------------
// Elemen bersama: sampul dan judul tumbuh dari mini player ke layar pemutar penuh (dan sebaliknya)
// ---------------------------------------------------------------------

/** Lingkup SharedTransitionLayout milik AppRoot; null bila tidak ada (mis. pratinjau). */
val LocalSharedScope = compositionLocalOf<SharedTransitionScope?> { null }

/** Lingkup AnimatedVisibility/AnimatedContent tempat elemen bersama sedang berada. */
val LocalVisScope = compositionLocalOf<AnimatedVisibilityScope?> { null }

/** Pegas "ekspresif": sedikit memantul saat sampai, bukan berhenti kaku. */
private val SharedSpring = BoundsTransform { _, _ ->
    spring<Rect>(dampingRatio = 0.78f, stiffness = Spring.StiffnessMediumLow)
}

/**
 * Tandai elemen yang berpindah antar layar dengan [key] yang sama. Pasang SEBELUM modifier ukuran
 * (size/fillMaxWidth) supaya ukurannya ikut beranimasi. Tanpa lingkup bersama, tidak berbuat apa-apa.
 */
@Composable
fun Modifier.sharedElementKey(key: String): Modifier {
    val shared = LocalSharedScope.current
    val vis = LocalVisScope.current
    if (shared == null || vis == null) return this
    return with(shared) {
        this@sharedElementKey.sharedElement(
            state = rememberSharedContentState(key = key),
            animatedVisibilityScope = vis,
            boundsTransform = SharedSpring,
        )
    }
}

/** Seperti [sharedElementKey], tetapi untuk isi yang berbeda (mis. teks kecil menjadi teks besar). */
@Composable
fun Modifier.sharedBoundsKey(key: String): Modifier {
    val shared = LocalSharedScope.current
    val vis = LocalVisScope.current
    if (shared == null || vis == null) return this
    return with(shared) {
        this@sharedBoundsKey.sharedBounds(
            sharedContentState = rememberSharedContentState(key = key),
            animatedVisibilityScope = vis,
            boundsTransform = SharedSpring,
        )
    }
}

/** Masuk untuk layar pemutar penuh: tumbuh dari bilah bawah (kecil ke besar), tanpa meluncur dari bawah. */
fun playerEnter(): EnterTransition =
    fadeIn(animationSpec = tween(260)) +
        scaleIn(
            animationSpec = spring(dampingRatio = 0.82f, stiffness = Spring.StiffnessMediumLow),
            initialScale = 0.3f,
            transformOrigin = OriginBottom,
        )

/** Kebalikan [playerEnter]: layar mengecil kembali ke bilah bawah. */
fun playerExit(): ExitTransition =
    fadeOut(animationSpec = tween(220, delayMillis = 40)) +
        scaleOut(
            animationSpec = tween(320, easing = FastOutSlowInEasing),
            targetScale = 0.3f,
            transformOrigin = OriginBottom,
        )

/** Pembungkus AnimatedVisibility dengan animasi tumbuh/mengecil bawaan aplikasi. */
@Composable
fun PopVisibility(
    visible: Boolean,
    modifier: Modifier = Modifier,
    origin: TransformOrigin = TransformOrigin.Center,
    from: Float = 0.8f,
    content: @Composable AnimatedVisibilityScope.() -> Unit,
) {
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = popEnter(origin, from),
        exit = popExit(origin, from + 0.05f),
        content = content,
    )
}

/** Transisi AnimatedContent: isi baru tumbuh masuk, isi lama memudar sambil sedikit mengecil. */
fun <S> AnimatedContentTransitionScope<S>.popTransform(from: Float = 0.92f): ContentTransform {
    val enter = fadeIn(animationSpec = tween(240, delayMillis = 40)) +
        scaleIn(
            animationSpec = tween(320, easing = FastOutSlowInEasing),
            initialScale = from,
        )
    val exit = fadeOut(animationSpec = tween(140)) +
        scaleOut(
            animationSpec = tween(220, easing = FastOutSlowInEasing),
            targetScale = 0.96f,
        )
    return enter togetherWith exit
}

/** Saat pertama muncul, isi tumbuh dari kecil ke besar (sekali saja). */
fun Modifier.growIn(initialScale: Float = 0.9f, delayMillis: Int = 0): Modifier = composed {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        if (delayMillis > 0) delay(delayMillis.toLong())
        progress.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow))
    }
    graphicsLayer {
        val p = progress.value
        val s = initialScale + (1f - initialScale) * p
        scaleX = s
        scaleY = s
        alpha = p.coerceIn(0f, 1f)
    }
}

/**
 * Umpan balik sentuhan: elemen mengecil sedikit saat ditekan lalu memantul kembali.
 * Tidak mengambil alih ketukan, jadi aman dipasang di luar clickable.
 */
fun Modifier.pressScale(pressedScale: Float = 0.9f): Modifier = composed {
    var pressed by remember { mutableStateOf(false) }
    val s by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    this
        .graphicsLayer {
            scaleX = s
            scaleY = s
        }
        .pointerInput(Unit) {
            awaitEachGesture {
                awaitFirstDown(requireUnconsumed = false)
                pressed = true
                waitForUpOrCancellation()
                pressed = false
            }
        }
}

/** Klik tanpa riak, untuk lapisan gelap (scrim) di belakang dialog dan panel. */
@Composable
fun Modifier.scrimClickable(onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick,
    )

/** Ingat nilai terakhir yang tidak null, supaya animasi keluar tetap menampilkan isi terakhir. */
@Suppress("UNCHECKED_CAST")
@Composable
fun <T : Any> rememberLastNonNull(value: T?): T? {
    val holder = remember { arrayOfNulls<Any>(1) }
    if (value != null) holder[0] = value
    return holder[0] as T?
}

/**
 * Dialog dengan animasi: kartunya tumbuh dari kecil ke besar saat dibuka dan mengecil saat ditutup,
 * lapisan gelapnya memudar. Dialog tetap ada di komposisi selama animasi keluar berjalan.
 */
@Composable
fun PopDialog(
    visible: Boolean,
    onDismissRequest: () -> Unit,
    content: @Composable () -> Unit,
) {
    val state = remember { MutableTransitionState(false) }
    LaunchedEffect(visible) { state.targetState = visible }

    if (state.currentState || state.targetState) {
        Dialog(
            onDismissRequest = onDismissRequest,
            properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false),
        ) {
            // Lapisan gelap digambar sendiri supaya bisa dianimasikan.
            val view = LocalView.current
            SideEffect {
                (view.parent as? DialogWindowProvider)?.window?.setDimAmount(0f)
            }
            val scrim = remember { Animatable(0f) }
            LaunchedEffect(visible) {
                scrim.animateTo(if (visible) 0.5f else 0f, tween(220))
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = scrim.value))
                    .scrimClickable(onDismissRequest),
                contentAlignment = Alignment.Center,
            ) {
                AnimatedVisibility(
                    visibleState = state,
                    enter = popEnter(from = 0.7f),
                    exit = popExit(target = 0.8f),
                ) {
                    Surface(
                        shape = MaterialTheme.shapes.extraLarge,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        tonalElevation = 6.dp,
                        modifier = Modifier
                            .padding(horizontal = 24.dp, vertical = 48.dp)
                            .widthIn(max = 420.dp)
                            .fillMaxWidth()
                            .heightIn(max = 640.dp)
                            // Ketukan di kartu tidak boleh menutup dialog.
                            .pointerInput(Unit) { detectTapGestures { } },
                    ) {
                        content()
                    }
                }
            }
        }
    }
}

/** Pengganti AlertDialog bawaan dengan animasi tumbuh/mengecil (lihat [PopDialog]). */
@Composable
fun PopAlertDialog(
    visible: Boolean,
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    dismissButton: (@Composable () -> Unit)? = null,
    title: (@Composable () -> Unit)? = null,
    text: (@Composable () -> Unit)? = null,
) {
    PopDialog(visible = visible, onDismissRequest = onDismissRequest) {
        Column(Modifier.padding(24.dp)) {
            if (title != null) {
                Box(Modifier.padding(bottom = 16.dp)) {
                    ProvideTextStyle(MaterialTheme.typography.headlineSmall) { title() }
                }
            }
            if (text != null) {
                Box(
                    Modifier
                        .weight(1f, fill = false)
                        .padding(bottom = 24.dp),
                ) {
                    ProvideTextStyle(MaterialTheme.typography.bodyMedium) { text() }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
            ) {
                if (dismissButton != null) dismissButton()
                confirmButton()
            }
        }
    }
}
