package app.mixbase.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection

/** Gambar sampul persegi dengan sudut membulat. */
@Composable
fun Thumb(url: String?, size: Dp, modifier: Modifier = Modifier, pageUrl: String? = null) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        // pageUrl (alamat video) dipakai sebagai cadangan bila gambar [url] gagal dimuat.
        ThumbImage(url, pageUrl, Modifier.fillMaxSize())
    }
}

/** Satu baris lagu di daftar hasil / pustaka. */
@Composable
fun TrackRow(
    track: Track,
    playing: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val download = rememberDownloader()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(track.thumb, 56.dp, pageUrl = track.url)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (playing) FontWeight.SemiBold else FontWeight.Normal,
            )
            val sub = buildString {
                append(track.artist)
                if (track.durationSec > 0) {
                    if (isNotEmpty()) append(" • ")
                    append(clock(track.durationSec))
                }
            }
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menu = false
                        onPlayNext()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menu = false
                        onAddToQueue()
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (favorite) "Hapus dari favorit" else "Tambah ke favorit") },
                    onClick = {
                        menu = false
                        onToggleFavorite()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Unduh audio") },
                    onClick = {
                        menu = false
                        download(track, false)
                    },
                )
            }
        }
    }
}

/**
 * Pemutar mini gaya Material 3 Expressive: kartu membulat yang melayang di atas bilah navigasi.
 * Sampul dan judulnya adalah elemen bersama: saat dibuka, keduanya tumbuh menjadi sampul dan
 * judul besar di layar pemutar penuh (dan mengecil lagi saat ditutup).
 * [track] diberikan dari luar supaya isinya tetap tampil selama animasi keluar.
 */
@Composable
fun MiniPlayer(player: PlayerConnection, track: Track, onOpen: () -> Unit) {
    val target = if (player.durationMs > 0L) {
        (player.positionMs.toFloat() / player.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    // Posisi hanya dilaporkan tiap 0,5 detik; dihaluskan supaya garis kemajuan mengalir.
    val fraction by animateFloatAsState(target, tween(500, easing = LinearEasing), label = "miniProgress")

    val primary = MaterialTheme.colorScheme.primary
    val onPrimary = MaterialTheme.colorScheme.onPrimary
    val trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
    // Tombol putar berubah bentuk: bulat saat memutar, kotak membulat saat jeda.
    val playCorner by animateDpAsState(
        targetValue = if (player.isPlaying) 22.dp else 13.dp,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium),
        label = "miniPlayCorner",
    )

    Surface(
        onClick = onOpen,
        shape = RoundedCornerShape(28.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 2.dp,
        shadowElevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
        Column {
            Row(
                modifier = Modifier.padding(start = 10.dp, end = 6.dp, top = 8.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // Sampul (elemen bersama "cover")
                Box(
                    Modifier
                        .sharedElementKey("cover")
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    AnimatedContent(
                        targetState = track,
                        modifier = Modifier.fillMaxSize(),
                        transitionSpec = { popTransform(from = 0.8f) },
                        label = "miniCover",
                    ) { t ->
                        ThumbImage(t.thumb, t.url, Modifier.fillMaxSize())
                    }
                }
                Spacer(Modifier.width(12.dp))
                // Judul + artis (batas bersama "meta")
                AnimatedContent(
                    targetState = track,
                    modifier = Modifier
                        .weight(1f)
                        .sharedBoundsKey("meta"),
                    transitionSpec = { popTransform(from = 0.9f) },
                    label = "miniMeta",
                ) { t ->
                    Column(Modifier.fillMaxWidth()) {
                        Text(
                            text = t.title,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = t.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .pressScale(0.9f)
                        .clip(RoundedCornerShape(playCorner))
                        .background(primary)
                        .clickable { player.togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    if (player.buffering && !player.isPlaying) {
                        PlayLoader(diameter = 24.dp, containerColor = onPrimary, color = primary)
                    } else {
                        AnimatedContent(
                            targetState = player.isPlaying,
                            transitionSpec = {
                                (fadeIn(tween(160)) + scaleIn(initialScale = 0.5f)) togetherWith
                                    (fadeOut(tween(100)) + scaleOut(targetScale = 0.5f))
                            },
                            label = "miniPlay",
                        ) { playing ->
                            Icon(
                                painter = painterResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play),
                                contentDescription = "Putar atau jeda",
                                tint = onPrimary,
                                modifier = Modifier.size(22.dp),
                            )
                        }
                    }
                }
                IconButton(onClick = { player.next() }, modifier = Modifier.pressScale()) {
                    Icon(
                        painter = painterResource(R.drawable.ic_skip_next),
                        contentDescription = "Berikutnya",
                    )
                }
                IconButton(onClick = { player.stopAndClear() }, modifier = Modifier.pressScale()) {
                    Icon(Icons.Filled.Close, contentDescription = "Tutup")
                }
            }
            // Garis kemajuan membulat di dasar kartu
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, bottom = 9.dp)
                    .height(3.dp),
            ) {
                val r = size.height / 2f
                drawRoundRect(color = trackColor, cornerRadius = CornerRadius(r, r))
                drawRoundRect(
                    color = primary,
                    size = Size((size.width * fraction).coerceAtLeast(size.height), size.height),
                    cornerRadius = CornerRadius(r, r),
                )
            }
        }
    }
}
