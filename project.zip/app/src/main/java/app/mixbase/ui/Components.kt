package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection

/** Gambar sampul persegi dengan sudut membulat. */
@Composable
fun Thumb(url: String?, size: Dp, modifier: Modifier = Modifier, pageUrl: String? = null) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        // pageUrl (alamat video) dipakai sebagai cadangan bila gambar [url] gagal dimuat.
        ThumbImage(url, pageUrl, Modifier.fillMaxSize())
    }
}

/** Satu baris lagu di daftar hasil / pustaka. */
@Composable
fun TrackRow(
    track: Track,
    playing: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val download = rememberDownloader()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Thumb(track.thumb, 56.dp, pageUrl = track.url)
            // Lagu yang sedang dipilih: penanda ekualiser di atas sampul
            if (playing) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center,
                ) {
                    EqualizerBars(playing = true, color = Color.White)
                }
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            val titleColor by animateColorAsState(
                targetValue = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                animationSpec = spring(stiffness = 300f),
                label = "title",
            )
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = titleColor,
                fontWeight = if (playing) FontWeight.SemiBold else FontWeight.Normal,
            )
            val sub = buildString {
                append(track.artist)
                if (track.durationSec > 0) {
                    if (isNotEmpty()) append(" • ")
                    append(clock(track.durationSec))
                }
            }
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menu = false
                        onPlayNext()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menu = false
                        onAddToQueue()
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (favorite) "Hapus dari favorit" else "Tambah ke favorit") },
                    onClick = {
                        menu = false
                        onToggleFavorite()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Unduh audio") },
                    onClick = {
                        menu = false
                        download(track, false)
                    },
                )
            }
        }
    }
}

/** Pemutar mini di atas bilah navigasi. Ketuk untuk membuka layar pemutar penuh. */
@Composable
fun MiniPlayer(player: PlayerConnection, onOpen: () -> Unit) {
    val track = player.current ?: return
    val fraction = if (player.durationMs > 0L) {
        (player.positionMs.toFloat() / player.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    // Kartu melayang berwarna lembut dengan progres bergelombang (gaya Material 3 Expressive)
    Surface(
        color = MaterialTheme.colorScheme.secondaryContainer,
        shape = RoundedCornerShape(28.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .bounceClickable(onClick = onOpen),
    ) {
        Column {
            Row(
                modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 8.dp, bottom = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(0.dp),
            ) {
                Thumb(track.thumb, 44.dp, pageUrl = track.url)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = LocalContentColor.current.copy(alpha = 0.72f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (player.buffering) {
                    PlayLoader(diameter = 28.dp)
                }
                IconButton(onClick = { player.togglePlay() }) {
                    Icon(
                        painter = painterResource(if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                        contentDescription = "Putar atau jeda",
                    )
                }
                IconButton(onClick = { player.next() }) {
                    Icon(
                        painter = painterResource(R.drawable.ic_skip_next),
                        contentDescription = "Berikutnya",
                    )
                }
                IconButton(onClick = { player.stopAndClear() }) {
                    Icon(Icons.Filled.Close, contentDescription = "Tutup")
                }
            }
            WavyProgress(
                progress = { fraction },
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.16f),
                animate = player.isPlaying,
                amplitude = 2.dp,
                wavelength = 18.dp,
                stroke = 3.dp,
            )
        }
    }
}
