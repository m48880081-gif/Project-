package app.mixbase.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection

/** Gambar sampul persegi dengan sudut membulat. */
@Composable
fun Thumb(url: String?, size: Dp, modifier: Modifier = Modifier, pageUrl: String? = null) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        // pageUrl (alamat video) dipakai sebagai cadangan bila gambar [url] gagal dimuat.
        ThumbImage(url, pageUrl, Modifier.fillMaxSize())
    }
}

/** Satu baris lagu di daftar hasil / pustaka. */
@Composable
fun TrackRow(
    track: Track,
    playing: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val download = rememberDownloader()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(track.thumb, 56.dp, pageUrl = track.url)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (playing) FontWeight.SemiBold else FontWeight.Normal,
            )
            val sub = buildString {
                append(track.artist)
                if (track.durationSec > 0) {
                    if (isNotEmpty()) append(" • ")
                    append(clock(track.durationSec))
                }
            }
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menu = false
                        onPlayNext()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menu = false
                        onAddToQueue()
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (favorite) "Hapus dari favorit" else "Tambah ke favorit") },
                    onClick = {
                        menu = false
                        onToggleFavorite()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Unduh audio") },
                    onClick = {
                        menu = false
                        download(track, false)
                    },
                )
            }
        }
    }
}

/**
 * Pemutar mini di atas bilah navigasi. Ketuk untuk membuka layar pemutar penuh.
 * [track] diberikan dari luar supaya isinya tetap tampil selama animasi keluar.
 */
@Composable
fun MiniPlayer(player: PlayerConnection, track: Track, onOpen: () -> Unit) {
    val target = if (player.durationMs > 0L) {
        (player.positionMs.toFloat() / player.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }
    // Posisi hanya dilaporkan tiap 0,5 detik; dihaluskan supaya garis kemajuan mengalir.
    val fraction by animateFloatAsState(target, tween(500, easing = LinearEasing), label = "miniProgress")

    Surface(
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
    ) {
        Column {
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
            )
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(0.dp),
            ) {
                AnimatedContent(
                    targetState = track,
                    transitionSpec = { popTransform(from = 0.8f) },
                    label = "miniTrack",
                    modifier = Modifier.weight(1f),
                ) { t ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Thumb(t.thumb, 44.dp, pageUrl = t.url)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = t.title,
                                style = MaterialTheme.typography.titleSmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = t.artist,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                    }
                }
                PopVisibility(visible = player.buffering, from = 0.4f) {
                    PlayLoader(diameter = 28.dp)
                }
                IconButton(onClick = { player.togglePlay() }, modifier = Modifier.pressScale()) {
                    AnimatedContent(
                        targetState = player.isPlaying,
                        transitionSpec = {
                            (fadeIn(tween(160)) + scaleIn(initialScale = 0.5f)) togetherWith
                                (fadeOut(tween(100)) + scaleOut(targetScale = 0.5f))
                        },
                        label = "miniPlay",
                    ) { playing ->
                        Icon(
                            painter = painterResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play),
                            contentDescription = "Putar atau jeda",
                        )
                    }
                }
                IconButton(onClick = { player.next() }, modifier = Modifier.pressScale()) {
                    Icon(
                        painter = painterResource(R.drawable.ic_skip_next),
                        contentDescription = "Berikutnya",
                    )
                }
                IconButton(onClick = { player.stopAndClear() }, modifier = Modifier.pressScale()) {
                    Icon(Icons.Filled.Close, contentDescription = "Tutup")
                }
            }
        }
    }
}
