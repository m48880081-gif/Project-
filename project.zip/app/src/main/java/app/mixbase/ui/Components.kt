package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.animation.core.tween
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.coroutineScope
import kotlin.math.abs
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.lerp
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import kotlin.math.roundToInt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection

/** Gambar sampul persegi dengan sudut membulat. */
@Composable
fun Thumb(url: String?, size: Dp, modifier: Modifier = Modifier, pageUrl: String? = null) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant),
    ) {
        // pageUrl (alamat video) dipakai sebagai cadangan bila gambar [url] gagal dimuat.
        ThumbImage(url, pageUrl, Modifier.fillMaxSize())
    }
}

/** Satu baris lagu di daftar hasil / pustaka. */
@Composable
fun TrackRow(
    track: Track,
    playing: Boolean,
    favorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val download = rememberDownloader()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(track.thumb, 56.dp, pageUrl = track.url)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (playing) FontWeight.SemiBold else FontWeight.Normal,
            )
            val sub = buildString {
                append(track.artist)
                if (track.durationSec > 0) {
                    if (isNotEmpty()) append(" • ")
                    append(clock(track.durationSec))
                }
            }
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menu = false
                        onPlayNext()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menu = false
                        onAddToQueue()
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (favorite) "Hapus dari favorit" else "Tambah ke favorit") },
                    onClick = {
                        menu = false
                        onToggleFavorite()
                    },
                )
                DropdownMenuItem(
                    text = { Text("Unduh audio") },
                    onClick = {
                        menu = false
                        download(track, false)
                    },
                )
            }
        }
    }
}

/**
 * Efek jeli: saat ditekan benda penyet (melebar, memendek), saat dilepas ia membal bergoyang seperti air
 * sebelum diam. [source] = sumber interaksi tombol/area yang ditekan; [squash] mengatur seberapa penyet.
 */
@Composable
fun Modifier.jelly(source: InteractionSource, squash: Float = 1f): Modifier {
    val pressed by source.collectIsPressedAsState()
    val sx = remember { Animatable(1f) }
    val sy = remember { Animatable(1f) }
    LaunchedEffect(pressed) {
        if (pressed) {
            launch { sx.animateTo(1f + 0.07f * squash, spring(dampingRatio = 0.55f, stiffness = 800f)) }
            launch { sy.animateTo(1f - 0.13f * squash, spring(dampingRatio = 0.55f, stiffness = 800f)) }
        } else {
            launch { sx.animateTo(1f, spring(dampingRatio = 0.30f, stiffness = 420f)) }
            launch { sy.animateTo(1f, spring(dampingRatio = 0.26f, stiffness = 460f)) }
        }
    }
    return this.graphicsLayer {
        scaleX = sx.value
        scaleY = sy.value
    }
}

/**
 * Pemutar mini berbentuk kapsul kaca (senada dengan bilah navigasi), gaya Auralys:
 * sampul bulat dengan cincin progres, judul + artis, tombol putar/berikutnya.
 * - ketuk: buka layar pemutar penuh (kapsul penyet lalu membal seperti jeli)
 * - geser kiri/kanan: lagu sebelumnya/berikutnya (kapsul melar mengikuti jari, lalu membal kembali)
 * - geser ke bawah: kapsul melar, lalu jatuh dan lenyap seperti tetesan air; setelah itu [onDismiss]
 *   dipanggil (di AppRoot: menghentikan lagu dan mengosongkan antrean)
 * Ukuran kapsul tetap, tidak mengecil saat daftar digulir.
 */
@Composable
fun MiniPlayer(
    player: PlayerConnection,
    backdrop: LiquidBackdrop? = null,
    onDismiss: () -> Unit = {},
    onOpen: () -> Unit,
) {
    val track = player.current ?: return
    // Dibaca hanya saat menggambar cincin progres, jadi kapsul tidak disusun ulang setiap tick posisi lagu.
    val fraction: () -> Float = {
        if (player.durationMs > 0L) {
            (player.positionMs.toFloat() / player.durationMs.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
    }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val currentDismiss by rememberUpdatedState(onDismiss)
    val offsetX = remember { Animatable(0f) }
    val offsetY = remember { Animatable(0f) }
    // Skala jeli untuk muncul dan menghilang. Mulai sedikit melar supaya saat muncul ia bergoyang sampai diam.
    val sx = remember { Animatable(0.93f) }
    val sy = remember { Animatable(1.08f) }
    val fade = remember { Animatable(1f) }
    var leaving by remember { mutableStateOf(false) }
    val body = remember { MutableInteractionSource() }
    val playSrc = remember { MutableInteractionSource() }
    val nextSrc = remember { MutableInteractionSource() }
    val onSurface = MaterialTheme.colorScheme.onSurface
    val ringTrack = onSurface.copy(alpha = 0.15f)
    val shape = RoundedCornerShape(50)
    val dropPx = with(density) { 56.dp.toPx() }

    LaunchedEffect(Unit) {
        launch { sx.animateTo(1f, spring(dampingRatio = 0.30f, stiffness = 420f)) }
        launch { sy.animateTo(1f, spring(dampingRatio = 0.26f, stiffness = 460f)) }
    }

    // Menghilang: penyet sedikit, memanjang, lalu jatuh sambil menyusut dan pudar. Setelah itu lagu dihentikan.
    val dismiss: () -> Unit = {
        if (!leaving) {
            leaving = true
            scope.launch {
                coroutineScope {
                    launch { sx.animateTo(1.10f, tween(80)) }
                    launch { sy.animateTo(0.80f, tween(80)) }
                }
                coroutineScope {
                    launch { sx.animateTo(0.88f, tween(120)) }
                    launch { sy.animateTo(1.16f, tween(120)) }
                }
                coroutineScope {
                    launch { offsetY.animateTo(offsetY.value + dropPx, tween(220)) }
                    launch { sx.animateTo(0.2f, tween(220)) }
                    launch { sy.animateTo(0.2f, tween(220)) }
                    launch { fade.animateTo(0f, tween(200)) }
                }
                currentDismiss()
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, bottom = 2.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .offset { IntOffset(offsetX.value.roundToInt(), offsetY.value.roundToInt()) }
                .graphicsLayer {
                    // Melar mengikuti tarikan jari (ke bawah / ke samping); saat membal lewat batas ia penyet.
                    val pullY = (offsetY.value / 700f).coerceIn(-0.08f, 0.14f)
                    val pullX = (abs(offsetX.value) / 900f).coerceIn(0f, 0.08f)
                    scaleX = sx.value * (1f - pullY * 0.7f) * (1f + pullX)
                    scaleY = sy.value * (1f + pullY) * (1f - pullX * 0.6f)
                    alpha = fade.value
                }
                .jelly(body, squash = 0.7f)
                .liquidGlass(backdrop, tintAlpha = 0.62f, saturation = 1.1f)
                .clip(shape)
                .pointerInput(Unit) {
                    val threshold = 80.dp.toPx()
                    detectHorizontalDragGestures(
                        onDragEnd = {
                            val x = offsetX.value
                            scope.launch {
                                if (!leaving) {
                                    if (x > threshold) player.previous() else if (x < -threshold) player.next()
                                }
                                offsetX.animateTo(0f, spring(dampingRatio = 0.40f, stiffness = 380f))
                            }
                        },
                        onDragCancel = {
                            scope.launch { offsetX.animateTo(0f, spring(dampingRatio = 0.40f, stiffness = 380f)) }
                        },
                        onHorizontalDrag = { change, dx ->
                            if (!leaving) {
                                change.consume()
                                scope.launch { offsetX.snapTo((offsetX.value + dx * 0.6f).coerceIn(-300f, 300f)) }
                            }
                        },
                    )
                }
                .pointerInput(Unit) {
                    val threshold = 40.dp.toPx()
                    detectVerticalDragGestures(
                        onDragEnd = {
                            if (offsetY.value > threshold) {
                                dismiss()
                            } else {
                                scope.launch { offsetY.animateTo(0f, spring(dampingRatio = 0.38f, stiffness = 380f)) }
                            }
                        },
                        onDragCancel = {
                            scope.launch { offsetY.animateTo(0f, spring(dampingRatio = 0.38f, stiffness = 380f)) }
                        },
                        onVerticalDrag = { change, dy ->
                            if (!leaving) {
                                change.consume()
                                scope.launch { offsetY.snapTo((offsetY.value + dy).coerceIn(0f, 300f)) }
                            }
                        },
                    )
                }
                .clickable(interactionSource = body, indication = null, enabled = !leaving) { onOpen() }
                .padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            CompositionLocalProvider(LocalContentColor provides onSurface) {
                // Sampul bulat + cincin progres
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .drawWithContent {
                            drawContent()
                            val stroke = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                            val d = size.minDimension - stroke.width
                            val topLeft = Offset((size.width - d) / 2f, (size.height - d) / 2f)
                            drawArc(
                                color = ringTrack,
                                startAngle = 0f,
                                sweepAngle = 360f,
                                useCenter = false,
                                topLeft = topLeft,
                                size = Size(d, d),
                                style = stroke,
                            )
                            drawArc(
                                color = LiquidRed,
                                startAngle = -90f,
                                sweepAngle = 360f * fraction(),
                                useCenter = false,
                                topLeft = topLeft,
                                size = Size(d, d),
                                style = stroke,
                            )
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Thumb(track.thumb, 40.dp, Modifier.sharedCover("cover").clip(CircleShape), pageUrl = track.url)
                }
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = track.title,
                            modifier = Modifier.sharedPart("np_title"),
                            style = MaterialTheme.typography.titleSmall,
                            color = onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = track.artist,
                            modifier = Modifier.sharedPart("np_artist"),
                            style = MaterialTheme.typography.bodySmall,
                            color = onSurface.copy(alpha = 0.7f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (player.buffering) {
                        PlayLoader(diameter = 24.dp)
                    }
                    IconButton(
                        onClick = { player.togglePlay() },
                        modifier = Modifier.size(44.dp).sharedPart("np_play").jelly(playSrc),
                        interactionSource = playSrc,
                    ) {
                        Icon(
                            painter = painterResource(if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                            contentDescription = "Putar atau jeda",
                            tint = onSurface,
                        )
                    }
                    IconButton(
                        onClick = { player.next() },
                        modifier = Modifier.size(44.dp).sharedPart("np_next").jelly(nextSrc),
                        interactionSource = nextSrc,
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_skip_next),
                            contentDescription = "Berikutnya",
                            tint = onSurface,
                        )
                    }
                }
            }
        }
    }
}
