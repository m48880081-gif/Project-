package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * Efek "fade": bilah atas dan bawah tidak lagi berupa blok padat. Konten bergulir di bawahnya dan
 * terlihat samar lewat gradasi transparan (seperti bilah atas Gemini dan bilah bawah Spotify), sehingga area video
 * lebih luas.
 */

/** Tinggi bilah bawah yang melayang (navigasi + mini player). Layar tab memakainya sebagai ruang kosong di bawah. */
val LocalBarPadding = compositionLocalOf { 0.dp }

/**
 * Bilah atas melayang dengan gradasi transparan yang memudar ke bawah. [onHeight] melaporkan tingginya (dp)
 * supaya daftar di bawahnya bisa memberi ruang kosong di atas isi pertama. Bilah ini selalu tampil.
 */
@Composable
fun FadeTopBar(
    onHeight: (Dp) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val bg = MaterialTheme.colorScheme.background
    val density = LocalDensity.current
    Box(
        modifier = modifier
            .fillMaxWidth()
            .onSizeChanged { onHeight(with(density) { it.height.toDp() }) }
            .background(
                Brush.verticalGradient(
                    0f to bg.copy(alpha = 0.78f),
                    0.55f to bg.copy(alpha = 0.5f),
                    1f to Color.Transparent,
                ),
            ),
    ) {
        content()
    }
}

/** Latar bilah bawah: transparan di atas, makin pekat ke bawah (gaya Spotify). */
@Composable
fun FadeBottomBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val bg = MaterialTheme.colorScheme.background
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.4f to bg.copy(alpha = 0.62f),
                    1f to bg.copy(alpha = 0.88f),
                ),
            ),
    ) {
        content()
    }
}
