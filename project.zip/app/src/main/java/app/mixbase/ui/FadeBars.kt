package app.mixbase.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/*
 * Efek "fade": bilah atas dan bawah tidak lagi berupa blok padat. Konten bergulir di bawahnya dan
 * memudar lewat gradasi (seperti bilah atas Gemini dan bilah bawah Spotify), sehingga area video
 * lebih luas.
 */

/** Tinggi bilah bawah yang melayang (navigasi + mini player). Layar tab memakainya sebagai ruang kosong di bawah. */
val LocalBarPadding = compositionLocalOf { 0.dp }

/**
 * Menyembunyikan bilah atas saat daftar digulir ke bawah dan memunculkannya lagi saat digulir ke atas.
 * Pasang [connection] lewat Modifier.nestedScroll pada induk daftar.
 */
class HideOnScroll {
    var visible by mutableStateOf(true)

    private var acc = 0f

    val connection: NestedScrollConnection = object : NestedScrollConnection {
        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
            val dy = available.y
            if (dy == 0f) return Offset.Zero
            if ((dy > 0f) != (acc > 0f)) acc = 0f
            acc += dy
            if (acc < -48f) {
                visible = false
            } else if (acc > 48f) {
                visible = true
            }
            return Offset.Zero
        }
    }
}

/**
 * Bilah atas melayang dengan gradasi memudar ke bawah. [onHeight] melaporkan tingginya (dp) supaya
 * daftar di bawahnya bisa memberi ruang kosong di atas isi pertama.
 */
@Composable
fun FadeTopBar(
    visible: Boolean,
    onHeight: (Dp) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit,
) {
    val bg = MaterialTheme.colorScheme.background
    val density = LocalDensity.current
    val shown by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(durationMillis = 220),
        label = "fadeTopBar",
    )
    Box(
        modifier = modifier
            .fillMaxWidth()
            .onSizeChanged { onHeight(with(density) { it.height.toDp() }) }
            .graphicsLayer {
                this.alpha = shown
                // Geser keluar layar saat disembunyikan supaya tidak menangkap sentuhan.
                this.translationY = -(1f - shown) * size.height
            }
            .background(
                Brush.verticalGradient(
                    0f to bg.copy(alpha = 0.97f),
                    0.72f to bg.copy(alpha = 0.9f),
                    1f to Color.Transparent,
                ),
            ),
    ) {
        content()
    }
}

/** Latar bilah bawah: transparan di atas, makin pekat ke bawah (gaya Spotify). */
@Composable
fun FadeBottomBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val bg = MaterialTheme.colorScheme.background
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.38f to bg.copy(alpha = 0.94f),
                    1f to bg,
                ),
            ),
    ) {
        content()
    }
}
