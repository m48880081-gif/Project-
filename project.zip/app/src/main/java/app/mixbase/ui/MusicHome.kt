package app.mixbase.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mixbase.R
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.I18n
import app.mixbase.data.MusicApi
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

/** Warna latar Beranda Musik (mode terang): abu kebiruan lembut. Dipasang oleh AppRoot saat Beranda tampil. */
val HomeBgLight = Color(0xFFF5F6F8)

/** Jarak tepi kiri/kanan isi Beranda. */
private val EDGE = 22.dp

/** Lebar kartu rak dan jarak antarkartu. */
private val CARD_SIZE = 140.dp
private val CARD_GAP = 26.dp

/**
 * Beranda mode Musik. Urutan dari atas: sapaan, chip suasana, Andalanmu, Quick picks, lalu rak-rak dari
 * beranda YouTube Music (Today's Indonesian Hits, Monsoon melancholy, ..., New releases, Covers and
 * remixes), dan terakhir kotak Suasana dan genre.
 */
@Composable
fun MusicHomeScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenAlbum: (Entry) -> Unit,
    onOpenArtist: (Entry) -> Unit,
    onOpenMore: (url: String, title: String) -> Unit,
) {
    val home = vm.musicHome
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) {
        home.load(vm.history.toList())
    }

    // Muat rak berikutnya saat daftar digulir hampir ke bawah.
    LaunchedEffect(listState, home) {
        snapshotFlow {
            val info = listState.layoutInfo
            val last = info.visibleItemsInfo.lastOrNull()?.index ?: 0
            Pair(info.totalItemsCount, info.totalItemsCount > 0 && last >= info.totalItemsCount - 3)
        }.collect { st -> if (st.second) home.loadMore() }
    }

    // Bilah atas (header) berupa kotak padat dan selalu tampil; isi bergulir di bawahnya.
    var topH by remember { mutableStateOf(0.dp) }
    val barPad = LocalBarPadding.current

    val openEntry: (Entry) -> Unit = { e ->
        if (e.kind == Entry.ARTIST) onOpenArtist(e) else onOpenAlbum(e)
    }

    // Tombol putar di kartu album: ambil daftar lagunya lalu langsung putar.
    val playEntry: (Entry) -> Unit = { e ->
        scope.launch {
            try {
                val d = withContext(Dispatchers.IO) { Engine.album(e.url) }
                if (d.tracks.isNotEmpty()) player.playQueue(d.tracks, 0)
            } catch (ex: CancellationException) {
                throw ex
            } catch (ex: Exception) {
                Toast.makeText(context, I18n.tr("Gagal memutar album"), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Pencarian suara: hasil ucapan langsung dicari di tab Cari.
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val text = res.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) {
                vm.musicSearch.search(text)
                onSearch()
            }
        }
    }
    val startVoice: () -> Unit = {
        try {
            voice.launch(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, I18n.tr("Sebutkan judul lagu atau artis"))
                },
            )
        } catch (ex: ActivityNotFoundException) {
            Toast.makeText(context, I18n.tr("Pencarian suara tidak tersedia di HP ini"), Toast.LENGTH_SHORT).show()
        }
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(top = topH, bottom = barPad),
        ) {
            item(key = "greeting") { Greeting() }

            item(key = "chips") {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(9.dp),
                ) {
                    items(MOODS.size) { i ->
                        val m = MOODS[i]
                        MoodChip(label = m.first, selected = home.mood == m.first) { home.pickMood(m.first) }
                    }
                }
            }

            if (home.mood != null) {
                // ---- Hasil suasana ----
                item(key = "mood-head") {
                    SectionHeader(
                        title = home.mood ?: "",
                        onPlayAll = if (home.moodTracks.isNotEmpty()) {
                            { player.playQueue(home.moodTracks, 0) }
                        } else {
                            null
                        },
                    )
                }
                if (home.moodLoading && home.moodTracks.isEmpty()) {
                    item(key = "mood-loading") { LoadingBox() }
                } else if (home.moodTracks.isEmpty()) {
                    item(key = "mood-empty") {
                        Text(
                            text = "Tidak ada lagu ditemukan.",
                            modifier = Modifier.padding(EDGE),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    itemsIndexed(home.moodTracks, key = { i, t -> "${t.url}#m$i" }) { i, t ->
                        SongRow(vm, player, t) { player.playQueue(home.moodTracks, i) }
                    }
                }
            } else if (home.loading && home.quick.isEmpty() && home.shelves.isEmpty() && home.dial.isEmpty()) {
                item(key = "loading") { LoadingBox() }
            } else if (home.error != null && home.quick.isEmpty() && home.shelves.isEmpty() && home.dial.isEmpty()) {
                item(key = "error") {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = home.error ?: "",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Button(
                            onClick = { home.load(vm.history.toList(), force = true) },
                            modifier = Modifier.padding(top = 16.dp),
                        ) {
                            Text("Coba lagi")
                        }
                    }
                }
            } else {
                // ---- Andalanmu ----
                if (home.dial.isNotEmpty()) {
                    item(key = "dial-head") { SectionHeader(title = "Andalanmu") }
                    item(key = "dial") {
                        SpeedDial(
                            dial = home.dial,
                            onPlay = { t ->
                                val songs = home.dial.mapNotNull { it.track }
                                player.playQueue(songs, songs.indexOfFirst { it.url == t.url }.coerceAtLeast(0))
                            },
                            onOpen = openEntry,
                        )
                    }
                }

                // ---- Quick picks ----
                if (home.quick.isNotEmpty()) {
                    item(key = "quick-head") {
                        SectionHeader(
                            title = "Quick picks",
                            onPlayAll = { player.playQueue(home.quick, 0) },
                        )
                    }
                    item(key = "quick") { SongPager(vm, player, home.quick) }
                }

                // ---- Rak-rak dari beranda YouTube Music ----
                itemsIndexed(home.shelves, key = { i, s -> "shelf#$i#${s.title}" }) { _, s ->
                    ShelfBlock(
                        shelf = s,
                        vm = vm,
                        player = player,
                        onOpenEntry = openEntry,
                        onPlayEntry = playEntry,
                        onOpenMore = onOpenMore,
                    )
                }

                if (home.hasMore || home.loadingMore) {
                    item(key = "more-loading") { LoadingBox(pad = 28) }
                } else {
                    // ---- Suasana dan genre ----
                    item(key = "genre-head") { SectionHeader(title = "Suasana dan genre") }
                    item(key = "genre") {
                        GenreGrid { label ->
                            if (home.mood != label) home.pickMood(label)
                            scope.launch { listState.animateScrollToItem(0) }
                        }
                    }
                }
            }

            item(key = "end") { Spacer(Modifier.height(28.dp)) }
        }

        TopBar(
            onHeight = { topH = it },
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            AppHeader(onMenu = onMenu, onSearch = onSearch, title = "Beranda")
        }

        // Tombol bulat melayang di kanan bawah: cari dengan suara dan putar acak.
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = barPad + 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            RoundFab(icon = R.drawable.ic_mic, description = "Cari dengan suara", onClick = startVoice)
            RoundFab(
                icon = R.drawable.ic_shuffle,
                description = "Putar acak",
                onClick = {
                    val pool = home.allSongs()
                    if (pool.isNotEmpty()) player.playQueue(pool.shuffled(), 0)
                },
            )
        }
    }
}

// =====================================================================
// Bagian-bagian kecil
// =====================================================================

private fun greetingNow(): String {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 4..10 -> "Selamat pagi"
        in 11..14 -> "Selamat siang"
        in 15..17 -> "Selamat sore"
        else -> "Selamat malam"
    }
}

/** Warna kotak/chip di atas latar Beranda (mengikuti terang/gelap). */
@Composable
private fun boxColor(): Color {
    val scheme = MaterialTheme.colorScheme
    return if (scheme.background.luminance() > 0.5f) Color(0xFFEDEEF2) else scheme.surfaceContainerHigh
}

@Composable
private fun Greeting() {
    val text = remember { greetingNow() }
    Text(
        text = text,
        fontSize = 32.sp,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        modifier = Modifier.padding(start = EDGE, end = EDGE, top = 12.dp, bottom = 14.dp),
    )
}

@Composable
private fun MoodChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val bg = if (selected) scheme.primaryContainer else boxColor()
    val fg = if (selected) scheme.onPrimaryContainer else scheme.onSurface
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = label, color = fg, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/** Judul bagian: teks kecil opsional di atas judul, lalu "Putar semua" atau panah "lihat semua" di kanan. */
@Composable
private fun SectionHeader(
    title: String,
    overline: String = "",
    onPlayAll: (() -> Unit)? = null,
    onMore: (() -> Unit)? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = EDGE, end = EDGE, top = 30.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            if (overline.isNotBlank()) {
                Text(
                    text = overline.uppercase(),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = title,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (onPlayAll != null) {
            Text(
                text = "Putar semua",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onPlayAll)
                    .padding(start = 12.dp, top = 6.dp, bottom = 6.dp),
            )
        }
        if (onMore != null) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onMore),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_arrow_forward),
                    contentDescription = "Lihat semua",
                    modifier = Modifier.size(24.dp),
                )
            }
        }
    }
}

@Composable
private fun LoadingBox(pad: Int = 48) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(pad.dp),
        contentAlignment = Alignment.Center,
    ) {
        PlayLoader()
    }
}

// ---------------------------------------------------------------------
// Andalanmu: kotak 3 x 3 per halaman, geser samping, penanda halaman di bawah
// ---------------------------------------------------------------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SpeedDial(dial: List<DialItem>, onPlay: (Track) -> Unit, onOpen: (Entry) -> Unit) {
    val pages = remember(dial) { dial.chunked(9) }
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(lazyListState = state)
    val current by remember(state) {
        derivedStateOf {
            val width = state.layoutInfo.viewportSize.width
            val offset = state.firstVisibleItemScrollOffset
            if (width > 0 && offset > width / 2) state.firstVisibleItemIndex + 1 else state.firstVisibleItemIndex
        }
    }
    Column {
        LazyRow(state = state, flingBehavior = fling) {
            items(pages.size) { p ->
                DialPage(pages[p], Modifier.fillParentMaxWidth(), onPlay, onOpen)
            }
        }
        PageDots(count = pages.size, current = current)
    }
}

@Composable
private fun DialPage(
    page: List<DialItem>,
    modifier: Modifier,
    onPlay: (Track) -> Unit,
    onOpen: (Entry) -> Unit,
) {
    Column(
        modifier = modifier.padding(horizontal = 26.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        for (row in page.chunked(3)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(9.dp),
            ) {
                for (item in row) {
                    DialTile(
                        item = item,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val t = item.track
                            val e = item.entry
                            if (t != null) onPlay(t) else if (e != null) onOpen(e)
                        },
                    )
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun DialTile(item: DialItem, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(296f / 220f)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            val t = item.track
            if (t != null) {
                ThumbImage(t.thumb, t.url, Modifier.fillMaxSize(), hd = true, px = 600)
            } else {
                HdImage(item.entry?.thumb, Modifier.fillMaxSize(), px = 600)
            }
        }
        Row(
            modifier = Modifier.padding(top = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = item.title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (item.entry != null) {
                Icon(
                    Icons.Filled.KeyboardArrowRight,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
            }
        }
    }
}

@Composable
private fun PageDots(count: Int, current: Int) {
    if (count <= 1) return
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        for (i in 0 until count) {
            val on = i == current
            val w by animateDpAsState(if (on) 18.dp else 9.dp, label = "dot")
            Box(
                modifier = Modifier
                    .padding(horizontal = 3.dp)
                    .width(w)
                    .height(3.dp)
                    .clip(RoundedCornerShape(50))
                    .background(
                        if (on) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outlineVariant,
                    ),
            )
        }
    }
}

// ---------------------------------------------------------------------
// Quick picks dan rak daftar lagu: halaman berisi 4 lagu, geser samping (halaman berikutnya mengintip)
// ---------------------------------------------------------------------

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SongPager(vm: AppViewModel, player: PlayerConnection, tracks: List<Track>) {
    val pages = remember(tracks) { tracks.chunked(4) }
    val state = rememberLazyListState()
    val fling = rememberSnapFlingBehavior(lazyListState = state)
    LazyRow(state = state, flingBehavior = fling) {
        items(pages.size) { p ->
            Column(Modifier.fillParentMaxWidth(0.9f)) {
                for ((j, t) in pages[p].withIndex()) {
                    SongRow(vm, player, t) { player.playQueue(tracks, p * 4 + j) }
                }
            }
        }
    }
}

/** Baris lagu: sampul, judul, artis, menu ⋮. */
@Composable
private fun SongRow(vm: AppViewModel, player: PlayerConnection, t: Track, onPlay: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val playing = player.current?.url == t.url

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
            .padding(start = EDGE, end = 2.dp, top = 9.dp, bottom = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(t.thumb, 52.dp, pageUrl = t.url)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = t.title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            if (t.artist.isNotBlank()) {
                Text(
                    text = t.artist,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menu = false
                        player.playNext(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menu = false
                        player.addToQueue(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (vm.isFavorite(t.url)) "Hapus dari favorit" else "Tambah ke favorit") },
                    onClick = {
                        menu = false
                        vm.toggleFavorite(t)
                    },
                )
            }
        }
    }
}

// ---------------------------------------------------------------------
// Rak dari beranda YouTube Music
// ---------------------------------------------------------------------

@Composable
private fun ShelfBlock(
    shelf: MusicApi.HomeShelf,
    vm: AppViewModel,
    player: PlayerConnection,
    onOpenEntry: (Entry) -> Unit,
    onPlayEntry: (Entry) -> Unit,
    onOpenMore: (url: String, title: String) -> Unit,
) {
    val asList = shelf.list && shelf.tracks.isNotEmpty()
    val more = shelf.more
    SectionHeader(
        title = shelf.title,
        overline = shelf.overline,
        onPlayAll = if (asList) {
            { player.playQueue(shelf.tracks, 0) }
        } else {
            null
        },
        onMore = if (!asList && more != null && shelf.entries.isNotEmpty()) {
            { onOpenMore("more:${more.browseId}|${more.params ?: ""}", shelf.title) }
        } else {
            null
        },
    )
    if (asList) {
        SongPager(vm, player, shelf.tracks)
    } else {
        CardRow(shelf, player, onOpenEntry, onPlayEntry)
    }
}

@Composable
private fun CardRow(
    shelf: MusicApi.HomeShelf,
    player: PlayerConnection,
    onOpenEntry: (Entry) -> Unit,
    onPlayEntry: (Entry) -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = EDGE),
        horizontalArrangement = Arrangement.spacedBy(CARD_GAP),
    ) {
        itemsIndexed(shelf.entries, key = { _, e -> "e:${e.url}" }) { _, e ->
            HomeCard(
                title = e.title,
                sub = e.sub,
                onClick = { onOpenEntry(e) },
                // Album: tombol putar besar; playlist/artis: hanya penanda kecil, ketuk untuk membuka.
                onPlay = if (e.kind == Entry.ALBUM) {
                    { onPlayEntry(e) }
                } else {
                    null
                },
            ) {
                HdImage(e.thumb, Modifier.fillMaxSize(), px = 600)
            }
        }
        itemsIndexed(shelf.tracks, key = { _, t -> "t:${t.url}" }) { i, t ->
            HomeCard(
                title = t.title,
                sub = t.artist,
                onClick = { player.playQueue(shelf.tracks, i) },
                onPlay = { player.playQueue(shelf.tracks, i) },
            ) {
                ThumbImage(t.thumb, t.url, Modifier.fillMaxSize(), hd = true, px = 600)
            }
        }
    }
}

/** Kartu persegi: sampul, judul, keterangan. [onPlay] != null = tombol putar besar di pojok kanan bawah. */
@Composable
private fun HomeCard(
    title: String,
    sub: String,
    onClick: () -> Unit,
    onPlay: (() -> Unit)?,
    image: @Composable () -> Unit,
) {
    Column(
        modifier = Modifier
            .width(CARD_SIZE)
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .size(CARD_SIZE)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            image()
            if (onPlay != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(9.dp)
                        .size(35.dp)
                        .clip(CircleShape)
                        .background(Color(0xE60E1116))
                        .clickable(onClick = onPlay),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.PlayArrow,
                        contentDescription = "Putar",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp),
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.45f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp),
                    )
                }
            }
        }
        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        if (sub.isNotBlank()) {
            Text(
                text = sub,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// ---------------------------------------------------------------------
// Suasana dan genre: kotak 4 baris, geser samping
// ---------------------------------------------------------------------

@Composable
private fun GenreGrid(onPick: (String) -> Unit) {
    val bg = boxColor()
    LazyHorizontalGrid(
        rows = GridCells.Fixed(4),
        modifier = Modifier
            .fillMaxWidth()
            .height(61.dp * 4 + 13.dp * 3),
        contentPadding = PaddingValues(horizontal = EDGE),
        horizontalArrangement = Arrangement.spacedBy(13.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp),
    ) {
        items(GENRES.size) { i ->
            val label = GENRES[i].first
            Box(
                modifier = Modifier
                    .width(196.dp)
                    .height(61.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(bg)
                    .clickable { onPick(label) }
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(text = label, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            }
        }
    }
}

// ---------------------------------------------------------------------
// Tombol bulat melayang
// ---------------------------------------------------------------------

@Composable
private fun RoundFab(icon: Int, description: String, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val light = scheme.background.luminance() > 0.5f
    Box(
        modifier = Modifier
            .size(48.dp)
            .shadow(6.dp, CircleShape)
            .clip(CircleShape)
            .background(if (light) Color.White.copy(alpha = 0.94f) else scheme.surfaceContainerHigh)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = description,
            modifier = Modifier.size(22.dp),
        )
    }
}
