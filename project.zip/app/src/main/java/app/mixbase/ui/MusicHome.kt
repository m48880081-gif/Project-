package app.mixbase.ui

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyHorizontalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Entry
import app.mixbase.data.Track
import app.mixbase.data.compactCount
import app.mixbase.player.PlayerConnection
import coil.compose.AsyncImage

/** Beranda mode Musik: bergaya YouTube Music (tetap putih). */
@Composable
fun MusicHomeScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenAlbum: (Entry) -> Unit,
    onOpenArtist: (Entry) -> Unit,
) {
    val home = vm.musicHome

    LaunchedEffect(Unit) {
        home.load(vm.history.toList())
    }

    // Bilah atas (header) berupa kotak padat dan selalu tampil; chip suasana ikut bergulir bersama isi.
    var topH by remember { mutableStateOf(0.dp) }
    val barPad = LocalBarPadding.current
    val listState = rememberLazyListState()
    LaunchedEffect(home.mood) {
        if (home.mood != null) listState.animateScrollToItem(0)
    }
    // "Andalanmu": favorit + riwayat dulu, lalu dilengkapi lagu dari beranda (maksimal 27 = 3 halaman 3x3).
    val mine: List<Track> = remember(vm.history.size, vm.favorites.size, home.quick, home.fresh) {
        (vm.favorites.toList() + vm.history.toList() + home.quick + home.fresh)
            .distinctBy { it.url }
            .take(27)
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(top = topH, bottom = barPad + 80.dp),
        ) {
            item { Greeting() }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    itemsIndexed(MOODS) { _, m ->
                        val sel = home.mood == m.first
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (sel) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.surfaceContainerHigh
                                    },
                                )
                                .clickable { home.pickMood(m.first) }
                                .padding(horizontal = 18.dp, vertical = 12.dp),
                        ) {
                            Text(
                                text = m.first,
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                }
            }

            if (home.mood != null) {
                // ---- Hasil suasana ----
                item {
                    SectionHeader(
                        title = home.mood ?: "",
                        onPlayAll = if (home.moodTracks.isNotEmpty()) {
                            { player.playQueue(home.moodTracks, 0) }
                        } else {
                            null
                        },
                    )
                }
                if (home.moodLoading) {
                    item { LoadingBox() }
                } else if (home.moodTracks.isEmpty()) {
                    item {
                        Text(
                            text = "Tidak ada lagu ditemukan.",
                            modifier = Modifier.padding(16.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                } else {
                    itemsIndexed(home.moodTracks, key = { i, t -> "${t.url}#$i" }) { i, t ->
                        QuickRow(vm, player, t) { player.playQueue(home.moodTracks, i) }
                    }
                }
            } else if (home.loading && home.quick.isEmpty() && home.albums.isEmpty()) {
                item { LoadingBox() }
            } else if (home.error != null && home.quick.isEmpty() && home.albums.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = home.error ?: "",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Button(
                            onClick = { home.load(vm.history.toList(), force = true) },
                            modifier = Modifier.padding(top = 16.dp),
                        ) {
                            Text("Coba lagi")
                        }
                    }
                }
            } else {
                // ---- Andalanmu: halaman geser 3x3 ----
                if (mine.isNotEmpty()) {
                    item { SectionHeader(title = "Andalanmu") }
                    item { YourGrid(mine, player) }
                }

                // ---- Pilihan cepat ----
                trackPager("Pilihan cepat", home.quick, vm, player)

                trackCarousel("LAGU TERPOPULER SAAT INI", "Hits Indonesia hari ini", home.extra["hits"].orEmpty(), player)
                trackCarousel("SOUNDTRACK HARI MENDUNG", "Hujan melankolis", home.extra["rain"].orEmpty(), player)

                if (home.albums.isNotEmpty()) {
                    item { SectionHeader(title = "Album yang sedang tren") }
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp),
                        ) {
                            itemsIndexed(home.albums, key = { _, e -> e.url }) { _, e ->
                                HomeCard(e.thumb, e.title, e.sub.ifBlank { "Album" }, 144.dp, false) { onOpenAlbum(e) }
                            }
                        }
                    }
                }

                trackCarousel("TEMAN SANTAI DI HARI HUJAN", "Santai dan hangat", home.extra["cozy"].orEmpty(), player)
                trackPager("Lagu tren untuk kamu", home.extra["trend"].orEmpty(), vm, player)
                trackCarousel("LAGU DUNIA TERBAIK SAAT INI", "Hits internasional hari ini", home.extra["world"].orEmpty(), player)
                trackCarousel(null, "Rilis baru", home.fresh, player, playBadge = true, arrowPlays = true)
                trackPager("Cover dan remix", home.extra["cover"].orEmpty(), vm, player)

                // ---- Suasana dan genre ----
                item { SectionHeader(title = "Suasana dan genre") }
                item { GenreGrid(home) }
            }

            item { Spacer(Modifier.height(16.dp)) }
        }

        TopBar(
            onHeight = { topH = it },
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            AppHeader(onMenu = onMenu, onSearch = onSearch, tag = "Musik")
        }

        // Tombol acak melayang (memutar acak dari riwayat, atau dari lagu beranda bila riwayat kosong).
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = barPad + 16.dp)
                .size(56.dp)
                .shadow(6.dp, CircleShape)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .clickable {
                    val pool = if (vm.history.isNotEmpty()) vm.history.toList() else home.quick
                    if (pool.isNotEmpty()) player.playQueue(pool.shuffled(), 0)
                },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_shuffle),
                contentDescription = "Putar acak",
                tint = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

// =====================================================================
// Bagian-bagian kecil
// =====================================================================

@Composable
private fun SectionHeader(
    title: String,
    onPlayAll: (() -> Unit)? = null,
    kicker: String? = null,
    onArrow: (() -> Unit)? = null,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 8.dp, top = 28.dp, bottom = 12.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Column(Modifier.weight(1f)) {
            if (kicker != null) {
                Text(
                    text = kicker,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall.copy(fontSize = 26.sp),
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (onPlayAll != null) {
            Text(
                text = "Putar semua",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .clickable(onClick = onPlayAll)
                    .padding(horizontal = 8.dp, vertical = 8.dp),
            )
        }
        if (onArrow != null) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Putar semua",
                modifier = Modifier
                    .clip(CircleShape)
                    .clickable(onClick = onArrow)
                    .padding(8.dp)
                    .size(24.dp),
            )
        }
    }
}

/** Salam sesuai jam di perangkat. */
@Composable
private fun Greeting() {
    val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
    val text = when (hour) {
        in 4..10 -> "Selamat pagi"
        in 11..14 -> "Selamat siang"
        in 15..17 -> "Selamat sore"
        else -> "Selamat malam"
    }
    Text(
        text = text,
        style = MaterialTheme.typography.headlineLarge.copy(fontSize = 34.sp),
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 4.dp, bottom = 8.dp),
    )
}

/** Kartu persegi besar (sampul + judul + sub) untuk carousel; [playBadge] menambah tombol putar di pojok. */
@Composable
private fun HomeCard(thumb: String?, title: String, sub: String, size: Dp, playBadge: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(size)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            HdImage(thumb, Modifier.fillMaxSize(), px = 600)
            if (playBadge) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.85f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        painter = painterResource(R.drawable.ic_play),
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp),
                    )
                }
            }
        }
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall.copy(fontSize = 16.sp),
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            text = sub,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Bagian carousel berisi lagu (kicker kecil + judul besar). Dilewati bila belum ada isinya. */
private fun LazyListScope.trackCarousel(
    kicker: String?,
    title: String,
    tracks: List<Track>,
    player: PlayerConnection,
    playBadge: Boolean = false,
    arrowPlays: Boolean = false,
) {
    if (tracks.isEmpty()) return
    item {
        SectionHeader(
            title = title,
            kicker = kicker,
            onArrow = if (arrowPlays) {
                { player.playQueue(tracks, 0) }
            } else {
                null
            },
        )
    }
    item {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            itemsIndexed(tracks, key = { i, t -> "${t.url}#$i" }) { i, t ->
                HomeCard(t.thumb, t.title, t.artist, 144.dp, playBadge) { player.playQueue(tracks, i) }
            }
        }
    }
}

/** Bagian daftar lagu halaman-halaman geser (4 lagu per halaman) dengan tombol "Putar semua". */
private fun LazyListScope.trackPager(
    title: String,
    tracks: List<Track>,
    vm: AppViewModel,
    player: PlayerConnection,
) {
    if (tracks.isEmpty()) return
    item { SectionHeader(title = title, onPlayAll = { player.playQueue(tracks, 0) }) }
    item { QuickPager(vm, player, tracks) }
}

/** "Andalanmu": halaman geser berisi kotak 3x3 sampul lagu, dengan penanda halaman di bawahnya. */
@Composable
private fun YourGrid(tracks: List<Track>, player: PlayerConnection) {
    val pages = tracks.chunked(9)
    val pager = rememberPagerState(pageCount = { pages.size })
    val onSurface = MaterialTheme.colorScheme.onSurface
    Column {
        HorizontalPager(
            state = pager,
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top,
        ) { p ->
            val page = pages[p]
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                page.chunked(3).forEachIndexed { r, row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        row.forEachIndexed { c, t ->
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { player.playQueue(tracks, p * 9 + r * 3 + c) },
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                ) {
                                    HdImage(t.thumb, Modifier.fillMaxSize(), px = 400)
                                }
                                Text(
                                    text = t.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontSize = 15.sp),
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 6.dp),
                                )
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        if (pages.size > 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 14.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                repeat(pages.size) { i ->
                    val selected = pager.currentPage == i
                    val w by animateDpAsState(if (selected) 24.dp else 12.dp, label = "dot")
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .height(4.dp)
                            .width(w)
                            .clip(CircleShape)
                            .background(if (selected) onSurface else onSurface.copy(alpha = 0.15f)),
                    )
                }
            }
        }
    }
}

/** "Suasana dan genre": kisi 4 baris yang digeser ke samping; mengetuk memuat lagu suasana itu. */
@Composable
private fun GenreGrid(home: MusicHomeState) {
    LazyHorizontalGrid(
        rows = GridCells.Fixed(4),
        modifier = Modifier
            .fillMaxWidth()
            .height(4 * 56.dp + 3 * 12.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(MOODS) { m ->
            Box(
                modifier = Modifier
                    .width(176.dp)
                    .height(56.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                    .clickable { home.pickMood(m.first) }
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(
                    text = m.first,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
    }
}

@Composable
private fun LoadingBox() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(48.dp),
        contentAlignment = Alignment.Center,
    ) {
        PlayLoader()
    }
}

/** Halaman-halaman geser samping, masing-masing berisi 4 lagu. */
@Composable
private fun QuickPager(vm: AppViewModel, player: PlayerConnection, tracks: List<Track>) {
    val pages = tracks.chunked(4)
    LazyRow(
        contentPadding = PaddingValues(start = 0.dp, end = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        itemsIndexed(pages) { p, page ->
            Column(Modifier.fillParentMaxWidth(0.92f)) {
                page.forEachIndexed { j, t ->
                    QuickRow(vm, player, t) { player.playQueue(tracks, p * 4 + j) }
                }
            }
        }
    }
}

/** Baris lagu: sampul, judul, "Artis • N jt pemutaran", menu ⋮. */
@Composable
fun QuickRow(vm: AppViewModel, player: PlayerConnection, t: Track, onPlay: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val playing = player.current?.url == t.url

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(t.thumb, 56.dp, pageUrl = t.url)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = t.title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            val sub = buildString {
                append(t.artist)
                if (t.views >= 0L) {
                    if (isNotEmpty()) append(" • ")
                    append(compactCount(t.views)).append(" pemutaran")
                }
            }
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menu = false
                        player.playNext(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menu = false
                        player.addToQueue(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (vm.isFavorite(t.url)) "Hapus dari favorit" else "Tambah ke favorit") },
                    onClick = {
                        menu = false
                        vm.toggleFavorite(t)
                    },
                )
            }
        }
    }
}

@Composable
private fun ShortcutCard(
    label: String,
    colors: List<Color>,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(124.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(colors))
            .clickable(onClick = onClick),
    ) {
        Box(Modifier.align(Alignment.Center)) { icon() }
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp),
        )
    }
}

@Composable
private fun ShortcutImageCard(label: String, thumb: String?, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(124.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
    ) {
        if (thumb != null) {
            AsyncImage(
                model = thumb,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)))),
        )
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp),
        )
    }
}

/** Kartu album persegi besar (HD): sampul, judul, "Album • artis". */
@Composable
fun AlbumCard(e: Entry, size: Dp, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(size)
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            HdImage(e.thumb, Modifier.fillMaxSize(), px = 600)
        }
        Text(
            text = e.title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            text = if (e.sub.isBlank()) "Album" else "Album • ${e.sub}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
