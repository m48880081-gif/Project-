package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Entry
import app.mixbase.data.Track
import app.mixbase.data.compactCount
import app.mixbase.player.PlayerConnection
import coil.compose.AsyncImage

/** Beranda mode Musik: bergaya YouTube Music (tetap putih). */
@Composable
fun MusicHomeScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onMenu: () -> Unit,
    onSearch: () -> Unit,
    onOpenAlbum: (Entry) -> Unit,
    onOpenArtist: (Entry) -> Unit,
) {
    val home = vm.musicHome

    LaunchedEffect(Unit) {
        home.load(vm.history.toList())
    }

    LazyColumn(Modifier.fillMaxSize()) {
        // Bilah atas (sama dengan Video)
        item { AppHeader(onMenu = onMenu, onSearch = onSearch, tag = "Musik") }

        // Chip suasana
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(MOODS) { _, m ->
                    FilterChip(
                        selected = home.mood == m.first,
                        onClick = { home.pickMood(m.first) },
                        label = { Text(m.first) },
                    )
                }
            }
        }

        if (home.mood != null) {
            // ---- Hasil suasana ----
            item {
                SectionHeader(
                    title = home.mood ?: "",
                    onPlayAll = if (home.moodTracks.isNotEmpty()) {
                        { player.playQueue(home.moodTracks, 0) }
                    } else {
                        null
                    },
                )
            }
            if (home.moodLoading) {
                item { LoadingBox() }
            } else if (home.moodTracks.isEmpty()) {
                item {
                    Text(
                        text = "Tidak ada lagu ditemukan.",
                        modifier = Modifier.padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            } else {
                itemsIndexed(home.moodTracks, key = { i, t -> "${t.url}#$i" }) { i, t ->
                    QuickRow(vm, player, t) { player.playQueue(home.moodTracks, i) }
                }
            }
        } else if (home.loading && home.quick.isEmpty() && home.albums.isEmpty()) {
            item { LoadingBox() }
        } else if (home.error != null && home.quick.isEmpty() && home.albums.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(
                        text = home.error ?: "",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge,
                    )
                    Button(
                        onClick = { home.load(vm.history.toList(), force = true) },
                        modifier = Modifier.padding(top = 16.dp),
                    ) {
                        Text("Coba lagi")
                    }
                }
            }
        } else {
            // ---- Pilihan cepat ----
            if (home.quick.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "Pilihan cepat",
                        onPlayAll = { player.playQueue(home.quick, 0) },
                    )
                }
                item { QuickPager(vm, player, home.quick) }
            }

            // ---- Pintasan cepat ----
            item { SectionHeader(title = "Pintasan cepat", onPlayAll = null) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (vm.favorites.isNotEmpty()) {
                        item {
                            ShortcutCard(
                                label = "Favorit",
                                colors = listOf(Color(0xFF7B5CFF), Color(0xFFE040A0)),
                                onClick = { player.playQueue(vm.favorites.toList(), 0) },
                            ) {
                                Icon(
                                    Icons.Filled.Favorite,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(40.dp),
                                )
                            }
                        }
                    }
                    item {
                        ShortcutCard(
                            label = "Acak",
                            colors = listOf(Color(0xFF00A58E), Color(0xFF3F8CFF)),
                            onClick = {
                                val pool = if (vm.history.isNotEmpty()) vm.history.toList() else home.quick
                                if (pool.isNotEmpty()) player.playQueue(pool.shuffled(), 0)
                            },
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_shuffle),
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(40.dp),
                            )
                        }
                    }
                    itemsIndexed(home.artists.take(6), key = { _, e -> e.url }) { _, e ->
                        ShortcutImageCard(e.title, e.thumb) { onOpenArtist(e) }
                    }
                }
            }

            // ---- Album untuk kamu ----
            if (home.albums.isNotEmpty()) {
                item { SectionHeader(title = "Album untuk kamu", onPlayAll = null) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        itemsIndexed(home.albums, key = { _, e -> e.url }) { _, e ->
                            AlbumCard(e, 160.dp) { onOpenAlbum(e) }
                        }
                    }
                }
            }

            // ---- Rilis terbaru ----
            if (home.fresh.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "Rilis terbaru",
                        onPlayAll = { player.playQueue(home.fresh, 0) },
                    )
                }
                item { QuickPager(vm, player, home.fresh) }
            }

            // ---- Artis untuk kamu ----
            if (home.artists.isNotEmpty()) {
                item { SectionHeader(title = "Artis untuk kamu", onPlayAll = null) }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(home.artists, key = { _, e -> e.url }) { _, e ->
                            Column(
                                modifier = Modifier
                                    .width(96.dp)
                                    .clickable { onOpenArtist(e) },
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Avatar(url = e.thumb, name = e.title, size = 96.dp)
                                Text(
                                    text = e.title,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 6.dp),
                                )
                            }
                        }
                    }
                }
            }

            // ---- Terakhir diputar ----
            if (vm.history.isNotEmpty()) {
                val recent = vm.history.take(8).toList()
                item { SectionHeader(title = "Terakhir diputar", onPlayAll = { player.playQueue(recent, 0) }) }
                itemsIndexed(recent, key = { i, t -> "${t.url}#r$i" }) { i, t ->
                    QuickRow(vm, player, t) { player.playQueue(recent, i) }
                }
            }
        }

        item { Spacer(Modifier.height(16.dp)) }
    }
}

// =====================================================================
// Bagian-bagian kecil
// =====================================================================

@Composable
private fun SectionHeader(title: String, onPlayAll: (() -> Unit)?) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (onPlayAll != null) {
            Text(
                text = "Putar semua",
                style = MaterialTheme.typography.labelLarge,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(MaterialTheme.colorScheme.secondaryContainer)
                    .clickable(onClick = onPlayAll)
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
        }
    }
}

@Composable
private fun LoadingBox() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(48.dp),
        contentAlignment = Alignment.Center,
    ) {
        PlayLoader()
    }
}

/** Halaman-halaman geser samping, masing-masing berisi 4 lagu. */
@Composable
private fun QuickPager(vm: AppViewModel, player: PlayerConnection, tracks: List<Track>) {
    val pages = tracks.chunked(4)
    LazyRow(
        contentPadding = PaddingValues(start = 0.dp, end = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(0.dp),
    ) {
        itemsIndexed(pages) { p, page ->
            Column(Modifier.fillParentMaxWidth(0.92f)) {
                page.forEachIndexed { j, t ->
                    QuickRow(vm, player, t) { player.playQueue(tracks, p * 4 + j) }
                }
            }
        }
    }
}

/** Baris lagu: sampul, judul, "Artis • N jt pemutaran", menu ⋮. */
@Composable
fun QuickRow(vm: AppViewModel, player: PlayerConnection, t: Track, onPlay: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val playing = player.current?.url == t.url

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onPlay)
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(t.thumb, 56.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = t.title,
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = if (playing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            val sub = buildString {
                append(t.artist)
                if (t.views >= 0L) {
                    if (isNotEmpty()) append(" • ")
                    append(compactCount(t.views)).append(" pemutaran")
                }
            }
            Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Box {
            IconButton(onClick = { menu = true }) {
                Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text("Putar berikutnya") },
                    onClick = {
                        menu = false
                        player.playNext(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text("Tambah ke antrean") },
                    onClick = {
                        menu = false
                        player.addToQueue(t)
                    },
                )
                DropdownMenuItem(
                    text = { Text(if (vm.isFavorite(t.url)) "Hapus dari favorit" else "Tambah ke favorit") },
                    onClick = {
                        menu = false
                        vm.toggleFavorite(t)
                    },
                )
            }
        }
    }
}

@Composable
private fun ShortcutCard(
    label: String,
    colors: List<Color>,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(124.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.linearGradient(colors))
            .clickable(onClick = onClick),
    ) {
        Box(Modifier.align(Alignment.Center)) { icon() }
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp),
        )
    }
}

@Composable
private fun ShortcutImageCard(label: String, thumb: String?, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(124.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick),
    ) {
        if (thumb != null) {
            AsyncImage(
                model = thumb,
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
            )
        }
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .align(Alignment.BottomCenter)
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)))),
        )
        Text(
            text = label,
            color = Color.White,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp),
        )
    }
}

/** Kartu album persegi besar (HD): sampul, judul, "Album • artis". */
@Composable
fun AlbumCard(e: Entry, size: Dp, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(size)
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            HdImage(e.thumb, Modifier.fillMaxSize(), px = 600)
        }
        Text(
            text = e.title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        Text(
            text = if (e.sub.isBlank()) "Album" else "Album • ${e.sub}",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
