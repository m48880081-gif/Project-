package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Channel
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.Track
import app.mixbase.data.compactCount
import app.mixbase.player.PlayerConnection
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** State satu halaman channel: info, tab yang aktif, dan isi tab (dengan muat berikutnya). */
class ChannelState(
    private val scope: CoroutineScope,
    private val url: String,
) {
    var details by mutableStateOf<Engine.ChannelDetails?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var tab by mutableIntStateOf(0)
        private set
    val tracks = mutableStateListOf<Track>()
    val entries = mutableStateListOf<Entry>()
    var tabLoading by mutableStateOf(false)
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var canMore by mutableStateOf(false)
        private set

    private var session: Engine.TabSession? = null
    private var tabJob: Job? = null
    private var epoch = 0

    init {
        scope.launch {
            try {
                val d = withContext(Dispatchers.IO) { Engine.channel(url) }
                details = d
                selectTab(0)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Gagal memuat channel: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun selectTab(i: Int) {
        val d = details ?: return
        if (i < 0 || i >= d.tabs.size) {
            tracks.clear()
            entries.clear()
            return
        }
        tab = i
        epoch += 1
        val id = epoch
        tabJob?.cancel()
        tracks.clear()
        entries.clear()
        canMore = false
        loadingMore = false
        tabLoading = true
        session = null
        tabJob = scope.launch {
            try {
                val s = withContext(Dispatchers.IO) { Engine.openTab(d.tabs[i]) }
                val batch = withContext(Dispatchers.IO) { s.first() }
                if (id == epoch) {
                    session = s
                    tracks.addAll(batch.tracks)
                    entries.addAll(batch.entries)
                    canMore = s.hasMore
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == epoch) error = "Gagal memuat isi: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                if (id == epoch) tabLoading = false
            }
        }
    }

    fun loadMore() {
        val s = session ?: return
        if (tabLoading || loadingMore || !canMore) return
        loadingMore = true
        val id = epoch
        scope.launch {
            try {
                val more = withContext(Dispatchers.IO) { s.more() }
                if (id == epoch) {
                    for (t in more.tracks) {
                        if (tracks.none { it.url == t.url }) tracks.add(t)
                    }
                    for (e in more.entries) {
                        if (entries.none { it.url == e.url }) entries.add(e)
                    }
                    canMore = s.hasMore
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == epoch) canMore = false
            } finally {
                if (id == epoch) loadingMore = false
            }
        }
    }
}

/**
 * Halaman akun/channel/artis. [Screen.ChannelPage.music] true → isinya diputar sebagai lagu
 * (pemutar musik); false → dibuka sebagai video.
 */
@Composable
fun ChannelScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
    page: Screen.ChannelPage,
    onBack: () -> Unit,
    onOpenCollection: (Entry) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val st = remember(page.url) { ChannelState(scope, page.url) }
    val listState = rememberLazyListState()

    BackHandler(onBack = onBack)

    val nearEnd by remember(st) {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            val total = st.tracks.size + st.entries.size
            total > 0 && last >= total - 1
        }
    }
    LaunchedEffect(nearEnd, st.tracks.size, st.entries.size) {
        if (nearEnd) st.loadMore()
    }

    val d = st.details

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
            // Spanduk + tombol kembali
            item {
                Box(Modifier.fillMaxWidth()) {
                    val banner = d?.banner
                    if (banner != null) {
                        AsyncImage(
                            model = banner,
                            contentDescription = null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 5f),
                            contentScale = ContentScale.Crop,
                        )
                    } else {
                        Spacer(
                            Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                        )
                    }
                    Row(
                        modifier = Modifier.padding(4.dp),
                    ) {
                        IconButton(onClick = onBack) {
                            Icon(
                                painter = painterResource(R.drawable.ic_arrow_back),
                                contentDescription = "Kembali",
                            )
                        }
                    }
                }
            }

            // Info channel
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(url = d?.avatar, name = d?.name ?: page.name, size = 76.dp)
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = d?.name?.ifBlank { null } ?: page.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                        if (d != null && d.subscribers >= 0L) {
                            Text(
                                text = compactCount(d.subscribers) + " subscriber",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }

            if (d != null && d.description.isNotBlank()) {
                item {
                    Text(
                        text = d.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                }
            }

            // Tombol
            item {
                val subscribed = vm.isSubscribed(page.url)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PillButton(
                        text = if (subscribed) "Berlangganan" else "Langganan\u200B",
                        style = if (subscribed) PillStyle.TONAL else PillStyle.FILLED,
                        onClick = {
                            vm.toggleSubscribe(
                                Channel(page.url, d?.name ?: page.name, d?.avatar),
                            )
                        },
                    )
                    if (page.music && st.tracks.isNotEmpty()) {
                        Button(onClick = { player.playQueue(st.tracks.toList(), 0) }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_play),
                                contentDescription = null,
                                modifier = Modifier.width(20.dp),
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Putar semua")
                        }
                    }
                }
            }

            // Tab
            if (d != null && d.tabs.size > 1) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        d.tabs.forEachIndexed { i, t ->
                            FilterChip(
                                selected = i == st.tab,
                                onClick = { st.selectTab(i) },
                                label = { Text(t.label) },
                            )
                        }
                    }
                }
            }

            // Status
            if (d == null && st.error == null) {
                item { CenterSpinner() }
            }
            val err = st.error
            if (err != null && st.tracks.isEmpty() && st.entries.isEmpty()) {
                item {
                    Text(
                        text = err,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                    )
                }
            }
            if (d != null && st.tabLoading) {
                item { CenterSpinner() }
            }

            // Koleksi (album/playlist/artis)
            itemsIndexed(st.entries, key = { i, e -> "${e.url}#e$i" }) { _, e ->
                EntryRow(e) { onOpenCollection(e) }
            }

            // Lagu / video
            itemsIndexed(st.tracks, key = { i, t -> "${t.url}#t$i" }) { i, t ->
                if (page.music) {
                    TrackItem(vm, player, t) { player.playQueue(st.tracks.toList(), i) }
                } else {
                    VideoCardFor(t, actions)
                }
            }

            if (st.loadingMore) {
                item { CenterSpinner() }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun CenterSpinner() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        contentAlignment = Alignment.Center,
    ) {
        PlayLoader()
    }
}
