package app.mixbase.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/**
 * Bilah kapsul polos (tanpa kaca) bergaya Auralys, hanya berisi ikon.
 * Penanda terpilih (kapsul warna tema) meluncur antar ikon dengan pegas yang memantul, memanjang/memipih
 * mengikuti kecepatan seperti jeli, dan muncul/hilang dengan membal. Ikon yang ditekan ikut penyet lalu membal.
 * [indicatorVisible] = false menyembunyikan penanda (tidak ada panel yang terbuka).
 */
@Composable
fun FlatBounceBar(
    icons: List<Int>,
    descriptions: List<String>,
    selectedIndex: Int,
    indicatorVisible: Boolean,
    onClick: (Int) -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = MaterialTheme.colorScheme.surfaceContainerHigh,
    indicatorColor: Color = MaterialTheme.colorScheme.secondaryContainer,
    iconColor: Color = MaterialTheme.colorScheme.onSurfaceVariant,
    selectedIconColor: Color = MaterialTheme.colorScheme.onSecondaryContainer,
) {
    val count = icons.size
    val shape = RoundedCornerShape(50)
    val sources = remember(count) { List(count) { MutableInteractionSource() } }
    val anyPressed = sources.map { it.collectIsPressedAsState().value }.any { it }
    val posA = remember { Animatable(selectedIndex.toFloat()) }
    val vis by animateFloatAsState(
        targetValue = if (indicatorVisible) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.5f, stiffness = 320f),
        label = "barVis",
    )
    val press by animateFloatAsState(
        targetValue = if (anyPressed) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.3f, stiffness = 450f),
        label = "barPress",
    )

    LaunchedEffect(selectedIndex, indicatorVisible) {
        if (indicatorVisible && vis > 0.05f) {
            posA.animateTo(selectedIndex.toFloat(), spring(dampingRatio = 0.5f, stiffness = 260f))
        } else {
            posA.snapTo(selectedIndex.toFloat())
        }
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(start = 20.dp, end = 20.dp, top = 4.dp, bottom = 8.dp),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .background(containerColor, shape),
        ) {
            // Penanda terpilih
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(1f / count)
                    .padding(3.dp)
                    .graphicsLayer {
                        val v = abs(posA.velocity)
                        val stretch = (v * 0.05f).coerceAtMost(0.4f)
                        translationX = posA.value * (size.width + 8.dp.toPx())
                        val s = vis.coerceAtLeast(0f)
                        scaleX = s * (1f + stretch + 0.08f * press)
                        scaleY = s * (1f - stretch * 0.4f - 0.12f * press)
                        alpha = vis.coerceIn(0f, 1f)
                    }
                    .background(indicatorColor, shape),
            )
            Row(Modifier.fillMaxSize()) {
                icons.forEachIndexed { i, res ->
                    val selected = indicatorVisible && i == selectedIndex
                    val tint by animateColorAsState(
                        targetValue = if (selected) selectedIconColor else iconColor,
                        animationSpec = tween(200),
                        label = "barTint",
                    )
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .jelly(sources[i], squash = 1.6f)
                            .clickable(interactionSource = sources[i], indication = null, role = Role.Tab) {
                                onClick(i)
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            painter = painterResource(res),
                            contentDescription = descriptions[i],
                            tint = tint,
                            modifier = Modifier.size(22.dp),
                        )
                    }
                }
            }
        }
    }
}
