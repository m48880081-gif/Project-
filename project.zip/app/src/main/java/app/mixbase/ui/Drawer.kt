package app.mixbase.ui

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.mixbase.R

/** Nama versi aplikasi (dari paket terpasang), mis. "0.3.2". */
fun appVersion(context: Context): String = try {
    context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
} catch (e: Exception) {
    "?"
}

/**
 * Laci samping (gaya NewPipe) — isinya hanya: pilihan Mode (Video / Musik), Setelan,
 * dan keterangan tentang aplikasi (nama, pengembang, versi).
 */
@Composable
fun AppDrawerContent(
    mode: Int,
    onMode: (Int) -> Unit,
    onSettings: () -> Unit,
) {
    val context = LocalContext.current
    val version = remember(context) { appVersion(context) }
    val itemPad = NavigationDrawerItemDefaults.ItemPadding

    // Lebar laci sekitar setengah layar (batas bawah 240dp supaya tulisan tetap muat).
    val screenWidth = LocalConfiguration.current.screenWidthDp
    val sheetWidth = (screenWidth / 2).coerceIn(240, 360).dp

    ModalDrawerSheet(modifier = Modifier.width(sheetWidth)) {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            // Kepala laci
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, end = 16.dp, top = 28.dp, bottom = 18.dp),
            ) {
                PlayTubeMark(40.dp)
                Spacer(Modifier.height(12.dp))
                Wordmark()
                Text(
                    text = "Versi $version",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            HorizontalDivider(Modifier.padding(horizontal = 16.dp))

            // Mode
            Text(
                text = "Mode",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 24.dp, top = 16.dp, bottom = 8.dp),
            )
            NavigationDrawerItem(
                label = { Text("Video") },
                selected = mode == 1,
                onClick = { onMode(1) },
                icon = {
                    Icon(
                        painterResource(if (mode == 1) R.drawable.ic_nav_video_filled else R.drawable.ic_nav_video_outline),
                        contentDescription = null,
                    )
                },
                modifier = Modifier.padding(itemPad),
            )
            NavigationDrawerItem(
                label = { Text("Musik") },
                selected = mode == 0,
                onClick = { onMode(0) },
                icon = {
                    Icon(
                        painterResource(if (mode == 0) R.drawable.ic_nav_music_filled else R.drawable.ic_nav_music_outline),
                        contentDescription = null,
                    )
                },
                modifier = Modifier.padding(itemPad),
            )

            HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 12.dp))

            // Setelan
            NavigationDrawerItem(
                label = { Text("Setelan") },
                selected = false,
                onClick = onSettings,
                icon = {
                    Icon(painterResource(R.drawable.ic_nav_tune_outline), contentDescription = null)
                },
                modifier = Modifier.padding(itemPad),
            )

            HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 12.dp))

            // Tentang aplikasi
            Text(
                text = "Tentang aplikasi ini",
                style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 24.dp, top = 4.dp, bottom = 8.dp),
            )
            Column(
                modifier = Modifier.padding(start = 24.dp, end = 16.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                AboutLine("Nama aplikasi", stringResource(R.string.app_name))
                AboutLine("Pengembang", stringResource(R.string.developer_name))
                AboutLine("Versi", version)
            }
        }
    }
}

@Composable
private fun AboutLine(label: String, value: String) {
    Column {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
        )
    }
}
