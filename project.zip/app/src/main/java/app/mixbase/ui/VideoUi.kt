package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.data.compactCount
import app.mixbase.player.VideoPlayer
import coil.compose.AsyncImage

/** "Channel • 1,4 jt x ditonton • 1 tahun lalu" */
fun videoMeta(t: Track): String {
    val parts = ArrayList<String>()
    if (t.artist.isNotBlank()) parts.add(t.artist)
    if (t.live) {
        if (t.views >= 0L) parts.add("${compactCount(t.views)} menonton")
    } else {
        if (t.views >= 0L) parts.add("${compactCount(t.views)} x ditonton")
        val up = t.uploaded
        if (!up.isNullOrBlank()) parts.add(up)
    }
    return parts.joinToString(" • ")
}

/**
 * Kartu video besar ala beranda YouTube: thumbnail penuh lebar 16:9 dengan lencana durasi,
 * lalu foto channel + judul + info + menu ⋮.
 */
@Composable
fun VideoCard(
    track: Track,
    onOpen: () -> Unit,
    onOpenChannel: (() -> Unit)?,
    onPlayAudio: () -> Unit,
    onQueueAudio: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val download = rememberDownloader()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            if (track.thumb != null) {
                AsyncImage(
                    model = track.thumb,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            }
            if (track.live) {
                Text(
                    text = "LIVE",
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(LiveRed)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            } else if (track.durationSec > 0L) {
                Text(
                    text = clock(track.durationSec),
                    color = Color.White,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(Color.Black.copy(alpha = 0.8f))
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                )
            }
        }

        Row(
            modifier = Modifier.padding(start = 12.dp, end = 4.dp, top = 10.dp, bottom = 14.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Avatar(
                url = track.avatar,
                name = track.artist,
                size = 38.dp,
                modifier = if (onOpenChannel != null) Modifier.clickable(onClick = onOpenChannel) else Modifier,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = videoMeta(track),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
            Box {
                IconButton(onClick = { menu = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Menu")
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(
                        text = { Text("Putar sebagai audio") },
                        onClick = {
                            menu = false
                            onPlayAudio()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Tambah ke antrean audio") },
                        onClick = {
                            menu = false
                            onQueueAudio()
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Unduh video") },
                        onClick = {
                            menu = false
                            download(track, true)
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Unduh audio") },
                        onClick = {
                            menu = false
                            download(track, false)
                        },
                    )
                    if (onOpenChannel != null) {
                        DropdownMenuItem(
                            text = { Text("Buka channel") },
                            onClick = {
                                menu = false
                                onOpenChannel()
                            },
                        )
                    }
                }
            }
        }
    }
}

/** Bilah mini video di atas navigasi saat halaman tonton diminimalkan. */
@Composable
fun MiniVideoBar(video: VideoPlayer, onOpen: () -> Unit) {
    val t = video.track ?: return
    val fraction = if (video.durationMs > 0L) {
        (video.positionMs.toFloat() / video.durationMs.toFloat()).coerceIn(0f, 1f)
    } else {
        0f
    }

    Surface(
        tonalElevation = 3.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
    ) {
        Column {
            LinearProgressIndicator(
                progress = { fraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp),
                color = MaterialTheme.colorScheme.primary,
            )
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .width(72.dp)
                        .height(42.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                ) {
                    if (t.thumb != null) {
                        AsyncImage(
                            model = t.thumb,
                            contentDescription = null,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = t.title,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = t.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (video.loading || video.buffering) {
                    PlayLoader(diameter = 28.dp)
                }
                IconButton(onClick = { video.togglePlay() }) {
                    Icon(
                        painter = painterResource(if (video.isPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                        contentDescription = "Putar atau jeda",
                    )
                }
                IconButton(onClick = { video.stop() }) {
                    Icon(Icons.Filled.Close, contentDescription = "Tutup")
                }
            }
        }
    }
}

/** Kumpulan aksi untuk kartu video, dibuat sekali di AppRoot dan dibagikan ke semua layar. */
class VideoActions(
    val open: (Track) -> Unit,
    val channel: (url: String, name: String) -> Unit,
    val audio: (Track) -> Unit,
    val queue: (Track) -> Unit,
)

@Composable
fun VideoCardFor(t: Track, a: VideoActions) {
    val ch = t.uploaderUrl
    val chClick: (() -> Unit)? = if (ch != null) ({ a.channel(ch, t.artist) }) else null
    VideoCard(
        track = t,
        onOpen = { a.open(t) },
        onOpenChannel = chClick,
        onPlayAudio = { a.audio(t) },
        onQueueAudio = { a.queue(t) },
    )
}
