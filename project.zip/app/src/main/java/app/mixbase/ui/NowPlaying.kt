package app.mixbase.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text as RawText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import app.mixbase.R
import app.mixbase.data.I18n
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Layar pemutar penuh: sampul besar yang "bernapas" mengikuti putar/jeda, seek bar tebal,
 * kontrol, tombol Lirik dan Antrean (≡), pratinjau lirik. Tanpa pengatur volume.
 */
@Composable
fun NowPlayingScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onClose: () -> Unit,
    onOpenChannel: (url: String, name: String) -> Unit,
) {
    val track = player.current
    var showLyrics by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }

    // Cari lirik setiap lagu berganti. Daftar album kadang tanpa durasi: tunggu durasi asli
    // dari pemutar supaya pencocokannya sama akuratnya dengan lagu dari hasil pencarian.
    LaunchedEffect(track?.url) {
        val t = track ?: return@LaunchedEffect
        var dur = t.durationSec
        if (dur <= 0L) {
            val ms = withTimeoutOrNull(4_000L) { snapshotFlow { player.durationMs }.first { it > 0L } }
            if (ms != null) dur = ms / 1000L
        }
        vm.loadLyrics(t, dur)
    }

    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    val duration: Long = if (player.durationMs > 0L) player.durationMs else 1L
    val fraction: Float = if (dragging) {
        dragValue
    } else {
        (player.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    }
    val shownSec: Long = (fraction * duration.toFloat() / 1000f).toLong()

    val cs = MaterialTheme.colorScheme
    val primary = cs.primary
    val muted = cs.onSurfaceVariant
    val dark = cs.background.luminance() < 0.5f

    Surface(modifier = Modifier.fillMaxSize(), color = cs.background) {
        Box(Modifier.fillMaxSize()) {
            // Latar lembut berwarna tema (bukan kaca/blur): pudar dari atas ke bawah.
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(cs.primaryContainer.copy(alpha = if (dark) 0.42f else 0.65f), cs.background),
                        ),
                    ),
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding(),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 8.dp),
            ) {
                // ---- Header ----
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth().appear(0),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = onClose) {
                            Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup")
                        }
                        Text(
                            text = "Sedang diputar",
                            style = MaterialTheme.typography.titleMedium,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f),
                        )
                        Spacer(Modifier.size(48.dp))
                    }
                }

                // ---- Sampul: membesar saat diputar, mengecil saat dijeda ----
                item {
                    val playing = player.isPlaying
                    val scale by animateFloatAsState(
                        targetValue = if (playing) 1f else 0.88f,
                        animationSpec = spring(dampingRatio = 0.62f, stiffness = 240f),
                        label = "artScale",
                    )
                    val lift by animateDpAsState(
                        targetValue = if (playing) 16.dp else 3.dp,
                        animationSpec = tween(420),
                        label = "artLift",
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp, bottom = 22.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.92f)
                                .aspectRatio(1f)
                                .graphicsLayer {
                                    scaleX = scale
                                    scaleY = scale
                                }
                                .shadow(lift, RoundedCornerShape(28.dp))
                                .clip(RoundedCornerShape(28.dp))
                                .background(cs.surfaceVariant),
                        ) {
                            Crossfade(
                                targetState = track?.thumb,
                                animationSpec = tween(420),
                                label = "cover",
                            ) { t ->
                                HdImage(t, Modifier.fillMaxSize(), px = 1200)
                            }
                        }
                    }
                }

                // ---- Judul + favorit ----
                item {
                    val cu = track?.uploaderUrl
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Crossfade(
                                targetState = track?.title ?: "",
                                animationSpec = tween(320),
                                label = "title",
                            ) { title ->
                                Text(
                                    text = title,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                            Text(
                                text = track?.artist ?: "",
                                style = MaterialTheme.typography.bodyLarge,
                                color = muted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .then(
                                        if (cu != null && track != null) {
                                            Modifier.clickable { onOpenChannel(cu, track.artist) }
                                        } else {
                                            Modifier
                                        },
                                    ),
                            )
                        }
                        if (track != null) {
                            FavButton(
                                fav = vm.isFavorite(track.url),
                                onClick = { vm.toggleFavorite(track) },
                            )
                        }
                    }
                }

                // ---- Seek bar ----
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 18.dp)) {
                        SeekBar(
                            fraction = fraction,
                            onChange = {
                                dragging = true
                                dragValue = it
                            },
                            onDone = {
                                player.seekTo((dragValue * duration.toFloat()).toLong())
                                dragging = false
                            },
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            RawText(
                                text = clock(shownSec),
                                style = MaterialTheme.typography.bodySmall,
                                color = muted,
                            )
                            RawText(
                                text = if (player.durationMs > 0L) clock(player.durationMs / 1000L) else "--:--",
                                style = MaterialTheme.typography.bodySmall,
                                color = muted,
                            )
                        }
                    }
                }

                // ---- Kontrol ----
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp, bottom = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        RoundControl(onClick = { player.toggleShuffle() }, size = 48.dp) {
                            Icon(
                                painter = painterResource(R.drawable.ic_shuffle),
                                contentDescription = "Acak",
                                tint = if (player.shuffle) primary else muted,
                            )
                        }
                        RoundControl(onClick = { player.previous() }, size = 56.dp) {
                            Icon(
                                painter = painterResource(R.drawable.ic_skip_previous),
                                contentDescription = "Sebelumnya",
                                modifier = Modifier.size(32.dp),
                            )
                        }
                        PlayButton(player)
                        RoundControl(onClick = { player.next() }, size = 56.dp) {
                            Icon(
                                painter = painterResource(R.drawable.ic_skip_next),
                                contentDescription = "Berikutnya",
                                modifier = Modifier.size(32.dp),
                            )
                        }
                        RoundControl(onClick = { player.cycleRepeat() }, size = 48.dp) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_repeat),
                                    contentDescription = "Ulangi",
                                    tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) primary else muted,
                                )
                                if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                                    RawText(
                                        text = "1",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = primary,
                                    )
                                }
                            }
                        }
                    }
                }

                // ---- Lirik & Antrean (≡) ----
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        ActionPill(R.drawable.ic_lyrics, "Lirik") { showLyrics = true }
                        ActionPill(R.drawable.ic_queue, "Antrean (${player.queue.size})") { showQueue = true }
                    }
                }

                // ---- Pratinjau lirik ----
                item {
                    LyricsCard(vm, player, onOpen = { showLyrics = true })
                }
            }

            // Layar lirik: naik dari bawah, turun saat ditutup.
            AnimatedVisibility(
                visible = showLyrics,
                enter = Motion.risingIn(),
                exit = Motion.sinkingOut(),
            ) {
                LyricsScreen(
                    vm = vm,
                    player = player,
                    onClose = { showLyrics = false },
                    onOpenQueue = { showQueue = true },
                )
            }

            // Antrean (lagu berikutnya): lembar bawah, di atas semuanya.
            QueueSheet(
                visible = showQueue,
                player = player,
                onDismiss = { showQueue = false },
            )
        }
    }
}

// ---------------------------------------------------------------------
// Komponen kecil
// ---------------------------------------------------------------------

/** Tombol bulat dengan umpan balik tekan (mengecil lalu memantul). */
@Composable
private fun RoundControl(
    onClick: () -> Unit,
    size: Dp,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(size)
            .bouncyClick(shape = CircleShape, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

/** Tombol putar/jeda: bulat saat jeda, berubah menjadi kotak membulat saat diputar. */
@Composable
private fun PlayButton(player: PlayerConnection) {
    val cs = MaterialTheme.colorScheme
    val playing = player.isPlaying
    val loading = player.buffering && !playing
    val corner by animateDpAsState(
        targetValue = if (playing) 26.dp else 38.dp,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 380f),
        label = "playShape",
    )
    val shape = RoundedCornerShape(corner)
    Box(
        modifier = Modifier
            .size(76.dp)
            .bouncyClick(shape = shape) { player.togglePlay() }
            .background(cs.primary, shape),
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(
            targetState = if (loading) 0 else if (playing) 1 else 2,
            animationSpec = tween(180),
            label = "playIcon",
        ) { state ->
            when (state) {
                0 -> PlayLoader(
                    diameter = 44.dp,
                    containerColor = cs.onPrimary,
                    color = cs.primary,
                )

                1 -> Icon(
                    painter = painterResource(R.drawable.ic_pause),
                    contentDescription = "Jeda",
                    tint = cs.onPrimary,
                    modifier = Modifier.size(36.dp),
                )

                else -> Icon(
                    painter = painterResource(R.drawable.ic_play),
                    contentDescription = "Putar",
                    tint = cs.onPrimary,
                    modifier = Modifier.size(36.dp),
                )
            }
        }
    }
}

/** Pil tombol di baris bawah pemutar (Lirik, Antrean). */
@Composable
private fun ActionPill(icon: Int, label: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(50)
    Row(
        modifier = Modifier
            .bouncyClick(shape = shape, onClick = onClick)
            .background(cs.surfaceContainerHigh, shape)
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = cs.onSurface,
            modifier = Modifier.size(20.dp),
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = cs.onSurface,
        )
    }
}

/** Hati favorit: memantul saat baru ditandai. */
@Composable
private fun FavButton(fav: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bounce = remember { Animatable(1f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(fav) {
        if (first) {
            first = false
        } else if (fav) {
            bounce.snapTo(0.55f)
            bounce.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = 420f))
        }
    }
    IconButton(onClick = onClick) {
        Icon(
            imageVector = if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            contentDescription = "Favorit",
            tint = if (fav) cs.primary else cs.onSurfaceVariant,
            modifier = Modifier.graphicsLayer {
                scaleX = bounce.value
                scaleY = bounce.value
            },
        )
    }
}

/**
 * Bilah geser tebal berujung bulat. Tebal dan gagangnya membesar saat disentuh.
 * [onChange] dipanggil terus saat digeser, [onDone] saat jari diangkat atau saat diketuk.
 */
@Composable
fun SeekBar(
    fraction: Float,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val cs = MaterialTheme.colorScheme
    val active = cs.primary
    val rail = cs.onSurface.copy(alpha = 0.14f)
    var widthPx by remember { mutableFloatStateOf(1f) }
    var pressed by remember { mutableStateOf(false) }
    val thick by animateFloatAsState(
        targetValue = if (pressed) 12f else 6f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = 500f),
        label = "seekThick",
    )
    val knob by animateFloatAsState(
        targetValue = if (pressed) 11f else 7f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "seekKnob",
    )
    val changeNow by rememberUpdatedState(onChange)
    val doneNow by rememberUpdatedState(onDone)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(32.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { off ->
                        changeNow((off.x / widthPx).coerceIn(0f, 1f))
                        doneNow()
                    },
                )
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { off ->
                        pressed = true
                        changeNow((off.x / widthPx).coerceIn(0f, 1f))
                    },
                    onDragEnd = {
                        pressed = false
                        doneNow()
                    },
                    onDragCancel = {
                        pressed = false
                        doneNow()
                    },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        changeNow((change.position.x / widthPx).coerceIn(0f, 1f))
                    },
                )
            },
    ) {
        Canvas(Modifier.fillMaxWidth().height(32.dp)) {
            val h = thick.dp.toPx()
            val r = knob.dp.toPx()
            val cy = size.height / 2f
            val corner = CornerRadius(h / 2f, h / 2f)
            drawRoundRect(
                color = rail,
                topLeft = Offset(0f, cy - h / 2f),
                size = Size(size.width, h),
                cornerRadius = corner,
            )
            val x = size.width * fraction.coerceIn(0f, 1f)
            drawRoundRect(
                color = active,
                topLeft = Offset(0f, cy - h / 2f),
                size = Size(x.coerceAtLeast(h), h),
                cornerRadius = corner,
            )
            drawCircle(
                color = active,
                radius = r,
                center = Offset(x.coerceIn(r, size.width - r), cy),
            )
        }
    }
}

/** Tiga batang penyeimbang kecil: bergerak saat lagu diputar. */
@Composable
fun EqualizerBars(playing: Boolean, color: Color, modifier: Modifier = Modifier.size(18.dp)) {
    val t = rememberInfiniteTransition(label = "eq")
    val a = t.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse),
        label = "a",
    )
    val b = t.animateFloat(
        initialValue = 0.45f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(410, easing = LinearEasing), RepeatMode.Reverse),
        label = "b",
    )
    val c = t.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(630, easing = LinearEasing), RepeatMode.Reverse),
        label = "c",
    )
    Canvas(modifier) {
        val w = size.width / 5f
        val hs = if (playing) listOf(a.value, b.value, c.value) else listOf(0.35f, 0.35f, 0.35f)
        for (k in 0 until 3) {
            val h = size.height * hs[k]
            drawRoundRect(
                color = color,
                topLeft = Offset(w * (k * 2f), size.height - h),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2f, w / 2f),
            )
        }
    }
}

// ---------------------------------------------------------------------
// Antrean (lagu berikutnya)
// ---------------------------------------------------------------------

private fun queueSummary(n: Int, totalSec: Long): String {
    val en = I18n.lang != "id"
    val songs = if (en) (if (n == 1) "1 song" else "$n songs") else "$n lagu"
    if (totalSec <= 0L) return songs
    val h = totalSec / 3600L
    val m = (totalSec % 3600L) / 60L
    val time = when {
        h > 0L -> if (en) "$h hr $m min" else "$h jam $m mnt"
        else -> if (en) "${maxOf(1L, m)} min" else "${maxOf(1L, m)} mnt"
    }
    return "$songs • $time"
}

/** Lembar bawah berisi lagu yang sedang diputar dan daftar lagu berikutnya. */
@Composable
private fun QueueSheet(visible: Boolean, player: PlayerConnection, onDismiss: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    SlideSheet(
        visible = visible,
        onDismiss = onDismiss,
        heightFraction = 0.82f,
        header = {
            val cur = player.current
            if (cur != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Thumb(cur.thumb, 52.dp, pageUrl = cur.url)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "Sedang diputar",
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.primary,
                        )
                        Text(
                            text = cur.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = cur.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val total = player.queue.sumOf { if (it.durationSec > 0L) it.durationSec else 0L }
                RawText(
                    text = queueSummary(player.queue.size, total),
                    style = MaterialTheme.typography.labelLarge,
                    color = cs.onSurface,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(cs.surfaceContainerHighest)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                )
                Spacer(Modifier.weight(1f))
                RoundControl(onClick = { player.toggleShuffle() }, size = 44.dp) {
                    Icon(
                        painter = painterResource(R.drawable.ic_shuffle),
                        contentDescription = "Acak",
                        tint = if (player.shuffle) cs.primary else cs.onSurfaceVariant,
                    )
                }
                RoundControl(onClick = { player.cycleRepeat() }, size = 44.dp) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            painter = painterResource(R.drawable.ic_repeat),
                            contentDescription = "Ulangi",
                            tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) cs.primary else cs.onSurfaceVariant,
                        )
                        if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                            RawText(
                                text = "1",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = cs.primary,
                            )
                        }
                    }
                }
            }
        },
    ) {
        // Kunci tiap baris tetap walau lagu di depannya dihapus, supaya animasi geser benar.
        val keys = remember(player.queue) {
            val seen = HashMap<String, Int>()
            player.queue.map { t ->
                val n = (seen[t.url] ?: 0) + 1
                seen[t.url] = n
                "${t.url}#$n"
            }
        }
        val listState = rememberLazyListState(
            initialFirstVisibleItemIndex = (player.index - 1).coerceAtLeast(0),
        )
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 24.dp),
        ) {
            itemsIndexed(player.queue, key = { i, _ -> keys.getOrElse(i) { "q$i" } }) { i, t ->
                val isCurrent = i == player.index
                val shape = RoundedCornerShape(16.dp)
                val rowBg = if (isCurrent) cs.primaryContainer.copy(alpha = 0.5f) else Color.Transparent
                Row(
                    modifier = Modifier
                        .animateItem()
                        .fillMaxWidth()
                        .clip(shape)
                        .background(rowBg)
                        .clickable { player.jumpTo(i) }
                        .padding(start = 8.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(48.dp)) {
                        Thumb(t.thumb, 48.dp, pageUrl = t.url)
                        if (isCurrent) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color.Black.copy(alpha = 0.45f)),
                                contentAlignment = Alignment.Center,
                            ) {
                                EqualizerBars(playing = player.isPlaying, color = Color.White)
                            }
                        }
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = t.title,
                            style = MaterialTheme.typography.bodyLarge,
                            color = if (isCurrent) cs.primary else cs.onSurface,
                            fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = t.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (t.durationSec > 0L) {
                        RawText(
                            text = clock(t.durationSec),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                            modifier = Modifier.padding(start = 8.dp),
                        )
                    }
                    IconButton(onClick = { player.removeAt(i) }) {
                        Icon(
                            Icons.Filled.Close,
                            contentDescription = "Hapus dari antrean",
                            tint = cs.onSurfaceVariant,
                        )
                    }
                }
            }
            item {
                Spacer(Modifier.navigationBarsPadding())
            }
        }
    }
}
