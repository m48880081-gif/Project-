package app.mixbase.ui

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import app.mixbase.R
import app.mixbase.data.I18n
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Layar pemutar penuh (dirombak). Halaman 1: sampul penuh yang memudar ke warna sampul, judul,
 * progres bergelombang, kontrol, dan baris tombol (lirik, antrean, bagikan, timer tidur).
 * Halaman 2 (geser ke atas atau ketuk ⋮): halaman penuh berisi aksi (bagikan, unduh, lirik, dll).
 * Antrean tidak lagi berupa daftar di bawah, melainkan tombol yang membuka lembar daftar lagu.
 */
@Composable
fun NowPlayingScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onClose: () -> Unit,
    onOpenChannel: (url: String, name: String) -> Unit,
) {
    val track = player.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val scheme = MaterialTheme.colorScheme
    val pager = rememberPagerState(pageCount = { 2 })

    var showLyrics by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var showSleep by remember { mutableStateOf(false) }
    // Waktu (ms epoch) musik dijeda otomatis; 0 = timer mati.
    var sleepAt by remember { mutableLongStateOf(0L) }

    // Cari lirik setiap lagu berganti.
    LaunchedEffect(track?.url) {
        if (track != null) vm.loadLyrics(track)
    }
    LaunchedEffect(sleepAt) {
        if (sleepAt > 0L) {
            val wait = sleepAt - System.currentTimeMillis()
            if (wait > 0L) delay(wait)
            player.pause()
            sleepAt = 0L
        }
    }
    BackHandler(enabled = !showQueue && !showLyrics && pager.currentPage == 1) {
        scope.launch { pager.animateScrollToPage(0) }
    }

    val art = rememberArtColor(track?.thumb)
    val bg = lerp(scheme.surface, art, 0.6f)
    val onBg = if (bg.luminance() > 0.5f) Color(0xFF101114) else Color.White

    val fav = track != null && vm.isFavorite(track.url)
    val download = rememberDownloader()

    fun openActions() {
        scope.launch { pager.animateScrollToPage(1) }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = scheme.surface) {
        Box(Modifier.fillMaxSize()) {
            VerticalPager(
                state = pager,
                modifier = Modifier.fillMaxSize(),
            ) { page ->
                if (page == 0) {
                    PlayerPage(
                        vm = vm,
                        player = player,
                        track = track,
                        fav = fav,
                        art = art,
                        bg = bg,
                        onBg = onBg,
                        sleepOn = sleepAt > 0L,
                        onClose = onClose,
                        onOpenChannel = onOpenChannel,
                        onMore = { openActions() },
                        onLyrics = { showLyrics = true },
                        onQueue = { showQueue = true },
                        onShare = { if (track != null) shareTrack(context, track) },
                        onSleep = { showSleep = true },
                    )
                } else {
                    ActionsPage(
                        vm = vm,
                        player = player,
                        track = track,
                        fav = fav,
                        tint = lerp(scheme.surface, art, 0.22f),
                        sleepOn = sleepAt > 0L,
                        onBack = { scope.launch { pager.animateScrollToPage(0) } },
                        onShare = { if (track != null) shareTrack(context, track) },
                        onDownload = { if (track != null) download(track, false) },
                        onLyrics = { showLyrics = true },
                        onQueue = { showQueue = true },
                        onSleep = { showSleep = true },
                        onFavorite = { if (track != null) vm.toggleFavorite(track) },
                        onArtist = {
                            val cu = track?.uploaderUrl
                            if (track != null && cu != null) onOpenChannel(cu, track.artist)
                        },
                    )
                }
            }

            // ---- Layar lirik (di bawah lembar antrean, supaya antrean bisa dibuka dari lirik) ----
            if (showLyrics) {
                LyricsScreen(
                    vm = vm,
                    player = player,
                    onClose = { showLyrics = false },
                    onQueue = { showQueue = true },
                    onShare = { if (track != null) shareTrack(context, track) },
                    onSleep = { showSleep = true },
                    sleepOn = sleepAt > 0L,
                )
            }

            // ---- Lembar antrean ----
            AnimatedVisibility(
                visible = showQueue,
                modifier = Modifier.fillMaxSize(),
                enter = fadeIn(),
                exit = fadeOut(),
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                        ) { showQueue = false },
                )
            }
            AnimatedVisibility(
                visible = showQueue,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = Motion.sheetIn(),
                exit = Motion.sheetOut(),
            ) {
                QueueSheet(player = player, onClose = { showQueue = false })
            }
            if (showQueue) {
                BackHandler { showQueue = false }
            }

        }
    }

    if (showSleep) {
        SleepDialog(
            active = sleepAt > 0L,
            onPick = { minutes ->
                sleepAt = if (minutes <= 0) 0L else System.currentTimeMillis() + minutes * 60_000L
                showSleep = false
            },
            onDismiss = { showSleep = false },
        )
    }
}

// =====================================================================
// Halaman 1: pemutar
// =====================================================================

@Composable
private fun PlayerPage(
    vm: AppViewModel,
    player: PlayerConnection,
    track: Track?,
    fav: Boolean,
    art: Color,
    bg: Color,
    onBg: Color,
    sleepOn: Boolean,
    onClose: () -> Unit,
    onOpenChannel: (url: String, name: String) -> Unit,
    onMore: () -> Unit,
    onLyrics: () -> Unit,
    onQueue: () -> Unit,
    onShare: () -> Unit,
    onSleep: () -> Unit,
) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme

    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val duration: Long = if (player.durationMs > 0L) player.durationMs else 1L
    val fraction: Float = if (dragging) {
        dragValue
    } else {
        (player.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    }
    val shownSec: Long = (fraction * duration.toFloat() / 1000f).toLong()
    val remainSec: Long = if (player.durationMs > 0L) (player.durationMs / 1000L) - shownSec else 0L

    // Tampil sebagai "sedang diputar" sejak diketuk (tanpa menunggu pemutar selesai memuat).
    val showPlaying = player.isPlaying || player.buffering

    val zoom by animateFloatAsState(
        targetValue = if (showPlaying) 1.07f else 1f,
        animationSpec = spring(dampingRatio = 1f, stiffness = 25f),
        label = "artZoom",
    )
    val playCorner by animateDpAsState(
        targetValue = if (showPlaying) 26.dp else 40.dp,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 380f),
        label = "playCorner",
    )
    val soft = onBg.copy(alpha = 0.16f)

    Column(
        Modifier
            .fillMaxSize()
            .background(bg),
    ) {
        // ---- Sampul penuh ----
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .clipToBounds()
                .background(art),
        ) {
            Crossfade(
                targetState = track?.thumb,
                animationSpec = tween(500),
                label = "art",
            ) { thumb ->
                HdImage(
                    thumb,
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = zoom
                            scaleY = zoom
                        },
                    px = 1200,
                )
            }
            // Bayangan atas (supaya tulisan putih terbaca) dan pudar ke warna latar di bawah.
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .align(Alignment.TopCenter)
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.5f), Color.Transparent))),
            )
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .align(Alignment.BottomCenter)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, bg))),
            )
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(start = 4.dp, end = 16.dp, top = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup", tint = Color.White)
                }
                Text(
                    text = "Sedang diputar",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )
            }
        }

        // ---- Kontrol ----
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 24.dp),
        ) {
            // Judul + favorit + menu
            Row(verticalAlignment = Alignment.CenterVertically) {
                val cu = track?.uploaderUrl
                Column(Modifier.weight(1f)) {
                    Text(
                        text = track?.title ?: "",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = onBg,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = track?.artist ?: "",
                        style = MaterialTheme.typography.bodyLarge,
                        color = onBg.copy(alpha = 0.75f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .padding(top = 2.dp)
                            .then(
                                if (cu != null && track != null) {
                                    Modifier.bounceClickable { onOpenChannel(cu, track.artist) }
                                } else {
                                    Modifier
                                },
                            ),
                    )
                }
                Spacer(Modifier.width(12.dp))
                CircleAction(background = soft, onClick = { if (track != null) vm.toggleFavorite(track) }) {
                    AnimatedContent(
                        targetState = fav,
                        transitionSpec = {
                            (scaleIn(spring(dampingRatio = 0.35f, stiffness = 380f)) + fadeIn(tween(120))) togetherWith
                                (scaleOut(tween(100)) + fadeOut(tween(100)))
                        },
                        label = "fav",
                    ) { f ->
                        Icon(
                            imageVector = if (f) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Favorit",
                            tint = onBg,
                        )
                    }
                }
                Spacer(Modifier.width(8.dp))
                CircleAction(background = soft, onClick = onMore) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Menu", tint = onBg)
                }
            }

            // Progres
            ExpressiveSlider(
                value = fraction,
                onValueChange = {
                    dragging = true
                    dragValue = it
                },
                onValueChangeFinished = {
                    player.seekTo((dragValue * duration.toFloat()).toLong())
                    dragging = false
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                animate = showPlaying,
                color = onBg,
                trackColor = onBg.copy(alpha = 0.25f),
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = clock(shownSec),
                    style = MaterialTheme.typography.bodySmall,
                    color = onBg.copy(alpha = 0.7f),
                )
                Text(
                    text = if (player.durationMs > 0L) "-" + clock(remainSec) else "--:--",
                    style = MaterialTheme.typography.bodySmall,
                    color = onBg.copy(alpha = 0.7f),
                )
            }

            // Kontrol putar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = { player.toggleShuffle() }) {
                    Icon(
                        painter = painterResource(R.drawable.ic_shuffle),
                        contentDescription = "Acak",
                        tint = if (player.shuffle) onBg else onBg.copy(alpha = 0.45f),
                    )
                }
                IconButton(onClick = { player.previous() }, modifier = Modifier.size(56.dp)) {
                    Icon(
                        painter = painterResource(R.drawable.ic_skip_previous),
                        contentDescription = "Sebelumnya",
                        tint = onBg,
                        modifier = Modifier.size(34.dp),
                    )
                }
                FilledIconButton(
                    onClick = { player.togglePlay() },
                    modifier = Modifier.size(76.dp),
                    shape = RoundedCornerShape(playCorner),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = onBg,
                        contentColor = bg,
                    ),
                ) {
                    AnimatedContent(
                        targetState = showPlaying,
                        transitionSpec = {
                            (scaleIn(spring(dampingRatio = 0.5f, stiffness = 500f)) + fadeIn(tween(120))) togetherWith
                                (scaleOut(tween(90)) + fadeOut(tween(90)))
                        },
                        label = "playIcon",
                    ) { playing ->
                        Icon(
                            painter = painterResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play),
                            contentDescription = "Putar atau jeda",
                            modifier = Modifier.size(38.dp),
                        )
                    }
                }
                IconButton(onClick = { player.next() }, modifier = Modifier.size(56.dp)) {
                    Icon(
                        painter = painterResource(R.drawable.ic_skip_next),
                        contentDescription = "Berikutnya",
                        tint = onBg,
                        modifier = Modifier.size(34.dp),
                    )
                }
                IconButton(onClick = { player.cycleRepeat() }) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            painter = painterResource(R.drawable.ic_repeat),
                            contentDescription = "Ulangi",
                            tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) onBg else onBg.copy(alpha = 0.45f),
                        )
                        if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                            Text(
                                text = "1",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = onBg,
                            )
                        }
                    }
                }
            }

            // Baris tombol: lirik, antrean, bagikan, timer tidur
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onLyrics) {
                    Icon(painterResource(R.drawable.ic_lyrics_bubble), contentDescription = "Lirik", tint = onBg)
                }
                IconButton(onClick = onQueue) {
                    Icon(painterResource(R.drawable.ic_queue_list), contentDescription = "Antrean", tint = onBg)
                }
                IconButton(onClick = onShare) {
                    Icon(painterResource(R.drawable.ic_share), contentDescription = "Bagikan", tint = onBg)
                }
                IconButton(onClick = onSleep) {
                    Icon(
                        painter = painterResource(R.drawable.ic_bedtime),
                        contentDescription = "Timer tidur",
                        tint = if (sleepOn) scheme.tertiary else onBg,
                    )
                }
            }
        }
    }
}

@Composable
private fun CircleAction(background: Color, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(background)
            .bounceClickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

// =====================================================================
// Halaman 2: aksi (bagikan, unduh, lirik, dll)
// =====================================================================

@Composable
private fun ActionsPage(
    vm: AppViewModel,
    player: PlayerConnection,
    track: Track?,
    fav: Boolean,
    tint: Color,
    sleepOn: Boolean,
    onBack: () -> Unit,
    onShare: () -> Unit,
    onDownload: () -> Unit,
    onLyrics: () -> Unit,
    onQueue: () -> Unit,
    onSleep: () -> Unit,
    onFavorite: () -> Unit,
    onArtist: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Column(
        Modifier
            .fillMaxSize()
            .background(tint)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp),
    ) {
        // Kepala: sampul kecil + judul + kembali ke pemutar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(scheme.surfaceVariant),
            ) {
                HdImage(track?.thumb, Modifier.fillMaxSize(), px = 400)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = track?.title ?: "",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = track?.artist ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = scheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Kembali ke pemutar")
            }
        }

        Text(
            text = "Aksi lagu",
            style = MaterialTheme.typography.titleSmall,
            color = scheme.primary,
            modifier = Modifier.padding(start = 4.dp, top = 4.dp, bottom = 8.dp),
        )

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile(
                label = "Bagikan",
                container = scheme.primaryContainer,
                content = scheme.onPrimaryContainer,
                modifier = Modifier.weight(1f),
                onClick = onShare,
            ) { Icon(painterResource(R.drawable.ic_share), contentDescription = null) }
            ActionTile(
                label = "Unduh audio",
                container = scheme.secondaryContainer,
                content = scheme.onSecondaryContainer,
                modifier = Modifier.weight(1f),
                onClick = onDownload,
            ) { Icon(painterResource(R.drawable.ic_download), contentDescription = null) }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile(
                label = "Lirik",
                container = scheme.tertiaryContainer,
                content = scheme.onTertiaryContainer,
                modifier = Modifier.weight(1f),
                onClick = onLyrics,
            ) { Icon(painterResource(R.drawable.ic_lyrics_bubble), contentDescription = null) }
            ActionTile(
                label = "Antrean",
                container = scheme.primaryContainer,
                content = scheme.onPrimaryContainer,
                modifier = Modifier.weight(1f),
                onClick = onQueue,
            ) { Icon(painterResource(R.drawable.ic_queue_list), contentDescription = null) }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            ActionTile(
                label = if (fav) "Hapus dari favorit" else "Tambah ke favorit",
                container = scheme.secondaryContainer,
                content = scheme.onSecondaryContainer,
                modifier = Modifier.weight(1f),
                onClick = onFavorite,
            ) {
                Icon(
                    imageVector = if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = null,
                )
            }
            ActionTile(
                label = if (sleepOn) "Timer tidur aktif" else "Timer tidur",
                container = scheme.tertiaryContainer,
                content = scheme.onTertiaryContainer,
                modifier = Modifier.weight(1f),
                onClick = onSleep,
            ) { Icon(painterResource(R.drawable.ic_bedtime), contentDescription = null) }
        }
        if (track?.uploaderUrl != null) {
            Spacer(Modifier.height(12.dp))
            ActionTile(
                label = "Buka artis",
                container = scheme.surfaceContainerHigh,
                content = scheme.onSurface,
                modifier = Modifier.fillMaxWidth(),
                onClick = onArtist,
            ) { Icon(Icons.Filled.Person, contentDescription = null) }
        }

        Text(
            text = "Lirik",
            style = MaterialTheme.typography.titleSmall,
            color = scheme.primary,
            modifier = Modifier.padding(start = 4.dp, top = 20.dp, bottom = 8.dp),
        )
        LyricsCard(vm, player, onOpen = onLyrics)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ActionTile(
    label: String,
    container: Color,
    content: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
) {
    Column(
        modifier = modifier
            .height(104.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(container)
            .bounceClickable(onClick = onClick)
            .padding(14.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        androidx.compose.runtime.CompositionLocalProvider(
            androidx.compose.material3.LocalContentColor provides content,
        ) {
            icon()
            Text(
                text = label,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = content,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

// =====================================================================
// Lembar antrean
// =====================================================================

@Composable
private fun QueueSheet(player: PlayerConnection, onClose: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val start = if (player.index > 1) player.index - 1 else 0
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = start)

    Surface(
        color = scheme.surfaceContainerHigh,
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp),
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.72f),
    ) {
        Column(Modifier.navigationBarsPadding()) {
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 10.dp)
                    .width(40.dp)
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(scheme.onSurfaceVariant.copy(alpha = 0.4f)),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 20.dp, end = 8.dp, top = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = I18n.tr("Antrean") + " (${player.queue.size})",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Filled.Close, contentDescription = "Tutup")
                }
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            ) {
                itemsIndexed(player.queue, key = { i, t -> "${t.url}#$i" }) { i, t ->
                    val isCurrent = i == player.index
                    val rowBg by animateColorAsState(
                        targetValue = if (isCurrent) scheme.secondaryContainer else Color.Transparent,
                        animationSpec = spring(stiffness = 300f),
                        label = "queueBg",
                    )
                    Row(
                        modifier = Modifier
                            .animateItem()
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(rowBg)
                            .bounceClickable { player.jumpTo(i) }
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Thumb(t.thumb, 44.dp, pageUrl = t.url)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = t.title,
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isCurrent) scheme.primary else scheme.onSurface,
                                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = t.artist,
                                style = MaterialTheme.typography.bodySmall,
                                color = scheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        if (isCurrent) {
                            EqualizerBars(playing = player.isPlaying, color = scheme.primary)
                        }
                        IconButton(onClick = { player.removeAt(i) }) {
                            Icon(Icons.Filled.Close, contentDescription = "Hapus dari antrean")
                        }
                    }
                }
            }
        }
    }
}

// =====================================================================
// Timer tidur dan bagikan
// =====================================================================

@Composable
private fun SleepDialog(active: Boolean, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Timer tidur") },
        text = {
            Column {
                Text(
                    text = "Musik dijeda otomatis setelah waktu yang dipilih.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                val options = listOf(
                    15 to "15 menit",
                    30 to "30 menit",
                    45 to "45 menit",
                    60 to "1 jam",
                )
                for ((minutes, label) in options) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .bounceClickable { onPick(minutes) }
                            .padding(horizontal = 12.dp, vertical = 14.dp),
                    )
                }
                if (active) {
                    Text(
                        text = "Matikan timer",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Start,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .bounceClickable { onPick(0) }
                            .padding(horizontal = 12.dp, vertical = 14.dp),
                    )
                }
            }
        },
    )
}

private fun shareTrack(context: Context, t: Track) {
    try {
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, t.title + " - " + t.artist + "\n" + t.url)
        val chooser = Intent.createChooser(send, null)
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (e: Exception) {
        // tidak ada aplikasi untuk berbagi
    }
}
