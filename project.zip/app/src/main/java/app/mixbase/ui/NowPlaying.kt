package app.mixbase.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.min
import kotlin.math.sin
import app.mixbase.R
import app.mixbase.data.Downloads
import app.mixbase.data.I18n
import app.mixbase.data.Track
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection
import coil.compose.AsyncImage
import coil.request.ImageRequest

// =====================================================================
// Bagian bersama (dipakai layar Now Playing dan layar lirik)
// =====================================================================

/**
 * Posisi putar yang mulus: dihitung per frame dari posisi terakhir yang dilaporkan pemutar
 * (yang hanya diperbarui tiap 0,5 detik), supaya seek bar dan animasi lirik bergerak halus.
 * Baca nilainya hanya di tahap gambar (lambda draw/graphicsLayer) agar tidak merekomposisi tiap frame.
 */
@Composable
fun rememberSmoothPosition(player: PlayerConnection): State<Long> {
    val pos = remember { mutableLongStateOf(player.positionMs) }
    LaunchedEffect(player.positionMs, player.isPlaying, player.current?.url) {
        val base = player.positionMs
        pos.longValue = base
        if (player.isPlaying) {
            val t0 = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                pos.longValue = base + (now - t0) / 1_000_000L
            }
        }
    }
    return pos
}

/**
 * Latar dari sampul lagu: sampul diperkecil lalu diburamkan, kemudian memudar ke warna permukaan
 * tema (gelap atau terang), sehingga teks di atasnya tetap terbaca di kedua tema.
 */
@Composable
fun CoverBackdrop(thumb: String?, modifier: Modifier = Modifier, veil: Float = 0.5f) {
    val surface = MaterialTheme.colorScheme.surface
    val context = LocalContext.current
    Box(modifier.background(surface)) {
        Crossfade(targetState = thumb, animationSpec = tween(700), label = "backdrop") { u ->
            if (u != null) {
                AsyncImage(
                    model = ImageRequest.Builder(context).data(u).size(64, 64).build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .blur(24.dp),
                )
            }
        }
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            surface.copy(alpha = veil),
                            surface.copy(alpha = 0.88f),
                            surface,
                        ),
                    ),
                ),
        )
    }
}

/** Tombol bulat setengah transparan, aman dibaca di atas gambar apa pun. */
@Composable
fun GlassButton(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier = modifier
            .size(44.dp)
            .pressScale()
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.62f))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

/**
 * Seek bar bergaya Material 3 Expressive: bagian yang sudah diputar berupa gelombang yang mengalir
 * saat lagu berjalan dan meluruh jadi garis lurus saat dijeda; gagangnya berupa batang membulat.
 * [fraction] dibaca saat menggambar, [onDrag] memberi tahu posisi geser (null saat dilepas).
 */
@Composable
fun SeekBar(
    fraction: () -> Float,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier,
    activeColor: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.16f),
    waving: Boolean = false,
    onDrag: (Float?) -> Unit = {},
) {
    var widthPx by remember { mutableFloatStateOf(1f) }
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    val seek by rememberUpdatedState(onSeek)
    val drag by rememberUpdatedState(onDrag)
    val thickness by animateDpAsState(
        targetValue = if (dragging) 8.dp else 6.dp,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "seekThickness",
    )
    val handleWidth by animateDpAsState(
        targetValue = if (dragging) 3.dp else 5.dp,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "seekHandle",
    )
    // Gelombang mengalir hanya saat lagu berjalan; saat dijeda atau digeser, amplitudonya meluruh ke nol.
    val amplitude by animateFloatAsState(
        targetValue = if (waving && !dragging) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessLow),
        label = "waveAmplitude",
    )
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(waving) {
        if (waving) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                phase = (phase + (now - last) / 1_000_000_000f * 4.2f) % TWO_PI
                last = now
            }
        }
    }
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(36.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { off -> seek((off.x / widthPx).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { off ->
                        dragging = true
                        dragFraction = (off.x / widthPx).coerceIn(0f, 1f)
                        drag(dragFraction)
                    },
                    onDragEnd = {
                        dragging = false
                        drag(null)
                        seek(dragFraction)
                    },
                    onDragCancel = {
                        dragging = false
                        drag(null)
                    },
                    onHorizontalDrag = { change, delta ->
                        change.consume()
                        dragFraction = (dragFraction + delta / widthPx).coerceIn(0f, 1f)
                        drag(dragFraction)
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(32.dp),
        ) {
            val f = (if (dragging) dragFraction else fraction()).coerceIn(0f, 1f)
            val stroke = thickness.toPx()
            val cy = size.height / 2f
            val activeEnd = size.width * f
            val amp = amplitude * 3.dp.toPx()
            val wavelength = 26.dp.toPx()
            val ph = phase

            // Bagian yang belum diputar: garis lurus.
            drawLine(
                color = trackColor,
                start = Offset(activeEnd, cy),
                end = Offset(size.width, cy),
                strokeWidth = stroke,
                cap = StrokeCap.Round,
            )
            // Bagian yang sudah diputar: gelombang.
            val path = Path()
            val step = 4.dp.toPx()
            var x = 0f
            path.moveTo(0f, cy + amp * sin(ph))
            while (x < activeEnd) {
                x = min(x + step, activeEnd)
                path.lineTo(x, cy + amp * sin(x / wavelength * TWO_PI + ph))
            }
            drawPath(
                path = path,
                color = activeColor,
                style = Stroke(width = stroke, cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
            // Gagang: batang membulat.
            val hw = handleWidth.toPx()
            val hh = 28.dp.toPx()
            drawRoundRect(
                color = activeColor,
                topLeft = Offset(activeEnd - hw / 2f, cy - hh / 2f),
                size = Size(hw, hh),
                cornerRadius = CornerRadius(hw / 2f, hw / 2f),
            )
        }
    }
}

private const val TWO_PI = 6.2831855f

/** Waktu berjalan (kiri) dan durasi (kanan) di bawah seek bar. */
@Composable
fun SeekTimes(pos: State<Long>, durationMs: Long, drag: State<Float?>, modifier: Modifier = Modifier) {
    val sec by remember(durationMs) {
        derivedStateOf {
            val d = drag.value
            (if (d != null) (d * durationMs.toFloat()).toLong() else pos.value) / 1000L
        }
    }
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = clock(sec), style = MaterialTheme.typography.bodySmall, color = muted)
        Text(
            text = if (durationMs > 0L) clock(durationMs / 1000L) else "--:--",
            style = MaterialTheme.typography.bodySmall,
            color = muted,
        )
    }
}

/** Seek bar + waktu, terhubung ke pemutar. */
@Composable
fun PlayerSeek(player: PlayerConnection, pos: State<Long>, modifier: Modifier = Modifier) {
    val drag = remember { mutableStateOf<Float?>(null) }
    val duration = player.durationMs
    Column(modifier.fillMaxWidth()) {
        SeekBar(
            fraction = { if (duration > 0L) (pos.value.toFloat() / duration.toFloat()) else 0f },
            onSeek = { f ->
                if (duration > 0L) {
                    player.seekTo((f * duration.toFloat()).toLong())
                    player.tick()
                }
            },
            waving = player.isPlaying,
            onDrag = { drag.value = it },
        )
        SeekTimes(pos, duration, drag)
    }
}

/**
 * Baris kontrol pemutar. Tombol putar berubah bentuk (bulat saat memutar, kotak membulat saat jeda)
 * dan ikonnya berganti dengan animasi.
 */
@Composable
fun TransportControls(
    player: PlayerConnection,
    modifier: Modifier = Modifier,
    withModes: Boolean = true,
    playSize: Dp = 76.dp,
) {
    val primary = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val shuffleTint by animateColorAsState(if (player.shuffle) primary else muted, label = "shuffleTint")
    val repeatTint by animateColorAsState(
        if (player.repeatMode != Player.REPEAT_MODE_OFF) primary else muted,
        label = "repeatTint",
    )
    val corner by animateDpAsState(
        targetValue = if (player.isPlaying) playSize / 2 else playSize / 3,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "playCorner",
    )

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (withModes) {
            IconButton(onClick = { player.toggleShuffle() }, modifier = Modifier.pressScale()) {
                Icon(
                    painter = painterResource(R.drawable.ic_shuffle),
                    contentDescription = "Acak",
                    tint = shuffleTint,
                )
            }
        }
        SkipButton(R.drawable.ic_skip_previous, "Sebelumnya") { player.previous() }
        Box(
            modifier = Modifier
                .size(playSize)
                .pressScale(0.92f)
                .clip(RoundedCornerShape(corner))
                .background(primary)
                .clickable { player.togglePlay() },
            contentAlignment = Alignment.Center,
        ) {
            if (player.buffering && !player.isPlaying) {
                PlayLoader(
                    diameter = playSize / 2,
                    containerColor = MaterialTheme.colorScheme.onPrimary,
                    color = primary,
                )
            } else {
                AnimatedContent(
                    targetState = player.isPlaying,
                    transitionSpec = {
                        (fadeIn(tween(160)) + scaleIn(initialScale = 0.5f)) togetherWith
                            (fadeOut(tween(100)) + scaleOut(targetScale = 0.5f))
                    },
                    label = "playIcon",
                ) { playing ->
                    Icon(
                        painter = painterResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play),
                        contentDescription = "Putar atau jeda",
                        tint = MaterialTheme.colorScheme.onPrimary,
                        modifier = Modifier.size(playSize / 2),
                    )
                }
            }
        }
        SkipButton(R.drawable.ic_skip_next, "Berikutnya") { player.next() }
        if (withModes) {
            IconButton(onClick = { player.cycleRepeat() }, modifier = Modifier.pressScale()) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        painter = painterResource(R.drawable.ic_repeat),
                        contentDescription = "Ulangi",
                        tint = repeatTint,
                    )
                    if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                        Text(
                            text = "1",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = primary,
                        )
                    }
                }
            }
        }
    }
}

/** Tombol lagu sebelumnya/berikutnya: kotak membulat berwarna (gaya Material 3 Expressive). */
@Composable
private fun SkipButton(icon: Int, description: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(width = 56.dp, height = 52.dp)
            .pressScale(0.88f)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.secondaryContainer)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = description,
            tint = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.size(28.dp),
        )
    }
}

// =====================================================================
// Layar Now Playing
// =====================================================================

/** Layar pemutar penuh: sampul besar, seek bar, kontrol; lirik dan antrean dibuka dari tombol di bawah. */
@Composable
fun NowPlayingScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onClose: () -> Unit,
    onOpenChannel: (url: String, name: String) -> Unit,
) {
    val track = player.current
    val context = LocalContext.current
    var showLyrics by remember { mutableStateOf(false) }
    var showQueue by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    // Cari lirik setiap lagu berganti.
    LaunchedEffect(track?.url) {
        if (track != null) vm.loadLyrics(track)
    }
    BackHandler(enabled = showQueue) { showQueue = false }

    val pos = rememberSmoothPosition(player)
    val onSurface = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant
    val primary = MaterialTheme.colorScheme.primary

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Box(Modifier.fillMaxSize()) {
            CoverBackdrop(track?.thumb, Modifier.fillMaxSize())

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                // ---- Atas ----
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .growIn(0.9f, 40),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    GlassButton(onClick = onClose) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup", tint = onSurface)
                    }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Text(
                            text = "Sedang diputar",
                            style = MaterialTheme.typography.labelLarge,
                            color = onSurface,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.62f))
                                .padding(horizontal = 14.dp, vertical = 7.dp),
                        )
                    }
                    Box {
                        GlassButton(onClick = { menuOpen = true }) {
                            Icon(Icons.Filled.MoreVert, contentDescription = "Menu", tint = onSurface)
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text("Unduh audio") },
                                onClick = {
                                    menuOpen = false
                                    if (track != null) {
                                        val msg = Downloads.start(track, false)
                                        Toast.makeText(context, I18n.tr(msg), Toast.LENGTH_SHORT).show()
                                    }
                                },
                            )
                            val cu = track?.uploaderUrl
                            if (cu != null && track != null) {
                                DropdownMenuItem(
                                    text = { Text("Buka halaman artis") },
                                    onClick = {
                                        menuOpen = false
                                        onOpenChannel(cu, track.artist)
                                    },
                                )
                            }
                        }
                    }
                }

                // ---- Sampul ----
                BoxWithConstraints(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    val side = if (maxWidth < maxHeight) maxWidth else maxHeight
                    // Sampul sedikit mengecil saat dijeda dan membesar lagi saat diputar.
                    val coverScale by animateFloatAsState(
                        targetValue = if (player.isPlaying) 1f else 0.88f,
                        animationSpec = spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow),
                        label = "coverScale",
                    )
                    // Sampul adalah elemen bersama: tumbuh dari sampul mini player saat layar dibuka.
                    Box(
                        modifier = Modifier
                            .sharedElementKey("cover")
                            .size(side)
                            .graphicsLayer {
                                scaleX = coverScale
                                scaleY = coverScale
                            }
                            .shadow(24.dp, RoundedCornerShape(32.dp))
                            .clip(RoundedCornerShape(32.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        AnimatedContent(
                            targetState = track,
                            modifier = Modifier.fillMaxSize(),
                            transitionSpec = { popTransform(from = 0.9f) },
                            label = "cover",
                        ) { t ->
                            HdImage(t?.thumb, Modifier.fillMaxSize(), px = 1200)
                        }
                    }
                }

                // ---- Judul + favorit ----
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // Judul + artis adalah batas bersama: tumbuh dari judul kecil di mini player.
                    AnimatedContent(
                        targetState = track,
                        modifier = Modifier
                            .weight(1f)
                            .sharedBoundsKey("meta"),
                        transitionSpec = { popTransform(from = 0.96f) },
                        label = "title",
                    ) { t ->
                        val cu = t?.uploaderUrl
                        Column(Modifier.fillMaxWidth()) {
                            Text(
                                text = t?.title ?: "",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = t?.artist ?: "",
                                style = MaterialTheme.typography.titleMedium,
                                color = muted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .then(
                                        if (cu != null && t != null) {
                                            Modifier.clickable { onOpenChannel(cu, t.artist) }
                                        } else {
                                            Modifier
                                        },
                                    ),
                            )
                        }
                    }
                    if (track != null) {
                        val fav = vm.isFavorite(track.url)
                        val pop = remember { Animatable(1f) }
                        LaunchedEffect(fav) {
                            if (fav) {
                                pop.snapTo(0.5f)
                                pop.animateTo(1f, spring(dampingRatio = 0.35f, stiffness = Spring.StiffnessMedium))
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        GlassButton(onClick = { vm.toggleFavorite(track) }) {
                            Icon(
                                imageVector = if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "Favorit",
                                tint = if (fav) primary else muted,
                                modifier = Modifier.graphicsLayer {
                                    scaleX = pop.value
                                    scaleY = pop.value
                                },
                            )
                        }
                    }
                }

                // ---- Seek bar ----
                PlayerSeek(player, pos, Modifier.padding(top = 12.dp).growIn(0.92f, 90))

                // ---- Kontrol ----
                TransportControls(
                    player = player,
                    modifier = Modifier
                        .padding(top = 4.dp, bottom = 8.dp)
                        .growIn(0.88f, 130),
                )

                // ---- Aksi: lirik, antrean, bagikan ----
                Row(
                    modifier = Modifier
                        .padding(top = 4.dp, bottom = 16.dp)
                        .growIn(0.85f, 180)
                        .clip(RoundedCornerShape(30.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.85f))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    PillAction(R.drawable.ic_lyrics, "Lirik", active = showLyrics) { showLyrics = true }
                    PillAction(R.drawable.ic_queue, "Antrean", active = showQueue) { showQueue = true }
                    PillAction(R.drawable.ic_share, "Bagikan", active = false) {
                        if (track != null) {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, track.url)
                            }
                            context.startActivity(Intent.createChooser(send, "Bagikan"))
                        }
                    }
                }
            }

            // ---- Lirik layar penuh: tumbuh dari bawah ----
            PopVisibility(
                visible = showLyrics,
                modifier = Modifier.fillMaxSize(),
                origin = OriginBottom,
                from = 0.55f,
            ) {
                LyricsScreen(vm, player, pos, onClose = { showLyrics = false })
            }

            // ---- Antrean: lapisan gelap memudar, panel naik sambil membesar ----
            AnimatedVisibility(
                visible = showQueue,
                enter = fadeIn(tween(220)),
                exit = fadeOut(tween(200)),
            ) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .scrimClickable { showQueue = false },
                )
            }
            AnimatedVisibility(
                visible = showQueue,
                modifier = Modifier.align(Alignment.BottomCenter),
                enter = popEnter(OriginBottom, 0.5f),
                exit = popExit(OriginBottom, 0.55f),
            ) {
                QueueSheet(player = player, onClose = { showQueue = false })
            }
        }
    }
}

/** Satu aksi di panel bawah (lirik / antrean / bagikan). Yang aktif diberi latar warna. */
@Composable
private fun PillAction(icon: Int, label: String, active: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(
        targetValue = if (active) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        label = "pillBg",
    )
    val tint by animateColorAsState(
        targetValue = if (active) {
            MaterialTheme.colorScheme.onPrimaryContainer
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        },
        label = "pillTint",
    )
    Box(
        modifier = Modifier
            .size(width = 76.dp, height = 48.dp)
            .pressScale(0.9f)
            .clip(RoundedCornerShape(24.dp))
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = label,
            tint = tint,
            modifier = Modifier.size(24.dp),
        )
    }
}

// =====================================================================
// Antrean: lagu yang sedang diputar + lagu berikutnya
// =====================================================================

@Composable
private fun QueueSheet(player: PlayerConnection, onClose: () -> Unit) {
    val queue = player.queue
    val upcoming: List<Int> = remember(player.queue, player.index, player.shuffle, player.repeatMode) {
        player.upcoming()
    }
    val current = player.current
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(0.78f)
            // Ketukan di panel tidak menutup antrean.
            .pointerInput(Unit) { detectTapGestures { } },
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 3.dp,
    ) {
        Column(Modifier.navigationBarsPadding()) {
            Box(
                Modifier
                    .padding(top = 10.dp)
                    .align(Alignment.CenterHorizontally)
                    .size(width = 36.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(muted.copy(alpha = 0.4f)),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 24.dp, end = 8.dp, top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    text = "Antrean",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = onClose, modifier = Modifier.pressScale()) {
                    Icon(Icons.Filled.Close, contentDescription = "Tutup")
                }
            }
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                state = rememberLazyListState(),
                contentPadding = PaddingValues(bottom = 16.dp),
            ) {
                item(key = "label-now") { QueueLabel("Sedang diputar") }
                if (current != null) {
                    item(key = "now") {
                        QueueRow(current, isCurrent = true, onClick = {}, onRemove = null)
                    }
                }
                item(key = "label-next") {
                    QueueLabel(if (upcoming.isEmpty()) "Tidak ada lagu berikutnya" else "Berikutnya")
                }
                itemsIndexed(
                    upcoming,
                    key = { _, i -> "q$i-${queue.getOrNull(i)?.url}" },
                ) { _, i ->
                    val t = queue.getOrNull(i)
                    if (t != null) {
                        QueueRow(
                            track = t,
                            isCurrent = false,
                            onClick = { player.jumpTo(i) },
                            onRemove = { player.removeAt(i) },
                            modifier = Modifier.animateItem(),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QueueLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 6.dp),
    )
}

@Composable
private fun QueueRow(
    track: Track,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onRemove: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val primary = MaterialTheme.colorScheme.primary
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable(enabled = !isCurrent, onClick = onClick)
            .padding(start = 24.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Thumb(track.thumb, 48.dp, pageUrl = track.url)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = track.title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (isCurrent) primary else MaterialTheme.colorScheme.onSurface,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = track.artist,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (onRemove != null) {
            IconButton(onClick = onRemove, modifier = Modifier.pressScale()) {
                Icon(Icons.Filled.Close, contentDescription = "Hapus dari antrean")
            }
        }
    }
}
