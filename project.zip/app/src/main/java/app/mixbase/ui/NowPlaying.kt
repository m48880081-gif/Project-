package app.mixbase.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.view.TextureView
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.material3.LocalContentColor
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.Player
import app.mixbase.R
import app.mixbase.data.Engine
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Layar pemutar penuh: sampul atau video, seek bar, kontrol, dan antrean. */
@Composable
fun NowPlayingScreen(vm: AppViewModel, player: PlayerConnection, onClose: () -> Unit) {
    val context = LocalContext.current
    var fullscreen by rememberSaveable { mutableStateOf(false) }

    // Keluar dari layar penuh kalau mode video dimatikan.
    LaunchedEffect(player.videoMode) {
        if (!player.videoMode) fullscreen = false
    }

    // Layar penuh = landscape + sembunyikan status bar & tombol navigasi.
    DisposableEffect(fullscreen) {
        val activity = context.findActivity()
        if (activity != null && fullscreen) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            val ctl = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
            ctl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            ctl.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (activity != null && fullscreen) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                    .show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    BackHandler(enabled = fullscreen) { fullscreen = false }

    if (fullscreen) {
        FullscreenVideo(player) { fullscreen = false }
    } else {
        PlayerPage(vm, player, onClose) { fullscreen = true }
    }
}

// ---------------------------------------------------------------- halaman biasa

@Composable
private fun PlayerPage(
    vm: AppViewModel,
    player: PlayerConnection,
    onClose: () -> Unit,
    onFullscreen: () -> Unit,
) {
    val track = player.current
    val trackUrl = track?.url

    val primary = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    // Daftar kualitas yang tersedia untuk video yang sedang diputar.
    var heights by remember { mutableStateOf<List<Int>>(emptyList()) }
    LaunchedEffect(trackUrl, player.videoMode) {
        heights = emptyList()
        val id = if (player.videoMode && trackUrl != null) Engine.videoIdOf(trackUrl) else null
        if (id != null) {
            heights = withContext(Dispatchers.IO) {
                try {
                    Engine.heightsFor(id)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    emptyList()
                }
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        ) {
            // ---- Header ----
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup")
                    }
                    Text(
                        text = "Sedang diputar",
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f),
                    )
                    if (track != null) {
                        val fav = vm.isFavorite(track.url)
                        IconButton(onClick = { vm.toggleFavorite(track) }) {
                            Icon(
                                imageVector = if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "Favorit",
                                tint = if (fav) primary else muted,
                            )
                        }
                    } else {
                        Spacer(Modifier.size(48.dp))
                    }
                }
            }

            // ---- Video atau sampul ----
            item {
                if (player.videoMode) {
                    VideoFrame(
                        player = player,
                        art = track?.thumb,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(16.dp)),
                    ) {
                        IconButton(
                            onClick = onFullscreen,
                            modifier = Modifier.align(Alignment.BottomEnd),
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.Black.copy(alpha = 0.45f),
                                contentColor = Color.White,
                            ),
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_fullscreen),
                                contentDescription = "Layar penuh",
                            )
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                        ) {
                            val art = track?.thumb
                            if (art != null) {
                                AsyncImage(
                                    model = art,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop,
                                )
                            }
                        }
                    }
                }
            }

            // ---- Judul ----
            item {
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        text = track?.title ?: "",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = track?.artist ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = muted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }

            // ---- Mode Audio / Video + kualitas ----
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(
                        selected = !player.videoMode,
                        onClick = { player.setVideoMode(false) },
                        label = { Text("Audio") },
                    )
                    FilterChip(
                        selected = player.videoMode,
                        onClick = { player.setVideoMode(true) },
                        label = { Text("Video") },
                    )
                    if (player.videoMode) {
                        Spacer(Modifier.weight(1f))
                        QualityButton(player, heights)
                    }
                }
            }

            // ---- Pesan error ----
            if (player.playerError != null) {
                item {
                    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                        Text(
                            text = player.playerError ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                        )
                        OutlinedButton(
                            onClick = { player.retry() },
                            modifier = Modifier.padding(top = 4.dp),
                        ) { Text("Coba lagi") }
                    }
                }
            }

            // ---- Seek bar ----
            item {
                Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    SeekBar(player, muted)
                }
            }

            // ---- Kontrol ----
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { player.toggleShuffle() }) {
                        Icon(
                            painter = painterResource(R.drawable.ic_shuffle),
                            contentDescription = "Acak",
                            tint = if (player.shuffle) primary else muted,
                        )
                    }
                    IconButton(onClick = { player.previous() }, modifier = Modifier.size(56.dp)) {
                        Icon(
                            painter = painterResource(R.drawable.ic_skip_previous),
                            contentDescription = "Sebelumnya",
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    FilledIconButton(
                        onClick = { player.togglePlay() },
                        modifier = Modifier.size(72.dp),
                    ) {
                        if (player.buffering && !player.isPlaying) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(32.dp),
                                strokeWidth = 3.dp,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                        } else {
                            Icon(
                                painter = painterResource(if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                                contentDescription = "Putar atau jeda",
                                modifier = Modifier.size(36.dp),
                            )
                        }
                    }
                    IconButton(onClick = { player.next() }, modifier = Modifier.size(56.dp)) {
                        Icon(
                            painter = painterResource(R.drawable.ic_skip_next),
                            contentDescription = "Berikutnya",
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    IconButton(onClick = { player.cycleRepeat() }) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                painter = painterResource(R.drawable.ic_repeat),
                                contentDescription = "Ulangi",
                                tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) primary else muted,
                            )
                            if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                                Text(
                                    text = "1",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = primary,
                                )
                            }
                        }
                    }
                }
            }

            // ---- Antrean ----
            item {
                Text(
                    text = "Antrean (${player.queue.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
                )
            }
            itemsIndexed(player.queue, key = { i, t -> "${t.url}#$i" }) { i, t ->
                val isCurrent = i == player.index
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { player.jumpTo(i) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Thumb(t.thumb, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = t.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isCurrent) primary else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = t.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = muted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(onClick = { player.removeAt(i) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Hapus dari antrean")
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- layar penuh

@Composable
private fun FullscreenVideo(player: PlayerConnection, onExit: () -> Unit) {
    var controls by remember { mutableStateOf(true) }
    val interaction = remember { MutableInteractionSource() }

    // Kontrol hilang sendiri setelah 3,5 detik selama video berjalan.
    LaunchedEffect(controls, player.isPlaying) {
        if (controls && player.isPlaying) {
            delay(3500)
            controls = false
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(interactionSource = interaction, indication = null) { controls = !controls },
    ) {
        VideoFrame(
            player = player,
            art = player.current?.thumb,
            modifier = Modifier.fillMaxSize(),
        )

        val err = player.playerError
        if (err != null) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = err,
                    color = Color.White,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center,
                )
                TextButton(onClick = { player.retry() }) { Text("Coba lagi", color = Color.White) }
            }
        }

        if (controls) {
            CompositionLocalProvider(LocalContentColor provides Color.White) {
                // Atas: keluar layar penuh + judul
                Row(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .displayCutoutPadding()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onExit) {
                        Icon(
                            painter = painterResource(R.drawable.ic_fullscreen_exit),
                            contentDescription = "Keluar layar penuh",
                        )
                    }
                    Text(
                        text = player.current?.title ?: "",
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                }

                // Bawah: seek bar + kontrol
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.45f))
                        .displayCutoutPadding()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                ) {
                    SeekBar(player, Color.White)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = { player.previous() }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_skip_previous),
                                contentDescription = "Sebelumnya",
                            )
                        }
                        IconButton(onClick = { player.togglePlay() }, modifier = Modifier.size(56.dp)) {
                            Icon(
                                painter = painterResource(if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                                contentDescription = "Putar atau jeda",
                                modifier = Modifier.size(36.dp),
                            )
                        }
                        IconButton(onClick = { player.next() }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_skip_next),
                                contentDescription = "Berikutnya",
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- bagian bersama

/**
 * Bingkai video dengan perbandingan sisi mengikuti video asli (tidak melar).
 * Sebelum frame pertama tampil, sampul ditampilkan sebagai gantinya.
 */
@Composable
private fun VideoFrame(
    player: PlayerConnection,
    art: String?,
    modifier: Modifier = Modifier,
    overlay: @Composable BoxScope.() -> Unit = {},
) {
    Box(
        modifier = modifier.background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.aspectRatio(player.videoAspect)) {
            if (art != null && !player.videoReady) {
                AsyncImage(
                    model = art,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            }
            VideoSurface(player, Modifier.fillMaxSize())
        }
        if (player.buffering) {
            CircularProgressIndicator(
                modifier = Modifier.size(40.dp),
                strokeWidth = 3.dp,
                color = Color.White,
            )
        }
        overlay()
    }
}

/** TextureView yang dipasang ke pemutar selama ada di layar. */
@Composable
private fun VideoSurface(player: PlayerConnection, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val tv = remember { TextureView(context) }
    DisposableEffect(tv) {
        player.attachVideo(tv)
        onDispose { player.detachVideo(tv) }
    }
    AndroidView(
        factory = { tv },
        modifier = modifier,
        update = { it.keepScreenOn = player.isPlaying },
    )
}

@Composable
private fun SeekBar(player: PlayerConnection, textColor: Color) {
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    val duration: Long = if (player.durationMs > 0L) player.durationMs else 1L
    val fraction: Float = if (dragging) {
        dragValue
    } else {
        (player.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    }
    val shownSec: Long = (fraction * duration.toFloat() / 1000f).toLong()

    Column(Modifier.fillMaxWidth()) {
        Slider(
            value = fraction,
            onValueChange = {
                dragging = true
                dragValue = it
            },
            onValueChangeFinished = {
                player.seekTo((dragValue * duration.toFloat()).toLong())
                dragging = false
            },
            modifier = Modifier.fillMaxWidth(),
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(
                text = clock(shownSec),
                style = MaterialTheme.typography.bodySmall,
                color = textColor,
            )
            Text(
                text = if (player.durationMs > 0L) clock(player.durationMs / 1000L) else "--:--",
                style = MaterialTheme.typography.bodySmall,
                color = textColor,
            )
        }
    }
}

@Composable
private fun QualityButton(player: PlayerConnection, heights: List<Int>) {
    var open by remember { mutableStateOf(false) }

    val base = if (player.videoHeight == 0) "Otomatis" else "${player.videoHeight}p"
    val now = if (player.videoReady && player.videoPx > 0 && player.videoPx != player.videoHeight) {
        " (${player.videoPx}p)"
    } else {
        ""
    }

    val options: List<Int> = if (heights.isEmpty()) {
        listOf(1080, 720, 480, 360)
    } else {
        heights.filter { it >= 144 }.distinct().sortedDescending()
    }

    Box {
        TextButton(onClick = { open = true }) {
            Text("Kualitas: $base$now")
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Otomatis (maks 1080p)") },
                onClick = {
                    player.setVideoHeight(0)
                    open = false
                },
            )
            for (h in options) {
                DropdownMenuItem(
                    text = { Text(if (h >= 720) "${h}p HD" else "${h}p") },
                    onClick = {
                        player.setVideoHeight(h)
                        open = false
                    },
                )
            }
        }
    }
}
