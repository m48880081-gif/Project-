package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import app.mixbase.R
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection

/** Layar pemutar penuh: sampul, seek bar, kontrol, dan antrean. */
@Composable
fun NowPlayingScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onClose: () -> Unit,
    onOpenChannel: (url: String, name: String) -> Unit,
) {
    val track = player.current
    var showLyrics by remember { mutableStateOf(false) }

    // Cari lirik setiap lagu berganti.
    LaunchedEffect(track?.url) {
        if (track != null) vm.loadLyrics(track)
    }

    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }

    val duration: Long = if (player.durationMs > 0L) player.durationMs else 1L
    val fraction: Float = if (dragging) {
        dragValue
    } else {
        (player.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    }
    val shownSec: Long = (fraction * duration.toFloat() / 1000f).toLong()

    val primary = MaterialTheme.colorScheme.primary
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Surface(modifier = Modifier.fillMaxSize()) {
      Box(Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
        ) {
            // ---- Header ----
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup")
                    }
                    Text(
                        text = "Sedang diputar",
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f),
                    )
                    if (track != null) {
                        val fav = vm.isFavorite(track.url)
                        IconButton(onClick = { vm.toggleFavorite(track) }) {
                            Icon(
                                imageVector = if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "Favorit",
                                tint = if (fav) primary else muted,
                            )
                        }
                    } else {
                        Spacer(Modifier.size(48.dp))
                    }
                }
            }

            // ---- Sampul ----
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                    ) {
                        HdImage(track?.thumb, Modifier.fillMaxSize(), px = 1200)
                    }
                }
            }

            // ---- Judul ----
            item {
                val cu = track?.uploaderUrl
                Column(Modifier.fillMaxWidth()) {
                    Text(
                        text = track?.title ?: "",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = track?.artist ?: "",
                        style = MaterialTheme.typography.bodyMedium,
                        color = muted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .then(
                                if (cu != null && track != null) {
                                    Modifier.clickable { onOpenChannel(cu, track.artist) }
                                } else {
                                    Modifier
                                },
                            ),
                    )
                }
            }

            // ---- Seek bar ----
            item {
                Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                    Slider(
                        value = fraction,
                        onValueChange = {
                            dragging = true
                            dragValue = it
                        },
                        onValueChangeFinished = {
                            player.seekTo((dragValue * duration.toFloat()).toLong())
                            dragging = false
                        },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(
                            text = clock(shownSec),
                            style = MaterialTheme.typography.bodySmall,
                            color = muted,
                        )
                        Text(
                            text = if (player.durationMs > 0L) clock(player.durationMs / 1000L) else "--:--",
                            style = MaterialTheme.typography.bodySmall,
                            color = muted,
                        )
                    }
                }
            }

            // ---- Kontrol ----
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = { player.toggleShuffle() }) {
                        Icon(
                            painter = painterResource(R.drawable.ic_shuffle),
                            contentDescription = "Acak",
                            tint = if (player.shuffle) primary else muted,
                        )
                    }
                    IconButton(onClick = { player.previous() }, modifier = Modifier.size(56.dp)) {
                        Icon(
                            painter = painterResource(R.drawable.ic_skip_previous),
                            contentDescription = "Sebelumnya",
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    FilledIconButton(
                        onClick = { player.togglePlay() },
                        modifier = Modifier.size(72.dp),
                    ) {
                        if (player.buffering && !player.isPlaying) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(32.dp),
                                strokeWidth = 3.dp,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                        } else {
                            Icon(
                                painter = painterResource(if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                                contentDescription = "Putar atau jeda",
                                modifier = Modifier.size(36.dp),
                            )
                        }
                    }
                    IconButton(onClick = { player.next() }, modifier = Modifier.size(56.dp)) {
                        Icon(
                            painter = painterResource(R.drawable.ic_skip_next),
                            contentDescription = "Berikutnya",
                            modifier = Modifier.size(32.dp),
                        )
                    }
                    IconButton(onClick = { player.cycleRepeat() }) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                painter = painterResource(R.drawable.ic_repeat),
                                contentDescription = "Ulangi",
                                tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) primary else muted,
                            )
                            if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                                Text(
                                    text = "1",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = primary,
                                )
                            }
                        }
                    }
                }
            }

            // ---- Lirik ----
            item {
                LyricsCard(vm, player, onOpen = { showLyrics = true })
            }

            // ---- Antrean ----
            item {
                Text(
                    text = "Antrean (${player.queue.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
                )
            }
            itemsIndexed(player.queue, key = { i, t -> "${t.url}#$i" }) { i, t ->
                val isCurrent = i == player.index
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { player.jumpTo(i) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Thumb(t.thumb, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = t.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isCurrent) primary else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = t.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = muted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(onClick = { player.removeAt(i) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Hapus dari antrean")
                    }
                }
            }
        }
        if (showLyrics) {
            LyricsScreen(vm, player, onClose = { showLyrics = false })
        }
      }
    }
}
