package app.mixbase.ui

import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import app.mixbase.data.Track
import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.media3.common.Player
import app.mixbase.R
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch

/** Isi area tengah layar pemutar: sampul, lirik, atau antrean. */
private enum class Pane { COVER, LYRICS, QUEUE }

/** Jenis animasi tombol: ditembakkan ke samping, berputar, bergoyang, atau melonjak. */
private enum class Fx { SHOOT_LEFT, SHOOT_RIGHT, SPIN, WIGGLE, POP }

/**
 * Layar pemutar penuh, gaya Auralys: gambar lagu memenuhi lebar layar lalu memudar ke warna latar
 * (latar mengikuti warna sampul lewat tema di AppRoot). Area tengah bisa berganti antara sampul / lirik /
 * antrean lewat bilah kaca dua tab di bawah; lirik bisa dibuat layar penuh (kontrol bawah disembunyikan,
 * hanya tersisa judul, durasi, putar, dan berikutnya). Semua tombol punya animasi tembak/membal.
 *
 * Posisi putar hanya dibaca di komponen kecil ([SeekSection], [FullLyricsControls]) dan saat menggambar,
 * jadi layar ini tidak ikut digambar ulang setiap detik.
 */
@Composable
fun NowPlayingScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onClose: () -> Unit,
    onOpenChannel: (url: String, name: String) -> Unit,
) {
    val track = player.current
    var pane by remember { mutableStateOf(Pane.COVER) }
    // Tab terakhir yang dipilih: lensa kaca tetap di sana (tersembunyi) saat sampul tampil.
    var navIndex by remember { mutableIntStateOf(1) }
    var fullLyrics by remember { mutableStateOf(false) }

    // Cari lirik setiap lagu berganti.
    LaunchedEffect(track?.url) {
        if (track != null) vm.loadLyrics(track)
    }
    LaunchedEffect(pane) {
        if (pane != Pane.LYRICS) fullLyrics = false
    }
    BackHandler(enabled = fullLyrics) { fullLyrics = false }

    // Warna tetap mengikuti tema app (tidak lagi mengikuti sampul lagu).
    val cs = MaterialTheme.colorScheme
    // Palet netral gaya Auralys (abu-abu di mode terang, hampir hitam di mode gelap), tidak ikut warna lagu.
    val lightBg = cs.background.luminance() > 0.5f
    val bg = if (lightBg) Color(0xFFB1B1B1) else Color(0xFF060606)
    val accent = Color(0xFFFF2D55)
    val onAccent = Color.White
    val fg = if (lightBg) Color(0xFF11161D) else Color(0xFFF2F2F2)
    val muted = fg.copy(alpha = 0.66f)

    // Gambar lagu hanya tampil di mode sampul; header putih di atasnya (ada bayangan gelap tipis).
    val onArt = pane == Pane.COVER && !fullLyrics
    val artAlpha = animateFloatAsState(if (onArt) 1f else 0f, animationSpec = tween(300), label = "artAlpha")
    val headColor by animateColorAsState(if (onArt) Color.White else fg, animationSpec = tween(300), label = "headColor")

    // Mode lirik (gaya Apple Music): bagian atas layar diberi rona sampul yang memudar ke warna latar.
    // Hanya tampil saat lirik terbuka; mode sampul dan antrean tetap netral.
    val art = rememberArtPalette(track?.thumb, track?.url)
    val glowAlpha by animateFloatAsState(
        targetValue = if (pane == Pane.LYRICS) 1f else 0f,
        animationSpec = tween(400),
        label = "glowAlpha",
    )
    val glowColor by animateColorAsState(
        targetValue = if (lightBg) lerp(art.top, Color.White, 0.6f) else art.top,
        animationSpec = tween(700),
        label = "glowColor",
    )

    // Ikon status bar: terang di atas gambar, selain itu menyesuaikan terang/gelapnya latar.
    val view = LocalView.current
    DisposableEffect(lightBg, onArt) {
        val window = (view.context as? Activity)?.window
        val ctrl = if (window != null) WindowCompat.getInsetsController(window, view) else null
        val prevStatus = ctrl?.isAppearanceLightStatusBars
        val prevNav = ctrl?.isAppearanceLightNavigationBars
        if (ctrl != null) {
            ctrl.isAppearanceLightStatusBars = lightBg && !onArt
            ctrl.isAppearanceLightNavigationBars = lightBg
        }
        onDispose {
            if (ctrl != null && prevStatus != null) ctrl.isAppearanceLightStatusBars = prevStatus
            if (ctrl != null && prevNav != null) ctrl.isAppearanceLightNavigationBars = prevNav
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(bg),
    ) {
        // ---- Gambar lagu: selebar layar, memudar ke warna latar di bawah ----
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.62f)
                .graphicsLayer { alpha = artAlpha.value },
        ) {
            Box(
                modifier = Modifier
                    .sharedCover("cover")
                    .fillMaxSize()
                    .background(fg.copy(alpha = 0.08f)),
            ) {
                HdImage(track?.thumb, Modifier.fillMaxSize(), px = 1200)
            }
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color.Black.copy(alpha = 0.45f),
                            0.20f to Color.Black.copy(alpha = 0f),
                            0.50f to bg.copy(alpha = 0f),
                            0.80f to bg.copy(alpha = 0.80f),
                            1f to bg,
                        ),
                    ),
            )
        }

        // ---- Rona sampul di atas layar, hanya saat lirik tampil ----
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = glowAlpha }
                .background(
                    Brush.verticalGradient(
                        0f to glowColor.copy(alpha = 0.9f),
                        0.65f to glowColor.copy(alpha = 0f),
                    ),
                ),
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding(),
        ) {
            // ---- Header ----
            AnimatedVisibility(visible = !fullLyrics) {
                Row(
                    modifier = Modifier
                        .flyInOut(fromTop = true)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    val closeSrc = remember { MutableInteractionSource() }
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.jelly(closeSrc),
                        interactionSource = closeSrc,
                    ) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup", tint = headColor)
                    }
                    Text(
                        text = "Sedang diputar",
                        style = MaterialTheme.typography.titleMedium,
                        color = headColor,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.size(48.dp))
                }
            }

            // ---- Area tengah: (sampul = gambar di belakang) / lirik / antrean ----
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 4.dp),
            ) {
                Crossfade(targetState = pane, animationSpec = tween(250), label = "pane") { p ->
                    when (p) {
                        Pane.COVER -> Spacer(Modifier.fillMaxSize())

                        Pane.LYRICS -> LyricsPane(
                            vm = vm,
                            player = player,
                            fg = fg,
                            full = fullLyrics,
                            onToggleFull = { fullLyrics = !fullLyrics },
                            modifier = Modifier.fillMaxSize(),
                        )

                        Pane.QUEUE -> QueuePane(player, fg, muted, accent)
                    }
                }
            }

            // ---- Mode normal: judul + suka, seek bar, kontrol, bilah kaca Antrean/Lirik ----
            AnimatedVisibility(visible = !fullLyrics) {
                Column(Modifier.fillMaxWidth()) {
                    val cu = track?.uploaderUrl
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = track?.title ?: "",
                                modifier = Modifier.sharedPart("np_title"),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = fg,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                text = track?.artist ?: "",
                                style = MaterialTheme.typography.bodyMedium,
                                color = muted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier
                                    .sharedPart("np_artist")
                                    .padding(top = 4.dp)
                                    .then(
                                        if (cu != null && track != null) {
                                            Modifier.clickable { onOpenChannel(cu, track.artist) }
                                        } else {
                                            Modifier
                                        },
                                    ),
                            )
                        }
                        if (track != null) {
                            Spacer(Modifier.width(12.dp))
                            HeartButton(
                                favorite = vm.isFavorite(track.url),
                                accent = accent,
                                fg = fg,
                                modifier = Modifier.flyInOut(),
                                onClick = { vm.toggleFavorite(track) },
                            )
                            Spacer(Modifier.width(8.dp))
                            MoreButton(
                                track = track,
                                fg = fg,
                                onOpenArtist = if (cu != null) {
                                    { onOpenChannel(cu, track.artist) }
                                } else {
                                    null
                                },
                                modifier = Modifier.flyInOut(),
                            )
                        }
                    }

                    SeekSection(
                        player = player,
                        fg = fg,
                        muted = muted,
                        modifier = Modifier.flyInOut(),
                    )

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        FxIconButton(
                            icon = R.drawable.np_shuffle,
                            desc = "Acak",
                            tint = if (player.shuffle) accent else muted,
                            iconSize = 26.dp,
                            fx = Fx.WIGGLE,
                            modifier = Modifier.flyInOut(),
                            onClick = { player.toggleShuffle() },
                        )
                        FxIconButton(
                            icon = R.drawable.np_prev,
                            desc = "Sebelumnya",
                            tint = fg,
                            iconSize = 34.dp,
                            fx = Fx.SHOOT_LEFT,
                            modifier = Modifier.flyInOut(),
                            onClick = { player.previous() },
                        )
                        PlayPauseButton(
                            player = player,
                            tint = fg,
                            iconSize = 58.dp,
                            modifier = Modifier.sharedPart("np_play"),
                        )
                        FxIconButton(
                            icon = R.drawable.np_next,
                            desc = "Berikutnya",
                            tint = fg,
                            iconSize = 34.dp,
                            fx = Fx.SHOOT_RIGHT,
                            modifier = Modifier.sharedPart("np_next"),
                            onClick = { player.next() },
                        )
                        FxIconButton(
                            icon = if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                                R.drawable.np_repeat_one
                            } else {
                                R.drawable.np_repeat
                            },
                            desc = "Ulangi",
                            tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) accent else muted,
                            iconSize = 26.dp,
                            fx = Fx.SPIN,
                            modifier = Modifier.flyInOut(),
                            onClick = { player.cycleRepeat() },
                        )
                    }

                    // Bilah polos gaya Auralys (tanpa kaca), hanya Antrean dan Lirik. Ada efek membal saat ditekan/pindah.
                    val toggleTab: (Int) -> Unit = { i ->
                        val target = if (i == 0) Pane.QUEUE else Pane.LYRICS
                        navIndex = i
                        pane = if (pane == target) Pane.COVER else target
                    }
                    FlatBounceBar(
                        containerColor = if (lightBg) Color(0xFFE9E9E9) else Color(0xFF2A2A2A),
                        indicatorColor = if (lightBg) Color.White else Color(0xFF454545),
                        iconColor = fg.copy(alpha = 0.75f),
                        selectedIconColor = fg,
                        icons = listOf(R.drawable.np_queue, R.drawable.np_lyrics),
                        descriptions = listOf("Antrean", "Lirik"),
                        selectedIndex = navIndex,
                        indicatorVisible = pane != Pane.COVER,
                        onClick = toggleTab,
                        modifier = Modifier.flyInOut(),
                    )
                }
            }

            // ---- Mode lirik penuh: hanya judul, durasi, putar, dan berikutnya ----
            AnimatedVisibility(visible = fullLyrics) {
                FullLyricsControls(
                    player = player,
                    title = track?.title ?: "",
                    fg = fg,
                    muted = muted,
                    accent = accent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 24.dp, vertical = 12.dp),
                )
            }
        }
    }
}

/** Seek bar tipis + waktu berjalan dan sisa waktu. Posisi dibaca di sini saja, bukan di layar induk. */
@Composable
private fun SeekSection(
    player: PlayerConnection,
    fg: Color,
    muted: Color,
    modifier: Modifier = Modifier,
) {
    // < 0 = tidak sedang digeser
    var dragFrac by remember { mutableFloatStateOf(-1f) }
    val fraction: () -> Float = {
        if (dragFrac >= 0f) {
            dragFrac
        } else if (player.durationMs > 0L) {
            (player.positionMs.toFloat() / player.durationMs.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
    }
    // Hanya berubah tiap detik, jadi teks tidak digambar ulang tiap tick posisi.
    val elapsedSec by remember {
        derivedStateOf {
            if (dragFrac >= 0f) (dragFrac * player.durationMs.toFloat() / 1000f).toLong() else player.positionMs / 1000L
        }
    }
    val totalSec = player.durationMs / 1000L
    Column(modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
        ThinSeekBar(
            fraction = fraction,
            active = fg,
            track = fg.copy(alpha = 0.22f),
            onDrag = { dragFrac = it },
            onCommit = {
                player.seekTo((it * player.durationMs.toFloat()).toLong())
                dragFrac = -1f
            },
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            Text(text = clock(elapsedSec), style = MaterialTheme.typography.bodySmall, color = muted)
            Text(
                text = if (player.durationMs > 0L) "-" + clock((totalSec - elapsedSec).coerceAtLeast(0L)) else "--:--",
                style = MaterialTheme.typography.bodySmall,
                color = muted,
            )
        }
    }
}

/**
 * Seek bar tipis gaya Auralys: garis 4dp yang menebal membal saat disentuh dan memunculkan titik geser.
 * [fraction] dibaca hanya saat menggambar, jadi pergerakan posisi tidak memicu komposisi ulang.
 */
@Composable
private fun ThinSeekBar(
    fraction: () -> Float,
    active: Color,
    track: Color,
    onDrag: (Float) -> Unit,
    onCommit: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    val grow = remember { Animatable(0f) }
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(32.dp)
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    scope.launch { grow.animateTo(1f, spring(dampingRatio = 0.45f, stiffness = 600f)) }
                    var v = (down.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                    onDrag(v)
                    while (true) {
                        val event = awaitPointerEvent()
                        val change = event.changes.firstOrNull { it.id == down.id } ?: break
                        v = (change.position.x / size.width.toFloat()).coerceIn(0f, 1f)
                        if (!change.pressed) {
                            onCommit(v)
                            break
                        }
                        change.consume()
                        onDrag(v)
                    }
                    scope.launch { grow.animateTo(0f, spring(dampingRatio = 0.30f, stiffness = 380f)) }
                }
            }
            .drawBehind {
                val g = grow.value
                val h = 4.dp.toPx() + 5.dp.toPx() * g
                val top = (size.height - h) / 2f
                val r = CornerRadius(h / 2f, h / 2f)
                drawRoundRect(track, topLeft = Offset(0f, top), size = Size(size.width, h), cornerRadius = r)
                val w = (size.width * fraction()).coerceIn(0f, size.width)
                if (w > 0f) {
                    drawRoundRect(active, topLeft = Offset(0f, top), size = Size(maxOf(w, h), h), cornerRadius = r)
                }
                if (g > 0.02f) {
                    drawCircle(active, radius = 7.dp.toPx() * g, center = Offset(w, size.height / 2f))
                }
            },
    )
}

/** Tombol ikon polos dengan efek jeli saat ditekan dan animasi tambahan [fx] saat diketuk. */
@Composable
private fun FxIconButton(
    icon: Int,
    desc: String,
    tint: Color,
    iconSize: Dp,
    fx: Fx,
    modifier: Modifier = Modifier,
    touch: Dp = 56.dp,
    onClick: () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val scope = rememberCoroutineScope()
    val job = remember { arrayOfNulls<Job>(1) }
    val tx = remember { Animatable(0f) }
    val rot = remember { Animatable(0f) }
    val sc = remember { Animatable(1f) }
    val al = remember { Animatable(1f) }
    val shootPx = with(LocalDensity.current) { 40.dp.toPx() }

    val fire: () -> Unit = {
        job[0]?.cancel()
        job[0] = scope.launch {
            when (fx) {
                Fx.SHOOT_LEFT, Fx.SHOOT_RIGHT -> {
                    // Ditembak keluar ke samping, lalu masuk lagi dari sisi seberang dan membal sampai diam.
                    val dir = if (fx == Fx.SHOOT_RIGHT) 1f else -1f
                    coroutineScope {
                        launch { tx.animateTo(dir * shootPx, tween(110, easing = FastOutLinearInEasing)) }
                        launch { al.animateTo(0f, tween(110)) }
                    }
                    tx.snapTo(-dir * shootPx)
                    coroutineScope {
                        launch { tx.animateTo(0f, spring(dampingRatio = 0.42f, stiffness = 380f)) }
                        launch { al.animateTo(1f, tween(140)) }
                    }
                }

                Fx.SPIN -> {
                    rot.snapTo(0f)
                    coroutineScope {
                        launch { rot.animateTo(360f, tween(520, easing = FastOutSlowInEasing)) }
                        launch {
                            sc.animateTo(0.8f, tween(120))
                            sc.animateTo(1f, spring(dampingRatio = 0.3f, stiffness = 400f))
                        }
                    }
                    rot.snapTo(0f)
                }

                Fx.WIGGLE -> {
                    coroutineScope {
                        launch { rot.animateTo(-20f, tween(80)) }
                        launch { sc.animateTo(0.82f, tween(80)) }
                    }
                    coroutineScope {
                        launch { rot.animateTo(0f, spring(dampingRatio = 0.16f, stiffness = 300f)) }
                        launch { sc.animateTo(1f, spring(dampingRatio = 0.3f, stiffness = 400f)) }
                    }
                }

                Fx.POP -> {
                    sc.snapTo(0.6f)
                    sc.animateTo(1f, spring(dampingRatio = 0.28f, stiffness = 380f))
                }
            }
        }
    }

    Box(
        modifier = modifier
            .size(touch)
            .jelly(src)
            .clickable(interactionSource = src, indication = null, role = Role.Button) {
                fire()
                onClick()
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = desc,
            tint = tint,
            modifier = Modifier
                .size(iconSize)
                .graphicsLayer {
                    translationX = tx.value
                    rotationZ = rot.value
                    scaleX = sc.value
                    scaleY = sc.value
                    alpha = al.value
                },
        )
    }
}

/** Putar/jeda: ikon polos besar tanpa lingkaran (gaya Auralys). Ikon melonjak membal setiap berganti. */
@Composable
private fun PlayPauseButton(
    player: PlayerConnection,
    tint: Color,
    iconSize: Dp,
    modifier: Modifier = Modifier,
) {
    val src = remember { MutableInteractionSource() }
    val pop = remember { Animatable(1f) }
    LaunchedEffect(player.isPlaying) {
        pop.snapTo(0.55f)
        pop.animateTo(1f, spring(dampingRatio = 0.28f, stiffness = 380f))
    }
    Box(
        modifier = modifier
            .size(88.dp)
            .jelly(src, squash = 0.9f)
            .clickable(interactionSource = src, indication = null, role = Role.Button) { player.togglePlay() },
        contentAlignment = Alignment.Center,
    ) {
        if (player.buffering && !player.isPlaying) {
            PlayLoader(diameter = iconSize * 0.85f)
        } else {
            Icon(
                painter = painterResource(if (player.isPlaying) R.drawable.np_pause else R.drawable.np_play),
                contentDescription = "Putar atau jeda",
                tint = tint,
                modifier = Modifier
                    .size(iconSize)
                    .graphicsLayer {
                        scaleX = pop.value
                        scaleY = pop.value
                    },
            )
        }
    }
}

/**
 * Tombol suka dalam lingkaran kaca di samping judul (gaya Auralys). Saat disukai hati melonjak membal
 * dan memercikkan titik-titik kecil ke sekelilingnya.
 */
@Composable
private fun HeartButton(
    favorite: Boolean,
    accent: Color,
    fg: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pop = remember { Animatable(1f) }
    val burst = remember { Animatable(0f) }
    var first by remember { mutableStateOf(true) }
    LaunchedEffect(favorite) {
        if (first) {
            first = false
        } else {
            if (favorite) {
                launch {
                    burst.snapTo(0f)
                    burst.animateTo(1f, tween(520, easing = FastOutSlowInEasing))
                }
            }
            pop.snapTo(0.55f)
            pop.animateTo(1f, spring(dampingRatio = 0.25f, stiffness = 380f))
        }
    }
    Box(
        modifier = modifier
            .size(52.dp)
            .jelly(src)
            .drawBehind {
                val b = burst.value
                if (b > 0f && b < 1f) {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val r = 24.dp.toPx() + 14.dp.toPx() * b
                    for (i in 0 until 8) {
                        val a = (i * 45f + 22f) * (Math.PI.toFloat() / 180f)
                        drawCircle(
                            color = accent.copy(alpha = 1f - b),
                            radius = 2.6.dp.toPx() * (1f - b * 0.6f),
                            center = Offset(c.x + cos(a) * r, c.y + sin(a) * r),
                        )
                    }
                }
            }
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (fg.luminance() < 0.5f) 0.38f else 0.12f))
            .border(1.dp, Color.White.copy(alpha = if (fg.luminance() < 0.5f) 0.55f else 0.16f), CircleShape)
            .clickable(interactionSource = src, indication = null, role = Role.Button) { onClick() },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(if (favorite) R.drawable.np_heart_fill else R.drawable.np_heart),
            contentDescription = "Favorit",
            tint = if (favorite) accent else fg,
            modifier = Modifier
                .size(26.dp)
                .graphicsLayer {
                    scaleX = pop.value
                    scaleY = pop.value
                },
        )
    }
}

/** Tombol menu (tiga titik) di samping tombol suka, gaya Auralys. */
@Composable
private fun MoreButton(
    track: Track,
    fg: Color,
    onOpenArtist: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val src = remember { MutableInteractionSource() }
    var menu by remember { mutableStateOf(false) }
    val download = rememberDownloader()
    Box(modifier) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .jelly(src)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = if (fg.luminance() < 0.5f) 0.38f else 0.12f))
                .border(1.dp, Color.White.copy(alpha = if (fg.luminance() < 0.5f) 0.55f else 0.16f), CircleShape)
                .clickable(interactionSource = src, indication = null, role = Role.Button) { menu = true },
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                imageVector = Icons.Filled.MoreVert,
                contentDescription = "Menu",
                tint = fg,
                modifier = Modifier.size(24.dp),
            )
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(
                text = { Text(text = "Unduh audio") },
                onClick = {
                    menu = false
                    download(track, false)
                },
            )
            if (onOpenArtist != null) {
                DropdownMenuItem(
                    text = { Text(text = "Buka halaman artis") },
                    onClick = {
                        menu = false
                        onOpenArtist()
                    },
                )
            }
        }
    }
}

/** Kontrol mode lirik penuh: bilah progres, judul, waktu, putar, dan berikutnya. */
@Composable
private fun FullLyricsControls(
    player: PlayerConnection,
    title: String,
    fg: Color,
    muted: Color,
    accent: Color,
    modifier: Modifier = Modifier,
) {
    val elapsedSec by remember { derivedStateOf { player.positionMs / 1000L } }
    val durText = if (player.durationMs > 0L) clock(player.durationMs / 1000L) else "--:--"
    Column(modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(50))
                .background(fg.copy(alpha = 0.2f))
                .drawBehind {
                    val f = if (player.durationMs > 0L) {
                        (player.positionMs.toFloat() / player.durationMs.toFloat()).coerceIn(0f, 1f)
                    } else {
                        0f
                    }
                    drawRect(accent, size = Size(size.width * f, size.height))
                },
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = fg,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = clock(elapsedSec) + " / " + durText,
                    style = MaterialTheme.typography.bodySmall,
                    color = muted,
                )
            }
            PlayPauseButton(player = player, tint = fg, iconSize = 40.dp)
            FxIconButton(
                icon = R.drawable.np_next,
                desc = "Berikutnya",
                tint = fg,
                iconSize = 30.dp,
                fx = Fx.SHOOT_RIGHT,
                onClick = { player.next() },
            )
        }
    }
}

/** Daftar antrean di area tengah; lagu yang sedang diputar disorot dengan warna aksen. */
@Composable
private fun QueuePane(player: PlayerConnection, fg: Color, muted: Color, accent: Color) {
    val lastIndex = (player.queue.size - 1).coerceAtLeast(0)
    val state = rememberLazyListState(
        initialFirstVisibleItemIndex = (player.index - 1).coerceIn(0, lastIndex),
    )
    Column(Modifier.fillMaxSize()) {
        Text(
            text = "Antrean (${player.queue.size})",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = fg,
            modifier = Modifier.padding(bottom = 8.dp),
        )
        if (player.queue.isEmpty()) {
            Text(text = "Antrean kosong", style = MaterialTheme.typography.bodyMedium, color = muted)
        }
        LazyColumn(state = state, modifier = Modifier.weight(1f).fillMaxWidth()) {
            itemsIndexed(player.queue, key = { i, t -> "${t.url}#$i" }) { i, t ->
                val isCurrent = i == player.index
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { player.jumpTo(i) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Thumb(t.thumb, 44.dp, pageUrl = t.url)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = t.title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isCurrent) accent else fg,
                            fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = t.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = muted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    IconButton(onClick = { player.removeAt(i) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Hapus dari antrean", tint = muted)
                    }
                }
            }
        }
    }
}
