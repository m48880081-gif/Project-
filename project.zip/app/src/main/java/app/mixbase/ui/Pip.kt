package app.mixbase.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import app.mixbase.player.VideoPlayer

/** Status mode Picture-in-Picture (jendela video mengambang milik sistem). */
object PipState {
    var inPip by mutableStateOf(false)
}

/** Saat PiP, tampilkan hanya video (hitam penuh) di atas seluruh isi app. */
@Composable
fun PipOverlay(video: VideoPlayer) {
    if (!PipState.inPip || !video.active || video.useEmbed) return
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        contentAlignment = Alignment.Center,
    ) {
        VideoSurface(video = video, boxAspect = maxWidth / maxHeight)
    }
}
