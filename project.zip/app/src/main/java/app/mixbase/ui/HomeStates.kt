package app.mixbase.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.mixbase.data.Batch
import app.mixbase.data.Channel
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.MusicApi
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// =====================================================================
// Home Musik
// =====================================================================

/** Chip suasana di atas Beranda Musik: label tampil → kata kunci pencarian. */
val MOODS: List<Pair<String, String>> = listOf(
    "Feel good" to "lagu senang ceria",
    "Relax" to "lagu santai",
    "Energize" to "lagu semangat",
    "Commute" to "lagu perjalanan",
    "Workout" to "lagu olahraga workout",
    "Party" to "lagu pesta dj remix",
    "Romance" to "lagu romantis",
    "Sad" to "lagu sedih galau",
    "Focus" to "musik fokus belajar",
    "Sleep" to "musik tidur",
)

/** Kotak "Suasana dan genre" di bawah Beranda (urut abjad; tersusun ke bawah per kolom). */
val GENRES: List<Pair<String, String>> = listOf(
    "Chill" to "lagu chill indonesia",
    "Commute" to "lagu perjalanan",
    "Energize" to "lagu semangat",
    "Feel good" to "lagu senang ceria",
    "Focus" to "musik fokus belajar",
    "Gaming" to "musik gaming",
    "Party" to "lagu pesta dj remix",
    "Romance" to "lagu romantis",
    "Sad" to "lagu sedih galau",
    "Sleep" to "musik tidur",
    "Workout" to "lagu olahraga workout",
)

/** Satu kotak "Andalanmu": lagu (diputar saat diketuk) atau album/playlist (dibuka saat diketuk). */
class DialItem(val track: Track?, val entry: Entry?) {
    val title: String
        get() = track?.title ?: entry?.title ?: ""
}

/**
 * Isi Home Musik. Sumber utamanya beranda YouTube Music (rak-rak seperti "Today's Indonesian Hits",
 * "New releases", dst., plus rak lanjutan saat digulir). Karena beranda tanpa akun tidak selalu
 * lengkap, "Quick picks" dan "Andalanmu" juga dilengkapi dari pencarian dan riwayat putar, dan bila
 * beranda YouTube Music gagal dimuat, rak cadangan dari pencarian ditampilkan.
 */
class MusicHomeState(private val scope: CoroutineScope) {

    /** "Quick picks": sampai [QUICK_COUNT] lagu. */
    var quick by mutableStateOf<List<Track>>(emptyList())
        private set

    /** "Andalanmu": sampai [DIAL_COUNT] kotak (lagu dulu, lalu album/playlist). */
    var dial by mutableStateOf<List<DialItem>>(emptyList())
        private set

    /** Rak-rak di bawah Quick picks, dari beranda YouTube Music. */
    var shelves by mutableStateOf<List<MusicApi.HomeShelf>>(emptyList())
        private set

    var loading by mutableStateOf(false)
        private set
    var loadingMore by mutableStateOf(false)
        private set

    /** true selama masih ada rak lanjutan yang bisa dimuat (kotak genre baru tampil setelah habis). */
    var hasMore by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var mood by mutableStateOf<String?>(null)
        private set
    var moodTracks by mutableStateOf<List<Track>>(emptyList())
        private set
    var moodLoading by mutableStateOf(false)
        private set

    private var loadedKey: String? = null
    private var epoch = 0
    private var loadJob: Job? = null
    private var moodJob: Job? = null

    // Bahan mentah; "quick", "dial", dan "shelves" disusun ulang dari sini tiap ada yang masuk.
    private var hist: List<Track> = emptyList()
    private var feed: List<MusicApi.HomeShelf> = emptyList()
    private var feedDone = false
    private var nextToken: String? = null
    private var contPages = 0
    private var personal: List<Track> = emptyList()
    private var popular: List<Track> = emptyList()
    private var viral: List<Track> = emptyList()
    private var albumList: List<Entry> = emptyList()

    private fun topArtist(history: List<Track>): String? {
        val counts = HashMap<String, Int>()
        for (t in history.take(40)) {
            val a = t.artist.replace(Regex("(?i)\\s*-\\s*topic$"), "").trim()
            if (a.isNotEmpty()) counts[a] = (counts[a] ?: 0) + 1
        }
        return counts.entries.maxByOrNull { it.value }?.key
    }

    /** Muat ulang beranda musik setelah bahasa konten diganti (bila sudah pernah dimuat). */
    fun relocalize(history: List<Track>) {
        if (loadedKey != null) load(history, force = true)
    }

    fun load(history: List<Track>, force: Boolean = false) {
        val top = topArtist(history)
        val key = top ?: "-"
        if (!force && loading) return
        if (!force && loadedKey == key && (quick.isNotEmpty() || shelves.isNotEmpty())) return

        loadJob?.cancel()
        epoch += 1
        val id = epoch
        loading = true
        loadingMore = false
        error = null
        hist = history.distinctBy { it.url }
        feed = emptyList()
        feedDone = false
        nextToken = null
        contPages = 0
        personal = emptyList()
        popular = emptyList()
        viral = emptyList()
        albumList = emptyList()
        rebuild()

        loadJob = scope.launch {
            try {
                coroutineScope {
                    launch {
                        val b = withContext(Dispatchers.IO) {
                            search(top ?: "lagu indonesia populer", Engine.FILTER_MUSIC)
                        }
                        if (id == epoch) {
                            personal = b.tracks.distinctBy { it.url }
                            rebuild()
                        }
                    }
                    launch {
                        val b = withContext(Dispatchers.IO) { search("lagu indonesia terbaru", Engine.FILTER_MUSIC) }
                        if (id == epoch) {
                            popular = b.tracks.distinctBy { it.url }
                            rebuild()
                        }
                    }
                    launch {
                        val b = withContext(Dispatchers.IO) { search("lagu viral tiktok indonesia", Engine.FILTER_MUSIC) }
                        if (id == epoch) {
                            viral = b.tracks.distinctBy { it.url }
                            rebuild()
                        }
                    }
                    launch {
                        val b = withContext(Dispatchers.IO) {
                            search(top ?: "album indonesia terbaik", Engine.FILTER_ALBUM)
                        }
                        if (id == epoch) {
                            albumList = b.entries.distinctBy { it.url }.take(12)
                            rebuild()
                        }
                    }
                    launch { loadFeed(id) }
                }
                if (id == epoch) {
                    loadedKey = key
                    if (quick.isEmpty() && shelves.isEmpty() && dial.isEmpty()) {
                        error = "Tidak ada konten. Periksa koneksi lalu coba lagi."
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == epoch) error = "Gagal memuat: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                if (id == epoch) loading = false
            }
        }
    }

    /** Halaman pertama beranda YouTube Music + beberapa halaman lanjutan supaya langsung penuh. */
    private suspend fun loadFeed(id: Int) {
        try {
            val first = withContext(Dispatchers.IO) { MusicApi.home() }
            if (id != epoch) return
            feed = first.shelves
            nextToken = first.next
            rebuild()
            var n = 0
            while (n < PRELOAD_PAGES && id == epoch) {
                val token = nextToken ?: break
                val page = withContext(Dispatchers.IO) { MusicApi.home(token) }
                if (id != epoch) return
                appendFeed(page)
                n += 1
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Beranda YouTube Music gagal: rak cadangan dari pencarian dipakai (lihat rebuild).
        } finally {
            if (id == epoch) {
                feedDone = true
                rebuild()
            }
        }
    }

    private fun appendFeed(page: MusicApi.HomePage) {
        val seen = HashSet<String>()
        for (s in feed) seen.add(s.title.lowercase())
        val add = page.shelves.filter { seen.add(it.title.lowercase()) }
        feed = feed + add
        nextToken = page.next
        contPages += 1
        rebuild()
    }

    /** Muat rak berikutnya (dipanggil saat daftar digulir hampir ke bawah). */
    fun loadMore() {
        val token = nextToken ?: return
        if (loading || loadingMore || mood != null || contPages >= MAX_CONT) return
        loadingMore = true
        val id = epoch
        scope.launch {
            try {
                val page = withContext(Dispatchers.IO) { MusicApi.home(token) }
                if (id == epoch) appendFeed(page)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == epoch) {
                    nextToken = null
                    rebuild()
                }
            } finally {
                if (id == epoch) loadingMore = false
            }
        }
    }

    /** Semua lagu yang sedang ada di beranda (untuk tombol acak). */
    fun allSongs(): List<Track> {
        val all = ArrayList<Track>()
        all.addAll(quick)
        for (d in dial) {
            val t = d.track
            if (t != null) all.add(t)
        }
        for (s in shelves) all.addAll(s.tracks)
        return all.distinctBy { it.url }
    }

    private fun rebuild() {
        val quickShelf = feed.firstOrNull { it.title.equals("Quick picks", ignoreCase = true) }
        val fromFeed = quickShelf?.tracks ?: emptyList()
        val pool = interleave(listOf(fromFeed, personal, popular, viral))
        val picks = pool.take(QUICK_COUNT)
        quick = picks

        // Andalanmu: lagu terakhir kamu + Quick picks (sampai 18), lalu album/playlist (sampai 9).
        val songs = (hist.take(6) + picks).distinctBy { it.url }.take(DIAL_COUNT * 2 / 3)
        val collections = LinkedHashMap<String, Entry>()
        for (s in feed) {
            for (e in s.entries) {
                if (e.kind != Entry.ARTIST) collections.putIfAbsent(e.url, e)
            }
        }
        for (e in albumList) collections.putIfAbsent(e.url, e)
        val items = ArrayList<DialItem>()
        for (t in songs) items.add(DialItem(t, null))
        for (e in collections.values) {
            if (items.size >= DIAL_COUNT) break
            items.add(DialItem(null, e))
        }
        if (items.size < DIAL_COUNT) {
            val used = HashSet<String>()
            for (d in items) {
                val t = d.track
                if (t != null) used.add(t.url)
            }
            for (t in pool) {
                if (items.size >= DIAL_COUNT) break
                if (t.url !in used) items.add(DialItem(t, null))
            }
        }
        dial = items

        val rest = feed.filter { !it.title.equals("Quick picks", ignoreCase = true) }
        shelves = if (rest.isNotEmpty() || !feedDone) rest else fallbackShelves()
        hasMore = nextToken != null && contPages < MAX_CONT
    }

    /** Rak cadangan (dari pencarian) bila beranda YouTube Music tidak bisa dimuat. */
    private fun fallbackShelves(): List<MusicApi.HomeShelf> {
        val out = ArrayList<MusicApi.HomeShelf>()
        if (popular.isNotEmpty()) {
            out.add(MusicApi.HomeShelf("Rilis terbaru", "", popular, emptyList(), true, null))
        }
        if (albumList.isNotEmpty()) {
            out.add(MusicApi.HomeShelf("Album untuk kamu", "", emptyList(), albumList, false, null))
        }
        if (viral.isNotEmpty()) {
            out.add(MusicApi.HomeShelf("Lagu viral", "", viral, emptyList(), true, null))
        }
        return out
    }

    private fun search(q: String, filter: String): Batch {
        return try {
            Engine.search(q, filter).first()
        } catch (e: Exception) {
            Batch(emptyList(), emptyList())
        }
    }

    /** Pilih/ganti chip suasana. Mengetuk chip yang sama lagi mematikannya. */
    fun pickMood(label: String) {
        moodJob?.cancel()
        if (mood == label) {
            mood = null
            moodTracks = emptyList()
            moodLoading = false
            return
        }
        val query = (MOODS + GENRES).firstOrNull { it.first == label }?.second ?: return
        mood = label
        moodTracks = emptyList()
        moodLoading = true
        moodJob = scope.launch {
            try {
                val pager = withContext(Dispatchers.IO) { Engine.search(query, Engine.FILTER_MUSIC) }
                var batch = withContext(Dispatchers.IO) { pager.first() }
                var all = batch.tracks.distinctBy { it.url }
                if (mood == label) {
                    moodTracks = all
                    moodLoading = false
                }
                // Ambil beberapa halaman lagi supaya daftar suasana panjang.
                var tries = 0
                while (tries < 3 && mood == label && pager.hasMore && all.size < 80) {
                    batch = withContext(Dispatchers.IO) { pager.more() }
                    all = (all + batch.tracks).distinctBy { it.url }
                    if (mood == label) moodTracks = all
                    tries += 1
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Biarkan yang sudah tampil.
            } finally {
                if (mood == label) moodLoading = false
            }
        }
    }

    companion object {
        const val QUICK_COUNT = 20
        const val DIAL_COUNT = 27

        /** Halaman lanjutan yang dimuat otomatis di awal (selebihnya saat digulir). */
        private const val PRELOAD_PAGES = 2

        /** Batas total halaman lanjutan. */
        private const val MAX_CONT = 6
    }
}

// =====================================================================
// Feed video (Home YouTube)
// =====================================================================

/** Sumber isi feed. Dipanggil dari coroutine; boleh memblokir (dijalankan di IO). */
interface FeedSource {
    suspend fun first(): List<Track>

    suspend fun more(): List<Track>

    val hasMore: Boolean
}

/** Beberapa pencarian video yang hasilnya diselang-seling supaya feed bervariasi. */
class SearchFeedSource(
    private val queries: List<String>,
    private val onlyLive: Boolean,
) : FeedSource {

    private val sessions = ArrayList<Engine.SearchSession>()

    override val hasMore: Boolean
        get() = sessions.any { it.hasMore }

    override suspend fun first(): List<Track> {
        val results = coroutineScope {
            queries.map { q ->
                async(Dispatchers.IO) {
                    try {
                        val s = Engine.newSearch(q, Engine.FILTER_VIDEO, includeLive = onlyLive)
                        val b = s.first()
                        Pair<Engine.SearchSession?, List<Track>>(s, b.tracks)
                    } catch (e: Exception) {
                        Pair<Engine.SearchSession?, List<Track>>(null, emptyList())
                    }
                }
            }.awaitAll()
        }
        val lists = ArrayList<List<Track>>()
        for (r in results) {
            val s = r.first
            if (s != null) sessions.add(s)
            lists.add(filterLive(r.second))
        }
        return interleave(lists)
    }

    override suspend fun more(): List<Track> {
        val active = sessions.filter { it.hasMore }
        if (active.isEmpty()) return emptyList()
        val results = coroutineScope {
            active.map { s ->
                async(Dispatchers.IO) {
                    try {
                        s.more().tracks
                    } catch (e: Exception) {
                        emptyList<Track>()
                    }
                }
            }.awaitAll()
        }
        return interleave(results.map { filterLive(it) })
    }

    private fun filterLive(list: List<Track>): List<Track> =
        if (onlyLive) list.filter { it.live } else list.filter { !it.live }
}

/** Kata kunci awal feed Shorts; tiap kali dimuat, empat di antaranya dipilih acak supaya bervariasi. */
val SHORTS_SEEDS = listOf(
    "#shorts",
    "shorts viral indonesia",
    "shorts lucu",
    "shorts musik",
    "shorts gaming",
    "shorts kuliner",
    "shorts hewan lucu",
    "shorts bola",
    "shorts hiburan",
    "shorts tutorial",
)

/** Video pendek (Shorts): hasil pencarian yang disaring, hanya video berdurasi sampai 90 detik. */
class ShortsFeedSource(private val queries: List<String>) : FeedSource {

    private val sessions = ArrayList<Engine.SearchSession>()

    override val hasMore: Boolean
        get() = sessions.any { it.hasMore }

    override suspend fun first(): List<Track> {
        val results = coroutineScope {
            queries.map { q ->
                async(Dispatchers.IO) {
                    try {
                        val s = Engine.newSearch(q, Engine.FILTER_VIDEO)
                        val b = s.first()
                        Pair<Engine.SearchSession?, List<Track>>(s, b.tracks)
                    } catch (e: Exception) {
                        Pair<Engine.SearchSession?, List<Track>>(null, emptyList())
                    }
                }
            }.awaitAll()
        }
        val lists = ArrayList<List<Track>>()
        for (r in results) {
            val s = r.first
            if (s != null) sessions.add(s)
            lists.add(onlyShort(r.second))
        }
        var out = interleave(lists)
        // Banyak hasil pencarian bukan video pendek: ambil halaman berikutnya beberapa kali bila kurang.
        var tries = 0
        while (out.size < 8 && tries < 3 && hasMore) {
            out = (out + more()).distinctBy { it.url }
            tries += 1
        }
        return out
    }

    override suspend fun more(): List<Track> {
        val active = sessions.filter { it.hasMore }
        if (active.isEmpty()) return emptyList()
        val results = coroutineScope {
            active.map { s ->
                async(Dispatchers.IO) {
                    try {
                        s.more().tracks
                    } catch (e: Exception) {
                        emptyList<Track>()
                    }
                }
            }.awaitAll()
        }
        return interleave(results.map { onlyShort(it) })
    }

    private fun onlyShort(list: List<Track>): List<Track> =
        list.filter { !it.live && it.durationSec in 1L..90L }
}

/** Video terbaru dari channel yang dilanggani. */
class SubscriptionFeedSource(private val channels: List<Channel>) : FeedSource {

    override val hasMore: Boolean = false

    override suspend fun first(): List<Track> {
        val lists = coroutineScope {
            channels.take(12).map { c ->
                async(Dispatchers.IO) {
                    try {
                        Engine.latestVideos(c.url, 4).map {
                            if (it.avatar == null) it.copy(avatar = c.avatar) else it
                        }
                    } catch (e: Exception) {
                        emptyList<Track>()
                    }
                }
            }.awaitAll()
        }
        return interleave(lists)
    }

    override suspend fun more(): List<Track> = emptyList()
}

private fun interleave(lists: List<List<Track>>): List<Track> {
    val out = ArrayList<Track>()
    val seen = HashSet<String>()
    var i = 0
    while (true) {
        var any = false
        for (l in lists) {
            if (i < l.size) {
                any = true
                val t = l[i]
                if (seen.add(t.url)) out.add(t)
            }
        }
        if (!any) break
        i += 1
    }
    return out
}

/** State satu feed video: daftar, memuat pertama kali, dan muat berikutnya. */
class VideoFeed(
    private val scope: CoroutineScope,
    private val makeSource: () -> FeedSource,
) {
    val items = mutableStateListOf<Track>()

    var loading by mutableStateOf(false)
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var loaded by mutableStateOf(false)
        private set

    private var source: FeedSource? = null
    private var epoch = 0

    val canLoadMore: Boolean
        get() = source?.hasMore == true

    fun load(force: Boolean = false) {
        if (loading) return
        if (loaded && !force) return
        epoch += 1
        val id = epoch
        loading = true
        error = null
        scope.launch {
            try {
                val s = makeSource()
                val list = s.first()
                if (id == epoch) {
                    source = s
                    items.clear()
                    items.addAll(list)
                    loaded = true
                    if (list.isEmpty()) error = "Tidak ada video. Periksa koneksi lalu coba lagi."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == epoch) error = "Gagal memuat: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                if (id == epoch) loading = false
            }
        }
    }

    fun loadMore() {
        val s = source ?: return
        if (loading || loadingMore || !s.hasMore) return
        loadingMore = true
        val id = epoch
        scope.launch {
            try {
                val more = s.more()
                if (id == epoch) {
                    for (t in more) {
                        if (items.none { it.url == t.url }) items.add(t)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Biarkan daftar yang sudah ada.
            } finally {
                if (id == epoch) loadingMore = false
            }
        }
    }

    /** Muat ulang bila sudah pernah dimuat (mis. setelah bahasa konten diganti); bila belum, cukup kosongkan. */
    fun relocalize() {
        val was = loaded
        reset()
        if (was) load()
    }

    fun reset() {
        epoch += 1
        items.clear()
        loaded = false
        loading = false
        loadingMore = false
        error = null
        source = null
    }
}
