package app.mixbase.ui

import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.mixbase.data.Channel
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// =====================================================================
// Home Musik
// =====================================================================

/** Chip suasana di Home Musik: label tampil → kata kunci pencarian. */
val MOODS: List<Pair<String, String>> = listOf(
    "Senang" to "lagu senang ceria",
    "Bersantai" to "lagu santai",
    "Mengisi energi" to "lagu semangat",
    "Perjalanan" to "lagu perjalanan",
    "Fokus" to "musik fokus belajar",
    "Romantis" to "lagu romantis",
    "Galau" to "lagu galau",
    "Olahraga" to "lagu olahraga workout",
    "Tidur" to "musik tidur",
    "Pesta" to "lagu pesta dj remix",
    "Gaming" to "musik gaming semangat",
)

/** Bagian-bagian tambahan beranda musik: kunci → kata kunci pencarian lagu. */
class HomeSpec(val key: String, val query: String, val limit: Int = 18)

val HOME_SPECS: List<HomeSpec> = listOf(
    HomeSpec("hits", "hits indonesia terpopuler 2026"),
    HomeSpec("rain", "lagu galau hujan melankolis"),
    HomeSpec("cozy", "lagu santai akustik indie"),
    HomeSpec("trend", "lagu viral tiktok indonesia", 16),
    HomeSpec("world", "top global hits 2026"),
    HomeSpec("cover", "cover lagu remix indonesia", 16),
)

/**
 * Isi Home Musik. YouTube Music tidak punya "beranda" tanpa akun, jadi isinya disusun dari
 * pencarian, diarahkan oleh artis yang paling sering kamu putar (riwayat).
 */
class MusicHomeState(private val scope: CoroutineScope) {

    var quick by mutableStateOf<List<Track>>(emptyList())
        private set
    var fresh by mutableStateOf<List<Track>>(emptyList())
        private set
    var albums by mutableStateOf<List<Entry>>(emptyList())
        private set
    var artists by mutableStateOf<List<Entry>>(emptyList())
        private set

    /** Isi bagian tambahan (kunci dari [HOME_SPECS]); terisi satu per satu seiring pencarian selesai. */
    var extra by mutableStateOf<Map<String, List<Track>>>(emptyMap())
        private set
    var loading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var mood by mutableStateOf<String?>(null)
        private set
    var moodTracks by mutableStateOf<List<Track>>(emptyList())
        private set
    var moodLoading by mutableStateOf(false)
        private set

    private var loadedKey: String? = null

    private fun topArtist(history: List<Track>): String? {
        val counts = HashMap<String, Int>()
        for (t in history.take(40)) {
            val a = t.artist.replace(Regex("(?i)\\s*-\\s*topic$"), "").trim()
            if (a.isNotEmpty()) counts[a] = (counts[a] ?: 0) + 1
        }
        return counts.entries.maxByOrNull { it.value }?.key
    }

    /** Muat ulang beranda musik setelah bahasa konten diganti (bila sudah pernah dimuat). */
    fun relocalize(history: List<Track>) {
        if (loadedKey != null) load(history, force = true)
    }

    fun load(history: List<Track>, force: Boolean = false) {
        val top = topArtist(history)
        val key = top ?: "-"
        if (!force && loading) return
        if (!force && loadedKey == key && quick.isNotEmpty()) return
        loading = true
        error = null
        scope.launch {
            try {
                val result = coroutineScope {
                    val q = async(Dispatchers.IO) {
                        search(top ?: "lagu indonesia populer", Engine.FILTER_MUSIC)
                    }
                    val f = async(Dispatchers.IO) { search("lagu indonesia terbaru", Engine.FILTER_MUSIC) }
                    val al = async(Dispatchers.IO) {
                        search(top ?: "album indonesia terbaik", Engine.FILTER_ALBUM)
                    }
                    listOf(q, f, al).awaitAll()
                }
                quick = result[0].tracks.distinctBy { it.url }.take(16)
                fresh = result[1].tracks.distinctBy { it.url }.take(20)
                albums = result[2].entries.distinctBy { it.url }.take(12)
                loadedKey = key
                extra = emptyMap()
                val gate = Semaphore(4)
                for (spec in HOME_SPECS) {
                    scope.launch {
                        val tracks = try {
                            gate.withPermit {
                                withContext(Dispatchers.IO) { search(spec.query, Engine.FILTER_MUSIC).tracks }
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            emptyList()
                        }
                        val clean = tracks.distinctBy { it.url }.take(spec.limit)
                        if (clean.isNotEmpty()) extra = extra + (spec.key to clean)
                    }
                }
                if (quick.isEmpty() && albums.isEmpty() && fresh.isEmpty()) {
                    error = "Tidak ada konten. Periksa koneksi lalu tarik ulang."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Gagal memuat: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                loading = false
            }
        }
    }

    private fun search(q: String, filter: String): app.mixbase.data.Batch {
        return try {
            Engine.search(q, filter).first()
        } catch (e: Exception) {
            app.mixbase.data.Batch(emptyList(), emptyList())
        }
    }

    /** Pilih/ganti chip suasana. Mengetuk chip yang sama lagi mematikannya. */
    fun pickMood(label: String) {
        if (mood == label) {
            mood = null
            moodTracks = emptyList()
            return
        }
        val query = MOODS.firstOrNull { it.first == label }?.second ?: return
        mood = label
        moodTracks = emptyList()
        moodLoading = true
        scope.launch {
            try {
                val batch = withContext(Dispatchers.IO) { Engine.search(query, Engine.FILTER_MUSIC).first() }
                if (mood == label) moodTracks = batch.tracks
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (mood == label) moodTracks = emptyList()
            } finally {
                if (mood == label) moodLoading = false
            }
        }
    }
}

// =====================================================================
// Feed video (Home YouTube)
// =====================================================================

/** Sumber isi feed. Dipanggil dari coroutine; boleh memblokir (dijalankan di IO). */
interface FeedSource {
    suspend fun first(): List<Track>

    suspend fun more(): List<Track>

    val hasMore: Boolean
}

/** Beberapa pencarian video yang hasilnya diselang-seling supaya feed bervariasi. */
class SearchFeedSource(
    private val queries: List<String>,
    private val onlyLive: Boolean,
) : FeedSource {

    private val sessions = ArrayList<Engine.SearchSession>()

    override val hasMore: Boolean
        get() = sessions.any { it.hasMore }

    override suspend fun first(): List<Track> {
        val results = coroutineScope {
            queries.map { q ->
                async(Dispatchers.IO) {
                    try {
                        val s = Engine.newSearch(q, Engine.FILTER_VIDEO, includeLive = onlyLive)
                        val b = s.first()
                        Pair<Engine.SearchSession?, List<Track>>(s, b.tracks)
                    } catch (e: Exception) {
                        Pair<Engine.SearchSession?, List<Track>>(null, emptyList())
                    }
                }
            }.awaitAll()
        }
        val lists = ArrayList<List<Track>>()
        for (r in results) {
            val s = r.first
            if (s != null) sessions.add(s)
            lists.add(filterLive(r.second))
        }
        return interleave(lists)
    }

    override suspend fun more(): List<Track> {
        val active = sessions.filter { it.hasMore }
        if (active.isEmpty()) return emptyList()
        val results = coroutineScope {
            active.map { s ->
                async(Dispatchers.IO) {
                    try {
                        s.more().tracks
                    } catch (e: Exception) {
                        emptyList<Track>()
                    }
                }
            }.awaitAll()
        }
        return interleave(results.map { filterLive(it) })
    }

    private fun filterLive(list: List<Track>): List<Track> =
        if (onlyLive) list.filter { it.live } else list.filter { !it.live }
}

/** Kata kunci awal feed Shorts; tiap kali dimuat, empat di antaranya dipilih acak supaya bervariasi. */
val SHORTS_SEEDS = listOf(
    "#shorts",
    "shorts viral indonesia",
    "shorts lucu",
    "shorts musik",
    "shorts gaming",
    "shorts kuliner",
    "shorts hewan lucu",
    "shorts bola",
    "shorts hiburan",
    "shorts tutorial",
)

/** Video pendek (Shorts): hasil pencarian yang disaring, hanya video berdurasi sampai 90 detik. */
class ShortsFeedSource(private val queries: List<String>) : FeedSource {

    private val sessions = ArrayList<Engine.SearchSession>()

    override val hasMore: Boolean
        get() = sessions.any { it.hasMore }

    override suspend fun first(): List<Track> {
        val results = coroutineScope {
            queries.map { q ->
                async(Dispatchers.IO) {
                    try {
                        val s = Engine.newSearch(q, Engine.FILTER_VIDEO)
                        val b = s.first()
                        Pair<Engine.SearchSession?, List<Track>>(s, b.tracks)
                    } catch (e: Exception) {
                        Pair<Engine.SearchSession?, List<Track>>(null, emptyList())
                    }
                }
            }.awaitAll()
        }
        val lists = ArrayList<List<Track>>()
        for (r in results) {
            val s = r.first
            if (s != null) sessions.add(s)
            lists.add(onlyShort(r.second))
        }
        var out = interleave(lists)
        // Banyak hasil pencarian bukan video pendek: ambil halaman berikutnya beberapa kali bila kurang.
        var tries = 0
        while (out.size < 8 && tries < 3 && hasMore) {
            out = (out + more()).distinctBy { it.url }
            tries += 1
        }
        return out
    }

    override suspend fun more(): List<Track> {
        val active = sessions.filter { it.hasMore }
        if (active.isEmpty()) return emptyList()
        val results = coroutineScope {
            active.map { s ->
                async(Dispatchers.IO) {
                    try {
                        s.more().tracks
                    } catch (e: Exception) {
                        emptyList<Track>()
                    }
                }
            }.awaitAll()
        }
        return interleave(results.map { onlyShort(it) })
    }

    private fun onlyShort(list: List<Track>): List<Track> =
        list.filter { !it.live && it.durationSec in 1L..90L }
}

/** Video terbaru dari channel yang dilanggani. */
class SubscriptionFeedSource(private val channels: List<Channel>) : FeedSource {

    override val hasMore: Boolean = false

    override suspend fun first(): List<Track> {
        val lists = coroutineScope {
            channels.take(12).map { c ->
                async(Dispatchers.IO) {
                    try {
                        Engine.latestVideos(c.url, 4).map {
                            if (it.avatar == null) it.copy(avatar = c.avatar) else it
                        }
                    } catch (e: Exception) {
                        emptyList<Track>()
                    }
                }
            }.awaitAll()
        }
        return interleave(lists)
    }

    override suspend fun more(): List<Track> = emptyList()
}

private fun interleave(lists: List<List<Track>>): List<Track> {
    val out = ArrayList<Track>()
    val seen = HashSet<String>()
    var i = 0
    while (true) {
        var any = false
        for (l in lists) {
            if (i < l.size) {
                any = true
                val t = l[i]
                if (seen.add(t.url)) out.add(t)
            }
        }
        if (!any) break
        i += 1
    }
    return out
}

/** State satu feed video: daftar, memuat pertama kali, dan muat berikutnya. */
class VideoFeed(
    private val scope: CoroutineScope,
    private val makeSource: () -> FeedSource,
) {
    val items = mutableStateListOf<Track>()

    var loading by mutableStateOf(false)
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var loaded by mutableStateOf(false)
        private set

    private var source: FeedSource? = null
    private var epoch = 0

    val canLoadMore: Boolean
        get() = source?.hasMore == true

    fun load(force: Boolean = false) {
        if (loading) return
        if (loaded && !force) return
        epoch += 1
        val id = epoch
        loading = true
        error = null
        scope.launch {
            try {
                val s = makeSource()
                val list = s.first()
                if (id == epoch) {
                    source = s
                    items.clear()
                    items.addAll(list)
                    loaded = true
                    if (list.isEmpty()) error = "Tidak ada video. Periksa koneksi lalu coba lagi."
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == epoch) error = "Gagal memuat: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                if (id == epoch) loading = false
            }
        }
    }

    fun loadMore() {
        val s = source ?: return
        if (loading || loadingMore || !s.hasMore) return
        loadingMore = true
        val id = epoch
        scope.launch {
            try {
                val more = s.more()
                if (id == epoch) {
                    for (t in more) {
                        if (items.none { it.url == t.url }) items.add(t)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Biarkan daftar yang sudah ada.
            } finally {
                if (id == epoch) loadingMore = false
            }
        }
    }

    /** Muat ulang bila sudah pernah dimuat (mis. setelah bahasa konten diganti); bila belum, cukup kosongkan. */
    fun relocalize() {
        val was = loaded
        reset()
        if (was) load()
    }

    fun reset() {
        epoch += 1
        items.clear()
        loaded = false
        loading = false
        loadingMore = false
        error = null
        source = null
    }
}
