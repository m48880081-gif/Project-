package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

/**
 * Lembar bawah buatan sendiri (tanpa API eksperimental): tirai gelap memudar, lembar naik sambil
 * membesar dari bawah, bisa ditarik ke bawah untuk menutup, dan menyusut saat ditutup.
 * Tetap tersusun selama animasi keluar.
 *
 * [header] berada di area yang bisa diseret (bersama gagang). [content] mengisi sisanya.
 */
@Composable
fun SlideSheet(
    visible: Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    heightFraction: Float = 0.8f,
    header: @Composable ColumnScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    var mounted by remember { mutableStateOf(visible) }
    val show = remember { Animatable(0f) }
    val drag = remember { Animatable(0f) }
    var heightPx by remember { mutableFloatStateOf(0f) }
    val scope = rememberCoroutineScope()
    val dismiss by rememberUpdatedState(onDismiss)

    LaunchedEffect(visible) {
        if (visible) {
            mounted = true
            drag.snapTo(0f)
            show.animateTo(1f, spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = 380f))
        } else {
            show.animateTo(0f, tween(240, easing = FastOutSlowInEasing))
            mounted = false
        }
    }
    if (!mounted) return

    BackHandler(enabled = visible) { dismiss() }

    Box(modifier.fillMaxSize()) {
        // Tirai
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = show.value.coerceIn(0f, 1f) }
                .background(Color.Black.copy(alpha = 0.5f))
                .pointerInput(Unit) { detectTapGestures { dismiss() } },
        )
        // Lembar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(heightFraction)
                .onSizeChanged { heightPx = it.height.toFloat() }
                .graphicsLayer {
                    val v = show.value
                    translationY = (1f - v) * heightPx + drag.value
                    alpha = (v * 2.5f).coerceIn(0f, 1f)
                    val s = 0.95f + 0.05f * v.coerceIn(0f, 1f)
                    scaleX = s
                    scaleY = s
                    transformOrigin = TransformOrigin(0.5f, 1f)
                }
                .pointerInput(Unit) { detectTapGestures { } },
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
        ) {
            Column(Modifier.fillMaxSize()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .pointerInput(Unit) {
                            detectVerticalDragGestures(
                                onDragEnd = {
                                    scope.launch {
                                        if (drag.value > heightPx * 0.22f) {
                                            dismiss()
                                        } else {
                                            drag.animateTo(0f, spring(dampingRatio = 0.8f, stiffness = 500f))
                                        }
                                    }
                                },
                                onDragCancel = {
                                    scope.launch { drag.animateTo(0f, spring()) }
                                },
                                onVerticalDrag = { change, amount ->
                                    change.consume()
                                    scope.launch { drag.snapTo((drag.value + amount).coerceAtLeast(0f)) }
                                },
                            )
                        },
                ) {
                    Box(
                        Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(top = 10.dp, bottom = 10.dp)
                            .width(36.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)),
                    )
                    header()
                }
                content()
            }
        }
    }
}
