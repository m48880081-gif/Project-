package app.mixbase.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection

@Composable
fun LibraryScreen(vm: AppViewModel, player: PlayerConnection) {
    var tab by rememberSaveable { mutableStateOf(0) }
    val list: List<Track> = if (tab == 0) vm.favorites else vm.history

    Column(Modifier.fillMaxSize()) {
        Text(
            text = "Pustaka",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp),
        )

        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Favorit") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Riwayat") })
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Button(
                onClick = { player.playQueue(list.toList(), 0) },
                enabled = list.isNotEmpty(),
            ) {
                Icon(
                    painter = painterResource(R.drawable.ic_play),
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                )
                Spacer(Modifier.width(8.dp))
                Text("Putar semua")
            }
            if (tab == 1) {
                TextButton(
                    onClick = { vm.clearHistory() },
                    enabled = list.isNotEmpty(),
                ) {
                    Text("Hapus riwayat")
                }
            }
        }

        if (list.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.TopCenter,
            ) {
                Text(
                    text = if (tab == 0) {
                        "Belum ada favorit. Buka menu ⋮ pada lagu lalu pilih \"Tambah ke favorit\"."
                    } else {
                        "Belum ada riwayat. Lagu yang kamu putar akan muncul di sini."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                )
            }
        } else {
            LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(list, key = { i, t -> "${t.url}#$i" }) { i, t ->
                    TrackItem(vm, player, t) {
                        player.playQueue(list.toList(), i)
                    }
                }
            }
        }
    }
}
