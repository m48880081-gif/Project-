package app.mixbase.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Track
import app.mixbase.player.PlayerConnection

@Composable
fun LibraryScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
) {
    // 0 = Favorit, 1 = Riwayat musik, 2 = Video ditonton, 3 = Langganan
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val audioList: List<Track> = if (tab == 0) vm.favorites else vm.history

    Column(Modifier.fillMaxSize()) {
        Text(
            text = "Pustaka",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 8.dp),
        )

        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Favorit") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Riwayat") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Video") })
            Tab(selected = tab == 3, onClick = { tab = 3 }, text = { Text("Langganan") })
        }

        when (tab) {
            0, 1 -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Button(
                        onClick = { player.playQueue(audioList.toList(), 0) },
                        enabled = audioList.isNotEmpty(),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_play),
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                        )
                        Spacer(Modifier.width(8.dp))
                        Text("Putar semua")
                    }
                    if (tab == 1) {
                        TextButton(
                            onClick = { vm.clearHistory() },
                            enabled = audioList.isNotEmpty(),
                        ) {
                            Text("Hapus riwayat")
                        }
                    }
                }

                if (audioList.isEmpty()) {
                    EmptyHint(
                        if (tab == 0) {
                            "Belum ada favorit. Buka menu ⋮ pada lagu lalu pilih \"Tambah ke favorit\", atau tekan suka di video."
                        } else {
                            "Belum ada riwayat. Lagu yang kamu putar akan muncul di sini."
                        },
                    )
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        itemsIndexed(audioList, key = { i, t -> "${t.url}#$i" }) { i, t ->
                            TrackItem(vm, player, t) {
                                player.playQueue(audioList.toList(), i)
                            }
                        }
                    }
                }
            }

            2 -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(
                        onClick = { vm.clearVideoHistory() },
                        enabled = vm.videoHistory.isNotEmpty(),
                    ) {
                        Text("Hapus riwayat tontonan")
                    }
                }
                if (vm.videoHistory.isEmpty()) {
                    EmptyHint("Belum ada video ditonton. Video yang kamu buka akan muncul di sini.")
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        itemsIndexed(vm.videoHistory.toList(), key = { i, t -> "${t.url}#$i" }) { _, t ->
                            VideoCardFor(t, actions)
                        }
                    }
                }
            }

            else -> {
                if (vm.subscriptions.isEmpty()) {
                    EmptyHint("Belum ada langganan. Buka channel lalu tekan Langganan.")
                } else {
                    LazyColumn(Modifier.fillMaxSize()) {
                        itemsIndexed(vm.subscriptions.toList(), key = { _, c -> c.url }) { _, c ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { actions.channel(c.url, c.name) }
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Avatar(url = c.avatar, name = c.name, size = 48.dp)
                                Spacer(Modifier.width(14.dp))
                                Text(
                                    text = c.name,
                                    style = MaterialTheme.typography.bodyLarge,
                                    modifier = Modifier.weight(1f),
                                )
                                TextButton(onClick = { vm.toggleSubscribe(c) }) {
                                    Text("Berhenti")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyHint(text: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.TopCenter,
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
}
