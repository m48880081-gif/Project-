package app.mixbase.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Nomor tab di mode Video (bilah bawah ala YouTube). */
object VTab {
    const val HOME = 0
    const val SEARCH = 1
    const val SUBS = 2
    const val HISTORY = 3
    const val DOWNLOADS = 4
}

/** Nomor tab di mode Musik (bilah bawah ala YouTube Music). */
object MTab {
    const val HOME = 0
    const val SEARCH = 1
    const val DOWNLOADS = 2
    const val PLAYLIST = 3
}

/** Layar yang bisa ditumpuk di atas tab. */
sealed interface Screen {
    /** Halaman akun/channel/artis. [music] menentukan cara memutar isinya. */
    data class ChannelPage(val url: String, val name: String, val music: Boolean) : Screen

    /** Daftar penuh milik seorang artis: [kind] = Artist.ALBUMS / SINGLES / VIDEOS / PLAYLISTS. */
    data class Collection(
        val url: String,
        val name: String,
        val kind: Int,
    ) : Screen

    data class AlbumPage(
        val url: String,
        val title: String,
        val thumb: String?,
        val artist: String,
    ) : Screen
}

/** Status navigasi: tab aktif tiap mode, tumpukan layar, halaman setelan, dan layar pemutar. */
@Stable
class Nav {
    /** Tab aktif di mode Video (lihat [VTab]). */
    var vtab by mutableIntStateOf(VTab.HOME)

    /** Tab aktif di mode Musik (lihat [MTab]). */
    var mtab by mutableIntStateOf(MTab.HOME)

    val stack = mutableStateListOf<Screen>()
    var settings by mutableStateOf(false)
    var nowPlaying by mutableStateOf(false)
    var watch by mutableStateOf(false)

    val top: Screen?
        get() = stack.lastOrNull()

    fun push(s: Screen) {
        // Hindari menumpuk layar yang sama berturut-turut.
        if (stack.lastOrNull() == s) return
        stack.add(s)
    }

    /** true bila ada layar yang ditutup. */
    fun pop(): Boolean {
        if (stack.isEmpty()) return false
        stack.removeAt(stack.size - 1)
        return true
    }
}
