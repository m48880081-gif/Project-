package app.mixbase.ui

import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Layar yang bisa ditumpuk di atas tab. */
sealed interface Screen {
    /** Pencarian layar penuh. [music] true = pencarian lagu, false = pencarian video. */
    data class SearchPage(val music: Boolean) : Screen

    /** Halaman akun/channel/artis. [music] menentukan cara memutar isinya. */
    data class ChannelPage(val url: String, val name: String, val music: Boolean) : Screen

    /** Daftar penuh milik seorang artis: [kind] = Artist.ALBUMS / SINGLES / VIDEOS / PLAYLISTS. */
    data class Collection(
        val url: String,
        val name: String,
        val kind: Int,
    ) : Screen

    data class AlbumPage(
        val url: String,
        val title: String,
        val thumb: String?,
        val artist: String,
    ) : Screen
}

/** Status navigasi: tab aktif, tumpukan layar, dan layar pemutar. */
@Stable
class Nav {
    /** 0 = Musik, 1 = Video, 2 = Pustaka, 3 = Setelan */
    var tab by mutableIntStateOf(0)
    val stack = mutableStateListOf<Screen>()
    var nowPlaying by mutableStateOf(false)
    var watch by mutableStateOf(false)

    val top: Screen?
        get() = stack.lastOrNull()

    fun push(s: Screen) {
        // Hindari menumpuk layar yang sama berturut-turut.
        if (stack.lastOrNull() == s) return
        stack.add(s)
    }

    /** true bila ada layar yang ditutup. */
    fun pop(): Boolean {
        if (stack.isEmpty()) return false
        stack.removeAt(stack.size - 1)
        return true
    }
}
