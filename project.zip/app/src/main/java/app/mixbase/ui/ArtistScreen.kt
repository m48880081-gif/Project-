package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Artist
import app.mixbase.data.Channel
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.MusicApi
import app.mixbase.data.Track
import app.mixbase.data.compactCount
import app.mixbase.player.PlayerConnection
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.rememberCoroutineScope
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Isi halaman artis. Tiap bagian dimuat sendiri-sendiri, jadi halaman muncul bertahap dan satu
 * bagian yang gagal tidak merusak bagian lain.
 */
class ArtistState(
    private val scope: CoroutineScope,
    private val url: String,
) {
    var details by mutableStateOf<Engine.ChannelDetails?>(null)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    var songs by mutableStateOf<List<Track>>(emptyList())
        private set
    var songsLoading by mutableStateOf(true)
        private set
    var albums by mutableStateOf<List<Entry>>(emptyList())
        private set
    var singles by mutableStateOf<List<Entry>>(emptyList())
        private set
    var releasesLoading by mutableStateOf(true)
        private set
    var releasesError by mutableStateOf<String?>(null)
        private set
    var videos by mutableStateOf<List<Track>>(emptyList())
        private set
    var playlists by mutableStateOf<List<Entry>>(emptyList())
        private set
    var similar by mutableStateOf<List<Entry>>(emptyList())
        private set

    init {
        scope.launch {
            // Sumber utama: YouTube Music (foto, lagu teratas, semua album, video, artis serupa).
            val page = try {
                withContext(Dispatchers.IO) { MusicApi.artist(url) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            val usable = page != null && page.name.isNotBlank() &&
                (page.songs.isNotEmpty() || page.albums.isNotEmpty() || page.singles.isNotEmpty() || page.videos.isNotEmpty())
            if (page != null && usable) {
                useMusic(page)
                return@launch
            }
            // Cadangan: sistem lama (NewPipe).
            try {
                val d = withContext(Dispatchers.IO) { Engine.channel(url) }
                details = d
                loadSections(d)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "Gagal memuat artis: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    /** Isi halaman dari YouTube Music; daftar penuh (semua album, lagu tambahan) menyusul di latar. */
    private fun useMusic(p: MusicApi.ArtistPage) {
        val d = Engine.ChannelDetails(
            url = url,
            name = p.name,
            avatar = p.avatar,
            banner = p.banner,
            subscribers = p.subscribers,
            description = p.description,
            tabs = emptyList(),
        )
        details = d
        songs = p.songs
        albums = p.albums
        singles = p.singles
        videos = p.videos.take(12)
        playlists = p.playlists
        similar = p.similar
        songsLoading = false
        releasesLoading = false

        // Lagu teratas: tambahkan sisa daftar "lihat semua" setelah lima lagu teratas.
        scope.launch {
            try {
                val extra = withContext(Dispatchers.IO) { MusicApi.moreSongs(p) }
                if (extra.isNotEmpty()) {
                    val seen = HashSet<String>()
                    val merged = ArrayList<Track>()
                    for (t in p.songs + extra) {
                        if (seen.add(t.url)) merged.add(t)
                    }
                    songs = merged
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // biarkan lagu dari rak teratas
            }
        }
        // Semua album dan single & EP: rak di halaman artis hanya memuat sebagian.
        scope.launch {
            try {
                val full = withContext(Dispatchers.IO) {
                    val pg = MusicApi.artistPager(url, Artist.ALBUMS)
                    if (pg == null) emptyList<Entry>() else Artist.collectEntries(pg, 4)
                }
                if (full.isNotEmpty()) albums = full.distinctBy { it.url }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // biarkan album dari rak
            }
        }
        scope.launch {
            try {
                val full = withContext(Dispatchers.IO) {
                    val pg = MusicApi.artistPager(url, Artist.SINGLES)
                    if (pg == null) emptyList<Entry>() else Artist.collectEntries(pg, 4)
                }
                if (full.isNotEmpty()) singles = full.distinctBy { it.url }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // biarkan single dari rak
            }
        }
        if (p.similar.isEmpty()) {
            scope.launch {
                try {
                    similar = withContext(Dispatchers.IO) { Artist.similar(d) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    similar = emptyList()
                }
            }
        }
    }

    private fun loadSections(d: Engine.ChannelDetails) {
        scope.launch {
            try {
                // Lagu teratas = paling banyak diputar: cocokkan daftar lagu dengan jumlah penonton video musiknya.
                val pools = coroutineScope {
                    val a = async(Dispatchers.IO) { Artist.songPool(d) }
                    val b = async(Dispatchers.IO) {
                        try {
                            Artist.videoPool(d)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            emptyList<Track>()
                        }
                    }
                    Pair(a.await(), b.await())
                }
                songs = Artist.rank(pools.first, pools.second)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                songs = emptyList()
            } finally {
                songsLoading = false
            }
        }
        scope.launch {
            try {
                // Beberapa halaman, supaya semua album (dan Single & EP) ikut terkumpul.
                val all = withContext(Dispatchers.IO) { Artist.collectEntries(Artist.releases(d), 4) }
                val uniq = all.distinctBy { it.url }
                albums = uniq.filter { !Artist.isSingle(it) }
                singles = uniq.filter { Artist.isSingle(it) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                albums = emptyList()
                singles = emptyList()
                releasesError = e.message ?: e.javaClass.simpleName
            } finally {
                releasesLoading = false
            }
        }
        scope.launch {
            try {
                videos = withContext(Dispatchers.IO) {
                    Artist.pager(d, Artist.VIDEOS)?.first()?.tracks?.take(12) ?: emptyList()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                videos = emptyList()
            }
        }
        scope.launch {
            try {
                playlists = withContext(Dispatchers.IO) {
                    Artist.pager(d, Artist.PLAYLISTS)?.first()?.entries?.take(12) ?: emptyList()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                playlists = emptyList()
            }
        }
        scope.launch {
            try {
                similar = withContext(Dispatchers.IO) { Artist.similar(d) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                similar = emptyList()
            }
        }
    }
}

/** Kartu sampul persegi (album, single, playlist) dengan judul dan keterangan. */
@Composable
fun CoverCard(
    title: String,
    subtitle: String,
    thumb: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
        ) {
            HdImage(thumb, Modifier.fillMaxSize(), px = 600)
        }
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        if (subtitle.isNotBlank()) {
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** Subjudul kartu rilis: "Album • 12 lagu" / "Single • 2 lagu". */
fun releaseLabel(e: Entry, fallback: String): String {
    val label = e.type.ifBlank { fallback }
    val n = Artist.trackCount(e.sub)
    if (n > 0) return "$label • $n lagu"
    val year = Regex("\\b(19|20)\\d{2}\\b").find(e.sub)?.value
    return if (year != null) "$label • $year" else label
}

@Composable
private fun VideoTile(t: Track, width: Dp, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(width)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh),
        ) {
            if (t.thumb != null) {
                AsyncImage(
                    model = t.thumb,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            }
        }
        Text(
            text = t.title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 8.dp),
        )
        val sub = if (t.views >= 0L) "${compactCount(t.views)} x ditonton" else t.artist
        Text(
            text = sub,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/**
 * Halaman artis bergaya YouTube Music: foto besar, tombol langganan/radio/putar, lagu teratas,
 * album, single & EP, video, playlist, artis serupa, dan tentang.
 */
@Composable
fun ArtistScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    actions: VideoActions,
    page: Screen.ChannelPage,
    onBack: () -> Unit,
    onOpenEntry: (Entry) -> Unit,
    onOpenCollection: (kind: Int) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var attempt by remember { mutableIntStateOf(0) }
    val st = remember(page.url, attempt) { ArtistState(scope, page.url) }
    var showAllSongs by remember(page.url) { mutableStateOf(false) }
    var aboutOpen by remember(page.url) { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    val d = st.details
    val name = d?.name?.ifBlank { null } ?: page.name

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(Modifier.fillMaxSize()) {
            // ---- Foto besar + nama ----
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(330.dp)
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh),
                ) {
                    val hero = d?.avatar ?: d?.banner
                    if (hero != null) {
                        HdImage(hero, Modifier.fillMaxSize(), px = 1200)
                    }
                    // Gelap tipis di atas (supaya tombol kembali terbaca), pudar ke latar di bawah.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent),
                                ),
                            ),
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(170.dp)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, MaterialTheme.colorScheme.background),
                                ),
                            ),
                    )
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.padding(6.dp),
                    ) {
                        Icon(
                            painter = painterResource(R.drawable.ic_arrow_back),
                            contentDescription = "Kembali",
                            tint = Color.White,
                        )
                    }
                    Text(
                        text = name,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 16.dp, end = 16.dp, bottom = 4.dp),
                    )
                }
            }

            // ---- Info + tombol ----
            item {
                Column(Modifier.padding(horizontal = 16.dp)) {
                    if (d != null && d.subscribers >= 0L) {
                        Text(
                            text = compactCount(d.subscribers) + " pelanggan",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    if (d != null && d.description.isNotBlank()) {
                        Text(
                            text = d.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        val subscribed = vm.isSubscribed(page.url)
                        PillButton(
                            text = if (subscribed) {
                                "Berlangganan"
                            } else if (d != null && d.subscribers >= 0L) {
                                "Langganan  " + compactCount(d.subscribers)
                            } else {
                                "Langganan\u200B"
                            },
                            style = if (subscribed) PillStyle.TONAL else PillStyle.OUTLINED,
                            onClick = {
                                vm.toggleSubscribe(Channel(page.url, name, d?.avatar))
                            },
                        )
                        Spacer(Modifier.weight(1f))
                        // Radio: putar lagu artis dalam urutan acak
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                .clickable(enabled = st.songs.isNotEmpty()) {
                                    player.playQueue(st.songs.shuffled(), 0)
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_radio),
                                contentDescription = "Radio artis",
                                modifier = Modifier.size(24.dp),
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        // Putar semua lagu artis
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary)
                                .clickable(enabled = st.songs.isNotEmpty()) {
                                    player.playQueue(st.songs, 0)
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_play),
                                contentDescription = "Putar",
                                tint = MaterialTheme.colorScheme.onPrimary,
                                modifier = Modifier.size(30.dp),
                            )
                        }
                    }
                }
            }

            if (d == null && st.error == null) {
                item { LoaderBox(Modifier.fillMaxWidth().height(220.dp)) }
            }
            val err = st.error
            if (err != null) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            text = err,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        PillButton(
                            text = "Coba lagi",
                            style = PillStyle.FILLED,
                            onClick = { attempt += 1 },
                            modifier = Modifier.padding(top = 16.dp),
                        )
                    }
                }
            }

            // ---- Lagu teratas ----
            if (d != null) {
                if (st.songsLoading) {
                    item { LoaderRow() }
                } else if (st.songs.isNotEmpty()) {
                    item {
                        ShelfHeader(
                            title = "Lagu teratas",
                            trailing = {
                                PillButton(
                                    text = "Putar semua",
                                    style = PillStyle.OUTLINED,
                                    onClick = { player.playQueue(st.songs, 0) },
                                )
                            },
                        )
                    }
                    val shown = if (showAllSongs) st.songs else st.songs.take(5)
                    itemsIndexed(shown, key = { i, t -> "${t.url}#s$i" }) { i, t ->
                        TrackItem(vm, player, t) { player.playQueue(st.songs, i) }
                    }
                    if (st.songs.size > 5) {
                        item {
                            TextButton(
                                onClick = { showAllSongs = !showAllSongs },
                                modifier = Modifier.padding(horizontal = 8.dp),
                            ) {
                                Text(if (showAllSongs) "Tampilkan lebih sedikit" else "Tampilkan semua")
                            }
                        }
                    }
                }
            }

            // ---- Album ----
            if (st.albums.isNotEmpty()) {
                item {
                    ShelfHeader(title = "Album", onMore = { onOpenCollection(Artist.ALBUMS) })
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        itemsIndexed(st.albums, key = { _, e -> e.url }) { _, e ->
                            CoverCard(
                                title = e.title,
                                subtitle = releaseLabel(e, "Album"),
                                thumb = e.thumb,
                                onClick = { onOpenEntry(e) },
                                modifier = Modifier.width(150.dp),
                            )
                        }
                    }
                }
            }

            // ---- Single & EP ----
            if (st.singles.isNotEmpty()) {
                item {
                    ShelfHeader(title = "Single & EP", onMore = { onOpenCollection(Artist.SINGLES) })
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        itemsIndexed(st.singles, key = { _, e -> e.url }) { _, e ->
                            CoverCard(
                                title = e.title,
                                subtitle = releaseLabel(e, "Single"),
                                thumb = e.thumb,
                                onClick = { onOpenEntry(e) },
                                modifier = Modifier.width(150.dp),
                            )
                        }
                    }
                }
            }

            if (st.releasesLoading && d != null) {
                item { LoaderRow() }
            } else if (d != null && st.albums.isEmpty() && st.singles.isEmpty()) {
                item {
                    Text(
                        text = if (st.releasesError != null) {
                            "Album belum bisa dimuat (${st.releasesError}). Buka ulang halaman ini untuk mencoba lagi."
                        } else {
                            "Album untuk artis ini tidak ditemukan."
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    )
                }
            }

            // ---- Video ----
            if (st.videos.isNotEmpty()) {
                item {
                    ShelfHeader(title = "Video", onMore = { onOpenCollection(Artist.VIDEOS) })
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        itemsIndexed(st.videos, key = { i, t -> "${t.url}#v$i" }) { _, t ->
                            VideoTile(t, 240.dp) { actions.open(t) }
                        }
                    }
                }
            }

            // ---- Playlist dari artis ----
            if (st.playlists.isNotEmpty()) {
                item {
                    ShelfHeader(
                        title = "Playlist dari $name",
                        onMore = { onOpenCollection(Artist.PLAYLISTS) },
                    )
                }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        itemsIndexed(st.playlists, key = { _, e -> e.url }) { _, e ->
                            CoverCard(
                                title = e.title,
                                subtitle = releaseLabel(e, "Playlist"),
                                thumb = e.thumb,
                                onClick = { onOpenEntry(e) },
                                modifier = Modifier.width(150.dp),
                            )
                        }
                    }
                }
            }

            // ---- Penggemar mungkin juga suka ----
            if (st.similar.isNotEmpty()) {
                item { ShelfHeader(title = "Penggemar mungkin juga suka") }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        itemsIndexed(st.similar, key = { _, e -> e.url }) { _, e ->
                            Column(
                                modifier = Modifier
                                    .width(112.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onOpenEntry(e) },
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Avatar(url = e.thumb, name = e.title, size = 112.dp)
                                Text(
                                    text = e.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(top = 8.dp),
                                )
                                if (e.sub.isNotBlank()) {
                                    Text(
                                        text = e.sub,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ---- Tentang ----
            if (d != null && (d.description.isNotBlank() || d.subscribers >= 0L)) {
                item { ShelfHeader(title = "Tentang") }
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceContainer)
                            .clickable { aboutOpen = !aboutOpen }
                            .padding(16.dp),
                    ) {
                        if (d.subscribers >= 0L) {
                            Text(
                                text = compactCount(d.subscribers) + " pelanggan",
                                style = MaterialTheme.typography.titleMedium,
                            )
                        }
                        if (d.description.isNotBlank()) {
                            Text(
                                text = d.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = if (aboutOpen) Int.MAX_VALUE else 4,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                            Text(
                                text = if (aboutOpen) "Sembunyikan" else "Selengkapnya",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(top = 8.dp),
                            )
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(32.dp)) }
        }
    }
}
