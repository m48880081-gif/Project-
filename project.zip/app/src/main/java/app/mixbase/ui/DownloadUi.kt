package app.mixbase.ui

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import app.mixbase.ui.Text
import app.mixbase.data.I18n
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.Downloads
import app.mixbase.data.Track
import java.util.Locale

/** Fungsi pemicu unduhan: (lagu/video, true = video / false = audio). Menampilkan pesan singkat. */
@Composable
fun rememberDownloader(): (Track, Boolean) -> Unit {
    val context = LocalContext.current
    return remember(context) {
        val f: (Track, Boolean) -> Unit = { t, video ->
            val msg = Downloads.start(t, video)
            Toast.makeText(context, I18n.tr(msg), Toast.LENGTH_SHORT).show()
        }
        f
    }
}

/** Dialog pilihan: unduh sebagai video (MP4) atau audio saja. */
@Composable
fun DownloadChoiceDialog(
    track: Track,
    onDismiss: () -> Unit,
    onPick: (video: Boolean) -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Unduh") },
        text = {
            Column {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                ChoiceRow(
                    icon = R.drawable.ic_video,
                    title = "Video (MP4)",
                    subtitle = "Sesuai batas kualitas di Setelan, maksimal 1080p",
                    onClick = { onPick(true) },
                )
                ChoiceRow(
                    icon = R.drawable.ic_music_note,
                    title = "Audio saja",
                    subtitle = "M4A, kualitas tertinggi",
                    onClick = { onPick(false) },
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        },
    )
}

@Composable
private fun ChoiceRow(icon: Int, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClickable(onClick = onClick)
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            painter = painterResource(icon),
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp),
        )
        Spacer(Modifier.width(16.dp))
        Column {
            Text(text = title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

/** 1536 → "1,5 KB", 5_300_000 → "5,1 MB". */
fun formatSize(bytes: Long): String {
    if (bytes <= 0L) return ""
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format(Locale.forLanguageTag("id-ID"), "%.0f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024.0) return String.format(Locale.forLanguageTag("id-ID"), "%.1f MB", mb)
    return String.format(Locale.forLanguageTag("id-ID"), "%.2f GB", mb / 1024.0)
}
