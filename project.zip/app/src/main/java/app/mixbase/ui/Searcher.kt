package app.mixbase.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import app.mixbase.data.Engine
import app.mixbase.data.Entry
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Satu "mesin pencarian" lengkap dengan state-nya (kata kunci, filter, hasil, saran,
 * muat halaman berikutnya). App punya dua: satu untuk musik, satu untuk video.
 */
class Searcher(
    private val scope: CoroutineScope,
    startFilter: String,
) {
    var query by mutableStateOf("")
        private set
    var filter by mutableStateOf(startFilter)
        private set
    val tracks = mutableStateListOf<Track>()
    val entries = mutableStateListOf<Entry>()
    var loading by mutableStateOf(false)
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var suggestions by mutableStateOf<List<String>>(emptyList())
        private set
    var canLoadMore by mutableStateOf(false)
        private set
    var searched by mutableStateOf(false)
        private set

    private var session: Engine.Pager? = null
    private var searchJob: Job? = null
    private var suggestJob: Job? = null
    private var searchId = 0

    val resultCount: Int
        get() = tracks.size + entries.size

    fun onQueryChange(q: String) {
        query = q
        suggestJob?.cancel()
        val text = q.trim()
        if (text.length < 2) {
            suggestions = emptyList()
            return
        }
        suggestJob = scope.launch {
            delay(250)
            val list = withContext(Dispatchers.IO) {
                try {
                    Engine.suggestions(text)
                } catch (e: Exception) {
                    emptyList()
                }
            }
            suggestions = list
        }
    }

    fun updateFilter(f: String) {
        if (f == filter) return
        filter = f
        if (searched && query.isNotBlank()) search()
    }

    fun search(q: String = query) {
        val text = q.trim()
        if (text.isEmpty()) return

        query = text
        suggestions = emptyList()
        suggestJob?.cancel()
        searchJob?.cancel()

        searchId += 1
        val id = searchId
        val currentFilter = filter

        loading = true
        loadingMore = false
        error = null
        searched = true
        tracks.clear()
        entries.clear()
        canLoadMore = false
        session = null

        searchJob = scope.launch {
            try {
                val s = withContext(Dispatchers.IO) { Engine.search(text, currentFilter) }
                val batch = withContext(Dispatchers.IO) { s.first() }
                if (id == searchId) {
                    session = s
                    tracks.addAll(batch.tracks)
                    entries.addAll(batch.entries)
                    canLoadMore = s.hasMore
                    if (batch.tracks.isEmpty() && batch.entries.isEmpty()) {
                        error = "Tidak ada hasil untuk \"$text\""
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == searchId) error = "Gagal memuat: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                if (id == searchId) loading = false
            }
        }
    }

    fun loadMore() {
        val s = session ?: return
        if (loading || loadingMore || !canLoadMore) return
        loadingMore = true
        val id = searchId
        scope.launch {
            try {
                val more = withContext(Dispatchers.IO) { s.more() }
                if (id == searchId) {
                    for (t in more.tracks) {
                        if (tracks.none { it.url == t.url }) tracks.add(t)
                    }
                    for (e in more.entries) {
                        if (entries.none { it.url == e.url }) entries.add(e)
                    }
                    canLoadMore = s.hasMore
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == searchId) canLoadMore = false
            } finally {
                if (id == searchId) loadingMore = false
            }
        }
    }
}
