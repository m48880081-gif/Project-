package app.mixbase.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.mixbase.data.Channel
import app.mixbase.data.Engine
import app.mixbase.data.LyricsData
import app.mixbase.data.Lyrics
import app.mixbase.data.Store
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Satu ViewModel untuk seluruh app: pengaturan, pustaka, langganan, pencarian, Home, dan lirik. */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)

    // ---------------- Pengaturan ----------------

    var themeMode by mutableIntStateOf(store.themeMode)
        private set
    var dynamicColor by mutableStateOf(store.dynamicColor)
        private set
    var highQuality by mutableStateOf(store.highQuality)
        private set
    var maxHeight by mutableIntStateOf(store.maxHeight)
        private set
    var prefer60 by mutableStateOf(store.prefer60)
        private set

    fun updateThemeMode(v: Int) {
        themeMode = v
        store.themeMode = v
    }

    fun updateDynamicColor(v: Boolean) {
        dynamicColor = v
        store.dynamicColor = v
    }

    fun updateHighQuality(v: Boolean) {
        highQuality = v
        store.highQuality = v
    }

    fun updateMaxHeight(v: Int) {
        maxHeight = v
        store.maxHeight = v
    }

    fun updatePrefer60(v: Boolean) {
        prefer60 = v
        store.prefer60 = v
    }

    // ---------------- Pustaka ----------------

    val favorites = mutableStateListOf<Track>().apply { addAll(store.loadFavorites()) }
    val history = mutableStateListOf<Track>().apply { addAll(store.loadHistory()) }
    val videoHistory = mutableStateListOf<Track>().apply { addAll(store.loadVideoHistory()) }

    fun isFavorite(url: String): Boolean = favorites.any { it.url == url }

    fun toggleFavorite(t: Track) {
        val i = favorites.indexOfFirst { it.url == t.url }
        if (i >= 0) favorites.removeAt(i) else favorites.add(0, t)
        store.saveFavorites(favorites.toList())
    }

    fun addHistory(t: Track) {
        history.removeAll { it.url == t.url }
        history.add(0, t)
        while (history.size > 200) history.removeAt(history.size - 1)
        store.saveHistory(history.toList())
    }

    fun clearHistory() {
        history.clear()
        store.saveHistory(emptyList())
    }

    fun addVideoHistory(t: Track) {
        videoHistory.removeAll { it.url == t.url }
        videoHistory.add(0, t)
        while (videoHistory.size > 200) videoHistory.removeAt(videoHistory.size - 1)
        store.saveVideoHistory(videoHistory.toList())
    }

    fun clearVideoHistory() {
        videoHistory.clear()
        store.saveVideoHistory(emptyList())
    }

    // ---------------- Langganan (lokal di perangkat) ----------------

    val subscriptions = mutableStateListOf<Channel>().apply { addAll(store.loadSubscriptions()) }

    fun isSubscribed(url: String): Boolean = subscriptions.any { it.url == url }

    fun toggleSubscribe(c: Channel) {
        val i = subscriptions.indexOfFirst { it.url == c.url }
        if (i >= 0) subscriptions.removeAt(i) else subscriptions.add(0, c)
        store.saveSubscriptions(subscriptions.toList())
        subscriptionsFeed.reset()
    }

    // ---------------- Pencarian ----------------

    val musicSearch = Searcher(viewModelScope, Engine.FILTER_MUSIC)
    val videoSearch = Searcher(viewModelScope, Engine.FILTER_VIDEO)

    // ---------------- Home ----------------

    val musicHome = MusicHomeState(viewModelScope)

    private fun homeQueries(): List<String> {
        val personal = ArrayList<String>()
        for (c in subscriptions.take(2)) personal.add(c.name)
        for (t in videoHistory.map { it.artist }.filter { it.isNotBlank() }.distinct().take(2)) {
            personal.add(t)
        }
        val defaults = listOf(
            "trending indonesia",
            "berita terbaru hari ini",
            "gaming indonesia",
            "podcast indonesia",
            "film pendek",
            "resep masakan",
        )
        return (personal + defaults).distinct().take(4)
    }

    val homeFeed = VideoFeed(viewModelScope) { SearchFeedSource(homeQueries(), false) }

    val musicVideoFeed = VideoFeed(viewModelScope) {
        SearchFeedSource(
            listOf("lagu indonesia terbaru", "official music video", "hits terpopuler"),
            false,
        )
    }

    val liveFeed = VideoFeed(viewModelScope) {
        SearchFeedSource(listOf("live streaming", "siaran langsung", "live musik"), true)
    }

    val subscriptionsFeed = VideoFeed(viewModelScope) { SubscriptionFeedSource(subscriptions.toList()) }

    // ---------------- Lirik ----------------

    private val lyricsCache = HashMap<String, LyricsData?>()
    private var lyricsJob: Job? = null

    /** URL lagu yang lirik-nya sedang ditampilkan. */
    var lyricsFor by mutableStateOf<String?>(null)
        private set
    var lyrics by mutableStateOf<LyricsData?>(null)
        private set
    var lyricsLoading by mutableStateOf(false)
        private set

    fun loadLyrics(t: Track) {
        if (lyricsFor == t.url && (lyricsLoading || lyrics != null)) return
        lyricsJob?.cancel()
        lyricsFor = t.url
        lyrics = null

        if (lyricsCache.containsKey(t.url)) {
            lyrics = lyricsCache[t.url]
            lyricsLoading = false
            return
        }

        lyricsLoading = true
        lyricsJob = viewModelScope.launch {
            try {
                val found = withContext(Dispatchers.IO) {
                    try {
                        Lyrics.fetch(t.artist, t.title, t.durationSec)
                    } catch (e: Exception) {
                        null
                    }
                }
                // Hanya hasil yang ditemukan yang disimpan; kegagalan jaringan boleh dicoba lagi.
                if (found != null) lyricsCache[t.url] = found
                if (lyricsFor == t.url) lyrics = found
            } catch (e: CancellationException) {
                throw e
            } finally {
                if (lyricsFor == t.url) lyricsLoading = false
            }
        }
    }
}
