package app.mixbase.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.mixbase.data.Channel
import app.mixbase.data.I18n
import app.mixbase.data.SameLanguageException
import app.mixbase.data.Translate
import app.mixbase.data.UnknownLanguageException
import app.mixbase.data.Engine
import app.mixbase.data.LyricsData
import app.mixbase.data.Lyrics
import app.mixbase.data.Store
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Satu ViewModel untuk seluruh app: pengaturan, pustaka, langganan, pencarian, Home, dan lirik. */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)

    // ---------------- Link dari luar ----------------

    /** Link YouTube yang menunggu dibuka oleh AppRoot (dari Bagikan, ketuk link, atau tempel di Cari). */
    var pendingLink by mutableStateOf<String?>(null)
        private set

    fun openLink(text: String) {
        pendingLink = text
    }

    fun consumeLink() {
        pendingLink = null
    }

    // ---------------- Pengaturan ----------------

    /** 0 = Musik, 1 = Video. Menentukan menu bawah dan beranda yang tampil. */
    var mode by mutableIntStateOf(store.mode)
        private set
    var themeMode by mutableIntStateOf(store.themeMode)
        private set
    var highQuality by mutableStateOf(store.highQuality)
        private set
    var maxHeight by mutableIntStateOf(store.maxHeight)
        private set
    var prefer60 by mutableStateOf(store.prefer60)
        private set

    /** Bahasa konten (judul, deskripsi, dll), kode ISO seperti "id". */
    var contentLang by mutableStateOf(store.contentLang)
        private set

    /** true = utamakan suara dubbing bahasa konten bila video menyediakan. */
    var preferDub by mutableStateOf(store.audioPref == 1)
        private set

    /** true = nyalakan subtitle otomatis bila bahasa video berbeda dari bahasa konten. */
    var subtitleAuto by mutableStateOf(store.subtitleAuto)
        private set

    /** Terjemahkan judul video otomatis ke bahasa aplikasi. */
    var translateTitles by mutableStateOf(store.translateTitles)
        private set

    fun updateTranslateTitles(v: Boolean) {
        translateTitles = v
        store.translateTitles = v
        I18n.translateTitles = v
    }

    fun updateContentLang(code: String) {
        if (code == contentLang) return
        contentLang = code
        store.contentLang = code
        I18n.lang = code
        Engine.setContentLanguage(code)
        // Daftar yang sudah tampil dimuat ulang supaya judulnya ikut berganti.
        homeFeed.relocalize()
        musicVideoFeed.relocalize()
        liveFeed.relocalize()
        subscriptionsFeed.relocalize()
        shortsFeed.relocalize()
        musicHome.relocalize(history.toList())
    }

    fun updatePreferDub(v: Boolean) {
        preferDub = v
        store.audioPref = if (v) 1 else 0
    }

    fun updateSubtitleAuto(v: Boolean) {
        subtitleAuto = v
        store.subtitleAuto = v
    }

    fun updateMode(v: Int) {
        mode = v
        store.mode = v
    }

    fun updateThemeMode(v: Int) {
        themeMode = v
        store.themeMode = v
    }

    fun updateHighQuality(v: Boolean) {
        highQuality = v
        store.highQuality = v
    }

    fun updateMaxHeight(v: Int) {
        maxHeight = v
        store.maxHeight = v
    }

    fun updatePrefer60(v: Boolean) {
        prefer60 = v
        store.prefer60 = v
    }

    // ---------------- Pustaka ----------------

    val favorites = mutableStateListOf<Track>().apply { addAll(store.loadFavorites()) }
    val history = mutableStateListOf<Track>().apply { addAll(store.loadHistory()) }
    val videoHistory = mutableStateListOf<Track>().apply { addAll(store.loadVideoHistory()) }

    fun isFavorite(url: String): Boolean = favorites.any { it.url == url }

    fun toggleFavorite(t: Track) {
        val i = favorites.indexOfFirst { it.url == t.url }
        if (i >= 0) favorites.removeAt(i) else favorites.add(0, t)
        store.saveFavorites(favorites.toList())
    }

    fun addHistory(t: Track) {
        history.removeAll { it.url == t.url }
        history.add(0, t)
        while (history.size > 200) history.removeAt(history.size - 1)
        store.saveHistory(history.toList())
    }

    fun clearHistory() {
        history.clear()
        store.saveHistory(emptyList())
    }

    fun addVideoHistory(t: Track) {
        videoHistory.removeAll { it.url == t.url }
        videoHistory.add(0, t)
        while (videoHistory.size > 200) videoHistory.removeAt(videoHistory.size - 1)
        store.saveVideoHistory(videoHistory.toList())
    }

    fun clearVideoHistory() {
        videoHistory.clear()
        store.saveVideoHistory(emptyList())
    }

    // ---------------- Langganan (lokal di perangkat) ----------------

    val subscriptions = mutableStateListOf<Channel>().apply { addAll(store.loadSubscriptions()) }

    fun isSubscribed(url: String): Boolean = subscriptions.any { it.url == url }

    fun toggleSubscribe(c: Channel) {
        val i = subscriptions.indexOfFirst { it.url == c.url }
        if (i >= 0) subscriptions.removeAt(i) else subscriptions.add(0, c)
        store.saveSubscriptions(subscriptions.toList())
        subscriptionsFeed.reset()
    }

    // ---------------- Pencarian ----------------

    val musicSearch = Searcher(
        viewModelScope,
        Engine.FILTER_MUSIC,
        store.loadQueries("qm"),
    ) { list -> store.saveQueries("qm", list) }
    val videoSearch = Searcher(
        viewModelScope,
        Engine.FILTER_VIDEO,
        store.loadQueries("qv"),
    ) { list -> store.saveQueries("qv", list) }

    // ---------------- Home ----------------

    val musicHome = MusicHomeState(viewModelScope)

    private fun homeQueries(): List<String> {
        val personal = ArrayList<String>()
        for (c in subscriptions.take(2)) personal.add(c.name)
        for (t in videoHistory.map { it.artist }.filter { it.isNotBlank() }.distinct().take(2)) {
            personal.add(t)
        }
        val defaults = listOf(
            "trending indonesia",
            "berita terbaru hari ini",
            "gaming indonesia",
            "podcast indonesia",
            "film pendek",
            "resep masakan",
        )
        return (personal + defaults).distinct().take(4)
    }

    val homeFeed = VideoFeed(viewModelScope) { SearchFeedSource(homeQueries(), false) }

    val musicVideoFeed = VideoFeed(viewModelScope) {
        SearchFeedSource(
            listOf("lagu indonesia terbaru", "official music video", "hits terpopuler"),
            false,
        )
    }

    val liveFeed = VideoFeed(viewModelScope) {
        SearchFeedSource(listOf("live streaming", "siaran langsung", "live musik"), true)
    }

    val subscriptionsFeed = VideoFeed(viewModelScope) { SubscriptionFeedSource(subscriptions.toList()) }

    /** Feed Shorts (video pendek) dan halaman Shorts terakhir yang dilihat (supaya tidak kembali ke awal). */
    val shortsFeed = VideoFeed(viewModelScope) { ShortsFeedSource(SHORTS_SEEDS.shuffled().take(4)) }

    var shortsPage by mutableStateOf(0)

    // ---------------- Lirik ----------------

    private val lyricsCache = HashMap<String, LyricsData?>()
    private var lyricsJob: Job? = null

    /** URL lagu yang lirik-nya sedang ditampilkan. */
    var lyricsFor by mutableStateOf<String?>(null)
        private set
    var lyrics by mutableStateOf<LyricsData?>(null)
        private set
    var lyricsLoading by mutableStateOf(false)
        private set

    // ---- Terjemahan lirik (di perangkat) ----

    /** Bahasa terjemahan lirik terpilih; kosong = mati. Diingat untuk lagu berikutnya. */
    var lyricsTrLang by mutableStateOf(store.lyricsLang)
        private set

    /** Hasil terjemahan, sejajar dengan baris lirik ([lyricLines]); hanya berlaku untuk [lyricsTrFor]. */
    var lyricsTr by mutableStateOf<List<String>>(emptyList())
        private set
    var lyricsTrFor by mutableStateOf<String?>(null)
        private set
    var lyricsTrBusy by mutableStateOf(false)
        private set
    var lyricsTrNote by mutableStateOf<String?>(null)
        private set
    private var trJob: Job? = null

    /** Baris-baris lirik yang diterjemahkan: yang bertanda waktu bila ada, jika tidak per baris teks biasa. */
    fun lyricLines(l: LyricsData): List<String> =
        if (l.synced.isNotEmpty()) l.synced.map { it.text } else l.plain.lines()

    /** Pilih bahasa terjemahan lirik ([lang] kosong = matikan). */
    fun translateLyrics(lang: String) {
        lyricsTrLang = lang
        store.lyricsLang = lang
        trJob?.cancel()
        lyricsTr = emptyList()
        lyricsTrFor = null
        lyricsTrNote = null
        lyricsTrBusy = false
        val url = lyricsFor ?: return
        val l = lyrics ?: return
        if (lang.isEmpty() || l.instrumental) return
        val lines = lyricLines(l)
        lyricsTrBusy = true
        trJob = viewModelScope.launch {
            try {
                val out = Translate.lines(lines, lang)
                if (lyricsFor == url && lyricsTrLang == lang) {
                    lyricsTr = out
                    lyricsTrFor = url
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: SameLanguageException) {
                if (lyricsFor == url) lyricsTrNote = "Lirik ini sudah dalam bahasa ${e.language}."
            } catch (e: UnknownLanguageException) {
                if (lyricsFor == url) lyricsTrNote = "Bahasa lirik tidak dikenali."
            } catch (e: Exception) {
                if (lyricsFor == url) {
                    lyricsTrNote = "Terjemahan gagal: ${e.message ?: "periksa internet untuk mengunduh model bahasa"}"
                }
            } finally {
                if (lyricsFor == url) lyricsTrBusy = false
            }
        }
    }

    /** Dipanggil saat layar lirik dibuka: terapkan bahasa terjemahan tersimpan ke lagu ini. */
    fun ensureLyricsTranslation() {
        val url = lyricsFor ?: return
        if (lyrics == null || lyricsTrLang.isEmpty()) return
        if (lyricsTrFor == url || lyricsTrBusy || lyricsTrNote != null) return
        translateLyrics(lyricsTrLang)
    }

    fun loadLyrics(t: Track) {
        if (lyricsFor == t.url && (lyricsLoading || lyrics != null)) return
        lyricsJob?.cancel()
        trJob?.cancel()
        lyricsTr = emptyList()
        lyricsTrFor = null
        lyricsTrNote = null
        lyricsTrBusy = false
        lyricsFor = t.url
        lyrics = null

        if (lyricsCache.containsKey(t.url)) {
            lyrics = lyricsCache[t.url]
            lyricsLoading = false
            return
        }

        lyricsLoading = true
        lyricsJob = viewModelScope.launch {
            try {
                val found = withContext(Dispatchers.IO) {
                    try {
                        Lyrics.fetch(t.artist, t.title, t.durationSec)
                    } catch (e: Exception) {
                        null
                    }
                }
                // Hanya hasil yang ditemukan yang disimpan; kegagalan jaringan boleh dicoba lagi.
                if (found != null) lyricsCache[t.url] = found
                if (lyricsFor == t.url) lyrics = found
            } catch (e: CancellationException) {
                throw e
            } finally {
                if (lyricsFor == t.url) lyricsLoading = false
            }
        }
    }
}
