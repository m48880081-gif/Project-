package app.mixbase.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.mixbase.data.Engine
import app.mixbase.data.Store
import app.mixbase.data.Track
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Satu ViewModel untuk seluruh app: pengaturan, pustaka (favorit/riwayat), dan pencarian. */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)

    // ---------------- Pengaturan ----------------

    var themeMode by mutableIntStateOf(store.themeMode)
        private set
    var dynamicColor by mutableStateOf(store.dynamicColor)
        private set
    var highQuality by mutableStateOf(store.highQuality)
        private set

    fun updateThemeMode(v: Int) {
        themeMode = v
        store.themeMode = v
    }

    fun updateDynamicColor(v: Boolean) {
        dynamicColor = v
        store.dynamicColor = v
    }

    fun updateHighQuality(v: Boolean) {
        highQuality = v
        store.highQuality = v
    }

    // ---------------- Pustaka ----------------

    val favorites = mutableStateListOf<Track>().apply { addAll(store.loadFavorites()) }
    val history = mutableStateListOf<Track>().apply { addAll(store.loadHistory()) }

    fun isFavorite(url: String): Boolean = favorites.any { it.url == url }

    fun toggleFavorite(t: Track) {
        val i = favorites.indexOfFirst { it.url == t.url }
        if (i >= 0) favorites.removeAt(i) else favorites.add(0, t)
        store.saveFavorites(favorites.toList())
    }

    fun addHistory(t: Track) {
        history.removeAll { it.url == t.url }
        history.add(0, t)
        while (history.size > 200) history.removeAt(history.size - 1)
        store.saveHistory(history.toList())
    }

    fun clearHistory() {
        history.clear()
        store.saveHistory(emptyList())
    }

    // ---------------- Pencarian ----------------

    var query by mutableStateOf("")
        private set
    var filter by mutableStateOf(Engine.FILTER_MUSIC)
        private set
    val results = mutableStateListOf<Track>()
    var loading by mutableStateOf(false)
        private set
    var loadingMore by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var suggestions by mutableStateOf<List<String>>(emptyList())
        private set
    var canLoadMore by mutableStateOf(false)
        private set
    var searched by mutableStateOf(false)
        private set

    private var session: Engine.SearchSession? = null
    private var searchJob: Job? = null
    private var suggestJob: Job? = null
    private var searchId = 0

    fun onQueryChange(q: String) {
        query = q
        suggestJob?.cancel()
        val text = q.trim()
        if (text.length < 2) {
            suggestions = emptyList()
            return
        }
        suggestJob = viewModelScope.launch {
            delay(250)
            val list = withContext(Dispatchers.IO) {
                try {
                    Engine.suggestions(text)
                } catch (e: Exception) {
                    emptyList()
                }
            }
            suggestions = list
        }
    }

    fun updateFilter(f: String) {
        if (f == filter) return
        filter = f
        if (searched && query.isNotBlank()) search()
    }

    fun search(q: String = query) {
        val text = q.trim()
        if (text.isEmpty()) return

        query = text
        suggestions = emptyList()
        suggestJob?.cancel()
        searchJob?.cancel()

        searchId += 1
        val id = searchId
        val currentFilter = filter

        loading = true
        loadingMore = false
        error = null
        searched = true
        results.clear()
        canLoadMore = false
        session = null

        searchJob = viewModelScope.launch {
            try {
                val s = withContext(Dispatchers.IO) { Engine.newSearch(text, currentFilter) }
                val tracks = withContext(Dispatchers.IO) { s.first() }
                if (id == searchId) {
                    session = s
                    results.addAll(tracks)
                    canLoadMore = s.hasMore
                    if (tracks.isEmpty()) error = "Tidak ada hasil untuk \"$text\""
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == searchId) error = "Gagal memuat: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                if (id == searchId) loading = false
            }
        }
    }

    fun loadMore() {
        val s = session ?: return
        if (loading || loadingMore || !canLoadMore) return
        loadingMore = true
        val id = searchId
        viewModelScope.launch {
            try {
                val more = withContext(Dispatchers.IO) { s.more() }
                if (id == searchId) {
                    for (t in more) {
                        if (results.none { it.url == t.url }) results.add(t)
                    }
                    canLoadMore = s.hasMore
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (id == searchId) canLoadMore = false
            } finally {
                if (id == searchId) loadingMore = false
            }
        }
    }
}
