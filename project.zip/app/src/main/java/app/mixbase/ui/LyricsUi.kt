package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text as RawText
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameMillis
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import app.mixbase.R
import app.mixbase.data.Languages
import app.mixbase.data.LyricLine
import app.mixbase.data.LyricsData
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection
import kotlin.math.abs

/** Indeks baris lirik yang sedang dinyanyikan pada posisi [posMs]; -1 bila belum mulai. */
fun currentLyricIndex(lines: List<LyricLine>, posMs: Long): Int {
    var lo = 0
    var hi = lines.size - 1
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= posMs + 250L) {
            ans = mid
            lo = mid + 1
        } else {
            hi = mid - 1
        }
    }
    return ans
}

/** Lirik milik lagu yang sedang diputar (null bila belum ada / milik lagu sebelumnya). */
@Composable
private fun lyricsOf(vm: AppViewModel, player: PlayerConnection): LyricsData? {
    val url = player.current?.url ?: return null
    return if (vm.lyricsFor == url) vm.lyrics else null
}

// =====================================================================
// Kartu pratinjau di layar Now Playing
// =====================================================================

/** Kartu lirik kecil di layar Now Playing: pratinjau baris yang sedang dinyanyikan. */
@Composable
fun LyricsCard(vm: AppViewModel, player: PlayerConnection, onOpen: () -> Unit) {
    val track = player.current ?: return
    val lyr = lyricsOf(vm, player)
    val loading = vm.lyricsFor != track.url || vm.lyricsLoading
    val cs = MaterialTheme.colorScheme
    val onColor = cs.onPrimaryContainer
    val shape = RoundedCornerShape(24.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 14.dp, bottom = 8.dp)
            .animateContentSize(spring(dampingRatio = 0.85f, stiffness = 400f))
            .clip(shape)
            .background(cs.primaryContainer)
            .clickable(enabled = lyr != null, onClick = onOpen)
            .padding(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                painter = painterResource(R.drawable.ic_lyrics),
                contentDescription = null,
                tint = onColor,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Lirik",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = onColor,
                modifier = Modifier.weight(1f),
            )
            if (loading && lyr == null) {
                PlayLoader(
                    diameter = 24.dp,
                    containerColor = Color.Transparent,
                    color = onColor,
                )
            } else if (lyr != null) {
                Text(
                    text = "Buka layar penuh",
                    style = MaterialTheme.typography.labelMedium,
                    color = onColor,
                )
            }
        }

        when {
            lyr == null && loading -> {
                Text(
                    text = "Mencari lirik…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr == null -> {
                Text(
                    text = "Lirik tidak ditemukan untuk lagu ini.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr.instrumental -> {
                Text(
                    text = "Lagu instrumental.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr.synced.isNotEmpty() -> {
                val idx = currentLyricIndex(lyr.synced, player.positionMs)
                AnimatedContent(
                    targetState = idx,
                    transitionSpec = {
                        (fadeIn(tween(300)) + slideInVertically(tween(300, easing = FastOutSlowInEasing)) { h -> h / 2 }) togetherWith
                            (fadeOut(tween(150)) + slideOutVertically(tween(220, easing = FastOutSlowInEasing)) { h -> -h / 2 })
                    },
                    label = "cardLine",
                ) { i ->
                    val now = (if (i >= 0) lyr.synced[i].text else "♪").ifBlank { "♪" }
                    val next = if (i + 1 < lyr.synced.size) lyr.synced[i + 1].text else ""
                    Column {
                        RawText(
                            text = now,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = onColor,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 10.dp),
                        )
                        if (next.isNotBlank()) {
                            RawText(
                                text = next,
                                style = MaterialTheme.typography.bodyLarge,
                                color = onColor.copy(alpha = 0.6f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                    }
                }
            }

            else -> {
                RawText(
                    text = lyr.plain,
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

// =====================================================================
// Layar lirik penuh
// =====================================================================

/** Pudarkan tepi atas dan bawah daftar (topeng alfa, bukan blur kaca). */
private fun Modifier.fadeEdges(top: Dp = 28.dp, bottom: Dp = 64.dp): Modifier =
    this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            val h = size.height
            if (h > 0f) {
                val t = (top.toPx() / h).coerceIn(0f, 0.45f)
                val b = (1f - bottom.toPx() / h).coerceIn(0.55f, 1f)
                drawRect(
                    brush = Brush.verticalGradient(
                        0f to Color.Transparent,
                        t to Color.Black,
                        b to Color.Black,
                        1f to Color.Transparent,
                    ),
                    blendMode = BlendMode.DstIn,
                )
            }
        }

/**
 * Teks lirik dengan sapuan per baris: teks redup di bawah, salinan terang di atasnya yang
 * terbuka perlahan dari kiri ke kanan (tepi lembut) mengikuti [progress] 0..1.
 * Baris yang terpecah jadi beberapa baris layar disapu berurutan.
 */
@Composable
private fun SweepText(
    text: String,
    style: TextStyle,
    base: Color,
    lit: Color,
    litAlpha: Float,
    progress: () -> Float,
    modifier: Modifier = Modifier,
) {
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val feather = with(LocalDensity.current) { 22.dp.toPx() }
    Box(modifier) {
        RawText(
            text = text,
            style = style,
            color = base,
            onTextLayout = { layout = it },
        )
        if (litAlpha > 0.01f) {
            RawText(
                text = text,
                style = style,
                color = lit.copy(alpha = litAlpha),
                modifier = Modifier
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        val w = size.width
                        if (w <= 0f) return@drawWithContent
                        val p = progress().coerceIn(0f, 1f)
                        val l = layout
                        val n = l?.lineCount ?: 0
                        if (l == null || n == 0) {
                            val edge = p * (w + feather)
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    0f to Color.Black,
                                    ((edge - feather) / w).coerceIn(0f, 1f) to Color.Black,
                                    (edge / w).coerceIn(0f, 1f) to Color.Transparent,
                                    1f to Color.Transparent,
                                    startX = 0f,
                                    endX = w,
                                ),
                                blendMode = BlendMode.DstIn,
                            )
                            return@drawWithContent
                        }
                        var total = 0f
                        for (k in 0 until n) total += (l.getLineRight(k) - l.getLineLeft(k))
                        var remain = p * total
                        for (k in 0 until n) {
                            val left = l.getLineLeft(k)
                            val lw = l.getLineRight(k) - left
                            val take = remain.coerceIn(0f, lw)
                            remain -= take
                            val q = if (lw <= 0f) 1f else take / lw
                            val edge = left + q * (lw + feather)
                            val top = l.getLineTop(k)
                            val bottom = l.getLineBottom(k)
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    0f to Color.Black,
                                    ((edge - feather) / w).coerceIn(0f, 1f) to Color.Black,
                                    (edge / w).coerceIn(0f, 1f) to Color.Transparent,
                                    1f to Color.Transparent,
                                    startX = 0f,
                                    endX = w,
                                ),
                                topLeft = Offset(0f, top),
                                size = Size(w, bottom - top),
                                blendMode = BlendMode.DstIn,
                            )
                        }
                    },
            )
        }
    }
}

/**
 * Satu baris lirik. [dist] = jarak ke baris aktif (0 = aktif, negatif = sudah lewat,
 * positif = berikutnya). Baris aktif membesar, terang, dan tersapu; yang jauh makin redup
 * dan sedikit buram supaya mata tertuju ke baris yang sedang dinyanyikan.
 */
@Composable
private fun LyricItem(
    text: String,
    translation: String?,
    dist: Int,
    synced: Boolean,
    progress: () -> Float,
    onClick: () -> Unit,
) {
    val cs = MaterialTheme.colorScheme
    val active = synced && dist == 0
    val d = abs(dist)
    val baseTarget = when {
        !synced -> 0.55f
        active -> 0.3f
        d == 1 -> 0.5f
        d == 2 -> 0.38f
        else -> 0.26f
    }
    val baseA by animateFloatAsState(baseTarget, tween(450), label = "lyBase")
    val lit by animateFloatAsState(if (active) 1f else 0f, tween(420), label = "lyLit")
    val scale by animateFloatAsState(
        targetValue = if (active || !synced) 1f else 0.93f,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = 300f),
        label = "lyScale",
    )
    val blurTarget = if (!synced || d <= 1) 0f else minOf(d - 1, 3) * 1.3f
    val blurR by animateFloatAsState(blurTarget, tween(450), label = "lyBlur")
    val trA by animateFloatAsState(if (active) 0.85f else baseTarget, tween(450), label = "lyTr")

    val style = MaterialTheme.typography.headlineSmall.copy(
        fontSize = 27.sp,
        lineHeight = 36.sp,
        fontWeight = FontWeight.ExtraBold,
    )

    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick),
    ) {
        Column(
            Modifier
                .padding(horizontal = 12.dp, vertical = 9.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    transformOrigin = TransformOrigin(0f, 0.5f)
                }
                .then(if (blurR > 0.05f) Modifier.blur(blurR.dp) else Modifier),
        ) {
            SweepText(
                text = text.ifBlank { "♪" },
                style = style,
                base = cs.onSurface.copy(alpha = baseA),
                lit = cs.onSurface,
                litAlpha = lit,
                progress = progress,
            )
            if (!translation.isNullOrBlank() && translation != text) {
                RawText(
                    text = translation,
                    style = MaterialTheme.typography.titleMedium,
                    color = cs.onSurface.copy(alpha = trA),
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }
}

/** Lirik layar penuh: baris aktif disapu dan digulir mulus; ketuk baris untuk melompat. */
@Composable
fun LyricsScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onClose: () -> Unit,
    onOpenQueue: () -> Unit,
) {
    val track = player.current ?: return
    val lyr = lyricsOf(vm, player)
    val listState = rememberLazyListState()
    val cs = MaterialTheme.colorScheme
    val dark = cs.background.luminance() < 0.5f

    BackHandler(onBack = onClose)

    var showTranslate by remember { mutableStateOf(false) }
    LaunchedEffect(track.url, lyr) { vm.ensureLyricsTranslation() }
    val trOk = vm.lyricsTrFor == track.url
    val translated: List<String> = if (trOk) vm.lyricsTr else emptyList()

    val synced: List<LyricLine> = lyr?.synced ?: emptyList()

    // Jam halus: posisi dari pemutar hanya diperbarui tiap ±0,5 dtk, jadi disisipi per frame
    // supaya sapuan lirik terlihat mulus.
    val smooth = remember { mutableLongStateOf(player.positionMs) }
    val pos = player.positionMs
    val playing = player.isPlaying
    LaunchedEffect(pos, playing) {
        smooth.longValue = pos
        if (playing) {
            val t0 = withFrameMillis { it }
            while (true) {
                withFrameMillis { t -> smooth.longValue = pos + (t - t0) }
            }
        }
    }
    val idx by remember(synced) {
        derivedStateOf { currentLyricIndex(synced, smooth.longValue) }
    }

    // Jeda gulir otomatis selama pengguna menggulir sendiri.
    var userUntil by remember { mutableLongStateOf(0L) }
    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect { i ->
            if (i is DragInteraction.Start) {
                userUntil = Long.MAX_VALUE
            } else if (i is DragInteraction.Stop || i is DragInteraction.Cancel) {
                userUntil = System.currentTimeMillis() + 3_500L
            }
        }
    }

    LaunchedEffect(track.url) { listState.scrollToItem(0) }
    LaunchedEffect(idx, lyr) {
        if (idx < 0 || synced.isEmpty()) return@LaunchedEffect
        if (System.currentTimeMillis() < userUntil) return@LaunchedEffect
        var item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx }
        if (item == null) {
            listState.scrollToItem(idx)
            item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx }
        }
        if (item != null) {
            val info = listState.layoutInfo
            val viewport = (info.viewportEndOffset - info.viewportStartOffset).toFloat()
            val delta = (item.offset + item.size / 2f) - viewport * 0.36f
            listState.animateScrollBy(delta, tween(650, easing = FastOutSlowInEasing))
        }
    }

    LyricsTranslateDialog(
        visible = showTranslate,
        current = vm.lyricsTrLang,
        onPick = {
            showTranslate = false
            vm.translateLyrics(it)
        },
        onDismiss = { showTranslate = false },
    )

    val status = when {
        lyr == null && (vm.lyricsFor != track.url || vm.lyricsLoading) -> 0
        lyr == null -> 1
        lyr.instrumental -> 2
        synced.isNotEmpty() -> 3
        translated.isNotEmpty() -> 4
        else -> 5
    }

    Surface(modifier = Modifier.fillMaxSize(), color = cs.background) {
        Box(Modifier.fillMaxSize()) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(cs.primaryContainer.copy(alpha = if (dark) 0.5f else 0.75f), cs.background),
                        ),
                    ),
            )
            Column(
                Modifier
                    .fillMaxSize()
                    .systemBarsPadding(),
            ) {
                // ---- Header ----
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup")
                    }
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "Sedang diputar",
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.onSurfaceVariant,
                        )
                        Text(
                            text = track.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    if (lyr != null && !lyr.instrumental) {
                        val pill = RoundedCornerShape(50)
                        Text(
                            text = if (vm.lyricsTrLang.isEmpty()) {
                                "Terjemahkan lirik"
                            } else {
                                Languages.byCode(vm.lyricsTrLang)?.name ?: vm.lyricsTrLang
                            },
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .bouncyClick(shape = pill) { showTranslate = true }
                                .background(cs.surfaceContainerHighest, pill)
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                        )
                    }
                }

                AnimatedVisibility(
                    visible = vm.lyricsTrBusy,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut(),
                ) {
                    Text(
                        text = "Menerjemahkan…",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp),
                    )
                }
                val trNote = vm.lyricsTrNote
                AnimatedVisibility(
                    visible = trNote != null,
                    enter = expandVertically() + fadeIn(),
                    exit = shrinkVertically() + fadeOut(),
                ) {
                    Text(
                        text = trNote ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp),
                    )
                }

                // ---- Isi lirik ----
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                ) {
                    Crossfade(
                        targetState = status,
                        animationSpec = tween(350),
                        label = "lyricsBody",
                    ) { s ->
                        when (s) {
                            0 -> Column(
                                Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                PlayLoader(diameter = 56.dp)
                                Text(
                                    text = "Mencari lirik…",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = cs.onSurfaceVariant,
                                    modifier = Modifier.padding(top = 12.dp),
                                )
                            }

                            1 -> Column(
                                Modifier.fillMaxSize().padding(24.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    text = "Lirik tidak tersedia.",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = cs.onSurfaceVariant,
                                )
                            }

                            2 -> Column(
                                Modifier.fillMaxSize().padding(24.dp),
                                verticalArrangement = Arrangement.Center,
                                horizontalAlignment = Alignment.CenterHorizontally,
                            ) {
                                Text(
                                    text = "Lagu instrumental.",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = cs.onSurfaceVariant,
                                )
                            }

                            3 -> LazyColumn(
                                state = listState,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .fadeEdges(),
                                contentPadding = PaddingValues(top = 56.dp, bottom = 260.dp),
                            ) {
                                itemsIndexed(synced) { i, line ->
                                    LyricItem(
                                        text = line.text,
                                        translation = translated.getOrNull(i),
                                        dist = i - idx,
                                        synced = true,
                                        progress = {
                                            val cur = idx
                                            when {
                                                i < cur -> 1f
                                                i > cur -> 0f
                                                else -> {
                                                    val next = synced.getOrNull(i + 1)?.timeMs ?: (line.timeMs + 5_000L)
                                                    val gap = (next - line.timeMs).coerceAtLeast(400L)
                                                    val span = minOf(gap * 0.92f, maxOf(1_500f, line.text.length * 95f))
                                                    ((smooth.longValue - line.timeMs) / span).coerceIn(0f, 1f)
                                                }
                                            }
                                        },
                                        onClick = { player.seekTo(line.timeMs) },
                                    )
                                }
                            }

                            4 -> {
                                val plainLines = (lyr?.plain ?: "").lines()
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                        .padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 260.dp),
                                ) {
                                    for ((i, line) in plainLines.withIndex()) {
                                        if (line.isBlank()) {
                                            Spacer(Modifier.height(14.dp))
                                            continue
                                        }
                                        RawText(
                                            text = line,
                                            style = MaterialTheme.typography.titleLarge,
                                            fontWeight = FontWeight.Bold,
                                            color = cs.onSurface,
                                        )
                                        val tl = translated.getOrNull(i)
                                        if (!tl.isNullOrBlank() && tl != line) {
                                            RawText(
                                                text = tl,
                                                style = MaterialTheme.typography.bodyLarge,
                                                color = cs.onSurface.copy(alpha = 0.65f),
                                                modifier = Modifier.padding(bottom = 8.dp),
                                            )
                                        }
                                    }
                                }
                            }

                            else -> RawText(
                                text = lyr?.plain ?: "",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = cs.onSurface,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .verticalScroll(rememberScrollState())
                                    .padding(start = 24.dp, end = 24.dp, top = 16.dp, bottom = 260.dp),
                            )
                        }
                    }
                }
            }

            // Kartu pemutar mini di bawah (selalu di atas daftar lirik)
            LyricsMiniCard(
                player = player,
                onOpenQueue = onOpenQueue,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .navigationBarsPadding(),
            )
        }
    }
}

/**
 * Kartu pemutar mini di layar lirik. Ikon expand/collapse membuka kontrol lengkap
 * (seek bar, sebelumnya/berikutnya, acak, ulang, antrean) lalu melipatnya kembali.
 */
@Composable
private fun LyricsMiniCard(
    player: PlayerConnection,
    onOpenQueue: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val track = player.current ?: return
    val cs = MaterialTheme.colorScheme
    var expanded by remember { mutableStateOf(false) }
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val duration: Long = if (player.durationMs > 0L) player.durationMs else 1L
    val fraction: Float = if (dragging) dragValue else (player.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    val shownSec: Long = (fraction * duration.toFloat() / 1000f).toLong()
    val shape = RoundedCornerShape(28.dp)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .animateContentSize(spring(dampingRatio = 0.85f, stiffness = 420f))
            .clip(shape)
            .background(cs.surfaceContainerHigh)
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Thumb(track.thumb, 48.dp, pageUrl = track.url)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    text = track.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = track.artist,
                    style = MaterialTheme.typography.bodySmall,
                    color = cs.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .bouncyClick(shape = CircleShape) { player.togglePlay() }
                    .background(cs.primary, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    painter = painterResource(if (player.isPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                    contentDescription = "Putar atau jeda",
                    tint = cs.onPrimary,
                    modifier = Modifier.size(24.dp),
                )
            }
            Spacer(Modifier.width(4.dp))
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .bouncyClick(shape = CircleShape) { expanded = !expanded },
                contentAlignment = Alignment.Center,
            ) {
                Crossfade(targetState = expanded, animationSpec = tween(200), label = "expandIcon") { open ->
                    Icon(
                        painter = painterResource(if (open) R.drawable.ic_close_full else R.drawable.ic_open_full),
                        contentDescription = if (open) "Ciutkan" else "Perluas",
                        tint = cs.onSurfaceVariant,
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically(spring(dampingRatio = 0.85f, stiffness = 420f)) + fadeIn(tween(220)),
            exit = shrinkVertically(tween(200)) + fadeOut(tween(120)),
        ) {
            Column(Modifier.padding(top = 8.dp)) {
                SeekBar(
                    fraction = fraction,
                    onChange = {
                        dragging = true
                        dragValue = it
                    },
                    onDone = {
                        player.seekTo((dragValue * duration.toFloat()).toLong())
                        dragging = false
                    },
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    RawText(
                        text = clock(shownSec),
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                    RawText(
                        text = if (player.durationMs > 0L) clock(player.durationMs / 1000L) else "--:--",
                        style = MaterialTheme.typography.bodySmall,
                        color = cs.onSurfaceVariant,
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    MiniControl(onClick = { player.toggleShuffle() }) {
                        Icon(
                            painter = painterResource(R.drawable.ic_shuffle),
                            contentDescription = "Acak",
                            tint = if (player.shuffle) cs.primary else cs.onSurfaceVariant,
                        )
                    }
                    MiniControl(onClick = { player.previous() }) {
                        Icon(
                            painter = painterResource(R.drawable.ic_skip_previous),
                            contentDescription = "Sebelumnya",
                            modifier = Modifier.size(28.dp),
                        )
                    }
                    MiniControl(onClick = { player.next() }) {
                        Icon(
                            painter = painterResource(R.drawable.ic_skip_next),
                            contentDescription = "Berikutnya",
                            modifier = Modifier.size(28.dp),
                        )
                    }
                    MiniControl(onClick = { player.cycleRepeat() }) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                painter = painterResource(R.drawable.ic_repeat),
                                contentDescription = "Ulangi",
                                tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) cs.primary else cs.onSurfaceVariant,
                            )
                            if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                                RawText(
                                    text = "1",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = cs.primary,
                                )
                            }
                        }
                    }
                    MiniControl(onClick = onOpenQueue) {
                        Icon(
                            painter = painterResource(R.drawable.ic_queue),
                            contentDescription = "Antrean",
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniControl(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .size(48.dp)
            .bouncyClick(shape = CircleShape, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        content()
    }
}

// =====================================================================
// Pilihan bahasa terjemahan lirik
// =====================================================================

@Composable
private fun LyricsTranslateDialog(
    visible: Boolean,
    current: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        visible = visible,
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Terjemahkan lirik") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Lirik asli tetap tampil; terjemahannya muncul di bawah tiap baris. " +
                        "Penerjemah jalan di HP; model bahasa (± 30 MB) diunduh sekali saat pertama dipakai.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                LyricsLangRow("Mati", current.isEmpty()) { onPick("") }
                for (l in Languages.ALL) {
                    LyricsLangRow(l.name, current == l.code) { onPick(l.code) }
                }
            }
        },
    )
}

@Composable
private fun LyricsLangRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null, modifier = Modifier.padding(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
