package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.LyricLine
import app.mixbase.data.Languages
import app.mixbase.data.LyricsData
import app.mixbase.player.PlayerConnection

/** Indeks baris lirik yang sedang dinyanyikan pada posisi [posMs]; -1 bila belum mulai. */
fun currentLyricIndex(lines: List<LyricLine>, posMs: Long): Int {
    var lo = 0
    var hi = lines.size - 1
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= posMs + 250L) {
            ans = mid
            lo = mid + 1
        } else {
            hi = mid - 1
        }
    }
    return ans
}

/** Lirik milik lagu yang sedang diputar (null bila belum ada / milik lagu sebelumnya). */
@Composable
private fun lyricsOf(vm: AppViewModel, player: PlayerConnection): LyricsData? {
    val url = player.current?.url ?: return null
    return if (vm.lyricsFor == url) vm.lyrics else null
}

/** Kartu lirik kecil di layar Now Playing: pratinjau baris yang sedang dinyanyikan. */
@Composable
fun LyricsCard(vm: AppViewModel, player: PlayerConnection, onOpen: () -> Unit) {
    val track = player.current ?: return
    val lyr = lyricsOf(vm, player)
    val loading = vm.lyricsFor != track.url || vm.lyricsLoading

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .clickable(enabled = lyr != null, onClick = onOpen)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                painter = painterResource(R.drawable.ic_lyrics),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Lirik",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.weight(1f),
            )
            if (loading && lyr == null) {
                PlayLoader(
                    diameter = 24.dp,
                    containerColor = androidx.compose.ui.graphics.Color.Transparent,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            } else if (lyr != null) {
                Text(
                    text = "Buka layar penuh",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }

        val onColor = MaterialTheme.colorScheme.onPrimaryContainer
        when {
            lyr == null && loading -> {
                Text(
                    text = "Mencari lirik…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr == null -> {
                Text(
                    text = "Lirik tidak ditemukan untuk lagu ini.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr.instrumental -> {
                Text(
                    text = "Lagu instrumental.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr.synced.isNotEmpty() -> {
                val idx = currentLyricIndex(lyr.synced, player.positionMs)
                val now = if (idx >= 0) lyr.synced[idx].text else "♪"
                val next = if (idx + 1 < lyr.synced.size) lyr.synced[idx + 1].text else ""
                Text(
                    text = now.ifBlank { "♪" },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = onColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 10.dp),
                )
                if (next.isNotBlank()) {
                    Text(
                        text = next,
                        style = MaterialTheme.typography.bodyLarge,
                        color = onColor.copy(alpha = 0.65f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }

            else -> {
                Text(
                    text = lyr.plain,
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

/** Lirik layar penuh: baris aktif disorot dan digulir otomatis; ketuk baris untuk melompat. */
@Composable
fun LyricsScreen(vm: AppViewModel, player: PlayerConnection, onClose: () -> Unit) {
    val track = player.current ?: return
    val lyr = lyricsOf(vm, player)
    val listState = rememberLazyListState()

    BackHandler(onBack = onClose)

    var showTranslate by remember { mutableStateOf(false) }
    LaunchedEffect(track.url, lyr) { vm.ensureLyricsTranslation() }
    val trOk = vm.lyricsTrFor == track.url
    val translated: List<String> = if (trOk) vm.lyricsTr else emptyList()

    val synced: List<LyricLine> = lyr?.synced ?: emptyList()
    val idx = currentLyricIndex(synced, player.positionMs)

    LaunchedEffect(idx) {
        if (idx >= 0) listState.animateScrollToItem((idx - 2).coerceAtLeast(0))
    }

    if (showTranslate) {
        LyricsTranslateDialog(
            current = vm.lyricsTrLang,
            onPick = {
                showTranslate = false
                vm.translateLyrics(it)
            },
            onDismiss = { showTranslate = false },
        )
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Tutup",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                if (lyr != null && !lyr.instrumental) {
                    Text(
                        text = if (vm.lyricsTrLang.isEmpty()) {
                            "Terjemahkan lirik"
                        } else {
                            Languages.byCode(vm.lyricsTrLang)?.name ?: vm.lyricsTrLang
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        maxLines = 1,
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .clip(RoundedCornerShape(50))
                            .background(MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.12f))
                            .clickable { showTranslate = true }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                }
            }

            if (vm.lyricsTrBusy) {
                Text(
                    text = "Menerjemahkan…",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp),
                )
            }
            val trNote = vm.lyricsTrNote
            if (trNote != null) {
                Text(
                    text = trNote,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp),
                )
            }

            when {
                lyr == null -> {
                    Text(
                        text = "Lirik tidak tersedia.",
                        modifier = Modifier.padding(24.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }

                synced.isNotEmpty() -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 96.dp),
                    ) {
                        itemsIndexed(synced) { i, line ->
                            val active = i == idx
                            val color by animateColorAsState(
                                targetValue = if (active) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.45f)
                                },
                                label = "lyric",
                            )
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { player.seekTo(line.timeMs) }
                                    .padding(horizontal = 24.dp, vertical = 10.dp),
                            ) {
                                Text(
                                    text = line.text.ifBlank { "♪" },
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Bold,
                                    color = color,
                                )
                                val tl = translated.getOrNull(i)
                                if (!tl.isNullOrBlank() && tl != line.text) {
                                    Text(
                                        text = tl,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = color,
                                        modifier = Modifier.padding(top = 2.dp),
                                    )
                                }
                            }
                        }
                    }
                }

                translated.isNotEmpty() && !lyr.instrumental -> {
                    val plainLines = lyr.plain.lines()
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(24.dp),
                    ) {
                        for ((i, line) in plainLines.withIndex()) {
                            if (line.isBlank()) {
                                Spacer(Modifier.height(12.dp))
                                continue
                            }
                            Text(
                                text = line,
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                            )
                            val tl = translated.getOrNull(i)
                            if (!tl.isNullOrBlank() && tl != line) {
                                Text(
                                    text = tl,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                                    modifier = Modifier.padding(bottom = 6.dp),
                                )
                            }
                        }
                    }
                }

                else -> {
                    Text(
                        text = if (lyr.instrumental) "Lagu instrumental." else lyr.plain,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(24.dp),
                    )
                }
            }
        }
    }
}

/** Pilihan bahasa terjemahan lirik. */
@Composable
private fun LyricsTranslateDialog(current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Terjemahkan lirik") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Lirik asli tetap tampil; terjemahannya muncul di bawah tiap baris. " +
                        "Penerjemah jalan di HP; model bahasa (± 30 MB) diunduh sekali saat pertama dipakai.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                LyricsLangRow("Mati", current.isEmpty()) { onPick("") }
                for (l in Languages.ALL) {
                    LyricsLangRow(l.name, current == l.code) { onPick(l.code) }
                }
            }
        },
    )
}

@Composable
private fun LyricsLangRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null, modifier = Modifier.padding(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
