package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import app.mixbase.ui.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.Player
import app.mixbase.R
import app.mixbase.data.LyricLine
import app.mixbase.data.Languages
import app.mixbase.data.LyricsData
import app.mixbase.data.clock
import app.mixbase.player.PlayerConnection

/** Indeks baris lirik yang sedang dinyanyikan pada posisi [posMs]; -1 bila belum mulai. */
fun currentLyricIndex(lines: List<LyricLine>, posMs: Long): Int {
    var lo = 0
    var hi = lines.size - 1
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= posMs + 250L) {
            ans = mid
            lo = mid + 1
        } else {
            hi = mid - 1
        }
    }
    return ans
}

/** Lirik milik lagu yang sedang diputar (null bila belum ada / milik lagu sebelumnya). */
@Composable
private fun lyricsOf(vm: AppViewModel, player: PlayerConnection): LyricsData? {
    val url = player.current?.url ?: return null
    return if (vm.lyricsFor == url) vm.lyrics else null
}

/** Kartu lirik kecil di layar Now Playing: pratinjau baris yang sedang dinyanyikan. */
@Composable
fun LyricsCard(vm: AppViewModel, player: PlayerConnection, onOpen: () -> Unit) {
    val track = player.current ?: return
    val lyr = lyricsOf(vm, player)
    val loading = vm.lyricsFor != track.url || vm.lyricsLoading

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .bounceClickable(enabled = lyr != null, onClick = onOpen)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                painter = painterResource(R.drawable.ic_lyrics),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Lirik",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.weight(1f),
            )
            if (loading && lyr == null) {
                PlayLoader(
                    diameter = 24.dp,
                    containerColor = androidx.compose.ui.graphics.Color.Transparent,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            } else if (lyr != null) {
                Text(
                    text = "Buka layar penuh",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }

        val onColor = MaterialTheme.colorScheme.onPrimaryContainer
        when {
            lyr == null && loading -> {
                Text(
                    text = "Mencari lirik…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr == null -> {
                Text(
                    text = "Lirik tidak ditemukan untuk lagu ini.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr.instrumental -> {
                Text(
                    text = "Lagu instrumental.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr.synced.isNotEmpty() -> {
                val idx = currentLyricIndex(lyr.synced, player.positionMs)
                val now = if (idx >= 0) lyr.synced[idx].text else "♪"
                val next = if (idx + 1 < lyr.synced.size) lyr.synced[idx + 1].text else ""
                Text(
                    text = now.ifBlank { "♪" },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = onColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 10.dp),
                )
                if (next.isNotBlank()) {
                    Text(
                        text = next,
                        style = MaterialTheme.typography.bodyLarge,
                        color = onColor.copy(alpha = 0.65f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }

            else -> {
                Text(
                    text = lyr.plain,
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

/**
 * Layar lirik gaya Apple Music: latar gradasi dari warna sampul, baris aktif terisi per huruf mengikuti
 * lagu, baris lain mengabur makin jauh dari baris aktif, terjemahan kecil di bawah tiap baris.
 * Dua mode: tidak penuh (lirik + kontrol lengkap) dan penuh (lirik memenuhi layar, hanya judul + progres).
 */
@Composable
fun LyricsScreen(
    vm: AppViewModel,
    player: PlayerConnection,
    onClose: () -> Unit,
    onQueue: () -> Unit,
    onShare: () -> Unit,
    onSleep: () -> Unit,
    sleepOn: Boolean,
) {
    val track = player.current ?: return
    val lyr = lyricsOf(vm, player)
    val listState = rememberLazyListState()
    val scheme = MaterialTheme.colorScheme

    BackHandler(onBack = onClose)

    var full by remember { mutableStateOf(false) }
    var showTranslate by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    LaunchedEffect(track.url, lyr) { vm.ensureLyricsTranslation() }
    val trOk = vm.lyricsTrFor == track.url
    val translated: List<String> = if (trOk) vm.lyricsTr else emptyList()

    val synced: List<LyricLine> = lyr?.synced ?: emptyList()
    val idx = currentLyricIndex(synced, player.positionMs)

    // Warna latar dari sampul: terang -> teks gelap, gelap -> teks putih.
    val art = rememberArtColor(track.thumb)
    val light = art.luminance() > 0.38f
    val topColor = if (light) lerp(art, Color.White, 0.30f) else art
    val bottomColor = if (light) lerp(art, Color(0xFF8A8A8A), 0.55f) else lerp(art, Color.Black, 0.55f)
    val onBg = if (light) Color(0xFF101114) else Color.White

    // Baris aktif diletakkan sekitar seperlima dari atas area lirik.
    LaunchedEffect(idx, full) {
        if (idx >= 0) {
            val h = listState.layoutInfo.viewportSize.height
            listState.animateScrollToItem(idx, -(h * 0.18f).toInt())
        }
    }

    if (showTranslate) {
        LyricsTranslateDialog(
            current = vm.lyricsTrLang,
            onPick = {
                showTranslate = false
                vm.translateLyrics(it)
            },
            onDismiss = { showTranslate = false },
        )
    }

    // Progres
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val duration: Long = if (player.durationMs > 0L) player.durationMs else 1L
    val fraction: Float = if (dragging) {
        dragValue
    } else {
        (player.positionMs.toFloat() / duration.toFloat()).coerceIn(0f, 1f)
    }
    val shownSec: Long = (fraction * duration.toFloat() / 1000f).toLong()
    val remainSec: Long = if (player.durationMs > 0L) (player.durationMs / 1000L) - shownSec else 0L
    val showPlaying = player.isPlaying || player.buffering

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(topColor, bottomColor))),
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
        ) {
            // ---- Area lirik (memudar di tepi atas dan bawah) ----
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        drawRect(
                            brush = Brush.verticalGradient(
                                0f to Color.Transparent,
                                0.06f to Color.Black,
                                0.90f to Color.Black,
                                1f to Color.Transparent,
                            ),
                            blendMode = BlendMode.DstIn,
                        )
                    },
            ) {
                when {
                    lyr == null -> {
                        val searching = vm.lyricsFor != track.url || vm.lyricsLoading
                        Text(
                            text = if (searching) "Mencari lirik…" else "Lirik tidak tersedia.",
                            style = MaterialTheme.typography.titleMedium,
                            color = onBg.copy(alpha = 0.8f),
                            modifier = Modifier
                                .align(Alignment.Center)
                                .padding(24.dp),
                        )
                    }

                    synced.isNotEmpty() -> {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(top = 24.dp, bottom = 320.dp),
                        ) {
                            itemsIndexed(synced) { i, line ->
                                val active = i == idx
                                val dist = if (idx < 0) 2 else if (i > idx) i - idx else idx - i
                                val blurDp by animateDpAsState(
                                    targetValue = when (dist) {
                                        0 -> 0.dp
                                        1 -> 1.5.dp
                                        2 -> 3.dp
                                        3 -> 4.5.dp
                                        else -> 6.dp
                                    },
                                    animationSpec = tween(350),
                                    label = "lyricBlur",
                                )
                                val lineStart = line.timeMs
                                val lineEnd = if (i + 1 < synced.size) synced[i + 1].timeMs else lineStart + 5000L
                                val span = (lineEnd - lineStart).coerceAtLeast(500L)
                                val raw = if (active) {
                                    ((player.positionMs - lineStart).toFloat() / span.toFloat()).coerceIn(0f, 1f)
                                } else {
                                    0f
                                }
                                val smooth by animateFloatAsState(
                                    targetValue = raw,
                                    animationSpec = tween(520, easing = LinearEasing),
                                    label = "lyricFill",
                                )
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable(
                                            interactionSource = remember { MutableInteractionSource() },
                                            indication = null,
                                        ) { player.seekTo(line.timeMs) }
                                        .padding(horizontal = 26.dp, vertical = 12.dp)
                                        .blur(blurDp, BlurredEdgeTreatment.Unbounded),
                                ) {
                                    KaraokeText(
                                        text = line.text.ifBlank { "♪" },
                                        fraction = if (active) smooth else 0f,
                                        dim = onBg.copy(alpha = 0.45f),
                                        bright = onBg,
                                        style = MaterialTheme.typography.headlineMedium,
                                    )
                                    val tl = translated.getOrNull(i)
                                    if (!tl.isNullOrBlank() && tl != line.text) {
                                        androidx.compose.material3.Text(
                                            text = tl,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = onBg.copy(alpha = if (active) 0.85f else 0.55f),
                                            modifier = Modifier.padding(top = 4.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }

                    translated.isNotEmpty() && !lyr.instrumental -> {
                        val plainLines = lyr.plain.lines()
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 26.dp, vertical = 24.dp),
                        ) {
                            for ((i, line) in plainLines.withIndex()) {
                                if (line.isBlank()) {
                                    Spacer(Modifier.height(14.dp))
                                    continue
                                }
                                androidx.compose.material3.Text(
                                    text = line,
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = onBg,
                                )
                                val tl = translated.getOrNull(i)
                                if (!tl.isNullOrBlank() && tl != line) {
                                    androidx.compose.material3.Text(
                                        text = tl,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = onBg.copy(alpha = 0.7f),
                                        modifier = Modifier.padding(bottom = 6.dp),
                                    )
                                }
                            }
                        }
                    }

                    else -> {
                        androidx.compose.material3.Text(
                            text = if (lyr.instrumental) "Lagu instrumental." else lyr.plain,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = onBg,
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 26.dp, vertical = 24.dp),
                        )
                    }
                }

                // Status terjemahan (kecil, di atas lirik)
                val trNote = vm.lyricsTrNote
                val status = if (vm.lyricsTrBusy) "Menerjemahkan…" else trNote
                if (status != null) {
                    Text(
                        text = status,
                        style = MaterialTheme.typography.labelMedium,
                        color = onBg,
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(percent = 50))
                            .background(onBg.copy(alpha = 0.14f))
                            .padding(horizontal = 12.dp, vertical = 5.dp),
                    )
                }
            }

            // ---- Judul + tombol mode penuh + menu ----
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 22.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(onBg.copy(alpha = 0.12f)),
                ) {
                    ThumbImage(track.thumb, track.url, Modifier.fillMaxSize())
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = onBg,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.bodyLarge,
                        color = onBg.copy(alpha = 0.72f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                IconButton(onClick = { full = !full }) {
                    Icon(
                        painter = painterResource(if (full) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen),
                        contentDescription = if (full) "Kecilkan lirik" else "Lirik layar penuh",
                        tint = onBg,
                    )
                }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(
                            painter = painterResource(R.drawable.ic_more_horiz),
                            contentDescription = "Menu",
                            tint = onBg,
                        )
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (lyr != null && !lyr.instrumental) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        if (vm.lyricsTrLang.isEmpty()) {
                                            "Terjemahkan lirik"
                                        } else {
                                            "Terjemahan: " + (Languages.byCode(vm.lyricsTrLang)?.name ?: vm.lyricsTrLang)
                                        },
                                    )
                                },
                                onClick = {
                                    menu = false
                                    showTranslate = true
                                },
                            )
                        }
                        val src = lyr?.source ?: ""
                        if (src.isNotBlank()) {
                            DropdownMenuItem(
                                text = { Text("Lirik dari: $src") },
                                enabled = false,
                                onClick = {},
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(if (vm.isFavorite(track.url)) "Hapus dari favorit" else "Tambah ke favorit") },
                            onClick = {
                                menu = false
                                vm.toggleFavorite(track)
                            },
                        )
                    }
                }
            }

            // ---- Progres ----
            ExpressiveSlider(
                value = fraction,
                onValueChange = {
                    dragging = true
                    dragValue = it
                },
                onValueChangeFinished = {
                    player.seekTo((dragValue * duration.toFloat()).toLong())
                    dragging = false
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                animate = showPlaying,
                color = onBg,
                trackColor = onBg.copy(alpha = 0.25f),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 26.dp, end = 26.dp, bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    text = clock(shownSec),
                    style = MaterialTheme.typography.bodySmall,
                    color = onBg.copy(alpha = 0.7f),
                )
                Text(
                    text = if (player.durationMs > 0L) "-" + clock(remainSec) else "--:--",
                    style = MaterialTheme.typography.bodySmall,
                    color = onBg.copy(alpha = 0.7f),
                )
            }

            // ---- Kontrol (disembunyikan di mode penuh) ----
            AnimatedVisibility(
                visible = !full,
                enter = expandVertically(spring(dampingRatio = 0.85f, stiffness = 380f)) + fadeIn(tween(200)),
                exit = shrinkVertically(spring(stiffness = 520f)) + fadeOut(tween(120)),
            ) {
                Column(Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        IconButton(onClick = { player.toggleShuffle() }) {
                            Icon(
                                painter = painterResource(R.drawable.ic_shuffle),
                                contentDescription = "Acak",
                                tint = if (player.shuffle) onBg else onBg.copy(alpha = 0.5f),
                            )
                        }
                        IconButton(onClick = { player.previous() }, modifier = Modifier.size(56.dp)) {
                            Icon(
                                painter = painterResource(R.drawable.ic_skip_previous),
                                contentDescription = "Sebelumnya",
                                tint = onBg,
                                modifier = Modifier.size(34.dp),
                            )
                        }
                        IconButton(onClick = { player.togglePlay() }, modifier = Modifier.size(76.dp)) {
                            Icon(
                                painter = painterResource(if (showPlaying) R.drawable.ic_pause else R.drawable.ic_play),
                                contentDescription = "Putar atau jeda",
                                tint = onBg,
                                modifier = Modifier.size(50.dp),
                            )
                        }
                        IconButton(onClick = { player.next() }, modifier = Modifier.size(56.dp)) {
                            Icon(
                                painter = painterResource(R.drawable.ic_skip_next),
                                contentDescription = "Berikutnya",
                                tint = onBg,
                                modifier = Modifier.size(34.dp),
                            )
                        }
                        IconButton(onClick = { player.cycleRepeat() }) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    painter = painterResource(R.drawable.ic_repeat),
                                    contentDescription = "Ulangi",
                                    tint = if (player.repeatMode != Player.REPEAT_MODE_OFF) onBg else onBg.copy(alpha = 0.5f),
                                )
                                if (player.repeatMode == Player.REPEAT_MODE_ONE) {
                                    Text(
                                        text = "1",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = onBg,
                                    )
                                }
                            }
                        }
                    }

                    // Baris tombol: lirik (aktif), antrean, bagikan, timer tidur
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            modifier = Modifier
                                .size(width = 64.dp, height = 46.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(onBg.copy(alpha = 0.18f))
                                .bounceClickable(onClick = onClose),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                painter = painterResource(R.drawable.ic_lyrics_bubble),
                                contentDescription = "Tutup lirik",
                                tint = onBg,
                            )
                        }
                        IconButton(onClick = onQueue) {
                            Icon(painterResource(R.drawable.ic_queue_list), contentDescription = "Antrean", tint = onBg)
                        }
                        IconButton(onClick = onShare) {
                            Icon(painterResource(R.drawable.ic_share), contentDescription = "Bagikan", tint = onBg)
                        }
                        IconButton(onClick = onSleep) {
                            Icon(
                                painter = painterResource(R.drawable.ic_bedtime),
                                contentDescription = "Timer tidur",
                                tint = if (sleepOn) scheme.tertiary else onBg,
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

/**
 * Satu baris lirik besar: teks redup di bawah, teks terang di atasnya yang terisi dari kiri ke kanan
 * sejauh [fraction] (per baris tampilan bila teks turun beberapa baris).
 */
@Composable
private fun KaraokeText(
    text: String,
    fraction: Float,
    dim: Color,
    bright: Color,
    style: TextStyle,
) {
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    Box {
        androidx.compose.material3.Text(
            text = text,
            style = style,
            fontWeight = FontWeight.Bold,
            color = dim,
            onTextLayout = { layout = it },
        )
        if (fraction > 0.001f) {
            androidx.compose.material3.Text(
                text = text,
                style = style,
                fontWeight = FontWeight.Bold,
                color = bright,
                modifier = Modifier.drawWithContent {
                    val l = layout
                    if (l == null) {
                        drawContent()
                    } else {
                        val path = Path()
                        var total = 0f
                        for (n in 0 until l.lineCount) total += l.getLineRight(n) - l.getLineLeft(n)
                        var remain = total * fraction
                        for (n in 0 until l.lineCount) {
                            val w = l.getLineRight(n) - l.getLineLeft(n)
                            val take = if (remain < w) remain else w
                            if (take > 0f) {
                                path.addRect(
                                    Rect(
                                        l.getLineLeft(n),
                                        l.getLineTop(n),
                                        l.getLineLeft(n) + take,
                                        l.getLineBottom(n),
                                    ),
                                )
                            }
                            remain -= take
                            if (remain <= 0f) break
                        }
                        clipPath(path) { this@drawWithContent.drawContent() }
                    }
                },
            )
        }
    }
}

/** Pilihan bahasa terjemahan lirik. */
@Composable
private fun LyricsTranslateDialog(current: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Terjemahkan lirik") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Lirik asli tetap tampil; terjemahannya muncul di bawah tiap baris. " +
                        "Penerjemah jalan di HP; model bahasa (± 30 MB) diunduh sekali saat pertama dipakai.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                LyricsLangRow("Mati", current.isEmpty()) { onPick("") }
                for (l in Languages.ALL) {
                    LyricsLangRow(l.name, current == l.code) { onPick(l.code) }
                }
            }
        },
    )
}

@Composable
private fun LyricsLangRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .bounceClickable(onClick = onClick)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null, modifier = Modifier.padding(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
