package app.mixbase.ui

import android.os.SystemClock
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.interaction.DragInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.mixbase.data.Languages
import app.mixbase.data.LyricLine
import app.mixbase.data.LyricsData
import app.mixbase.player.PlayerConnection
import kotlin.math.abs
import kotlinx.coroutines.flow.first
import androidx.compose.material3.Text as RawText

/** Indeks baris lirik yang sedang dinyanyikan pada posisi [posMs]; -1 bila belum mulai. */
fun currentLyricIndex(lines: List<LyricLine>, posMs: Long): Int {
    var lo = 0
    var hi = lines.size - 1
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= posMs + 250L) {
            ans = mid
            lo = mid + 1
        } else {
            hi = mid - 1
        }
    }
    return ans
}

/** Lirik milik lagu yang sedang diputar (null bila belum ada / milik lagu sebelumnya). */
@Composable
private fun lyricsOf(vm: AppViewModel, player: PlayerConnection): LyricsData? {
    val url = player.current?.url ?: return null
    return if (vm.lyricsFor == url) vm.lyrics else null
}

private const val MODE_LOADING = 0
private const val MODE_NONE = 1
private const val MODE_INSTRUMENTAL = 2
private const val MODE_SYNCED = 3
private const val MODE_PLAIN = 4

/** Keadaan tampilan lirik; perubahan antar-keadaan dianimasikan lewat AnimatedContent. */
private data class LyricsView(val mode: Int, val lyr: LyricsData?)

/** Titik awal baris lirik: kiri-tengah, supaya baris aktif membesar ke kanan. */
private val LineOrigin = TransformOrigin(0f, 0.5f)

/** Titik tumbuh tombol terjemah di sudut kanan atas. */
private val OriginEnd = TransformOrigin(1f, 0.5f)

/**
 * Lirik layar penuh. Baris yang sedang dinyanyikan membesar, terisi warna dari kiri ke kanan
 * mengikuti waktu, dan digulir otomatis ke posisi nyaman; baris lain mengecil, memudar dan
 * memburam menurut jaraknya. Ketuk baris untuk melompat ke bagian itu.
 */
@Composable
fun LyricsScreen(vm: AppViewModel, player: PlayerConnection, pos: State<Long>, onClose: () -> Unit) {
    val track = player.current ?: return
    val url = track.url
    val lyr = lyricsOf(vm, player)
    val loading = vm.lyricsFor != url || vm.lyricsLoading

    BackHandler(onBack = onClose)

    var showTranslate by remember { mutableStateOf(false) }
    LaunchedEffect(url, lyr) { vm.ensureLyricsTranslation() }

    val view = when {
        lyr == null && loading -> LyricsView(MODE_LOADING, null)
        lyr == null -> LyricsView(MODE_NONE, null)
        lyr.instrumental -> LyricsView(MODE_INSTRUMENTAL, lyr)
        lyr.synced.isNotEmpty() -> LyricsView(MODE_SYNCED, lyr)
        else -> LyricsView(MODE_PLAIN, lyr)
    }
    // Terjemahan dibaca langsung dari vm, supaya datangnya terjemahan tidak mengulang animasi daftar.
    val translated: () -> List<String> = { if (vm.lyricsTrFor == url) vm.lyricsTr else emptyList() }

    val onSurface = MaterialTheme.colorScheme.onSurface
    val muted = MaterialTheme.colorScheme.onSurfaceVariant

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Box(Modifier.fillMaxSize()) {
            CoverBackdrop(track.thumb, Modifier.fillMaxSize(), veil = 0.35f)

            Column(
                Modifier
                    .fillMaxSize()
                    .systemBarsPadding(),
            ) {
                // ---- Atas: tutup, judul, tombol terjemah ----
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    GlassButton(onClick = onClose) {
                        Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Tutup", tint = onSurface)
                    }
                    Column(
                        Modifier
                            .weight(1f)
                            .padding(horizontal = 12.dp),
                    ) {
                        Text(
                            text = track.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            text = track.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = muted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    PopVisibility(
                        visible = lyr != null && !lyr.instrumental,
                        origin = OriginEnd,
                        from = 0.6f,
                    ) {
                        Text(
                            text = if (vm.lyricsTrLang.isEmpty()) {
                                "Terjemahkan lirik"
                            } else {
                                Languages.byCode(vm.lyricsTrLang)?.name ?: vm.lyricsTrLang
                            },
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            modifier = Modifier
                                .pressScale(0.94f)
                                .clip(RoundedCornerShape(50))
                                .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.62f))
                                .clickable { showTranslate = true }
                                .padding(horizontal = 14.dp, vertical = 9.dp),
                        )
                    }
                }

                // ---- Status terjemahan ----
                val busy = vm.lyricsTrBusy
                val note = vm.lyricsTrNote
                val message = rememberLastNonNull(if (busy) "Menerjemahkan…" else note)
                AnimatedVisibility(
                    visible = busy || note != null,
                    enter = fadeIn(tween(200)) + expandVertically(tween(260)),
                    exit = fadeOut(tween(160)) + shrinkVertically(tween(220)),
                ) {
                    Text(
                        text = message ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = muted,
                        modifier = Modifier.padding(horizontal = 28.dp, vertical = 4.dp),
                    )
                }

                // ---- Isi lirik ----
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .fadeVerticalEdges(),
                ) {
                    AnimatedContent(
                        targetState = view,
                        modifier = Modifier.fillMaxSize(),
                        transitionSpec = { popTransform(from = 0.96f) },
                        label = "lyricsMode",
                    ) { v ->
                        when (v.mode) {
                            MODE_LOADING -> CenterMessage {
                                PlayLoader(diameter = 44.dp)
                                Spacer(Modifier.height(16.dp))
                                Text("Mencari lirik…", color = muted)
                            }

                            MODE_NONE -> CenterMessage {
                                Text(
                                    text = "Lirik tidak ditemukan untuk lagu ini.",
                                    color = muted,
                                    textAlign = TextAlign.Center,
                                )
                            }

                            MODE_INSTRUMENTAL -> CenterMessage {
                                Text(
                                    text = "Lagu instrumental.",
                                    style = MaterialTheme.typography.titleLarge,
                                    textAlign = TextAlign.Center,
                                )
                            }

                            MODE_SYNCED -> SyncedLyrics(
                                lines = v.lyr?.synced ?: emptyList(),
                                translated = translated,
                                pos = pos,
                                onSeek = { ms ->
                                    player.seekTo(ms)
                                    player.tick()
                                },
                            )

                            else -> PlainLyrics(text = v.lyr?.plain ?: "", translated = translated)
                        }
                    }
                }

                // ---- Bawah: seek bar dan kontrol (tanpa volume) ----
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp)
                        .padding(bottom = 12.dp),
                ) {
                    PlayerSeek(player, pos)
                    TransportControls(player, withModes = false, playSize = 64.dp)
                }
            }
        }
    }

    LyricsTranslateDialog(
        visible = showTranslate,
        current = vm.lyricsTrLang,
        onPick = {
            showTranslate = false
            vm.translateLyrics(it)
        },
        onDismiss = { showTranslate = false },
    )
}

/** Memudarkan tepi atas dan bawah area lirik, supaya baris tampak masuk dan keluar dengan halus. */
private fun Modifier.fadeVerticalEdges(): Modifier =
    this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            drawRect(
                brush = Brush.verticalGradient(
                    0f to Color.Transparent,
                    0.07f to Color.Black,
                    0.93f to Color.Black,
                    1f to Color.Transparent,
                ),
                blendMode = BlendMode.DstIn,
            )
        }

@Composable
private fun CenterMessage(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) { content() }
}

// =====================================================================
// Lirik bertanda waktu
// =====================================================================

@Composable
private fun SyncedLyrics(
    lines: List<LyricLine>,
    translated: () -> List<String>,
    pos: State<Long>,
    onSeek: (Long) -> Unit,
) {
    val listState = rememberLazyListState()
    val idxState = remember(lines) { derivedStateOf { currentLyricIndex(lines, pos.value) } }
    val idx = idxState.value
    val tr = translated()

    // Bila pengguna sedang menggeser daftar sendiri, jangan rebut kendali dengan gulir otomatis.
    var dragging by remember { mutableStateOf(false) }
    var lastUserMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(listState) {
        listState.interactionSource.interactions.collect { i ->
            when (i) {
                is DragInteraction.Start -> {
                    dragging = true
                    lastUserMs = SystemClock.uptimeMillis()
                }

                is DragInteraction.Stop, is DragInteraction.Cancel -> {
                    dragging = false
                    lastUserMs = SystemClock.uptimeMillis()
                }

                else -> {}
            }
        }
    }

    val firstScroll = remember { booleanArrayOf(true) }
    LaunchedEffect(idx) {
        if (idx < 0) return@LaunchedEffect
        val viewport = snapshotFlow { listState.layoutInfo.viewportSize.height }.first { it > 0 }
        val target = viewport * ANCHOR
        val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == idx + 1 }
        when {
            firstScroll[0] -> {
                firstScroll[0] = false
                listState.scrollToItem(idx + 1, -target.toInt())
            }

            dragging || SystemClock.uptimeMillis() - lastUserMs < 2500L -> Unit

            item != null -> listState.animateScrollBy(
                value = item.offset - target,
                animationSpec = tween(520, easing = FastOutSlowInEasing),
            )

            else -> listState.animateScrollToItem(idx + 1, -target.toInt())
        }
    }

    LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
        item(key = "top") { Spacer(Modifier.fillParentMaxHeight(ANCHOR)) }
        itemsIndexed(lines, key = { i, _ -> i }) { i, line ->
            val next = lines.getOrNull(i + 1)?.timeMs
            LyricItem(
                line = line,
                durationMs = sungDuration(line, next),
                index = i,
                activeIdx = idx,
                translation = tr.getOrNull(i),
                pos = pos,
                onClick = { onSeek(line.timeMs) },
            )
        }
        item(key = "bottom") { Spacer(Modifier.fillParentMaxHeight(1f - ANCHOR)) }
    }
}

/** Posisi (sebagai pecahan tinggi daftar) tempat baris aktif ditahan. */
private const val ANCHOR = 0.3f

/** Perkiraan lama sebuah baris dinyanyikan: sampai baris berikutnya, tapi tidak lebih dari panjang teksnya. */
private fun sungDuration(line: LyricLine, nextMs: Long?): Long {
    val estimate = (line.text.length * 85L).coerceAtLeast(1500L)
    val gap = if (nextMs != null) (nextMs - line.timeMs).coerceAtLeast(500L) else estimate
    return minOf(gap, estimate)
}

@Composable
private fun LyricItem(
    line: LyricLine,
    durationMs: Long,
    index: Int,
    activeIdx: Int,
    translation: String?,
    pos: State<Long>,
    onClick: () -> Unit,
) {
    val active = index == activeIdx
    val distance = abs(index - activeIdx)

    val lineAlpha by animateFloatAsState(
        targetValue = when {
            active -> 1f
            distance == 1 -> 0.9f
            distance == 2 -> 0.75f
            else -> 0.6f
        },
        animationSpec = tween(350),
        label = "lyricAlpha",
    )
    val lineScale by animateFloatAsState(
        targetValue = if (active) 1f else 0.88f,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow),
        label = "lyricScale",
    )
    val lineBlur by animateFloatAsState(
        targetValue = if (active) 0f else (distance * 1.4f).coerceAtMost(4f),
        animationSpec = tween(350),
        label = "lyricBlur",
    )
    // Lapisan "sudah dinyanyikan" muncul saat baris aktif dan memudar saat baris berlalu.
    val sungAlpha by animateFloatAsState(
        targetValue = if (active) 1f else 0f,
        animationSpec = tween(320),
        label = "lyricSung",
    )

    val onSurface = MaterialTheme.colorScheme.onSurface
    val style = MaterialTheme.typography.headlineMedium.copy(
        fontWeight = FontWeight.ExtraBold,
        lineHeight = 36.sp,
    )
    val shown = line.text.ifBlank { "♪" }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }

    val blurMod = if (lineBlur > 0.2f) {
        Modifier.blur(lineBlur.dp, BlurredEdgeTreatment.Unbounded)
    } else {
        Modifier
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .pressScale(0.97f)
            .scrimClickable(onClick)
            .padding(horizontal = 24.dp, vertical = 10.dp)
            .graphicsLayer {
                scaleX = lineScale
                scaleY = lineScale
                alpha = lineAlpha
                transformOrigin = LineOrigin
            }
            .then(blurMod),
    ) {
        Box {
            // Lapisan dasar: teks redup (belum dinyanyikan).
            RawText(
                text = shown,
                style = style,
                color = onSurface.copy(alpha = 0.42f),
                onTextLayout = { layout = it },
            )
            // Lapisan terang: terbuka dari kiri ke kanan mengikuti waktu.
            if (sungAlpha > 0.01f) {
                RawText(
                    text = shown,
                    style = style,
                    color = onSurface,
                    modifier = Modifier
                        .graphicsLayer {
                            compositingStrategy = CompositingStrategy.Offscreen
                            alpha = sungAlpha
                        }
                        .drawWithContent {
                            drawContent()
                            val lay = layout
                            if (lay != null) {
                                val fraction = when {
                                    index < activeIdx -> 1f
                                    index > activeIdx -> 0f
                                    else -> ((pos.value - line.timeMs).toFloat() / durationMs.toFloat())
                                        .coerceIn(0f, 1f)
                                }
                                if (fraction < 1f) hideUnsung(lay, fraction)
                            }
                        },
                )
            }
        }
        if (!translation.isNullOrBlank() && translation != line.text) {
            RawText(
                text = translation,
                style = MaterialTheme.typography.titleMedium,
                color = onSurface.copy(alpha = 0.72f),
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

/**
 * Menutupi bagian teks yang belum dinyanyikan. [fraction] (0..1) adalah kemajuan seluruh baris;
 * baris yang terbungkus ke beberapa baris tampilan terisi satu per satu, dari atas ke bawah.
 * Tepi isian dibuat lembut dengan gradasi.
 */
private fun DrawScope.hideUnsung(lay: TextLayoutResult, fraction: Float) {
    val feather = 28.dp.toPx()
    var total = 0f
    for (l in 0 until lay.lineCount) total += lay.getLineRight(l) - lay.getLineLeft(l)
    var remaining = fraction * total
    for (l in 0 until lay.lineCount) {
        val left = lay.getLineLeft(l)
        val right = lay.getLineRight(l)
        val w = (right - left).coerceAtLeast(1f)
        val f = (remaining / w).coerceIn(0f, 1f)
        remaining -= w
        val edge = left + (w + feather) * f
        val startX = edge - feather
        val top = lay.getLineTop(l)
        val bottom = lay.getLineBottom(l)
        drawRect(
            brush = Brush.horizontalGradient(
                0f to Color.Transparent,
                1f to Color.Black,
                startX = startX,
                endX = edge,
            ),
            topLeft = Offset(startX, top),
            size = Size((size.width - startX).coerceAtLeast(0f), bottom - top),
            blendMode = BlendMode.DstOut,
        )
    }
}

// =====================================================================
// Lirik tanpa waktu
// =====================================================================

@Composable
private fun PlainLyrics(text: String, translated: () -> List<String>) {
    val tr = translated()
    val onSurface = MaterialTheme.colorScheme.onSurface
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 28.dp, vertical = 24.dp),
    ) {
        for ((i, line) in text.lines().withIndex()) {
            if (line.isBlank()) {
                Spacer(Modifier.height(14.dp))
                continue
            }
            RawText(
                text = line,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = onSurface,
            )
            val t = tr.getOrNull(i)
            if (!t.isNullOrBlank() && t != line) {
                RawText(
                    text = t,
                    style = MaterialTheme.typography.bodyLarge,
                    color = onSurface.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 2.dp, bottom = 6.dp),
                )
            }
        }
        Spacer(Modifier.height(48.dp))
    }
}

// =====================================================================
// Dialog bahasa terjemahan
// =====================================================================

/** Pilihan bahasa terjemahan lirik. */
@Composable
private fun LyricsTranslateDialog(
    visible: Boolean,
    current: String,
    onPick: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    PopAlertDialog(
        visible = visible,
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tutup") } },
        title = { Text("Terjemahkan lirik") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    text = "Lirik asli tetap tampil; terjemahannya muncul di bawah tiap baris. " +
                        "Penerjemah jalan di HP; model bahasa (± 30 MB) diunduh sekali saat pertama dipakai.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 8.dp),
                )
                LyricsLangRow("Mati", current.isEmpty()) { onPick("") }
                for (l in Languages.ALL) {
                    LyricsLangRow(l.name, current == l.code) { onPick(l.code) }
                }
            }
        },
    )
}

@Composable
private fun LyricsLangRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = null, modifier = Modifier.padding(12.dp))
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}
