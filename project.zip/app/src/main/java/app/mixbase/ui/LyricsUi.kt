package app.mixbase.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.mixbase.R
import app.mixbase.data.LyricLine
import app.mixbase.data.LyricsData
import app.mixbase.player.PlayerConnection

/** Indeks baris lirik yang sedang dinyanyikan pada posisi [posMs]; -1 bila belum mulai. */
fun currentLyricIndex(lines: List<LyricLine>, posMs: Long): Int {
    var lo = 0
    var hi = lines.size - 1
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= posMs + 250L) {
            ans = mid
            lo = mid + 1
        } else {
            hi = mid - 1
        }
    }
    return ans
}

/** Lirik milik lagu yang sedang diputar (null bila belum ada / milik lagu sebelumnya). */
@Composable
private fun lyricsOf(vm: AppViewModel, player: PlayerConnection): LyricsData? {
    val url = player.current?.url ?: return null
    return if (vm.lyricsFor == url) vm.lyrics else null
}

/** Kartu lirik kecil di layar Now Playing: pratinjau baris yang sedang dinyanyikan. */
@Composable
fun LyricsCard(vm: AppViewModel, player: PlayerConnection, onOpen: () -> Unit) {
    val track = player.current ?: return
    val lyr = lyricsOf(vm, player)
    val loading = vm.lyricsFor != track.url || vm.lyricsLoading

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primaryContainer)
            .clickable(enabled = lyr != null, onClick = onOpen)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                painter = painterResource(R.drawable.ic_lyrics),
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(20.dp),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = "Lirik",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.weight(1f),
            )
            if (loading && lyr == null) {
                PlayLoader(
                    diameter = 24.dp,
                    containerColor = androidx.compose.ui.graphics.Color.Transparent,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            } else if (lyr != null) {
                Text(
                    text = "Buka layar penuh",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                )
            }
        }

        val onColor = MaterialTheme.colorScheme.onPrimaryContainer
        when {
            lyr == null && loading -> {
                Text(
                    text = "Mencari lirik…",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr == null -> {
                Text(
                    text = "Lirik tidak ditemukan untuk lagu ini.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr.instrumental -> {
                Text(
                    text = "Lagu instrumental.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }

            lyr.synced.isNotEmpty() -> {
                val idx = currentLyricIndex(lyr.synced, player.positionMs)
                val now = if (idx >= 0) lyr.synced[idx].text else "♪"
                val next = if (idx + 1 < lyr.synced.size) lyr.synced[idx + 1].text else ""
                Text(
                    text = now.ifBlank { "♪" },
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = onColor,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 10.dp),
                )
                if (next.isNotBlank()) {
                    Text(
                        text = next,
                        style = MaterialTheme.typography.bodyLarge,
                        color = onColor.copy(alpha = 0.65f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }

            else -> {
                Text(
                    text = lyr.plain,
                    style = MaterialTheme.typography.bodyMedium,
                    color = onColor,
                    maxLines = 4,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 8.dp),
                )
            }
        }
    }
}

/** Lirik layar penuh: baris aktif disorot dan digulir otomatis; ketuk baris untuk melompat. */
@Composable
fun LyricsScreen(vm: AppViewModel, player: PlayerConnection, onClose: () -> Unit) {
    val track = player.current ?: return
    val lyr = lyricsOf(vm, player)
    val listState = rememberLazyListState()

    BackHandler(onBack = onClose)

    val synced: List<LyricLine> = lyr?.synced ?: emptyList()
    val idx = currentLyricIndex(synced, player.positionMs)

    LaunchedEffect(idx) {
        if (idx >= 0) listState.animateScrollToItem((idx - 2).coerceAtLeast(0))
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .systemBarsPadding(),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) {
                    Icon(
                        Icons.Filled.KeyboardArrowDown,
                        contentDescription = "Tutup",
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = track.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            }

            when {
                lyr == null -> {
                    Text(
                        text = "Lirik tidak tersedia.",
                        modifier = Modifier.padding(24.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                }

                synced.isNotEmpty() -> {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(vertical = 96.dp),
                    ) {
                        itemsIndexed(synced) { i, line ->
                            val active = i == idx
                            val color by animateColorAsState(
                                targetValue = if (active) {
                                    MaterialTheme.colorScheme.onPrimaryContainer
                                } else {
                                    MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.45f)
                                },
                                label = "lyric",
                            )
                            Text(
                                text = line.text.ifBlank { "♪" },
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = if (active) FontWeight.ExtraBold else FontWeight.Bold,
                                color = color,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { player.seekTo(line.timeMs) }
                                    .padding(horizontal = 24.dp, vertical = 10.dp),
                            )
                        }
                    }
                }

                else -> {
                    Text(
                        text = if (lyr.instrumental) "Lagu instrumental." else lyr.plain,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(24.dp),
                    )
                }
            }
        }
    }
}
