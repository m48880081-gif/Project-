package app.mixbase.ui

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** Chip pil ala Spotify: abu-abu datar saat mati, hijau penuh saat aktif, tanpa garis tepi. */
@Composable
fun PillChip(
    selected: Boolean,
    onClick: () -> Unit,
    label: @Composable () -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = MaterialTheme.colorScheme
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = label,
        modifier = modifier,
        shape = CircleShape,
        border = null,
        colors = FilterChipDefaults.filterChipColors(
            containerColor = c.surfaceContainerHigh,
            labelColor = c.onSurface,
            selectedContainerColor = c.primary,
            selectedLabelColor = c.onPrimary,
        ),
    )
}
