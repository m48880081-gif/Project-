# Tidak dipakai selama isMinifyEnabled = false.
# Aturan di bawah dari dokumentasi NewPipeExtractor, siap kalau R8 dinyalakan nanti.
-keep class org.mozilla.javascript.** { *; }
-keep class org.mozilla.classfile.ClassFileWriter
-dontwarn org.mozilla.javascript.tools.**
-dontwarn javax.script.**
-dontwarn java.beans.**
