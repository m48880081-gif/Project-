import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "app.mixbase"
    compileSdk = 35

    defaultConfig {
        applicationId = "app.mixbase"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "0.3.1"
    }

    // Keystore tetap supaya update APK bisa menimpa versi lama tanpa uninstall.
    // Ini kunci pribadi untuk build sendiri, BUKAN untuk Play Store.
    signingConfigs {
        create("fixed") {
            storeFile = rootProject.file("keystore/mixbase.jks")
            storePassword = "mixbase123"
            keyAlias = "mixbase"
            keyPassword = "mixbase123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            // R8 dimatikan: lebih aman (Rhino/NewPipeExtractor sensitif terhadap shrinking).
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("fixed")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        // NewPipeExtractor butuh API Java 11+ (java.time, dst) di minSdk < 33.
        isCoreLibraryDesugaringEnabled = true
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "META-INF/DEPENDENCIES",
                "META-INF/LICENSE*",
                "META-INF/NOTICE*",
                "META-INF/INDEX.LIST",
            )
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs_nio:2.1.5")

    // Mesin yang sama dengan URMIX. Sengaja v0.26.5, bukan v0.27.x: v0.27 membuang klien ANDROID,
    // sehingga video "dibuat untuk anak-anak" ditolak YouTube (UNPLAYABLE). v0.26.x masih memilikinya.
    implementation("com.github.TeamNewPipe:NewPipeExtractor:v0.26.5")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")

    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")

    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.media3:media3-session:1.5.1")
    implementation("androidx.media3:media3-datasource:1.5.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.5.1")
    implementation("androidx.media3:media3-exoplayer-dash:1.5.1")
    implementation("com.google.guava:guava:33.3.1-android")

    implementation("io.coil-kt:coil-compose:2.7.0")
}
